#!/usr/bin/env bash
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Chưa cài Node.js (bản 22 trở lên): https://nodejs.org"; exit 1; }
[ -d node_modules ] || { echo "Đang cài thư viện lần đầu..."; npm install --ignore-scripts || exit 1; }
[ -f .next/BUILD_ID ] || { echo "Đang build lần đầu (1–2 phút)..."; npm run build || exit 1; }
echo "Góc Cafe chạy tại http://localhost:3100  (Ctrl+C để tắt)"
( sleep 3; (xdg-open http://localhost:3100 || open http://localhost:3100) >/dev/null 2>&1 ) &
npm start -- -p 3100

#!/usr/bin/env bash
# Cài trên mini-PC Ubuntu/Debian trong quán: Docker + app + HTTPS nội bộ (Caddy tls internal).
# Dùng:  sudo bash deploy/install-minipc.sh 192.168.1.50      (IP LAN cố định của mini-PC)
set -euo pipefail
IP="${1:?Nhập IP LAN của mini-PC, ví dụ 192.168.1.50}"
command -v docker >/dev/null || curl -fsSL https://get.docker.com | sh
cat > Caddyfile <<C
cafe.local, ${IP} {
	tls internal
	encode gzip
	reverse_proxy app:3000
}
C
docker compose up -d --build
echo "Xong. Mở https://${IP} trên điện thoại/máy tính trong cùng Wi-Fi."
echo "Cần cài chứng chỉ gốc của Caddy lên từng thiết bị để hết cảnh báo:"
echo "  docker compose cp caddy:/data/caddy/pki/authorities/local/root.crt ./caddy-root.crt"
echo "  (xem DEPLOY.md mục 'Cài chứng chỉ lên điện thoại')"

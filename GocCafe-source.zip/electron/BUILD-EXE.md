# Tạo file cài đặt .exe (chạy trên máy Windows)

**Chạy ở đâu:** trên máy tính Windows của bạn, trong thư mục dự án (thư mục có file `package.json` và `start.bat` — chính là thư mục bạn vừa giải nén `GocCafe-source.zip`).

1. Cài Node.js bản LTS (22 trở lên): https://nodejs.org
2. Mở thư mục dự án trong File Explorer → bấm vào thanh địa chỉ, gõ `cmd` rồi Enter (mở cửa sổ dòng lệnh ngay tại thư mục đó).
3. Gõ:
   ```
   node electron/build-exe.mjs
   ```
   Chờ vài phút (cần Internet, tải Electron khoảng 100 MB).
4. Lấy file `GocCafe-Setup-1.0.0.exe` trong thư mục `stage\dist`. Nhấp đúp để cài; có biểu tượng trên Desktop/Start Menu và mục gỡ cài đặt.

Muốn bản chạy thẳng không cần cài: `node electron/build-exe.mjs portable`.
Dữ liệu của app nằm ở `%APPDATA%\Góc Cafe\data` (gỡ cài đặt không xóa dữ liệu).

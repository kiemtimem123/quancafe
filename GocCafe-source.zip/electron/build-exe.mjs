// Dùng:  node electron/build-exe.mjs [nsis|portable]   (mặc định nsis = bộ cài Setup.exe; chạy trên Windows)
import { cpSync, rmSync, mkdirSync, writeFileSync, readFileSync, existsSync } from 'node:fs';
import { execSync } from 'node:child_process';
import path from 'node:path';
const target = process.argv[2] || 'nsis';
const root = path.resolve(import.meta.dirname, '..');
const stage = path.join(root, 'stage');
const sh = (c, cwd = root) => { console.log('>', c); execSync(c, { cwd, stdio: 'inherit' }); };

if (!existsSync(path.join(root, 'node_modules'))) sh('npm install --ignore-scripts');
sh('npm run build');
rmSync(stage, { recursive: true, force: true });
mkdirSync(path.join(stage, 'build'), { recursive: true });
for (const d of ['.next', 'public', 'electron']) cpSync(path.join(root, d), path.join(stage, d), { recursive: true });
rmSync(path.join(stage, '.next', 'cache'), { recursive: true, force: true });
cpSync(path.join(root, 'next.config.mjs'), path.join(stage, 'next.config.mjs'));
cpSync(path.join(root, 'public/icons/icon-512.png'), path.join(stage, 'build/icon.png'));
cpSync(path.join(root, 'electron/package.app.json'), path.join(stage, 'package.json'));
let yml = readFileSync(path.join(root, 'electron/electron-builder.yml'), 'utf8').replace(/target: \[\{ target: \w+/, `target: [{ target: ${target}`);
writeFileSync(path.join(stage, 'electron-builder.yml'), yml);
sh('npm install --omit=dev --os=win32 --cpu=x64 --ignore-scripts', stage);
sh('npx --yes electron-builder@25 --win --x64 --config electron-builder.yml', stage);
console.log('\nXong! File nằm trong thư mục stage/dist');

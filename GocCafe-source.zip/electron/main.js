// Vỏ Electron: chạy máy chủ Next.js ngay trong ứng dụng và mở cửa sổ. Dữ liệu lưu ở %APPDATA%\Góc Cafe\data.
const { app, BrowserWindow, Menu, shell, dialog } = require('electron');
const path = require('path');
const http = require('http');

if (!app.requestSingleInstanceLock()) { app.quit(); }
let win;
const appDir = path.join(__dirname, '..');
process.env.DATA_DIR = path.join(app.getPath('userData'), 'data');
process.env.NODE_ENV = 'production';

async function startServer() {
  process.chdir(appDir);
  const next = require('next');
  const server = next({ dev: false, dir: appDir });
  await server.prepare();
  const handle = server.getRequestHandler();
  const srv = http.createServer((req, res) => handle(req, res));
  // Cổng cố định để dữ liệu offline (IndexedDB/Service Worker) giữ nguyên giữa các lần mở; nếu bận thì lấy cổng tự do.
  const listen = (p) => new Promise((resolve, reject) => { srv.once('error', reject); srv.listen(p, '127.0.0.1', () => resolve(srv.address().port)); });
  return listen(47831).catch(() => listen(0));
}

async function createWindow() {
  Menu.setApplicationMenu(null);
  win = new BrowserWindow({ width: 1366, height: 860, minWidth: 380, minHeight: 600, title: 'Góc Cafe', backgroundColor: '#f5eee1', autoHideMenuBar: true, icon: path.join(appDir, 'public', 'icons', 'icon-512.png') });
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:\/\/(127\.0\.0\.1|localhost)/.test(url)) return { action: 'allow' }; shell.openExternal(url); return { action: 'deny' }; });
  try {
    const port = await startServer();
    await win.loadURL(`http://127.0.0.1:${port}/`);
  } catch (e) {
    dialog.showErrorBox('Góc Cafe không khởi động được', String(e && e.stack || e));
    app.quit();
  }
}
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());

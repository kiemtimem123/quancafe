const { loadRecipes } = require('../lib/recipes');
for (const r of loadRecipes()) { const m = r.sizes.find((s:any)=>s.name==='M'); console.log(r.name.padEnd(24), String(Math.round(m.cost)).padStart(6), String(m.selling_price).padStart(6), Math.round(m.margin)+'%', r.sizes.map((s:any)=>Math.round(s.cost)).join('/')); }

const { localAssistant } = require('../lib/assistant');
for (const q of ['Tôi có cà phê, sữa đặc, sữa tươi, caramel và đá. Hãy gợi ý 5 món dễ bán.','Tôi có 500ml sữa tươi và 100g matcha, hãy tạo công thức sử dụng hết nguyên liệu']) {
 const r = localAssistant(q); console.log(r.detected, r.reply); for (const s of r.suggestions) console.log(' -', s.name, Math.round(s.percent), s.missing, s.max_cups ?? '', s.note ?? '');
}

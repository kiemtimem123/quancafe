import fs from 'fs';
import path from 'path';
const dir = path.join(process.cwd(), 'data');
for (const f of fs.existsSync(dir) ? fs.readdirSync(dir) : []) if (f.startsWith('cafe.db')) fs.unlinkSync(path.join(dir, f));
// eslint-disable-next-line @typescript-eslint/no-require-imports
const { getDb } = require('../lib/db');
const db = getDb();
console.log('Đã nạp dữ liệu mẫu:', db.prepare('SELECT COUNT(*) c FROM recipes').get(), db.prepare('SELECT COUNT(*) c FROM ingredients').get());

# Triển khai thật (có HTTPS)

**Vì sao cần HTTPS?** Trình duyệt chỉ cho phép *Service Worker* (chạy offline), *cài app lên màn hình* và lưu dữ liệu offline khi trang chạy qua **HTTPS** (hoặc `localhost`). Mở bằng `http://192.168.x.x` trên điện thoại sẽ **không** dùng được offline. Chọn một trong hai cách:

## Cách A — Mini-PC đặt trong quán (không cần Internet để bán hàng)
1. Cài Ubuntu Server/Debian trên mini-PC, đặt IP LAN cố định (ví dụ `192.168.1.50`) trong router.
2. Chép thư mục dự án lên mini-PC, chạy: `sudo bash deploy/install-minipc.sh 192.168.1.50`
3. Mở `https://192.168.1.50` từ điện thoại cùng Wi-Fi. Lần đầu sẽ báo chứng chỉ chưa tin cậy — **cài chứng chỉ gốc** (bên dưới) để hết cảnh báo và để offline hoạt động.
4. Tạo tài khoản chủ quán ở lần mở đầu tiên.

### Cài chứng chỉ lên điện thoại
- Lấy file: `docker compose cp caddy:/data/caddy/pki/authorities/local/root.crt ./caddy-root.crt` rồi gửi sang điện thoại (Zalo/USB).
- **Android:** Cài đặt → Bảo mật → Mã hóa & thông tin xác thực → Cài chứng chỉ → Chứng chỉ CA.
- **iPhone:** mở file → Cài đặt → Đã tải về hồ sơ → Cài đặt; rồi Cài đặt → Cài đặt chung → Giới thiệu → Cài đặt tin cậy chứng chỉ → bật tin cậy.
- **Windows/Mac:** nhấp đúp file, thêm vào kho “Trusted Root Certification Authorities”.

## Cách B — VPS + tên miền (truy cập từ mọi nơi)
1. Thuê VPS Ubuntu (1 vCPU / 1 GB là đủ), trỏ bản ghi DNS `A` của tên miền về IP VPS.
2. Cài Docker: `curl -fsSL https://get.docker.com | sh`
3. Sửa `Caddyfile` (đổi `cafe.example.com` thành tên miền của bạn) — Caddy tự xin chứng chỉ Let’s Encrypt.
4. `docker compose up -d --build` → mở `https://tên-miền-của-bạn`.

## Không dùng Docker
```bash
npm ci --ignore-scripts && npm run build
COOKIE_SECURE=1 PORT=3000 npm start      # đặt sau Caddy/Nginx để có HTTPS
```
Chạy nền bằng `systemd` hoặc `pm2 start npm -- start`.

## Dữ liệu & sao lưu
- Toàn bộ dữ liệu nằm trong thư mục `data/` (`cafe.db`, `uploads/`, `backups/`). **Sao chép thư mục này ra ổ khác/Drive hằng tuần.**
- App tự sao lưu mỗi ngày (giữ 14 bản) ở `data/backups/`; trang **Sao lưu & khôi phục** cho tải về/khôi phục. Có thể tự gửi bản sao lưu qua Telegram/email ở trang **Thông báo**.
- Biến môi trường: `DB_PATH` (đường dẫn CSDL), `BACKUP_DIR`, `COOKIE_SECURE=1` (bắt buộc khi chạy HTTPS).

## Sau khi cài
- Mở app một lần khi có mạng → bấm **Cài ứng dụng lên màn hình** (menu tài khoản) để dùng như app và offline.
- Đặt tài khoản ngân hàng ở **Bán hàng → Cài đặt cửa hàng** để in mã VietQR có sẵn số tiền & nội dung.

## Cách C — Hosting có Node.js (cPanel “Setup Node.js App”, Plesk, VPS có panel)
Yêu cầu: **Node.js 22 trở lên**, có SSH hoặc Terminal trong cPanel, ≥ 1 GB RAM khi build, tên miền có **SSL (HTTPS)** (bật AutoSSL/Let’s Encrypt trong panel).
1. Giải nén mã nguồn vào thư mục **ngoài** `public_html` (ví dụ `~/goccafe`).
2. cPanel → **Setup Node.js App** → Create Application: Node 22, Application root `goccafe`, Application URL = tên miền, Startup file `server.js`.
3. Trong Terminal (hoặc nút “Run NPM Install”): `npm install --ignore-scripts && npm run build` (nếu hosting build bị ngắt vì thiếu RAM: build trên máy bạn rồi tải thư mục `.next` lên).
4. Thêm biến môi trường: `COOKIE_SECURE=1`. Bấm **Restart**.
5. Mở tên miền, tạo tài khoản chủ quán. Dữ liệu ở thư mục `data/` — tải về định kỳ.
Hosting “chia sẻ” không hỗ trợ Node.js (chỉ PHP/WordPress) thì **không chạy được** app này; khi đó cần VPS (Cách B).

## Cách D — Hostinger hPanel (gói Business hoặc Cloud)
1. **Gói hỗ trợ:** Websites → Add website → *Node.js web app* (chỉ có ở Business Web Hosting và các gói Cloud; gói Single/Premium không có).
2. Nén dự án **không có** `node_modules` và `.git` thành `.zip` (đã có sẵn `GocCafe-source.zip`), chọn *Upload your files*.
3. Cài đặt build: Framework **Next.js**, Node.js **22**, Build command `npm run build`. Nếu hPanel hỏi *Entry file* thì điền `server.js`.
4. **Quan trọng — dữ liệu:** mỗi lần Deploy, Hostinger tạo thư mục build mới và xóa bản cũ, nên thư mục `data/` trong dự án **sẽ mất**. Trước khi Deploy, ở mục *Environment Variables* thêm:
   - `DATA_DIR` = `/home/<tên-tài-khoản>/goccafe-data`  (thư mục nằm ngoài thư mục build; tạo bằng File Manager)
   - `COOKIE_SECURE` = `1`
5. Deploy → bật SSL cho tên miền → mở `https://tên-miền`, tạo tài khoản chủ quán.
6. Mỗi lần cập nhật phiên bản mới chỉ cần Deploy lại; dữ liệu vẫn nằm ở `DATA_DIR`. Tải thư mục đó về máy định kỳ để dự phòng.

## Đặt món qua QR cần gì?
Điện thoại khách phải mở được địa chỉ của quán: dùng tên miền HTTPS (Cách B/C/D) hoặc IP mạng Wi-Fi quán (Cách A, ví dụ http://192.168.1.10:3000). Khi chạy sau proxy, đảm bảo header `x-forwarded-for` được truyền để giới hạn tần suất theo IP đúng.

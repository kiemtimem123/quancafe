@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul || (echo Chua cai Node.js. Tai ban LTS tai https://nodejs.org roi chay lai file nay. & pause & exit /b 1)
if not exist node_modules (echo Dang cai thu vien lan dau, vui long cho... & call npm install --ignore-scripts || (echo Cai thu vien that bai & pause & exit /b 1))
if not exist .next\BUILD_ID (echo Dang build lan dau, khoang 1-2 phut... & call npm run build || (echo Build that bai & pause & exit /b 1))
echo.
echo ===== Goc Cafe dang chay tai http://localhost:3100  (dong cua so nay de tat) =====
start "" http://localhost:3100
call npm start -- -p 3100
pause

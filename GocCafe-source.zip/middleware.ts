import { NextResponse, type NextRequest } from 'next/server';

const PUBLIC_PAGES = ['/login', '/order'];
const PUBLIC_API = ['/api/auth/login', '/api/auth/setup', '/api/auth/reset'];

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const isApi = pathname.startsWith('/api/');

  // Chống CSRF: yêu cầu ghi phải cùng origin
  if (isApi && !['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
    const origin = req.headers.get('origin');
    if (origin && new URL(origin).host !== req.headers.get('host')) {
      return NextResponse.json({ error: 'Yêu cầu bị từ chối (origin không hợp lệ)' }, { status: 403 });
    }
  }
  // Kiểm tra nhanh có cookie; việc xác thực thật nằm ở từng route (đọc DB)
  const has = !!req.cookies.get('session')?.value;
  if (isApi) {
    const open = PUBLIC_API.includes(pathname) || pathname.startsWith('/api/public/') || (req.method === 'GET' && pathname.startsWith('/api/images/'));
    if (!has && !open && pathname !== '/api/auth/me') return NextResponse.json({ error: 'Bạn cần đăng nhập' }, { status: 401 });
  } else if (!has && !PUBLIC_PAGES.includes(pathname)) {
    return NextResponse.redirect(new URL('/login', req.url));
  }
  return NextResponse.next();
}
export const config = { matcher: ['/((?!_next/|favicon.ico|icon.svg|icons/|sw.js|offline.html|manifest.webmanifest|precache.json).*)'] };

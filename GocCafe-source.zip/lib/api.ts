import { NextResponse } from 'next/server';
import { headers } from 'next/headers';
import { getDb } from './db';
import { sweepExpired } from './expiry';
import { ZodError, z } from 'zod';
import { getSessionUser } from './auth';
import { can, type Perm, type SessionUser } from './roles';
import { PURCHASE_UNITS, RECIPE_UNITS, SIZES } from './types';

export class ApiError extends Error {
  constructor(public status: number, message: string, public extra?: unknown) { super(message); }
}
async function run<T>(fn: () => Promise<T> | T) {
  try {
    return NextResponse.json(await fn());
  } catch (e) {
    if (e instanceof ApiError) return NextResponse.json({ error: e.message, ...(e.extra ? { details: e.extra } : {}) }, { status: e.status });
    if (e instanceof ZodError) {
      const msg = e.issues.map((i) => `${i.path.join('.') || 'dữ liệu'}: ${i.message}`).join('; ');
      return NextResponse.json({ error: 'Dữ liệu không hợp lệ — ' + msg }, { status: 400 });
    }
    if (e instanceof SyntaxError) return NextResponse.json({ error: 'Nội dung gửi lên không phải JSON hợp lệ' }, { status: 400 });
    const msg = e instanceof Error ? e.message : String(e);
    if (/UNIQUE constraint/.test(msg)) return NextResponse.json({ error: 'Tên hoặc email đã tồn tại, hãy chọn giá trị khác' }, { status: 409 });
    console.error(e);
    return NextResponse.json({ error: 'Lỗi máy chủ: ' + msg }, { status: 500 });
  }
}

/** Route cần đăng nhập; truyền `perm` để yêu cầu thêm quyền. */
export function handle<T>(fn: (user: SessionUser) => Promise<T> | T, perm?: Perm) {
  return run(async () => {
    const user = await getSessionUser();
    if (!user) throw new ApiError(401, 'Bạn cần đăng nhập');
    if (perm && !can(user.role, perm)) throw new ApiError(403, 'Bạn không có quyền thực hiện thao tác này');
    try { sweepExpired(); } catch (e) { console.error('sweepExpired', e); }
    // Thao tác đồng bộ từ chế độ offline mang khóa riêng: gửi lại nhiều lần vẫn chỉ áp dụng một lần
    const opKey = (await headers()).get('x-op-key');
    if (opKey && /^[\w-]{8,80}$/.test(opKey)) {
      const db = getDb();
      if (db.prepare('SELECT 1 FROM op_keys WHERE key=?').get(opKey)) return { ok: true, duplicate: true } as T;
      const out = await fn(user);
      db.prepare('INSERT OR IGNORE INTO op_keys (key) VALUES (?)').run(opKey);
      db.prepare("DELETE FROM op_keys WHERE created_at < datetime('now','-60 day')").run();
      return out;
    }
    return fn(user);
  });
}
/** Route công khai (đăng nhập, thiết lập lần đầu). */
export const handlePublic = run;

export const parseId = (s: string) => {
  const n = Number(s);
  if (!Number.isInteger(n) || n <= 0) throw new ApiError(400, 'ID không hợp lệ');
  return n;
};

const money = z.coerce.number().min(0, 'Không được âm').max(1e9);
export const ingredientSchema = z.object({
  name: z.string().trim().min(1, 'Nhập tên nguyên liệu').max(80),
  category: z.string().trim().min(1).max(40).default('Khác'),
  unit: z.enum(PURCHASE_UNITS),
  base_unit: z.enum(['g', 'ml', 'cái']),
  pack_size: z.coerce.number().gt(0, 'Quy cách phải lớn hơn 0').max(1e7),
  purchase_price: money,
  stock_quantity: money,
  minimum_stock: money.default(0),
  supplier: z.string().trim().max(80).default(''),
  note: z.string().trim().max(200).default(''),
  group_name: z.string().trim().max(40).default(''),
  track_stock: z.boolean().default(true),
  track_expiry: z.boolean().optional(),
  shelf_life_days: z.coerce.number().int().min(0).max(3650).optional(),
});

export const recipeSchema = z.object({
  name: z.string().trim().min(1, 'Nhập tên món').max(80),
  category: z.string().trim().min(1, 'Chọn danh mục'),
  description: z.string().trim().max(300).default(''),
  image: z.string().trim().max(500).default('').refine((v) => v === '' || /^\/api\/images\/[a-f0-9]{32}\.webp$/.test(v) || /^https?:\/\/\S+$/.test(v), 'Ảnh phải là ảnh đã tải lên hoặc đường dẫn http(s)'),
  difficulty: z.enum(['Dễ', 'Trung bình', 'Khó']).default('Dễ'),
  preparation_time: z.coerce.number().int().min(1, 'Thời gian tối thiểu 1 phút').max(240),
  instructions: z.array(z.string().trim().min(1)).max(30).default([]),
  sizes: z.array(z.object({
    name: z.enum(SIZES),
    selling_price: money,
    lines: z.array(z.object({
      ingredient_id: z.coerce.number().int().positive(),
      quantity: z.coerce.number().gt(0, 'Định lượng phải lớn hơn 0').max(1e6),
      unit: z.enum(RECIPE_UNITS),
      optional: z.boolean().default(false),
    })).min(1, 'Mỗi size cần ít nhất 1 nguyên liệu'),
  })).min(1, 'Cần ít nhất 1 size').refine((s) => new Set(s.map((x) => x.name)).size === s.length, 'Size bị lặp'),
});

export const passwordSchema = z.string().min(8, 'Mật khẩu tối thiểu 8 ký tự').max(200);

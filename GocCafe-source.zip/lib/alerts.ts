import { loadRecipes } from './recipes';
import { getNumSetting } from './settings';

export interface MarginSnap { id: number; name: string; margin: number; cost: number; price: number }
export interface MarginAlert { id: number; name: string; before: number; after: number; cost_before: number; cost_after: number }

/** Chụp tỷ suất lợi nhuận size M của mọi món — dùng để so sánh trước/sau khi đổi giá nhập. */
export function marginSnapshot(): Map<number, MarginSnap> {
  const m = new Map<number, MarginSnap>();
  for (const r of loadRecipes()) {
    const s = r.sizes.find((x) => x.name === 'M') ?? r.sizes[0];
    if (s) m.set(r.id, { id: r.id, name: r.name, margin: s.margin, cost: s.cost, price: s.selling_price });
  }
  return m;
}
/** Món nào bị tụt dưới ngưỡng lợi nhuận tối thiểu (hoặc giảm đáng kể) sau thay đổi. */
export function diffMargins(before: Map<number, MarginSnap>, after: Map<number, MarginSnap>): { alerts: MarginAlert[]; threshold: number } {
  const threshold = getNumSetting('min_margin', 50);
  const alerts: MarginAlert[] = [];
  for (const [id, a] of after) {
    const b = before.get(id);
    if (!b || a.price <= 0) continue;
    if (a.margin < threshold && a.margin < b.margin - 0.05) alerts.push({ id, name: a.name, before: b.margin, after: a.margin, cost_before: b.cost, cost_after: a.cost });
  }
  alerts.sort((x, y) => x.after - y.after);
  return { alerts, threshold };
}

import type Database from 'better-sqlite3';
import { RECIPE_CATEGORIES } from './types';

// [tên, nhóm, đơn vị mua, đơn vị cơ bản, số đơn vị cơ bản / 1 đơn vị mua, giá nhập, tồn, tồn tối thiểu, nhà cung cấp, ghi chú]
type Ing = [string, string, string, string, number, number, number, number, string, string];
const INGREDIENTS: Ing[] = [
  ['Espresso', 'Cà phê', 'kg', 'ml', 2200, 180000, 5, 1, 'Cà phê Mộc', '1kg cà phê máy = 55 ly, 1 ly 40ml'],
  ['Cà phê phin', 'Cà phê', 'kg', 'ml', 2250, 220000, 4, 1, 'Cà phê Mộc', '1kg = 45 ly, 1 ly 50ml'],
  ['Sữa đặc', 'Sữa & Kem', 'lon', 'ml', 300, 25000, 20, 6, 'Đại lý Ngôi Sao', 'Lon 380g ≈ 300ml'],
  ['Sữa tươi', 'Sữa & Kem', 'lít', 'ml', 1000, 35000, 3, 5, 'Đại lý Sữa Xanh', ''],
  ['Kem béo', 'Sữa & Kem', 'hộp', 'ml', 354, 30000, 6, 2, 'Đại lý Ngôi Sao', 'Kem béo Rich'],
  ['Kem tươi (whipping)', 'Sữa & Kem', 'hộp', 'ml', 907, 80000, 3, 1, 'Đại lý Ngôi Sao', 'Whipping base'],
  ['Kem mặn', 'Sữa & Kem', 'hộp', 'ml', 1200, 29285, 4, 1, 'Tự làm', ''],
  ['Trà đen', 'Trà', 'kg', 'ml', 72000, 145000, 2, 0.5, 'Lộc Phát', '1kg trà ủ được 72 lít'],
  ['Trà lài', 'Trà', 'kg', 'ml', 56000, 208000, 1.5, 0.5, 'Lộc Phát', '1kg trà ủ được 56 lít'],
  ['Cốt trà sữa', 'Trà', 'lít', 'ml', 1000, 12000, 6, 3, 'Tự pha', 'Theo giáo án'],
  ['Matcha Đài Loan', 'Matcha & Bột', 'kg', 'g', 1000, 700000, 1, 0.3, 'Matcha Đài Loan', '500g = 350.000đ'],
  ['Bột cacao', 'Matcha & Bột', 'kg', 'g', 1000, 270000, 1.5, 0.5, 'Nguyên liệu Tâm An', ''],
  ['Bột frappe', 'Matcha & Bột', 'kg', 'g', 1000, 130000, 2, 0.5, 'Nguyên liệu Tâm An', 'Bột tạo độ sánh đá xay'],
  ['Syrup vanilla', 'Syrup & Sốt', 'chai', 'ml', 750, 165000, 2, 1, 'Torani', ''],
  ['Syrup caramel', 'Syrup & Sốt', 'chai', 'ml', 750, 165000, 2, 1, 'Torani', ''],
  ['Syrup đào', 'Syrup & Sốt', 'chai', 'ml', 750, 165000, 3, 1, 'Torani', ''],
  ['Syrup dâu', 'Syrup & Sốt', 'chai', 'ml', 750, 165000, 2, 1, 'Torani', ''],
  ['Syrup vải', 'Syrup & Sốt', 'chai', 'ml', 750, 165000, 1, 1, 'Torani', ''],
  ['Syrup blue curacao', 'Syrup & Sốt', 'chai', 'ml', 700, 110000, 2, 1, 'Golden Farm', ''],
  ['Sốt chocolate', 'Syrup & Sốt', 'chai', 'ml', 620, 105000, 2, 1, 'Monin', ''],
  ['Sốt caramel', 'Syrup & Sốt', 'chai', 'ml', 620, 95000, 2, 1, 'Monin', ''],
  ['Mật ong', 'Syrup & Sốt', 'chai', 'ml', 1000, 90000, 2, 1, 'Mật ong phố núi', ''],
  ['Đường', 'Syrup & Sốt', 'kg', 'ml', 1200, 22000, 8, 3, 'Đường Biên Hòa', '1kg đường nấu được 1200ml syrup'],
  ['Chanh', 'Trái cây', 'kg', 'ml', 450, 25000, 2, 1, 'Chợ đầu mối', '1kg chanh ≈ 450ml cốt'],
  ['Tắc', 'Trái cây', 'kg', 'ml', 500, 25000, 1.5, 1, 'Chợ đầu mối', '1kg tắc ≈ 500ml cốt'],
  ['Cam tươi', 'Trái cây', 'kg', 'ml', 500, 35000, 4, 2, 'Chợ đầu mối', '1kg cam ≈ 500ml nước'],
  ['Sả', 'Trái cây', 'kg', 'g', 1000, 30000, 0.5, 0.3, 'Chợ đầu mối', ''],
  ['Đào ngâm', 'Trái cây', 'lon', 'cái', 28, 30000, 4, 1, 'Đại lý Ngôi Sao', '1 lon = 28 miếng'],
  ['Vải ngâm', 'Trái cây', 'lon', 'cái', 20, 37500, 2, 1, 'Đại lý Ngôi Sao', '1 lon = 20 quả'],
  ['Xoài', 'Trái cây', 'kg', 'g', 1000, 45000, 3, 1, 'Chợ đầu mối', ''],
  ['Bơ', 'Trái cây', 'kg', 'g', 1000, 60000, 2, 1, 'Chợ đầu mối', ''],
  ['Dâu tây', 'Trái cây', 'kg', 'g', 1000, 140000, 0.8, 0.5, 'Chợ đầu mối', 'Hộp 500g ≈ 70.000đ'],
  ['Mãng cầu', 'Trái cây', 'kg', 'g', 1000, 80000, 1, 0.5, 'Chợ đầu mối', 'Đã xay nhuyễn'],
  ['Bánh Oreo', 'Topping', 'gói', 'cái', 12, 30000, 3, 1, 'Đại lý Ngôi Sao', ''],
  ['Trân châu', 'Topping', 'bịch', 'g', 2000, 55000, 3, 1, 'Gia Uy', ''],
  ['Xí muội', 'Topping', 'bịch', 'cái', 100, 60000, 1, 1, 'Chợ đầu mối', '1 bịch 100 viên'],
  ['Soda', 'Đồ uống', 'lon', 'ml', 330, 5200, 24, 12, 'Đại lý nước giải khát', ''],
  ['Đá viên', 'Khác', 'bịch', 'g', 10000, 20000, 4, 2, 'Đá Hoàng Gia', 'Bịch 10kg'],
  ['Nước lọc', 'Cơ bản', 'lít', 'ml', 1000, 2000, 100, 10, '', ''],
  ['Ly + ống hút + nắp', 'Bao bì', 'cái', 'cái', 1, 1100, 500, 100, 'Bao bì Minh Phát', 'Bộ ly muỗng'],
];

type Spec = [string, number]; // [tên nguyên liệu, lượng size M] (đơn vị = đơn vị cơ bản)
interface R { n: string; c: string; d: string; t: number; p: number; desc: string; i: Spec[]; s: string[] }
const LY: Spec = ['Ly + ống hút + nắp', 1];
const RECIPES: R[] = [
  { n: 'Cà phê đen đá', c: 'Cà phê', d: 'Dễ', t: 3, p: 20000, desc: 'Cà phê phin đậm vị, ngọt nhẹ, uống đá.', i: [['Cà phê phin', 70], ['Đường', 15], ['Đá viên', 200], LY],
    s: ['Cho đường vào ly.', 'Pha cà phê phin trực tiếp lên đường (hoặc rót cà phê đã pha).', 'Khuấy đến khi đường tan.', 'Thêm đá viên đầy ly.', 'Phục vụ.'] },
  { n: 'Cà phê sữa đá', c: 'Cà phê', d: 'Dễ', t: 3, p: 25000, desc: 'Món bán chạy nhất: espresso hòa cùng sữa đặc, thơm béo.', i: [['Espresso', 45], ['Sữa đặc', 30], ['Đá viên', 200], LY],
    s: ['Cho sữa đặc vào ly.', 'Chiết xuất espresso.', 'Cho espresso vào ly và khuấy đều.', 'Thêm đá.', 'Trang trí và phục vụ.'] },
  { n: 'Cà phê phin sữa đá', c: 'Cà phê', d: 'Dễ', t: 5, p: 22000, desc: 'Cà phê phin truyền thống với sữa đặc.', i: [['Cà phê phin', 60], ['Sữa đặc', 30], ['Đá viên', 200], LY],
    s: ['Cho sữa đặc vào ly.', 'Pha cà phê phin, nhỏ giọt vào ly.', 'Khuấy đều.', 'Thêm đá và phục vụ.'] },
  { n: 'Bạc xỉu', c: 'Cà phê', d: 'Dễ', t: 3, p: 29000, desc: 'Nhiều sữa, ít cà phê, vị ngọt béo dễ uống.', i: [['Espresso', 30], ['Sữa đặc', 30], ['Sữa tươi', 100], ['Đá viên', 200], LY],
    s: ['Cho sữa đặc và sữa tươi vào ly, khuấy tan.', 'Thêm đá.', 'Chiết xuất espresso và rót nhẹ lên trên.', 'Phục vụ (khuấy trước khi uống).'] },
  { n: 'Cà phê sữa tươi', c: 'Cà phê', d: 'Dễ', t: 3, p: 29000, desc: 'Espresso kết hợp sữa tươi, ít ngọt.', i: [['Espresso', 45], ['Sữa tươi', 120], ['Đường', 15], ['Đá viên', 200], LY],
    s: ['Cho đường và sữa tươi vào ly, khuấy tan.', 'Thêm đá.', 'Chiết xuất espresso, rót lên trên.', 'Phục vụ.'] },
  { n: 'Cà phê muối', c: 'Cà phê', d: 'Trung bình', t: 4, p: 29000, desc: 'Cà phê sữa phủ lớp kem mặn béo bùi.', i: [['Cà phê phin', 50], ['Sữa đặc', 20], ['Kem mặn', 40], ['Đá viên', 150], LY],
    s: ['Cho sữa đặc và cà phê vào ly, khuấy đều.', 'Thêm đá.', 'Đánh nhẹ kem mặn cho mịn.', 'Phủ kem mặn lên trên mặt ly.', 'Phục vụ.'] },
  { n: 'Espresso', c: 'Cà phê', d: 'Trung bình', t: 2, p: 25000, desc: 'Shot espresso nguyên chất.', i: [['Espresso', 30], LY],
    s: ['Làm nóng ly.', 'Xay và nén cà phê vào tay cầm.', 'Chiết xuất 25–30 giây.', 'Phục vụ ngay.'] },
  { n: 'Americano', c: 'Cà phê', d: 'Dễ', t: 3, p: 30000, desc: 'Espresso pha loãng với nước, vị thanh.', i: [['Espresso', 45], ['Nước lọc', 150], ['Đá viên', 150], LY],
    s: ['Cho nước lọc và đá vào ly.', 'Chiết xuất espresso.', 'Rót espresso lên trên.', 'Phục vụ.'] },
  { n: 'Latte', c: 'Cà phê', d: 'Trung bình', t: 4, p: 35000, desc: 'Espresso với nhiều sữa tươi đánh nóng.', i: [['Espresso', 45], ['Sữa tươi', 180], LY],
    s: ['Chiết xuất espresso vào ly.', 'Đánh nóng sữa tươi đến khoảng 65°C.', 'Rót sữa vào espresso, tạo lớp bọt mỏng.', 'Phục vụ.'] },
  { n: 'Cappuccino', c: 'Cà phê', d: 'Trung bình', t: 4, p: 39000, desc: 'Lớp bọt sữa dày, vị cà phê đậm.', i: [['Espresso', 45], ['Sữa tươi', 120], ['Kem béo', 30], LY],
    s: ['Chiết xuất espresso vào ly.', 'Trộn sữa tươi với kem béo, đánh nóng tạo bọt dày.', 'Rót sữa, múc thêm bọt lên trên.', 'Phục vụ.'] },
  { n: 'Mocha', c: 'Cà phê', d: 'Trung bình', t: 5, p: 45000, desc: 'Cà phê, chocolate và sữa — ngọt đậm.', i: [['Espresso', 45], ['Sốt chocolate', 25], ['Sữa tươi', 150], ['Kem tươi (whipping)', 20], LY],
    s: ['Cho sốt chocolate vào ly.', 'Chiết xuất espresso vào ly, khuấy đều.', 'Đánh nóng sữa tươi và rót vào.', 'Phủ kem tươi, rưới thêm chocolate.', 'Phục vụ.'] },
  { n: 'Caramel Macchiato', c: 'Cà phê', d: 'Trung bình', t: 5, p: 49000, desc: 'Sữa, vanilla, espresso và sốt caramel.', i: [['Espresso', 45], ['Syrup vanilla', 15], ['Sữa tươi', 170], ['Sốt caramel', 15], LY],
    s: ['Cho syrup vanilla vào ly.', 'Đánh nóng sữa tươi và rót vào ly.', 'Chiết xuất espresso, rót nhẹ lên mặt sữa.', 'Rưới sốt caramel thành hình lưới.', 'Phục vụ.'] },
  { n: 'Vanilla Latte', c: 'Cà phê', d: 'Dễ', t: 4, p: 45000, desc: 'Latte thơm vị vanilla.', i: [['Espresso', 45], ['Syrup vanilla', 20], ['Sữa tươi', 180], LY],
    s: ['Cho syrup vanilla và espresso vào ly.', 'Đánh nóng sữa tươi.', 'Rót sữa vào ly, khuấy nhẹ.', 'Phục vụ.'] },

  { n: 'Trà sữa truyền thống', c: 'Trà sữa', d: 'Dễ', t: 3, p: 25000, desc: 'Trà sữa cổ điển với trân châu.', i: [['Cốt trà sữa', 200], ['Trân châu', 40], ['Đường', 15], ['Đá viên', 150], LY],
    s: ['Cho trân châu vào ly.', 'Thêm đường và cốt trà sữa.', 'Lắc đều cùng đá.', 'Rót ra ly, phục vụ.'] },
  { n: 'Trà sữa kem mặn', c: 'Trà sữa', d: 'Trung bình', t: 4, p: 30000, desc: 'Trà sữa trân châu phủ kem mặn.', i: [['Cốt trà sữa', 200], ['Trân châu', 40], ['Kem mặn', 40], ['Đá viên', 150], LY],
    s: ['Cho trân châu vào ly, thêm đá.', 'Rót cốt trà sữa.', 'Phủ kem mặn lên trên.', 'Phục vụ.'] },

  { n: 'Trà đào', c: 'Trà trái cây', d: 'Dễ', t: 3, p: 30000, desc: 'Trà đen thơm mùi đào, miếng đào giòn ngọt.', i: [['Trà đen', 200], ['Syrup đào', 25], ['Đào ngâm', 3], ['Đường', 10], ['Tắc', 10], ['Đá viên', 150], LY],
    s: ['Cho syrup đào, đường và nước tắc vào bình lắc.', 'Thêm trà đen và đá, lắc đều.', 'Cho miếng đào vào ly.', 'Rót trà vào ly và phục vụ.'] },
  { n: 'Trà đào cam sả', c: 'Trà trái cây', d: 'Trung bình', t: 4, p: 35000, desc: 'Hương sả thanh mát, vị cam đào chua ngọt.', i: [['Trà đen', 180], ['Syrup đào', 20], ['Cam tươi', 40], ['Sả', 10], ['Đào ngâm', 2], ['Đá viên', 150], LY],
    s: ['Đập dập sả cho vào ly.', 'Cho syrup đào, nước cam và miếng đào vào ly.', 'Thêm đá, rót trà đen.', 'Khuấy nhẹ và phục vụ.'] },
  { n: 'Trà tắc', c: 'Trà trái cây', d: 'Dễ', t: 2, p: 18000, desc: 'Trà lài chua nhẹ vị tắc.', i: [['Trà lài', 200], ['Tắc', 40], ['Đường', 30], ['Xí muội', 1], ['Đá viên', 150], LY],
    s: ['Cho đường, nước tắc và xí muội vào ly.', 'Rót trà lài, thêm đá.', 'Khuấy đều và phục vụ.'] },
  { n: 'Trà chanh', c: 'Trà trái cây', d: 'Dễ', t: 2, p: 20000, desc: 'Trà lài chanh giải khát.', i: [['Trà lài', 200], ['Chanh', 30], ['Đường', 30], ['Xí muội', 1], ['Đá viên', 150], LY],
    s: ['Cho đường, nước chanh và xí muội vào ly.', 'Rót trà lài, thêm đá.', 'Khuấy đều và phục vụ.'] },
  { n: 'Trà vải', c: 'Trà trái cây', d: 'Dễ', t: 3, p: 32000, desc: 'Trà lài thơm mùi vải, kèm trái vải ngâm.', i: [['Trà lài', 200], ['Syrup vải', 25], ['Vải ngâm', 3], ['Đá viên', 150], LY],
    s: ['Cho syrup vải và trái vải vào ly.', 'Thêm đá và rót trà lài.', 'Khuấy đều và phục vụ.'] },
  { n: 'Trà dâu', c: 'Trà trái cây', d: 'Dễ', t: 3, p: 32000, desc: 'Trà đen hương dâu tươi.', i: [['Trà đen', 200], ['Syrup dâu', 25], ['Dâu tây', 40], ['Đường', 10], ['Tắc', 10], ['Đá viên', 150], LY],
    s: ['Dầm nhẹ dâu tây trong ly.', 'Thêm syrup dâu, đường, nước tắc.', 'Thêm đá và rót trà đen.', 'Khuấy đều và phục vụ.'] },
  { n: 'Trà xoài', c: 'Trà trái cây', d: 'Dễ', t: 3, p: 32000, desc: 'Trà lài với xoài tươi.', i: [['Trà lài', 200], ['Xoài', 80], ['Đường', 15], ['Tắc', 10], ['Đá viên', 150], LY],
    s: ['Xay nhuyễn một nửa xoài với đường.', 'Cho vào ly cùng xoài cắt hạt lựu.', 'Thêm đá, nước tắc và rót trà lài.', 'Khuấy đều và phục vụ.'] },

  { n: 'Matcha đá', c: 'Matcha', d: 'Trung bình', t: 4, p: 29000, desc: 'Matcha nguyên vị, hơi ngọt, thanh mát.', i: [['Matcha Đài Loan', 6], ['Nước lọc', 120], ['Đường', 20], ['Đá viên', 150], LY],
    s: ['Rây matcha vào chén, thêm 40ml nước ấm (80°C).', 'Đánh tan bằng chasen đến khi mịn.', 'Cho đường và nước lạnh vào ly, thêm đá.', 'Rót matcha lên trên và phục vụ.'] },
  { n: 'Matcha Latte', c: 'Matcha', d: 'Trung bình', t: 4, p: 35000, desc: 'Matcha hòa sữa tươi béo nhẹ.', i: [['Matcha Đài Loan', 6], ['Sữa tươi', 160], ['Đường', 20], ['Nước lọc', 40], ['Đá viên', 150], LY],
    s: ['Rây matcha vào chén, thêm nước ấm và đánh tan.', 'Cho đường và sữa tươi vào ly, thêm đá.', 'Rót matcha lên trên.', 'Phục vụ.'] },
  { n: 'Matcha đá xay', c: 'Matcha', d: 'Trung bình', t: 5, p: 42000, desc: 'Matcha xay mịn lạnh, phủ kem tươi.', i: [['Matcha Đài Loan', 8], ['Sữa tươi', 100], ['Đường', 25], ['Bột frappe', 20], ['Đá viên', 200], ['Kem tươi (whipping)', 20], LY],
    s: ['Cho matcha, sữa tươi, đường, bột frappe và đá vào máy xay.', 'Xay 30–40 giây đến khi mịn.', 'Đổ ra ly.', 'Phủ kem tươi và phục vụ.'] },
  { n: 'Matcha dâu', c: 'Matcha', d: 'Trung bình', t: 5, p: 42000, desc: 'Hai lớp matcha sữa và dâu tươi.', i: [['Matcha Đài Loan', 6], ['Sữa tươi', 120], ['Dâu tây', 40], ['Syrup dâu', 15], ['Đá viên', 150], LY],
    s: ['Dầm dâu tây với syrup dâu, cho vào đáy ly.', 'Thêm đá và sữa tươi.', 'Đánh matcha với nước ấm, rót nhẹ lên trên.', 'Phục vụ.'] },

  { n: 'Cookies đá xay', c: 'Đá xay', d: 'Trung bình', t: 5, p: 42000, desc: 'Đá xay vị bánh Oreo.', i: [['Bánh Oreo', 3], ['Sữa tươi', 100], ['Sữa đặc', 20], ['Bột frappe', 20], ['Đá viên', 200], ['Kem tươi (whipping)', 20], LY],
    s: ['Cho 2 bánh Oreo, sữa, bột frappe và đá vào máy xay.', 'Xay đến khi mịn.', 'Đổ ra ly, phủ kem tươi.', 'Bẻ vụn 1 bánh Oreo rắc lên trên.'] },
  { n: 'Chocolate đá xay', c: 'Đá xay', d: 'Dễ', t: 5, p: 42000, desc: 'Chocolate xay lạnh béo ngọt.', i: [['Bột cacao', 15], ['Sữa tươi', 100], ['Sữa đặc', 20], ['Bột frappe', 20], ['Đá viên', 200], ['Kem tươi (whipping)', 20], LY],
    s: ['Cho cacao, sữa tươi, sữa đặc, bột frappe và đá vào máy xay.', 'Xay mịn.', 'Đổ ra ly và phủ kem tươi.', 'Rắc cacao trang trí.'] },
  { n: 'Cà phê đá xay', c: 'Đá xay', d: 'Dễ', t: 5, p: 42000, desc: 'Cà phê xay lạnh mát sảng khoái.', i: [['Espresso', 45], ['Sữa tươi', 100], ['Sữa đặc', 20], ['Bột frappe', 20], ['Đá viên', 200], ['Kem tươi (whipping)', 20], LY],
    s: ['Chiết xuất espresso, để nguội nhanh.', 'Cho espresso, sữa, bột frappe và đá vào máy xay.', 'Xay mịn rồi đổ ra ly.', 'Phủ kem tươi, phục vụ.'] },

  { n: 'Chocolate đá', c: 'Chocolate', d: 'Dễ', t: 3, p: 32000, desc: 'Chocolate sữa béo, uống lạnh.', i: [['Bột cacao', 15], ['Sữa đặc', 25], ['Kem béo', 30], ['Sữa tươi', 100], ['Đá viên', 150], LY],
    s: ['Hòa cacao với một ít nước nóng cho tan.', 'Cho sữa đặc, kem béo và sữa tươi vào, khuấy đều.', 'Thêm đá.', 'Phục vụ.'] },
  { n: 'Chocolate nóng', c: 'Chocolate', d: 'Dễ', t: 4, p: 35000, desc: 'Chocolate nóng đậm đà.', i: [['Sốt chocolate', 30], ['Bột cacao', 10], ['Sữa tươi', 200], LY],
    s: ['Cho sốt chocolate và cacao vào ly.', 'Đánh nóng sữa tươi.', 'Rót sữa vào ly, khuấy đều.', 'Phục vụ nóng.'] },

  { n: 'Sinh tố bơ', c: 'Sinh tố', d: 'Dễ', t: 4, p: 38000, desc: 'Bơ sáp xay mịn, béo ngậy.', i: [['Bơ', 120], ['Sữa đặc', 30], ['Sữa tươi', 50], ['Đường', 10], ['Đá viên', 100], LY],
    s: ['Cho bơ, sữa đặc, sữa tươi, đường và đá vào máy xay.', 'Xay mịn 30 giây.', 'Đổ ra ly và phục vụ.'] },
  { n: 'Sinh tố xoài', c: 'Sinh tố', d: 'Dễ', t: 4, p: 35000, desc: 'Xoài chín xay mịn, ngọt thơm.', i: [['Xoài', 150], ['Sữa đặc', 20], ['Sữa tươi', 50], ['Đường', 15], ['Đá viên', 100], LY],
    s: ['Cho xoài, sữa đặc, sữa tươi, đường và đá vào máy xay.', 'Xay mịn.', 'Đổ ra ly và phục vụ.'] },
  { n: 'Sinh tố dâu', c: 'Sinh tố', d: 'Dễ', t: 4, p: 38000, desc: 'Dâu tây tươi xay cùng sữa.', i: [['Dâu tây', 100], ['Sữa đặc', 20], ['Sữa tươi', 50], ['Đường', 20], ['Đá viên', 100], LY],
    s: ['Cho dâu, sữa đặc, sữa tươi, đường và đá vào máy xay.', 'Xay mịn.', 'Đổ ra ly và phục vụ.'] },
  { n: 'Sinh tố mãng cầu', c: 'Sinh tố', d: 'Dễ', t: 4, p: 38000, desc: 'Mãng cầu xiêm chua ngọt thanh mát.', i: [['Mãng cầu', 100], ['Sữa đặc', 25], ['Đường', 20], ['Nước lọc', 30], ['Đá viên', 100], LY],
    s: ['Cho mãng cầu, sữa đặc, đường, nước và đá vào máy xay.', 'Xay mịn.', 'Đổ ra ly và phục vụ.'] },

  { n: 'Nước ép cam', c: 'Nước ép', d: 'Dễ', t: 3, p: 30000, desc: 'Cam tươi vắt nguyên chất.', i: [['Cam tươi', 150], ['Đường', 15], ['Đá viên', 150], LY],
    s: ['Vắt cam lấy nước.', 'Cho đường vào ly, thêm nước cam.', 'Thêm đá, khuấy đều.', 'Phục vụ.'] },
  { n: 'Cam mật ong', c: 'Nước ép', d: 'Dễ', t: 3, p: 32000, desc: 'Cam tươi với mật ong thanh ngọt.', i: [['Cam tươi', 120], ['Mật ong', 15], ['Nước lọc', 50], ['Đá viên', 150], LY],
    s: ['Vắt cam lấy nước.', 'Cho mật ong và nước vào ly, khuấy tan.', 'Thêm nước cam và đá.', 'Phục vụ.'] },

  { n: 'Soda chanh', c: 'Soda', d: 'Dễ', t: 2, p: 25000, desc: 'Soda chanh chua ngọt sảng khoái.', i: [['Chanh', 30], ['Đường', 25], ['Soda', 150], ['Đá viên', 150], LY],
    s: ['Cho nước chanh và đường vào ly, khuấy tan.', 'Thêm đá.', 'Rót soda nhẹ nhàng.', 'Phục vụ.'] },
  { n: 'Soda dâu', c: 'Soda', d: 'Dễ', t: 2, p: 28000, desc: 'Soda hương dâu hồng xinh.', i: [['Syrup dâu', 30], ['Soda', 150], ['Chanh', 10], ['Đá viên', 150], LY],
    s: ['Cho syrup dâu và nước chanh vào ly.', 'Thêm đá.', 'Rót soda, khuấy nhẹ.', 'Phục vụ.'] },
  { n: 'Soda blue', c: 'Soda', d: 'Dễ', t: 2, p: 28000, desc: 'Soda xanh blue curacao bắt mắt.', i: [['Syrup blue curacao', 30], ['Soda', 150], ['Chanh', 10], ['Đá viên', 150], LY],
    s: ['Cho syrup blue và nước chanh vào ly.', 'Thêm đá.', 'Rót soda từ từ để tạo lớp màu.', 'Phục vụ.'] },
];

const round5 = (x: number) => Math.max(5, Math.round(x / 5) * 5);

export function seedDatabase(db: Database.Database) {
  const tx = db.transaction(() => {
    const insCat = db.prepare('INSERT OR IGNORE INTO categories (name, icon) VALUES (?,?)');
    for (const c of RECIPE_CATEGORIES) insCat.run(c.name, c.icon);

    const insIng = db.prepare(`INSERT INTO ingredients (name, category, unit, base_unit, pack_size, purchase_price, stock_quantity, minimum_stock, supplier, note, group_name, track_stock) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`);
    const insPH = db.prepare("INSERT INTO price_history (ingredient_id, price, created_at) VALUES (?,?,datetime('now',?))");
    const insMove = db.prepare("INSERT INTO stock_moves (ingredient_id, kind, delta, balance, unit_price, note, user_name, created_at) VALUES (?,?,?,?,?,?,?,datetime('now','-10 days'))");
    const GROUPS: Record<string, string> = { 'Syrup caramel': 'Caramel', 'Sốt caramel': 'Caramel' };
    const NO_TRACK = new Set(['Nước lọc']);
    const ids = new Map<string, { id: number; base: string }>();
    for (const r of INGREDIENTS) {
      const id = Number(insIng.run(...r, GROUPS[r[0]] ?? '', NO_TRACK.has(r[0]) ? 0 : 1).lastInsertRowid);
      ids.set(r[0], { id, base: r[3] });
      insPH.run(id, Math.round(r[5] * 0.93 / 500) * 500 || r[5], '-40 days');
      insPH.run(id, r[5], '-10 days');
      insMove.run(id, 'import', r[6], r[6], r[5], 'Tồn đầu kỳ (dữ liệu mẫu)', 'Hệ thống');
    }

    // Bán thành phẩm mẫu: Cốt trà sữa = trà đen + đường + sữa đặc → 1000ml
    const tea = ids.get('Cốt trà sữa')!;
    db.prepare('INSERT INTO preps (ingredient_id, yield_qty, instructions) VALUES (?,?,?)').run(tea.id, 1000, 'Ủ trà đen, hòa đường và sữa đặc, để nguội.');
    const insPL = db.prepare('INSERT INTO prep_lines (prep_id, component_id, quantity, unit) VALUES (?,?,?,?)');
    insPL.run(tea.id, ids.get('Trà đen')!.id, 700, 'ml');
    insPL.run(tea.id, ids.get('Đường')!.id, 100, 'ml');
    insPL.run(tea.id, ids.get('Sữa đặc')!.id, 200, 'ml');

    db.prepare("INSERT OR REPLACE INTO settings (key, value) VALUES ('waste_percent','5')").run();
    db.prepare("INSERT OR REPLACE INTO settings (key, value) VALUES ('shop_name','Góc Cafe')").run();

    const insR = db.prepare(`INSERT INTO recipes (name, category, description, difficulty, preparation_time, selling_price, instructions, created_at, updated_at) VALUES (?,?,?,?,?,?,?,datetime('now',?),datetime('now',?))`);
    const insS = db.prepare('INSERT INTO recipe_sizes (recipe_id, name, selling_price) VALUES (?,?,?)');
    const insL = db.prepare('INSERT INTO recipe_ingredients (recipe_id, ingredient_id, quantity, unit, size, optional) VALUES (?,?,?,?,?,?)');
    const insB = db.prepare('INSERT INTO brew_log (recipe_id, size, quantity, created_at) VALUES (?,?,?,datetime(\'now\',\'-3 days\'))');
    const insSale = db.prepare("INSERT INTO sales (recipe_id, recipe_name, category, size, quantity, revenue, unit_cost, sold_on, source) VALUES (?,?,?,?,?,?,?,date('now',?),'demo')");
    const demoSales: Record<string, number> = { 'Cà phê sữa đá': 240, 'Bạc xỉu': 160, 'Trà đào': 140, 'Matcha Latte': 120, 'Trà đào cam sả': 110, 'Cà phê muối': 90, 'Soda chanh': 70, 'Trà sữa truyền thống': 85 };

    RECIPES.forEach((r, idx) => {
      const age = idx >= RECIPES.length - 8 ? '-2 days' : '-60 days';
      const rid = Number(insR.run(r.n, r.c, r.desc, r.d, r.t, r.p, JSON.stringify(r.s), age, age).lastInsertRowid);
      const factor: Record<string, number> = { S: 0.75, M: 1, L: 1.3 };
      const price: Record<string, number> = { S: r.p - 5000, M: r.p, L: r.p + 6000 };
      for (const size of ['S', 'M', 'L']) {
        insS.run(rid, size, price[size]);
        for (const [name, qty] of r.i) {
          const ing = ids.get(name);
          if (!ing) throw new Error(`Seed: thiếu nguyên liệu "${name}" (món ${r.n})`);
          let q = qty;
          if (size !== 'M') {
            if (ing.base === 'cái') q = name.startsWith('Ly') || name === 'Xí muội' ? qty : Math.max(1, Math.round(qty * factor[size]));
            else q = round5(qty * factor[size]);
            if (ing.base !== 'cái' && qty < 10) q = Math.round(qty * factor[size] * 2) / 2; // lượng nhỏ (matcha 6g)
          }
          insL.run(rid, ing.id, q, ing.base, size, name === 'Kem tươi (whipping)' ? 1 : 0);
        }
      }
      insB.run(rid, 'M', demoSales[r.n] ?? 10 + ((idx * 7) % 40));
      const total = demoSales[r.n] ?? 10 + ((idx * 7) % 40);
      for (let d = 1; d <= 14; d++) {
        const qty = Math.max(1, Math.round((total / 30) * (0.6 + ((d * 7 + idx * 3) % 9) / 10)));
        insSale.run(rid, r.n, r.c, 'M', qty, qty * r.p, Math.round(r.p * 0.32), `-${d} days`);
      }
    });
  });
  tx();
}

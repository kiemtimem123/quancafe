import { computeAvailability } from './availability';
import type Database from 'better-sqlite3';
import { getDb } from './db';
import { toBase } from './units';
import { removeImage } from './images';
import type { Ingredient, Recipe, RecipeLine, SizeDetail, Size, BaseUnit } from './types';
import { SIZES } from './types';
import { expiryOf, WARN_DAYS_DEFAULT, type Batch } from './batches-pure';
import { vnDate } from './time';

export function getWaste(db = getDb()): number {
  const r = db.prepare("SELECT value FROM settings WHERE key='waste_percent'").get() as { value: string } | undefined;
  return r ? Number(r.value) : 5;
}

interface IngRow {
  id: number; name: string; category: string; unit: string; base_unit: BaseUnit; pack_size: number; purchase_price: number;
  stock_quantity: number; minimum_stock: number; supplier: string; note: string; created_at: string; updated_at: string;
  group_name: string; track_stock: number; track_expiry: number; shelf_life_days: number;
}
export type { Prep } from './pure';
import type { Prep } from './pure';

export function loadPreps(db = getDb()): Map<number, Prep> {
  const out = new Map<number, Prep>();
  for (const p of db.prepare('SELECT ingredient_id, yield_qty, instructions FROM preps').all() as Omit<Prep, 'lines'>[]) out.set(p.ingredient_id, { ...p, lines: [] });
  for (const l of db.prepare('SELECT prep_id, component_id, quantity, unit FROM prep_lines ORDER BY id').all() as { prep_id: number; component_id: number; quantity: number; unit: string }[])
    out.get(l.prep_id)?.lines.push({ component_id: l.component_id, quantity: l.quantity, unit: l.unit });
  return out;
}

/** Nguyên liệu kèm đơn giá. Bán thành phẩm: đơn giá = tổng giá vốn thành phần / sản lượng mẻ. */
export function loadIngredients(db = getDb()): Ingredient[] {
  const rows = db.prepare('SELECT * FROM ingredients ORDER BY category, name').all() as IngRow[];
  const preps = loadPreps(db);
  const byId = new Map(rows.map((r) => [r.id, r]));
  const memo = new Map<number, number>();
  const unitCost = (id: number, stack: Set<number>): number => {
    if (memo.has(id)) return memo.get(id)!;
    const r = byId.get(id);
    if (!r) return 0;
    const p = preps.get(id);
    let c: number;
    if (p && p.yield_qty > 0 && !stack.has(id)) {
      stack.add(id);
      c = p.lines.reduce((a, l) => { const b = toBase(l.quantity, l.unit); return a + (b ? b.qty * unitCost(l.component_id, stack) : 0); }, 0) / p.yield_qty;
      stack.delete(id);
    } else c = r.pack_size > 0 ? r.purchase_price / r.pack_size : 0;
    memo.set(id, c);
    return c;
  };
  const warnRow = db.prepare("SELECT value FROM settings WHERE key='expiry_warn_days'").get() as { value: string } | undefined;
  const warn = warnRow && Number.isFinite(Number(warnRow.value)) ? Number(warnRow.value) : WARN_DAYS_DEFAULT;
  const today = vnDate();
  const bBy = new Map<number, Batch[]>();
  for (const b of db.prepare('SELECT * FROM batches WHERE qty>0 AND expires_on IS NOT NULL').all() as Batch[]) (bBy.get(b.ingredient_id) ?? bBy.set(b.ingredient_id, []).get(b.ingredient_id)!).push(b);
  return rows.map((r) => {
    const unit_cost = unitCost(r.id, new Set());
    const has_prep = preps.has(r.id);
    const track = !!r.track_stock;
    return {
      id: r.id, name: r.name, category: r.category, unit: r.unit, base_unit: r.base_unit, pack_size: r.pack_size,
      purchase_price: has_prep ? unit_cost * r.pack_size : r.purchase_price,
      stock_quantity: r.stock_quantity, minimum_stock: r.minimum_stock, supplier: r.supplier, note: r.note,
      created_at: r.created_at, updated_at: r.updated_at, unit_cost, has_prep, group_name: r.group_name ?? '', track_stock: track,
      track_expiry: !!r.track_expiry, shelf_life_days: r.shelf_life_days ?? 0, expiry: r.track_expiry ? expiryOf(bBy.get(r.id) ?? [], today, warn) : null,
      low_stock: track && r.minimum_stock > 0 && r.stock_quantity <= r.minimum_stock,
      out_of_stock: track && r.stock_quantity <= 0,
    };
  });
}
export const loadIngredient = (id: number, db = getDb()) => loadIngredients(db).find((i) => i.id === id);

interface RecipeRow {
  id: number; name: string; category: string; description: string; image: string; difficulty: string;
  preparation_time: number; instructions: string; favorite: number; created_at: string; updated_at: string;
}
interface LineRow { recipe_id: number; ingredient_id: number; quantity: number; unit: string; size: string; optional: number }
interface SizeRow { recipe_id: number; name: string; selling_price: number }

export function loadRecipes(db = getDb(), ids?: number[]): Recipe[] {
  const waste = getWaste(db) / 100;
  const ings = new Map(loadIngredients(db).map((i) => [i.id, i]));
  const rows = (ids
    ? db.prepare(`SELECT * FROM recipes WHERE id IN (${ids.map(() => '?').join(',') || 'NULL'}) ORDER BY name`).all(...ids)
    : db.prepare('SELECT * FROM recipes ORDER BY name').all()) as RecipeRow[];
  if (!rows.length) return [];
  const lines = db.prepare('SELECT recipe_id, ingredient_id, quantity, unit, size, optional FROM recipe_ingredients ORDER BY id').all() as LineRow[];
  const sizes = db.prepare('SELECT recipe_id, name, selling_price FROM recipe_sizes').all() as SizeRow[];
  const linesBy = new Map<string, LineRow[]>();
  for (const l of lines) {
    const k = `${l.recipe_id}|${l.size}`;
    (linesBy.get(k) ?? linesBy.set(k, []).get(k)!).push(l);
  }
  const sizesBy = new Map<number, SizeRow[]>();
  for (const s of sizes) (sizesBy.get(s.recipe_id) ?? sizesBy.set(s.recipe_id, []).get(s.recipe_id)!).push(s);

  const allIngs = Array.from(ings.values());
  const preps = loadPreps(db);
  return rows.map((r) => {
    const sz = (sizesBy.get(r.id) ?? []).sort((a, b) => SIZES.indexOf(a.name as Size) - SIZES.indexOf(b.name as Size));
    const sizeDetails: SizeDetail[] = sz.map((s) => {
      const ls: RecipeLine[] = (linesBy.get(`${r.id}|${s.name}`) ?? []).flatMap((l) => {
        const ing = ings.get(l.ingredient_id);
        const b = toBase(l.quantity, l.unit);
        if (!ing || !b) return [];
        return [{
          ingredient_id: ing.id, name: ing.name, category: ing.category, quantity: l.quantity, unit: l.unit,
          base_qty: b.qty, cost: b.qty * ing.unit_cost, stock_ok: !ing.track_stock || ing.stock_quantity * ing.pack_size >= b.qty, optional: !!l.optional,
        }];
      });
      const raw = ls.reduce((a, l) => a + l.cost, 0);
      const waste_cost = raw * waste;
      const cost = raw + waste_cost;
      const profit = s.selling_price - cost;
      return {
        name: s.name as Size, selling_price: s.selling_price, lines: ls, raw_cost: raw, waste_cost, cost, profit,
        margin: s.selling_price > 0 ? (profit / s.selling_price) * 100 : 0,
        cost_ratio: s.selling_price > 0 ? (cost / s.selling_price) * 100 : 0,
      };
    });
    return {
      id: r.id, name: r.name, category: r.category, description: r.description, image: r.image,
      difficulty: r.difficulty, preparation_time: r.preparation_time, favorite: !!r.favorite,
      instructions: safeJson(r.instructions), created_at: r.created_at, updated_at: r.updated_at, sizes: sizeDetails,
      availability: computeAvailability(sizeDetails.find((x) => x.name === 'M') ?? sizeDetails[0], allIngs, preps),
    };
  });
}
function safeJson(s: string): string[] { try { const v = JSON.parse(s); return Array.isArray(v) ? v : []; } catch { return []; } }

export { mainSize } from './pure';

export interface RecipeInput {
  name: string; category: string; description: string; image: string; difficulty: string;
  preparation_time: number; instructions: string[];
  sizes: { name: Size; selling_price: number; lines: { ingredient_id: number; quantity: number; unit: string; optional?: boolean }[] }[];
}

export function saveRecipe(input: RecipeInput, id?: number): number {
  const db = getDb();
  const tx = db.transaction(() => {
    let rid = id;
    const oldImage = rid ? (db.prepare('SELECT image FROM recipes WHERE id=?').get(rid) as { image: string } | undefined)?.image : '';
    const main = input.sizes.find((s) => s.name === 'M') ?? input.sizes[0];
    if (rid) {
      db.prepare(`UPDATE recipes SET name=?, category=?, description=?, image=?, difficulty=?, preparation_time=?, selling_price=?, instructions=?, updated_at=datetime('now') WHERE id=?`)
        .run(input.name, input.category, input.description, input.image, input.difficulty, input.preparation_time, main.selling_price, JSON.stringify(input.instructions), rid);
      db.prepare('DELETE FROM recipe_sizes WHERE recipe_id=?').run(rid);
      db.prepare('DELETE FROM recipe_ingredients WHERE recipe_id=?').run(rid);
    } else {
      rid = Number(db.prepare(`INSERT INTO recipes (name, category, description, image, difficulty, preparation_time, selling_price, instructions) VALUES (?,?,?,?,?,?,?,?)`)
        .run(input.name, input.category, input.description, input.image, input.difficulty, input.preparation_time, main.selling_price, JSON.stringify(input.instructions)).lastInsertRowid);
    }
    const insS = db.prepare('INSERT INTO recipe_sizes (recipe_id, name, selling_price) VALUES (?,?,?)');
    const insL = db.prepare('INSERT INTO recipe_ingredients (recipe_id, ingredient_id, quantity, unit, size, optional) VALUES (?,?,?,?,?,?)');
    for (const s of input.sizes) {
      insS.run(rid, s.name, s.selling_price);
      for (const l of s.lines) insL.run(rid, l.ingredient_id, l.quantity, l.unit, s.name, l.optional ? 1 : 0);
    }
    if (oldImage && oldImage !== input.image) removeImage(oldImage);
    return rid!;
  });
  return tx();
}

/** Kiểm tra đơn vị công thức tương thích với đơn vị cơ bản của nguyên liệu. */
export function validateLines(input: RecipeInput, db: Database.Database = getDb()): string | null {
  const ings = new Map(loadIngredients(db).map((i) => [i.id, i]));
  for (const s of input.sizes) {
    const seen = new Set<number>();
    for (const l of s.lines) {
      const ing = ings.get(l.ingredient_id);
      if (!ing) return `Nguyên liệu #${l.ingredient_id} không tồn tại`;
      const b = toBase(l.quantity, l.unit);
      if (!b) return `Đơn vị "${l.unit}" không hợp lệ`;
      if (b.base !== (ing.base_unit as BaseUnit)) return `"${ing.name}" tính theo ${ing.base_unit}, không dùng được đơn vị ${l.unit} (size ${s.name})`;
      if (seen.has(l.ingredient_id)) return `"${ing.name}" bị lặp trong size ${s.name}`;
      seen.add(l.ingredient_id);
    }
  }
  return null;
}

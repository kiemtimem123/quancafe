import { getDb } from './db';

export const readSettings = () => {
  const rows = getDb().prepare('SELECT key, value FROM settings').all() as { key: string; value: string }[];
  const m = Object.fromEntries(rows.map((r) => [r.key, r.value]));
  return {
    waste_percent: Number(m.waste_percent ?? 5), shop_name: m.shop_name ?? 'Góc Cafe',
    shop_address: m.shop_address ?? '', shop_phone: m.shop_phone ?? '', receipt_footer: m.receipt_footer ?? 'Cảm ơn quý khách — hẹn gặp lại!',
    paper_width: m.paper_width === '58' ? '58' : '80', table_count: Number(m.table_count ?? 10), expiry_warn_days: Number(m.expiry_warn_days ?? 3), has_qr: !!m.qr_image, qr_order: m.qr_order === '1', bank_info: m.bank_info ?? '',
    bank_bin: m.bank_bin ?? '', bank_account: m.bank_account ?? '', bank_holder: m.bank_holder ?? '',
    loyalty_earn_per: Number(m.loyalty_earn_per ?? 10000), loyalty_point_value: Number(m.loyalty_point_value ?? 500),
  };
};

export function getSetting(key: string, fallback = ''): string {
  const r = getDb().prepare('SELECT value FROM settings WHERE key=?').get(key) as { value: string } | undefined;
  return r?.value ?? fallback;
}
export function getNumSetting(key: string, fallback: number): number {
  const n = Number(getSetting(key, ''));
  return getSetting(key, '') !== '' && Number.isFinite(n) ? n : fallback;
}

import type { Availability, Ingredient, Recipe, SizeDetail } from './types';
import { ALWAYS_AVAILABLE } from './types';
import type { Prep } from './pure';

export const LOW_CUPS = 10;

/** Lượng khả dụng (đơn vị cơ bản) của một nguyên liệu: tồn + tiềm năng làm mẻ (nếu là bán thành phẩm). */
function ownBase(ing: Ingredient, preps: Map<number, Prep>, byId: Map<number, Ingredient>): { base: number; viaPrep: boolean } {
  let base = ing.stock_quantity * ing.pack_size;
  let viaPrep = false;
  const p = preps.get(ing.id);
  if (p && p.lines.length) {
    let batches = Infinity;
    for (const l of p.lines) {
      const c = byId.get(l.component_id);
      if (!c || !c.track_stock) continue;
      const need = toBaseQty(l.quantity, l.unit);
      batches = Math.min(batches, Math.floor((c.stock_quantity * c.pack_size) / need));
    }
    if (Number.isFinite(batches) && batches > 0) { base += batches * p.yield_qty; viaPrep = base > ing.stock_quantity * ing.pack_size; }
    else if (!Number.isFinite(batches)) { base = Infinity; }
  }
  return { base, viaPrep };
}
const toBaseQty = (q: number, unit: string) => (unit === 'kg' || unit === 'lít' ? q * 1000 : q);

export function computeAvailability(sz: SizeDetail | undefined, ings: Ingredient[], preps: Map<number, Prep>): Availability {
  const empty: Availability = { status: 'ok', cups: null, out: [], limiting: [], substitutes: [] };
  if (!sz) return empty;
  const byId = new Map(ings.map((i) => [i.id, i]));
  const groups = new Map<string, Ingredient[]>();
  for (const i of ings) if (i.group_name) (groups.get(i.group_name) ?? groups.set(i.group_name, []).get(i.group_name)!).push(i);

  let cups = Infinity;
  const perLine: { name: string; cups: number }[] = [];
  const out: string[] = [], substitutes: string[] = [];
  for (const l of sz.lines) {
    if (l.optional || ALWAYS_AVAILABLE.includes(l.category)) continue;
    const ing = byId.get(l.ingredient_id);
    if (!ing || !ing.track_stock || l.base_qty <= 0) continue;
    const own = ownBase(ing, preps, byId);
    const ownCups = Math.floor(own.base / l.base_qty + 1e-9);
    let pool = own.base;
    if (ing.group_name) {
      for (const m of groups.get(ing.group_name) ?? []) {
        if (m.id !== ing.id && m.base_unit === ing.base_unit && m.track_stock) pool += ownBase(m, preps, byId).base;
      }
    }
    const lineCups = Math.floor(pool / l.base_qty + 1e-9);
    if (lineCups < 1) out.push(ing.name);
    else if (ownCups < lineCups && ownCups < 1) substitutes.push(ing.name);
    else if (own.viaPrep && ing.stock_quantity * ing.pack_size < l.base_qty) substitutes.push(`${ing.name} (làm mẻ)`);
    cups = Math.min(cups, lineCups);
    perLine.push({ name: ing.name, cups: lineCups });
  }
  if (!Number.isFinite(cups)) return empty;
  const limiting = perLine.filter((p) => p.cups === cups).map((p) => p.name);
  return { status: cups < 1 ? 'out' : cups <= LOW_CUPS ? 'low' : 'ok', cups, out, limiting, substitutes };
}

/** Gợi ý món thay thế cho món hết hàng: cùng nhóm còn hàng trước, rồi món lãi cao, dễ làm. */
export function suggestAlternatives(target: Recipe, all: Recipe[], limit = 4): Recipe[] {
  const main = (r: Recipe) => r.sizes.find((s) => s.name === 'M') ?? r.sizes[0];
  const tIngs = new Set(main(target)?.lines.map((l) => l.ingredient_id));
  const score = (r: Recipe) => {
    const m = main(r);
    const shared = m ? m.lines.filter((l) => tIngs.has(l.ingredient_id) && !ALWAYS_AVAILABLE.includes(l.category)).length : 0;
    return (r.category === target.category ? 100 : 0) + shared * 10 + (m ? Math.min(m.margin, 90) / 10 : 0) + (r.availability?.status === 'ok' ? 5 : 0);
  };
  return all
    .filter((r) => r.id !== target.id && r.availability && r.availability.status !== 'out')
    .sort((a, b) => score(b) - score(a))
    .slice(0, limit);
}

import type Database from 'better-sqlite3';
import { getDb } from './db';
import { loadIngredients } from './recipes';
import { moveStock, recordPrice } from './stock';
import { addDays } from './batches-pure';
import { vnDate } from './time';
import { ApiError } from './api';

export interface POLine { id: number; ingredient_id: number; name: string; unit: string; qty: number; price: number; received_qty: number; stock: number; track_expiry: boolean; shelf_life_days: number }
export interface PO { id: number; supplier: string; status: 'draft' | 'sent' | 'partial' | 'received' | 'cancelled'; note: string; created_by: string; created_at: string; received_at: string | null; total: number; lines: POLine[] }

export function loadPOs(ids?: number[], db: Database.Database = getDb()): PO[] {
  const rows = db.prepare(`SELECT * FROM purchase_orders ${ids ? `WHERE id IN (${ids.map(() => '?').join(',')})` : ''} ORDER BY id DESC LIMIT 200`).all(...(ids ?? [])) as Omit<PO, 'lines' | 'total'>[];
  if (!rows.length) return [];
  const lines = db.prepare(`SELECT l.id, l.po_id, l.ingredient_id, i.name, i.unit, l.qty, l.price, l.received_qty, i.stock_quantity stock, i.track_expiry, i.shelf_life_days
    FROM purchase_order_lines l JOIN ingredients i ON i.id=l.ingredient_id WHERE l.po_id IN (${rows.map(() => '?').join(',')}) ORDER BY l.id`).all(...rows.map((r) => r.id)) as (Omit<POLine, 'track_expiry'> & { po_id: number; track_expiry: number })[];
  return rows.map((r) => {
    const ls = lines.filter((l) => l.po_id === r.id).map(({ po_id: _p, ...l }) => ({ ...l, track_expiry: !!l.track_expiry }));
    return { ...r, lines: ls, total: Math.round(ls.reduce((a, l) => a + l.qty * l.price, 0)) };
  });
}

/** Gợi ý mua: dưới mức tối thiểu → mua lên gấp đôi mức tối thiểu (giống trang "cần mua"). */
export function suggestLines() {
  return loadIngredients(getDb()).filter((i) => !i.has_prep && i.track_stock && i.minimum_stock > 0 && i.stock_quantity < i.minimum_stock * 1.0001)
    .map((i) => ({ ingredient_id: i.id, supplier: i.supplier || 'Chưa rõ NCC', qty: Math.max(1, Math.ceil((i.minimum_stock * 2 - i.stock_quantity) * 100) / 100), price: i.purchase_price }));
}

export function createPO(supplier: string, lines: { ingredient_id: number; qty: number; price?: number }[], user: string, note = '', db: Database.Database = getDb()): number {
  return db.transaction(() => {
    const id = Number(db.prepare('INSERT INTO purchase_orders (supplier, note, created_by) VALUES (?,?,?)').run(supplier, note, user).lastInsertRowid);
    const pr = db.prepare('SELECT purchase_price FROM ingredients WHERE id=?');
    const ins = db.prepare('INSERT INTO purchase_order_lines (po_id, ingredient_id, qty, price) VALUES (?,?,?,?)');
    for (const l of lines) {
      const p = pr.get(l.ingredient_id) as { purchase_price: number } | undefined;
      if (!p) throw new ApiError(400, 'Có nguyên liệu không tồn tại');
      ins.run(id, l.ingredient_id, l.qty, l.price ?? p.purchase_price);
    }
    return id;
  })();
}

export interface RecvLine { line_id: number; qty: number; price?: number; expires_on?: string }
/** Nhận hàng: nhập kho theo từng dòng (kèm giá thực tế và hạn sử dụng của lô). */
export function receivePO(poId: number, recv: RecvLine[], user: string, db: Database.Database = getDb()) {
  db.transaction(() => {
    const po = db.prepare('SELECT status FROM purchase_orders WHERE id=?').get(poId) as { status: string } | undefined;
    if (!po) throw new ApiError(404, 'Không tìm thấy đơn đặt hàng');
    if (po.status === 'cancelled') throw new ApiError(400, 'Đơn đã hủy');
    for (const r of recv) {
      if (r.qty <= 0) continue;
      const l = db.prepare('SELECT l.*, i.purchase_price cur, i.track_expiry, i.shelf_life_days FROM purchase_order_lines l JOIN ingredients i ON i.id=l.ingredient_id WHERE l.id=? AND l.po_id=?').get(r.line_id, poId) as { id: number; ingredient_id: number; price: number; cur: number; track_expiry: number; shelf_life_days: number } | undefined;
      if (!l) throw new ApiError(400, 'Dòng hàng không thuộc đơn này');
      const price = r.price ?? l.price;
      db.prepare('UPDATE ingredients SET track_stock=1 WHERE id=? AND track_stock=0').run(l.ingredient_id);
      const today = vnDate();
      moveStock(l.ingredient_id, r.qty, 'purchase', {
        note: `Nhận hàng đơn đặt #${poId}`, unitPrice: price, user, db,
        batch: l.track_expiry ? { expires_on: r.expires_on ?? (l.shelf_life_days > 0 ? addDays(today, l.shelf_life_days) : null), received_on: today } : undefined,
      });
      if (Math.abs(price - l.cur) > 1e-9) {
        db.prepare("UPDATE ingredients SET purchase_price=?, updated_at=datetime('now') WHERE id=?").run(price, l.ingredient_id);
        recordPrice(l.ingredient_id, price, db);
      }
      db.prepare('UPDATE purchase_order_lines SET received_qty=received_qty+?, price=? WHERE id=?').run(r.qty, price, r.line_id);
    }
    const open = (db.prepare('SELECT COUNT(*) c FROM purchase_order_lines WHERE po_id=? AND received_qty < qty - 1e-9').get(poId) as { c: number }).c;
    db.prepare("UPDATE purchase_orders SET status=?, received_at=datetime('now'), received_by=? WHERE id=?").run(open ? 'partial' : 'received', user, poId);
  })();
}

export function poText(po: PO, shop: string): string {
  return `${shop} — Đặt hàng ${po.supplier}\nNgày: ${vnDate().split('-').reverse().join('/')}\n` + po.lines.map((l) => `- ${l.name}: ${Math.round(l.qty * 100) / 100} ${l.unit}`).join('\n') + (po.note ? `\nGhi chú: ${po.note}` : '') + '\nCảm ơn!';
}

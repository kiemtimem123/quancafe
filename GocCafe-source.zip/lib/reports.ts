import { getDb } from './db';
import { AUTO_NOTE } from './expiry';
import { loadIngredients } from './recipes';
import { vnDate } from './time';

const VN = "datetime(m.created_at, '+7 hours')";

/** Thất thoát theo tháng: hết hạn tự loại, hủy/hao hụt, kiểm kê thiếu. Tiền = lượng × giá nhập hiện tại. */
export function wasteReport(months = 6) {
  const db = getDb();
  const rows = db.prepare(`SELECT strftime('%Y-%m', ${VN}) ym, m.kind, m.note, -m.delta qty, i.id ing_id, i.name, i.unit, COALESCE(m.unit_price, i.purchase_price) price
    FROM stock_moves m JOIN ingredients i ON i.id=m.ingredient_id
    WHERE m.delta < 0 AND (m.kind='waste' OR (m.kind='adjust' AND m.note NOT LIKE 'Tồn ban đầu%'))
      AND ${VN} >= datetime('now', '+7 hours', 'start of month', ?)`).all(`-${Math.max(1, months) - 1} months`) as { ym: string; kind: string; note: string; qty: number; ing_id: number; name: string; unit: string; price: number }[];
  type Cat = 'expired' | 'waste' | 'stocktake';
  const byMonth = new Map<string, Record<Cat, number>>();
  const byIng = new Map<number, { name: string; unit: string; qty: number; cost: number }>();
  for (const r of rows) {
    const cat: Cat = r.kind === 'adjust' ? 'stocktake' : r.note.startsWith(AUTO_NOTE) ? 'expired' : 'waste';
    const cost = r.qty * (r.price || 0);
    const m = byMonth.get(r.ym) ?? { expired: 0, waste: 0, stocktake: 0 };
    m[cat] += cost; byMonth.set(r.ym, m);
    const g = byIng.get(r.ing_id) ?? { name: r.name, unit: r.unit, qty: 0, cost: 0 };
    g.qty += r.qty; g.cost += cost; byIng.set(r.ing_id, g);
  }
  const monthly = [...byMonth].sort((a, b) => b[0].localeCompare(a[0])).map(([ym, v]) => ({ month: ym, ...v, total: v.expired + v.waste + v.stocktake }));
  const top = [...byIng.values()].sort((a, b) => b.cost - a.cost).slice(0, 10);
  const recent = db.prepare(`SELECT ${VN} at, m.kind, m.note, -m.delta qty, i.name, i.unit, COALESCE(m.unit_price, i.purchase_price) price
    FROM stock_moves m JOIN ingredients i ON i.id=m.ingredient_id WHERE m.delta < 0 AND (m.kind='waste' OR (m.kind='adjust' AND m.note NOT LIKE 'Tồn ban đầu%')) ORDER BY m.id DESC LIMIT 30`).all() as { at: string; kind: string; note: string; qty: number; name: string; unit: string; price: number }[];
  return {
    monthly, top,
    recent: recent.map((r) => ({ at: r.at, name: r.name, unit: r.unit, qty: r.qty, cost: r.qty * (r.price || 0), kind: r.kind === 'adjust' ? 'stocktake' : r.note.startsWith(AUTO_NOTE) ? 'expired' : 'waste', note: r.note })),
    total: monthly.reduce((a, m) => a + m.total, 0),
  };
}

/** Dự báo nhập hàng từ mức tiêu thụ bình quân (mặc định 28 ngày gần nhất). */
export function forecast(window = 28, horizon = 14) {
  const db = getDb();
  const cons = new Map((db.prepare(`SELECT ingredient_id id, SUM(-delta) q, MIN(created_at) first FROM stock_moves WHERE kind IN ('brew','prep_use') AND delta<0 AND created_at >= datetime('now', ?) GROUP BY ingredient_id`).all(`-${window} day`) as { id: number; q: number; first: string }[]).map((r) => [r.id, r]));
  const firstAny = (db.prepare('SELECT MIN(created_at) f FROM stock_moves').get() as { f: string | null }).f;
  const spanDays = firstAny ? Math.max(7, Math.min(window, Math.ceil((Date.now() - new Date(firstAny.replace(' ', 'T') + 'Z').getTime()) / 864e5))) : window;
  const rows = loadIngredients(db).filter((i) => i.track_stock && !i.has_prep).map((i) => {
    const q = cons.get(i.id)?.q ?? 0;
    const perDay = q / spanDays;
    const daysLeft = perDay > 0 ? i.stock_quantity / perDay : null;
    const need = Math.max(0, perDay * horizon - i.stock_quantity);
    const buy = need > 0 ? Math.max(1, Math.ceil(need * 10) / 10) : 0;
    const overstock = i.track_expiry && i.shelf_life_days > 0 && daysLeft !== null && daysLeft > i.shelf_life_days * 1.2;
    return { id: i.id, name: i.name, unit: i.unit, supplier: i.supplier, stock: i.stock_quantity, per_day: perDay, days_left: daysLeft, buy, cost: Math.round(buy * i.purchase_price), overstock, shelf_life_days: i.shelf_life_days };
  }).filter((r) => r.per_day > 0).sort((a, b) => (a.days_left ?? 1e9) - (b.days_left ?? 1e9));
  return { window: spanDays, horizon, rows, total: rows.reduce((a, r) => a + r.cost, 0) };
}

export function profitReport(month: string) {
  const db = getDb();
  const from = `${month}-01`;
  const to = `${month}-31`;
  const s = db.prepare('SELECT COALESCE(SUM(revenue),0) rev, COALESCE(SUM(quantity*unit_cost),0) cogs, COALESCE(SUM(quantity),0) cups FROM sales WHERE sold_on BETWEEN ? AND ?').get(from, to) as { rev: number; cogs: number; cups: number };
  const fixed = db.prepare('SELECT id, name, amount, active FROM fixed_costs ORDER BY id').all() as { id: number; name: string; amount: number; active: number }[];
  const fixedTotal = fixed.filter((f) => f.active).reduce((a, f) => a + f.amount, 0);
  const waste = wasteReport(12).monthly.find((m) => m.month === month)?.total ?? 0;
  const gross = s.rev - s.cogs;
  const margin = s.rev > 0 ? gross / s.rev : 0;
  const net = gross - waste - fixedTotal;
  const [y, mo] = month.split('-').map(Number);
  const daysInMonth = new Date(y, mo, 0).getDate();
  const today = vnDate();
  const elapsed = today.startsWith(month) ? Number(today.slice(8)) : today > month ? daysInMonth : 0;
  const breakEvenRevenue = margin > 0 ? (fixedTotal + waste) / margin : null;
  return {
    month, revenue: s.rev, cogs: s.cogs, cups: s.cups, gross, margin, waste, fixed, fixed_total: fixedTotal, net,
    break_even_revenue: breakEvenRevenue, break_even_per_day: breakEvenRevenue ? breakEvenRevenue / daysInMonth : null,
    reached: breakEvenRevenue !== null && s.rev >= breakEvenRevenue,
    progress: breakEvenRevenue ? Math.min(1, s.rev / breakEvenRevenue) : 0,
    days_in_month: daysInMonth, days_elapsed: elapsed,
    avg_daily_revenue: elapsed ? s.rev / elapsed : 0,
    projected_revenue: elapsed ? (s.rev / elapsed) * daysInMonth : 0,
  };
}

/** Giờ cao điểm + hiệu suất nhân viên (giờ Việt Nam). */
export function insights(days = 30) {
  const db = getDb();
  const from = vnDate(new Date(Date.now() - (days - 1) * 864e5));
  const hours = db.prepare("SELECT CAST(strftime('%H', datetime(created_at, '+7 hours')) AS INTEGER) h, COUNT(*) n, COALESCE(SUM(total),0) rev FROM orders WHERE status='paid' AND order_date>=? GROUP BY h ORDER BY h").all(from) as { h: number; n: number; rev: number }[];
  const wd = db.prepare("SELECT CAST(strftime('%w', order_date) AS INTEGER) d, COUNT(*) n, COALESCE(SUM(total),0) rev, COUNT(DISTINCT order_date) days FROM orders WHERE status='paid' AND order_date>=? GROUP BY d").all(from) as { d: number; n: number; rev: number; days: number }[];
  const staff = db.prepare(`SELECT user_name name, SUM(status='paid') n, COALESCE(SUM(CASE WHEN status='paid' THEN total END),0) rev, COALESCE(SUM(CASE WHEN status='paid' THEN discount END),0) disc, SUM(status='void') voids,
      (SELECT COALESCE(SUM(i.quantity),0) FROM order_items i JOIN orders o2 ON o2.id=i.order_id WHERE o2.user_name=orders.user_name AND o2.status='paid' AND o2.order_date>=?) cups
    FROM orders WHERE order_date>=? GROUP BY user_name ORDER BY rev DESC`).all(from, from) as { name: string; n: number; rev: number; disc: number; voids: number; cups: number }[];
  const fullHours = Array.from({ length: 24 }, (_, h) => hours.find((x) => x.h === h) ?? { h, n: 0, rev: 0 });
  const peak = [...fullHours].sort((a, b) => b.n - a.n).filter((x) => x.n > 0).slice(0, 3);
  const DOWN = ['Chủ nhật', 'Thứ hai', 'Thứ ba', 'Thứ tư', 'Thứ năm', 'Thứ sáu', 'Thứ bảy'];
  const weekdays = [1, 2, 3, 4, 5, 6, 0].map((d) => { const r = wd.find((x) => x.d === d); return { d, label: DOWN[d], n: r?.n ?? 0, rev: r?.rev ?? 0, avg_rev: r && r.days ? r.rev / r.days : 0 }; });
  return { from, days, hours: fullHours, peak, weekdays, staff: staff.map((s) => ({ ...s, avg: s.n ? s.rev / s.n : 0 })) };
}

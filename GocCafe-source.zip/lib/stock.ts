import type Database from 'better-sqlite3';
import { getDb } from './db';
import { addDays, consumeFefo, type Batch } from './batches-pure';
import { vnDate } from './time';

export type MoveKind = 'purchase' | 'adjust' | 'brew' | 'prep_use' | 'prep_make' | 'import' | 'waste' | 'edit';
export const MOVE_LABEL: Record<MoveKind, string> = {
  purchase: 'Nhập kho', adjust: 'Kiểm kê', brew: 'Pha chế', prep_use: 'Dùng làm mẻ', prep_make: 'Thu được từ mẻ', import: 'Nhập Excel', waste: 'Hao hụt / hủy', edit: 'Sửa tay',
};

/** Thay đổi tồn kho (theo đơn vị mua) và ghi sổ kho. Trả về tồn mới. */
export function moveStock(ingredientId: number, delta: number, kind: MoveKind, opts: { note?: string; unitPrice?: number | null; user?: string; db?: Database.Database; batch?: { expires_on?: string | null; received_on?: string }; skipBatches?: boolean } = {}): number {
  const db = opts.db ?? getDb();
  const cur = db.prepare('SELECT stock_quantity, track_expiry, shelf_life_days FROM ingredients WHERE id=?').get(ingredientId) as { stock_quantity: number; track_expiry: number; shelf_life_days: number } | undefined;
  if (!cur) throw new Error('Nguyên liệu không tồn tại');
  const next = Math.max(0, Math.round((cur.stock_quantity + delta) * 1e6) / 1e6);
  db.prepare("UPDATE ingredients SET stock_quantity=?, updated_at=datetime('now') WHERE id=?").run(next, ingredientId);
  db.prepare('INSERT INTO stock_moves (ingredient_id, kind, delta, balance, unit_price, note, user_name) VALUES (?,?,?,?,?,?,?)')
    .run(ingredientId, kind, next - cur.stock_quantity, next, opts.unitPrice ?? null, opts.note ?? '', opts.user ?? '');
  const real = next - cur.stock_quantity;
  if (real < -1e-12 && !opts.skipBatches) {
    const open = db.prepare('SELECT * FROM batches WHERE ingredient_id=? AND qty>0').all(ingredientId) as Batch[];
    const upd = db.prepare('UPDATE batches SET qty=? WHERE id=?');
    for (const t of consumeFefo(open, -real)) upd.run(Math.max(0, open.find((b) => b.id === t.id)!.qty - t.take), t.id);
  } else if (real > 1e-12 && cur.track_expiry && (kind === 'purchase' || kind === 'prep_make')) {
    const today = vnDate();
    const expires = opts.batch ? opts.batch.expires_on ?? null : cur.shelf_life_days > 0 ? addDays(today, cur.shelf_life_days) : null;
    if (opts.batch || expires) {
      db.prepare('INSERT INTO batches (ingredient_id, qty, received_on, expires_on, unit_price, note) VALUES (?,?,?,?,?,?)')
        .run(ingredientId, real, opts.batch?.received_on ?? today, expires, opts.unitPrice ?? null, opts.note ?? '');
    }
  }
  return next;
}

/** Ghi lịch sử giá nếu giá thay đổi. Trả về giá cũ (hoặc null nếu chưa có). */
export function recordPrice(ingredientId: number, price: number, db: Database.Database = getDb()): number | null {
  const last = db.prepare('SELECT price FROM price_history WHERE ingredient_id=? ORDER BY id DESC LIMIT 1').get(ingredientId) as { price: number } | undefined;
  if (last && Math.abs(last.price - price) < 1e-9) return last.price;
  db.prepare('INSERT INTO price_history (ingredient_id, price) VALUES (?,?)').run(ingredientId, price);
  return last?.price ?? null;
}

import type { Recipe, SizeDetail } from './types';

/** Phần dùng chung cho cả server lẫn trình duyệt (không phụ thuộc cơ sở dữ liệu). */
export interface Prep { ingredient_id: number; yield_qty: number; instructions: string; lines: { component_id: number; quantity: number; unit: string }[] }
/** Size đại diện (ưu tiên M) */
export function mainSize(r: Recipe): SizeDetail | undefined {
  return r.sizes.find((s) => s.name === 'M') ?? r.sizes[0];
}

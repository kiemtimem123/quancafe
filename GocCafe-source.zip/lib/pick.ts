import type { Recipe, SizeDetail } from './types';
export const mainOf = (r: Recipe): SizeDetail | undefined => r.sizes.find((s) => s.name === 'M') ?? r.sizes[0];

import type { Ingredient, MatchResult, Recipe } from './types';
import type { SessionUser } from './roles';
import { can } from './roles';

export const canSeeCost = (u: SessionUser) => can(u.role, 'view_cost');

export function redactRecipe(r: Recipe): Recipe {
  return {
    ...r,
    sizes: r.sizes.map((s) => ({
      ...s, raw_cost: 0, waste_cost: 0, cost: 0, profit: 0, margin: 0, cost_ratio: 0,
      lines: s.lines.map((l) => ({ ...l, cost: 0 })),
    })),
  };
}
export const redactIngredient = (i: Ingredient): Ingredient => ({ ...i, purchase_price: 0, unit_cost: 0, supplier: '' });
export const redactMatch = (m: MatchResult): MatchResult => ({ ...m, recipe: redactRecipe(m.recipe) });

import crypto from 'crypto';
import { getDb } from './db';
import { ApiError } from './api';
import { loadRecipes, loadIngredients } from './recipes';
import { loadOptions } from './options';
import { readSettings } from './settings';
import { createOrder, type NewOrder } from './orders';
import { audit } from './audit';
import { notifyNewCustomerOrder } from './notify';
import { normPhone, validPhone } from './loyalty-pure';
import { vnDate } from './time';
import { bankConfigured } from './vietqr';
import type { SessionUser } from './roles';

export interface CoItem { recipe_id: number; name: string; size: 'S' | 'M' | 'L'; quantity: number; unit_price: number; note: string; options: { id: number; name: string; price: number; qty: number }[] }
export interface CustomerOrder {
  id: number; code: string; status: 'pending' | 'accepted' | 'rejected'; table_name: string; note: string; customer_name: string; customer_phone: string;
  pay_pref: 'cash' | 'transfer'; items: CoItem[]; total: number; order_id: number | null; order_code: string; reject_reason: string; decided_by: string; created_at: string; decided_at: string | null;
}
const MAX_PENDING = 40;
const hits = new Map<string, number[]>();

/** Giới hạn tần suất theo IP: tối đa 6 đơn / 10 phút. */
function rateLimit(ip: string) {
  const now = Date.now(); const arr = (hits.get(ip) ?? []).filter((t) => now - t < 600_000);
  if (arr.length >= 6) throw new ApiError(429, 'Bạn gửi đơn quá nhanh. Vui lòng đợi vài phút hoặc gọi nhân viên.');
  arr.push(now); hits.set(ip, arr);
  if (hits.size > 5000) for (const [k, v] of hits) if (!v.some((t) => now - t < 600_000)) hits.delete(k);
}

const row = (r: Record<string, unknown>): CustomerOrder => ({ ...(r as unknown as CustomerOrder), items: JSON.parse(String(r.items)) as CoItem[] });
const tableNames = (n: number) => ['Mang đi', ...Array.from({ length: n }, (_, i) => `Bàn ${i + 1}`)];

/** Thực đơn công khai cho khách: không có giá vốn, tồn kho hay dữ liệu nội bộ. */
export function publicMenu() {
  const s = readSettings();
  if (!s.qr_order) return { enabled: false as const, shop_name: s.shop_name };
  const db = getDb();
  const ings = loadIngredients(db);
  const recipes = loadRecipes(db).filter((r) => r.sizes.some((z) => z.selling_price > 0));
  const bank = bankConfigured({ bank_bin: s.bank_bin, bank_account: s.bank_account }) ? { bank_bin: s.bank_bin, bank_account: s.bank_account, bank_holder: s.bank_holder } : null;
  return {
    enabled: true as const, shop_name: s.shop_name, tables: tableNames(s.table_count), bank,
    items: recipes.map((r) => ({
      id: r.id, name: r.name, category: r.category, image: r.image, description: r.description,
      sold_out: r.availability?.status === 'out',
      sizes: r.sizes.filter((z) => z.selling_price > 0).map((z) => ({ name: z.name, price: z.selling_price })),
    })),
    options: loadOptions(db, ings).filter((o) => o.active && o.available).map((o) => ({ id: o.id, name: o.name, price: o.price })),
  };
}

export interface SubmitInput {
  table_name: string; note?: string; pay_pref: 'cash' | 'transfer'; customer_name?: string; customer_phone?: string;
  items: { recipe_id: number; size: 'S' | 'M' | 'L'; quantity: number; note?: string; options?: { id: number; qty: number }[] }[];
}

export function submitCustomerOrder(input: SubmitInput, ip: string) {
  const s = readSettings();
  if (!s.qr_order) throw new ApiError(403, 'Quán chưa bật tính năng đặt món qua QR.');
  if (!tableNames(s.table_count).includes(input.table_name)) throw new ApiError(400, 'Bàn không hợp lệ. Vui lòng quét lại mã QR trên bàn.');
  rateLimit(ip);
  const db = getDb();
  if ((db.prepare("SELECT COUNT(*) c FROM customer_orders WHERE status='pending'").get() as { c: number }).c >= MAX_PENDING) throw new ApiError(429, 'Quán đang nhận quá nhiều đơn chờ. Vui lòng gọi nhân viên.');
  const recipes = new Map(loadRecipes(db).map((r) => [r.id, r]));
  const opts = new Map(loadOptions(db).map((o) => [o.id, o]));
  const items: CoItem[] = []; let total = 0;
  for (const it of input.items) {
    const r = recipes.get(it.recipe_id);
    const sz = r?.sizes.find((z) => z.name === it.size);
    if (!r || !sz || sz.selling_price <= 0) throw new ApiError(400, 'Có món không còn trong thực đơn. Vui lòng tải lại trang.');
    if (r.availability?.status === 'out') throw new ApiError(409, `${r.name} đã hết. Vui lòng chọn món khác.`);
    const os = (it.options ?? []).map((o) => {
      const x = opts.get(o.id);
      if (!x || !x.active || !x.available) throw new ApiError(409, 'Có topping đã hết. Vui lòng chọn lại.');
      return { id: x.id, name: x.name, price: x.price, qty: o.qty };
    });
    const unit = sz.selling_price + os.reduce((a, o) => a + o.price * o.qty, 0);
    total += unit * it.quantity;
    items.push({ recipe_id: r.id, name: r.name, size: it.size, quantity: it.quantity, unit_price: unit, note: (it.note ?? '').trim().slice(0, 120), options: os });
  }
  const phone = input.customer_phone ? normPhone(input.customer_phone) : '';
  if (phone && !validPhone(phone)) throw new ApiError(400, 'Số điện thoại không hợp lệ');
  const token = crypto.randomBytes(16).toString('hex');
  const today = vnDate();
  const n = (db.prepare("SELECT COUNT(*) c FROM customer_orders WHERE date(created_at,'+7 hours')=?").get(today) as { c: number }).c + 1;
  const code = `K${today.slice(8, 10)}${today.slice(5, 7)}-${String(n).padStart(3, '0')}`;
  const id = Number(db.prepare(`INSERT INTO customer_orders (code, token, table_name, note, customer_name, customer_phone, pay_pref, items, total) VALUES (?,?,?,?,?,?,?,?,?)`)
    .run(code, token, input.table_name, (input.note ?? '').trim().slice(0, 200), (input.customer_name ?? '').trim().slice(0, 60), phone, input.pay_pref, JSON.stringify(items), total).lastInsertRowid);
  notifyNewCustomerOrder({ code, table_name: input.table_name, total, customer_name: input.customer_name?.trim(), customer_phone: phone, note: input.note?.trim(),
    lines: items.map((i) => `• ${i.quantity} × ${i.name} (${i.size})${i.options.length ? ' + ' + i.options.map((x) => x.name).join(', ') : ''}${i.note ? ` — ${i.note}` : ''}`) });
  return { id, code, token, total };
}

/** Khách xem trạng thái đơn của mình (cần token riêng, không đoán được). */
export function customerOrderStatus(id: number, token: string) {
  const r = getDb().prepare('SELECT * FROM customer_orders WHERE id=? AND token=?').get(id, token) as Record<string, unknown> | undefined;
  if (!r) throw new ApiError(404, 'Không tìm thấy đơn');
  const o = row(r);
  return { code: o.code, status: o.status, total: o.total, table_name: o.table_name, pay_pref: o.pay_pref, order_code: o.order_code, reject_reason: o.reject_reason, items: o.items };
}

export function listCustomerOrders(status: 'pending' | 'recent') {
  const db = getDb();
  const rows = status === 'pending'
    ? db.prepare("SELECT * FROM customer_orders WHERE status='pending' ORDER BY id").all()
    : db.prepare("SELECT * FROM customer_orders WHERE status!='pending' AND date(created_at,'+7 hours')=? ORDER BY id DESC LIMIT 50").all(vnDate());
  return (rows as Record<string, unknown>[]).map((r) => { const { token: _t, ...rest } = r; void _t; return row(rest); });
}
export const pendingCount = () => (getDb().prepare("SELECT COUNT(*) c FROM customer_orders WHERE status='pending'").get() as { c: number }).c;

export function decideCustomerOrder(id: number, d: { action: 'accept' | 'reject'; payment?: 'cash' | 'transfer'; reason?: string; force?: boolean }, user: SessionUser, canForce: boolean) {
  const db = getDb();
  const r = db.prepare('SELECT * FROM customer_orders WHERE id=?').get(id) as Record<string, unknown> | undefined;
  if (!r) throw new ApiError(404, 'Không tìm thấy đơn');
  const co = row(r);
  if (co.status !== 'pending') throw new ApiError(409, 'Đơn này đã được xử lý rồi');
  if (d.action === 'reject') {
    db.prepare("UPDATE customer_orders SET status='rejected', reject_reason=?, decided_by=?, decided_at=datetime('now') WHERE id=?").run((d.reason ?? '').slice(0, 120), user.name, id);
    audit(user, 'update', 'order', null, `Từ chối đơn khách đặt ${co.code}${d.reason ? `: ${d.reason}` : ''}`);
    return { status: 'rejected' as const };
  }
  const input: NewOrder = {
    key: `co-${id}`, table_name: co.table_name, payment: d.payment ?? co.pay_pref, force: d.force,
    note: [`Khách đặt qua QR (${co.code})`, co.customer_name, co.note].filter(Boolean).join(' · ').slice(0, 200),
    customer: co.customer_phone ? { phone: co.customer_phone, name: co.customer_name || undefined } : undefined,
    items: co.items.map((i) => ({ recipe_id: i.recipe_id, size: i.size, quantity: i.quantity, note: i.note || undefined, options: i.options.length ? i.options.map((o) => ({ id: o.id, qty: o.qty })) : undefined })),
  };
  const order = createOrder(input, user, canForce);
  db.prepare("UPDATE customer_orders SET status='accepted', order_id=?, order_code=?, decided_by=?, decided_at=datetime('now') WHERE id=?").run(order.id, order.code, user.name, id);
  return { status: 'accepted' as const, order };
}

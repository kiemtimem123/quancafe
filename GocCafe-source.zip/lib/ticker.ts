import path from 'path';
import { autoBackupIfNeeded, backupDir } from './backup';
import { buildDailyReport } from './daily-report';
import { sweepExpired } from './expiry';
import { getNotify, emailReady, telegramReady, sendAll, sendEmail, sendTelegram } from './notify';
import { getSetting, } from './settings';
import { setSettingRaw } from './settings-write';

const vnNow = () => new Date(Date.now() + 7 * 3600_000);

/** Gửi file sao lưu qua kênh đã chọn (n_backup_send: none|telegram|email|both). */
export async function sendBackup(file: string): Promise<{ sent: string[]; errors: string[] }> {
  const mode = getNotify().n_backup_send || 'none';
  const sent: string[] = []; const errors: string[] = [];
  const cap = `💾 Sao lưu Góc Cafe: ${path.basename(file)}`;
  if ((mode === 'telegram' || mode === 'both') && telegramReady()) { const r = await sendTelegram(cap, file); (r.ok ? sent : errors).push(r.ok ? 'Telegram' : `Telegram: ${r.error}`); }
  if ((mode === 'email' || mode === 'both') && emailReady()) { const r = await sendEmail('Sao lưu Góc Cafe', cap, undefined, file); (r.ok ? sent : errors).push(r.ok ? 'Email' : `Email: ${r.error}`); }
  return { sent, errors };
}

async function reportIfDue() {
  const c = getNotify();
  if (c.n_report_enabled !== '1') return;
  const now = vnNow(); const today = now.toISOString().slice(0, 10);
  const hhmm = now.toISOString().slice(11, 16);
  if (hhmm < (c.n_report_time || '22:00') || getSetting('n_report_last') === today) return;
  setSettingRaw('n_report_last', today);
  const { subject, text } = buildDailyReport(today);
  await sendAll(subject, text);
}

let started = false;
export function startTicker() {
  if (started) return; started = true;
  const tick = async () => {
    try { sweepExpired(); } catch (e) { console.error('sweep', e); }
    try { const b = await autoBackupIfNeeded(); if (b) await sendBackup(path.join(backupDir(), b.name)); } catch (e) { console.error('backup', e); }
    try { await reportIfDue(); } catch (e) { console.error('report', e); }
  };
  setTimeout(tick, 15_000);
  setInterval(tick, 5 * 60_000).unref?.();
}

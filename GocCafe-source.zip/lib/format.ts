export const vnd = (n: number) => Math.round(n).toLocaleString('vi-VN') + 'đ';
export const num = (n: number, d = 1) => (Math.round(n * 10 ** d) / 10 ** d).toLocaleString('vi-VN');
export const pct = (n: number) => `${Math.round(n)}%`;
/** Bỏ dấu tiếng Việt để tìm kiếm */
export const norm = (s: string) =>
  (s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/g, 'd').trim();

import type { Ingredient, SizeDetail } from './types';

export interface Consumption {
  deduct: Map<number, number>; // ingredient id -> lượng trừ (đơn vị cơ bản)
  short: string[]; // nguyên liệu không đủ
  substitutes: string[];
}

/** Bộ mô phỏng trừ kho: dùng chung cho "Pha món này" và đơn hàng (nhiều món cùng lúc, có nguyên liệu thay thế). */
export function makeConsumer(ings: Ingredient[]) {
  const byId = new Map(ings.map((i) => [i.id, i]));
  const left = new Map(ings.map((i) => [i.id, i.stock_quantity * i.pack_size]));
  const res: Consumption = { deduct: new Map(), short: [], substitutes: [] };
  const take = (id: number, amt: number) => {
    const t = Math.min(left.get(id)!, amt);
    if (t > 0) { left.set(id, left.get(id)! - t); res.deduct.set(id, (res.deduct.get(id) ?? 0) + t); }
    return t;
  };
  /** Trừ `need` (đơn vị cơ bản) của một nguyên liệu, tự dùng nguyên liệu cùng nhóm thay thế nếu thiếu. */
  const useIng = (ing: Ingredient, need: number, optional: boolean, force: boolean) => {
    if (!ing.track_stock) return;
    need -= take(ing.id, need);
    if (need > 1e-9 && ing.group_name) {
      const mates = ings.filter((m) => m.id !== ing.id && m.group_name === ing.group_name && m.base_unit === ing.base_unit && m.track_stock).sort((a, b) => left.get(b.id)! - left.get(a.id)!);
      for (const m of mates) {
        if (need <= 1e-9) break;
        const t = take(m.id, need);
        if (t > 0) { need -= t; res.substitutes.push(`${m.name} thay ${ing.name}`); }
      }
    }
    if (need > 1e-9 && !optional) {
      if (!res.short.includes(ing.name)) res.short.push(ing.name);
      if (force) res.deduct.set(ing.id, (res.deduct.get(ing.id) ?? 0) + need);
    }
  };
  return {
    res,
    /** Trừ nguyên liệu cho `quantity` ly của một size. force = cho phép thiếu (trừ về 0). */
    use(sz: SizeDetail, quantity: number, force = false) {
      for (const l of sz.lines) {
        const ing = byId.get(l.ingredient_id);
        if (ing) useIng(ing, l.base_qty * quantity, l.optional, force);
      }
    },
    /** Trừ một nguyên liệu lẻ (topping/tuỳ chọn) — `need` tính theo đơn vị cơ bản. */
    useIngredient(ingredientId: number, need: number, force = false) {
      const ing = byId.get(ingredientId);
      if (ing && need > 0) useIng(ing, need, false, force);
    },
  };
}

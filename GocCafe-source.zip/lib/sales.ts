import ExcelJS from 'exceljs';
import { norm } from './format';
import { getDb } from './db';
import { loadRecipes } from './recipes';
import { parseNum } from './ingredient-import';
import { SIZES, type Size } from './types';

export interface SaleRow { row: number; date: string; recipe: string; size: Size; quantity: number; revenue?: number; recipe_id?: number; error?: string }

const cellText = (v: ExcelJS.CellValue): string => {
  if (v == null) return '';
  if (v instanceof Date) return v.toISOString().slice(0, 10);
  if (typeof v === 'object') {
    if ('result' in v) return cellText(v.result as ExcelJS.CellValue);
    if ('richText' in v) return v.richText.map((t) => t.text).join('');
    if ('text' in v) return String(v.text);
    return '';
  }
  return String(v).trim();
};
export function parseDate(v: ExcelJS.CellValue): string | null {
  if (v instanceof Date && !isNaN(+v)) return v.toISOString().slice(0, 10);
  const s = cellText(v);
  let m = /^(\d{4})-(\d{1,2})-(\d{1,2})/.exec(s);
  if (m) return `${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}`;
  m = /^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$/.exec(s);
  if (m) return `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`;
  return null;
}
const FIELDS: Record<string, string[]> = { date: ['ngay', 'ngay ban', 'date'], recipe: ['mon', 'ten mon', 'san pham'], size: ['size'], qty: ['so luong', 'sl', 'so ly'], revenue: ['doanh thu', 'thanh tien', 'tong tien'] };

export async function parseSalesFile(buf: Buffer): Promise<SaleRow[]> {
  if (buf.length < 4 || buf[0] !== 0x50 || buf[1] !== 0x4b) throw new Error('File không phải Excel (.xlsx).');
  const wb = new ExcelJS.Workbook();
  try { await wb.xlsx.load(buf as unknown as ExcelJS.Buffer); } catch { throw new Error('Không đọc được file Excel.'); }
  const ws = wb.worksheets[0];
  if (!ws) throw new Error('File không có sheet nào');
  let hr = 0; const cols: Record<string, number> = {};
  for (let r = 1; r <= Math.min(ws.rowCount, 30) && !hr; r++) {
    const found: Record<string, number> = {};
    ws.getRow(r).eachCell((c, col) => { const t = norm(cellText(c.value).replace(/\(.*?\)/g, '')).replace(/\s+/g, ' '); for (const [k, l] of Object.entries(FIELDS)) if (l.includes(t) && !(k in found)) found[k] = col; });
    if (found.date && found.recipe && found.qty) { hr = r; Object.assign(cols, found); }
  }
  if (!hr) throw new Error('Không thấy dòng tiêu đề. File cần các cột: Ngày, Món, Số lượng (tuỳ chọn: Size, Doanh thu). Tải file mẫu để xem.');
  const rows: SaleRow[] = [];
  const recipes = new Map(loadRecipes().map((r) => [norm(r.name), r]));
  for (let r = hr + 1; r <= ws.rowCount; r++) {
    const row = ws.getRow(r);
    const name = cellText(row.getCell(cols.recipe).value).replace(/\s+/g, ' ');
    if (!name) continue;
    if (rows.length >= 5000) throw new Error('Tối đa 5000 dòng mỗi lần nhập.');
    const date = parseDate(row.getCell(cols.date).value);
    const sizeRaw = cols.size ? cellText(row.getCell(cols.size).value).toUpperCase() || 'M' : 'M';
    const q = parseNum(row.getCell(cols.qty).value);
    const rev = cols.revenue ? parseNum(row.getCell(cols.revenue).value) : NaN;
    const rec = recipes.get(norm(name));
    const s: SaleRow = { row: r, date: date ?? '', recipe: name, size: (SIZES as readonly string[]).includes(sizeRaw) ? (sizeRaw as Size) : 'M', quantity: q, revenue: isFinite(rev) ? rev : undefined, recipe_id: rec?.id };
    if (!date) s.error = 'Ngày không hợp lệ (dùng dd/mm/yyyy)';
    else if (!(SIZES as readonly string[]).includes(sizeRaw)) s.error = `Size "${sizeRaw}" không hợp lệ`;
    else if (!isFinite(q) || q <= 0 || !Number.isInteger(q) || q > 10000) s.error = 'Số lượng phải là số nguyên dương';
    else if (!rec) s.error = 'Không có món này trong hệ thống';
    else if (!rec.sizes.some((z) => z.name === s.size)) s.error = `Món chưa có size ${s.size}`;
    rows.push(s);
  }
  return rows;
}

export function insertSales(rows: SaleRow[], source: string): number {
  const db = getDb();
  const recipes = new Map(loadRecipes(db).map((r) => [r.id, r]));
  const ins = db.prepare('INSERT INTO sales (recipe_id, recipe_name, category, size, quantity, revenue, unit_cost, sold_on, source) VALUES (?,?,?,?,?,?,?,?,?)');
  let n = 0;
  db.transaction(() => {
    for (const s of rows) {
      if (s.error || !s.recipe_id) continue;
      const r = recipes.get(s.recipe_id)!; const sz = r.sizes.find((z) => z.name === s.size)!;
      ins.run(r.id, r.name, r.category, s.size, s.quantity, s.revenue ?? sz.selling_price * s.quantity, Math.round(sz.cost), s.date, source);
      n++;
    }
  })();
  return n;
}

export interface Agg { key: string; qty: number; revenue: number; cost: number; profit: number; margin: number }
export function salesReport(from: string, to: string) {
  const db = getDb();
  const rows = db.prepare('SELECT recipe_name, category, quantity q, revenue, unit_cost*quantity cost, sold_on FROM sales WHERE sold_on BETWEEN ? AND ?').all(from, to) as { recipe_name: string; category: string; q: number; revenue: number; cost: number; sold_on: string }[];
  const agg = (keyf: (r: (typeof rows)[number]) => string) => {
    const m = new Map<string, Agg>();
    for (const r of rows) { const k = keyf(r); const a = m.get(k) ?? { key: k, qty: 0, revenue: 0, cost: 0, profit: 0, margin: 0 }; a.qty += r.q; a.revenue += r.revenue; a.cost += r.cost; m.set(k, a); }
    for (const a of m.values()) { a.profit = a.revenue - a.cost; a.margin = a.revenue > 0 ? (a.profit / a.revenue) * 100 : 0; }
    return [...m.values()];
  };
  const by_recipe = agg((r) => r.recipe_name).sort((a, b) => b.profit - a.profit);
  const by_category = agg((r) => r.category).sort((a, b) => b.revenue - a.revenue);
  const by_day = agg((r) => r.sold_on).sort((a, b) => a.key.localeCompare(b.key));
  const total = by_day.reduce((t, d) => ({ qty: t.qty + d.qty, revenue: t.revenue + d.revenue, cost: t.cost + d.cost }), { qty: 0, revenue: 0, cost: 0 });
  // Ma trận menu: phổ biến (≥ 70% mức trung bình) × lợi nhuận/ly (≥ trung bình có trọng số)
  const avgQty = by_recipe.length ? total.qty / by_recipe.length : 0;
  const avgUnit = total.qty ? (total.revenue - total.cost) / total.qty : 0;
  const menu = by_recipe.map((a) => {
    const unit = a.qty ? a.profit / a.qty : 0;
    const pop = a.qty >= avgQty * 0.7, prof = unit >= avgUnit;
    return { name: a.key, qty: a.qty, unit_profit: unit, class: pop && prof ? 'star' : pop ? 'plowhorse' : prof ? 'puzzle' : 'dog' };
  });
  return { from, to, total: { ...total, profit: total.revenue - total.cost, margin: total.revenue ? ((total.revenue - total.cost) / total.revenue) * 100 : 0 }, by_recipe, by_category, by_day, menu };
}

import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';

const globalForDb = globalThis as unknown as { __db?: Database.Database };

const SCHEMA = `
CREATE TABLE IF NOT EXISTS categories (id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, icon TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS ingredients (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  category TEXT NOT NULL DEFAULT 'Khác',
  unit TEXT NOT NULL DEFAULT 'kg',
  base_unit TEXT NOT NULL DEFAULT 'g',
  pack_size REAL NOT NULL DEFAULT 1000,
  purchase_price REAL NOT NULL DEFAULT 0,
  stock_quantity REAL NOT NULL DEFAULT 0,
  minimum_stock REAL NOT NULL DEFAULT 0,
  supplier TEXT DEFAULT '',
  note TEXT DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS recipes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  description TEXT DEFAULT '',
  image TEXT DEFAULT '',
  difficulty TEXT DEFAULT 'Dễ',
  preparation_time INTEGER DEFAULT 3,
  selling_price REAL DEFAULT 0,
  instructions TEXT DEFAULT '[]',
  favorite INTEGER DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS recipe_sizes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  recipe_id INTEGER NOT NULL REFERENCES recipes(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  selling_price REAL NOT NULL DEFAULT 0,
  UNIQUE(recipe_id, name)
);
CREATE TABLE IF NOT EXISTS recipe_ingredients (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  recipe_id INTEGER NOT NULL REFERENCES recipes(id) ON DELETE CASCADE,
  ingredient_id INTEGER NOT NULL REFERENCES ingredients(id) ON DELETE RESTRICT,
  quantity REAL NOT NULL,
  unit TEXT NOT NULL,
  size TEXT NOT NULL DEFAULT 'M'
);
CREATE INDEX IF NOT EXISTS idx_ri_recipe ON recipe_ingredients(recipe_id);
CREATE INDEX IF NOT EXISTS idx_ri_ing ON recipe_ingredients(ingredient_id);
CREATE TABLE IF NOT EXISTS brew_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  recipe_id INTEGER NOT NULL REFERENCES recipes(id) ON DELETE CASCADE,
  size TEXT NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, password TEXT NOT NULL DEFAULT '',
  role TEXT NOT NULL DEFAULT 'staff'
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
CREATE TABLE IF NOT EXISTS preps (
  ingredient_id INTEGER PRIMARY KEY REFERENCES ingredients(id) ON DELETE CASCADE,
  yield_qty REAL NOT NULL,
  instructions TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS prep_lines (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  prep_id INTEGER NOT NULL REFERENCES preps(ingredient_id) ON DELETE CASCADE,
  component_id INTEGER NOT NULL REFERENCES ingredients(id) ON DELETE RESTRICT,
  quantity REAL NOT NULL,
  unit TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS stock_moves (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ingredient_id INTEGER NOT NULL REFERENCES ingredients(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
  delta REAL NOT NULL,
  balance REAL NOT NULL,
  unit_price REAL,
  note TEXT DEFAULT '',
  user_name TEXT DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_moves_ing ON stock_moves(ingredient_id, id);
CREATE TABLE IF NOT EXISTS price_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ingredient_id INTEGER NOT NULL REFERENCES ingredients(id) ON DELETE CASCADE,
  price REAL NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_price_ing ON price_history(ingredient_id, id);
CREATE TABLE IF NOT EXISTS sales (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  recipe_id INTEGER REFERENCES recipes(id) ON DELETE SET NULL,
  recipe_name TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT '',
  size TEXT NOT NULL DEFAULT 'M',
  quantity INTEGER NOT NULL,
  revenue REAL NOT NULL,
  unit_cost REAL NOT NULL DEFAULT 0,
  sold_on TEXT NOT NULL,
  source TEXT NOT NULL DEFAULT 'manual',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_sales_day ON sales(sold_on);
CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  user_name TEXT NOT NULL DEFAULT '',
  action TEXT NOT NULL,
  entity TEXT NOT NULL DEFAULT '',
  entity_id INTEGER,
  summary TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_audit_time ON audit_log(created_at);
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_date TEXT NOT NULL,
  seq INTEGER NOT NULL,
  client_key TEXT UNIQUE,
  status TEXT NOT NULL DEFAULT 'paid',
  table_name TEXT NOT NULL DEFAULT 'Mang đi',
  note TEXT NOT NULL DEFAULT '',
  subtotal REAL NOT NULL,
  discount REAL NOT NULL DEFAULT 0,
  discount_label TEXT NOT NULL DEFAULT '',
  total REAL NOT NULL,
  payment TEXT NOT NULL DEFAULT 'cash',
  cash_received REAL,
  user_id INTEGER,
  user_name TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  voided_at TEXT,
  void_reason TEXT NOT NULL DEFAULT '',
  voided_by TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_orders_date ON orders(order_date, id);
CREATE TABLE IF NOT EXISTS order_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  recipe_id INTEGER,
  name TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT '',
  size TEXT NOT NULL DEFAULT 'M',
  quantity INTEGER NOT NULL,
  unit_price REAL NOT NULL,
  unit_cost REAL NOT NULL DEFAULT 0,
  note TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_items_order ON order_items(order_id);
CREATE TABLE IF NOT EXISTS order_deductions (
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  ingredient_id INTEGER NOT NULL,
  qty REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_deduct_order ON order_deductions(order_id);
CREATE TABLE IF NOT EXISTS shift_closes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  closed_at TEXT NOT NULL DEFAULT (datetime('now')),
  closed_by TEXT NOT NULL DEFAULT '',
  from_order_id INTEGER NOT NULL,
  to_order_id INTEGER NOT NULL,
  order_count INTEGER NOT NULL,
  void_count INTEGER NOT NULL DEFAULT 0,
  cash_total REAL NOT NULL,
  transfer_total REAL NOT NULL,
  discount_total REAL NOT NULL DEFAULT 0,
  opening_cash REAL NOT NULL DEFAULT 0,
  expected_cash REAL NOT NULL,
  counted_cash REAL,
  diff REAL,
  note TEXT NOT NULL DEFAULT ''
);
`;

/** Nguyên liệu không cần theo dõi hạn: đường trắng, đường phèn, bao bì, ống hút, đồ nhựa. */
const NO_EXPIRY_COND = "category = 'Bao bì' OR name LIKE '%ường trắng%' OR name LIKE '%ường phèn%' OR name LIKE '%ng hút%' OR name LIKE '%nhựa%'";
const NO_EXPIRY_UPDATE = `UPDATE ingredients SET track_expiry=0 WHERE ${NO_EXPIRY_COND}`;
const NO_EXPIRY_TRIGGER_BODY = `UPDATE ingredients SET track_expiry=0 WHERE id=NEW.id AND (${NO_EXPIRY_COND});`;

function migrate(db: Database.Database) {
  db.exec(`
  CREATE TABLE IF NOT EXISTS options (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    price REAL NOT NULL DEFAULT 0,
    ingredient_id INTEGER REFERENCES ingredients(id) ON DELETE SET NULL,
    qty REAL NOT NULL DEFAULT 0,
    active INTEGER NOT NULL DEFAULT 1,
    sort INTEGER NOT NULL DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS promotions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    code TEXT NOT NULL DEFAULT '',
    type TEXT NOT NULL DEFAULT 'percent',
    value REAL NOT NULL DEFAULT 0,
    scope TEXT NOT NULL DEFAULT 'order',
    target TEXT NOT NULL DEFAULT '',
    min_total REAL NOT NULL DEFAULT 0,
    min_qty INTEGER NOT NULL DEFAULT 0,
    time_from TEXT NOT NULL DEFAULT '',
    time_to TEXT NOT NULL DEFAULT '',
    days TEXT NOT NULL DEFAULT '',
    date_from TEXT NOT NULL DEFAULT '',
    date_to TEXT NOT NULL DEFAULT '',
    active INTEGER NOT NULL DEFAULT 1
  );
  CREATE TABLE IF NOT EXISTS customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    phone TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL DEFAULT '',
    points INTEGER NOT NULL DEFAULT 0,
    visits INTEGER NOT NULL DEFAULT 0,
    total_spent REAL NOT NULL DEFAULT 0,
    last_visit TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS reset_codes (
    user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    code_hash TEXT NOT NULL,
    expires_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS purchase_orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    supplier TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'draft',
    note TEXT NOT NULL DEFAULT '',
    created_by TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    received_at TEXT,
    received_by TEXT NOT NULL DEFAULT ''
  );
  CREATE TABLE IF NOT EXISTS purchase_order_lines (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    po_id INTEGER NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
    ingredient_id INTEGER NOT NULL REFERENCES ingredients(id) ON DELETE CASCADE,
    qty REAL NOT NULL,
    price REAL NOT NULL DEFAULT 0,
    received_qty REAL NOT NULL DEFAULT 0
  );
  CREATE INDEX IF NOT EXISTS idx_pol_po ON purchase_order_lines(po_id);
  CREATE TABLE IF NOT EXISTS fixed_costs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    amount REAL NOT NULL DEFAULT 0,
    active INTEGER NOT NULL DEFAULT 1
  );`);
  db.exec('CREATE TABLE IF NOT EXISTS op_keys (key TEXT PRIMARY KEY, created_at TEXT NOT NULL DEFAULT (datetime(\'now\')))');
  const cols = (db.prepare('PRAGMA table_info(users)').all() as { name: string }[]).map((c) => c.name);
  if (!cols.includes('active')) db.exec('ALTER TABLE users ADD COLUMN active INTEGER NOT NULL DEFAULT 1');
  if (!cols.includes('created_at')) db.exec("ALTER TABLE users ADD COLUMN created_at TEXT");
  const oc = (db.prepare('PRAGMA table_info(orders)').all() as { name: string }[]).map((c) => c.name);
  if (!oc.includes('customer_id')) {
    db.exec("ALTER TABLE orders ADD COLUMN customer_id INTEGER");
    db.exec("ALTER TABLE orders ADD COLUMN customer_phone TEXT NOT NULL DEFAULT ''");
    db.exec("ALTER TABLE orders ADD COLUMN customer_name TEXT NOT NULL DEFAULT ''");
    db.exec("ALTER TABLE orders ADD COLUMN points_earned INTEGER NOT NULL DEFAULT 0");
    db.exec("ALTER TABLE orders ADD COLUMN points_used INTEGER NOT NULL DEFAULT 0");
  }
  const oic = (db.prepare('PRAGMA table_info(order_items)').all() as { name: string }[]).map((c) => c.name);
  if (!oic.includes('options')) db.exec("ALTER TABLE order_items ADD COLUMN options TEXT NOT NULL DEFAULT '[]'");
  if (!cols.includes('totp_secret')) {
    db.exec("ALTER TABLE users ADD COLUMN totp_secret TEXT NOT NULL DEFAULT ''");
    db.exec("ALTER TABLE users ADD COLUMN totp_enabled INTEGER NOT NULL DEFAULT 0");
    db.exec("ALTER TABLE users ADD COLUMN recovery TEXT NOT NULL DEFAULT '[]'");
  }
  const ic = (db.prepare('PRAGMA table_info(ingredients)').all() as { name: string }[]).map((c) => c.name);
  if (!ic.includes('group_name')) db.exec("ALTER TABLE ingredients ADD COLUMN group_name TEXT NOT NULL DEFAULT ''");
  if (!ic.includes('track_expiry')) {
    db.exec('ALTER TABLE ingredients ADD COLUMN track_expiry INTEGER NOT NULL DEFAULT 1');
    db.exec('ALTER TABLE ingredients ADD COLUMN shelf_life_days INTEGER NOT NULL DEFAULT 0');
    db.exec(NO_EXPIRY_UPDATE);
  }
  db.exec(`CREATE TABLE IF NOT EXISTS batches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ingredient_id INTEGER NOT NULL REFERENCES ingredients(id) ON DELETE CASCADE,
    qty REAL NOT NULL,
    received_on TEXT NOT NULL,
    expires_on TEXT,
    unit_price REAL,
    note TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_batches_ing ON batches(ingredient_id, expires_on);
  DROP TRIGGER IF EXISTS trg_ing_no_expiry;
  CREATE TRIGGER trg_ing_no_expiry AFTER INSERT ON ingredients BEGIN ${NO_EXPIRY_TRIGGER_BODY} END;`);
  if (!ic.includes('track_stock')) db.exec('ALTER TABLE ingredients ADD COLUMN track_stock INTEGER NOT NULL DEFAULT 1');
  const rc = (db.prepare('PRAGMA table_info(recipe_ingredients)').all() as { name: string }[]).map((c) => c.name);
  if (!rc.includes('optional')) db.exec('ALTER TABLE recipe_ingredients ADD COLUMN optional INTEGER NOT NULL DEFAULT 0');
  const sc = (db.prepare('PRAGMA table_info(sales)').all() as { name: string }[]).map((c) => c.name);
  if (!sc.includes('order_id')) db.exec('ALTER TABLE sales ADD COLUMN order_id INTEGER');
  db.exec('CREATE INDEX IF NOT EXISTS idx_sales_order ON sales(order_id)');
  db.exec(`CREATE TABLE IF NOT EXISTS customer_orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT NOT NULL,
    token TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    table_name TEXT NOT NULL DEFAULT 'Mang đi',
    note TEXT NOT NULL DEFAULT '',
    customer_name TEXT NOT NULL DEFAULT '',
    customer_phone TEXT NOT NULL DEFAULT '',
    pay_pref TEXT NOT NULL DEFAULT 'cash',
    items TEXT NOT NULL,
    total REAL NOT NULL DEFAULT 0,
    order_id INTEGER,
    order_code TEXT NOT NULL DEFAULT '',
    reject_reason TEXT NOT NULL DEFAULT '',
    decided_by TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    decided_at TEXT
  )`);
  db.exec('CREATE INDEX IF NOT EXISTS idx_co_status ON customer_orders(status, id)');
  // tài khoản mẫu cũ không có mật khẩu → bỏ (người dùng sẽ tạo admin ở lần chạy đầu)
  db.prepare("DELETE FROM users WHERE password = ''").run();
}

export function getDb(): Database.Database {
  if (globalForDb.__db) return globalForDb.__db;
  const dir = (process.env.DATA_DIR || path.join(process.cwd(), 'data'));
  fs.mkdirSync(dir, { recursive: true });
  const db = new Database(process.env.DB_PATH || path.join(dir, 'cafe.db'));
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.exec(SCHEMA);
  migrate(db);
  globalForDb.__db = db;
  const count = (db.prepare('SELECT COUNT(*) c FROM ingredients').get() as { c: number }).c;
  if (count === 0) {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    require('./seed').seedDatabase(db);
  }
  return db;
}

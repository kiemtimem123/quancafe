import crypto from 'crypto';
import { cookies, headers } from 'next/headers';
import { getDb } from './db';
import { can, type Perm, type Role, type SessionUser } from './roles';

export const COOKIE = 'session';
const TTL_MS = 30 * 24 * 3600 * 1000;

export function hashPassword(pw: string): string {
  const salt = crypto.randomBytes(16);
  const h = crypto.scryptSync(pw, salt, 64);
  return `scrypt$${salt.toString('hex')}$${h.toString('hex')}`;
}
const DUMMY = hashPassword('dummy-password-for-timing');
export function verifyPassword(pw: string, stored: string): boolean {
  const [alg, saltHex, hashHex] = (stored || DUMMY).split('$');
  if (alg !== 'scrypt' || !saltHex || !hashHex) return false;
  const expected = Buffer.from(hashHex, 'hex');
  const actual = crypto.scryptSync(pw, Buffer.from(saltHex, 'hex'), expected.length);
  return crypto.timingSafeEqual(actual, expected) && !!stored;
}
export const sha = (s: string) => crypto.createHash('sha256').update(s).digest('hex');

export function createSession(userId: number): { token: string; expires: Date } {
  const token = crypto.randomBytes(32).toString('base64url');
  const expires = new Date(Date.now() + TTL_MS);
  const db = getDb();
  db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(Date.now());
  db.prepare('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?,?,?)').run(sha(token), userId, expires.getTime());
  return { token, expires };
}
export function destroySession(token: string) { getDb().prepare('DELETE FROM sessions WHERE token_hash=?').run(sha(token)); }
export function destroyUserSessions(userId: number, exceptToken?: string) {
  getDb().prepare('DELETE FROM sessions WHERE user_id=? AND token_hash != ?').run(userId, exceptToken ? sha(exceptToken) : '');
}

export async function currentToken(): Promise<string | undefined> { return (await cookies()).get(COOKIE)?.value; }

export async function getSessionUser(): Promise<SessionUser | null> {
  const token = await currentToken();
  if (!token) return null;
  const row = getDb().prepare(`SELECT u.id, u.name, u.email, u.role FROM sessions s JOIN users u ON u.id = s.user_id
    WHERE s.token_hash=? AND s.expires_at > ? AND u.active = 1`).get(sha(token), Date.now()) as SessionUser | undefined;
  return row ?? null;
}

export async function setSessionCookie(token: string, expires: Date) {
  const h = await headers();
  const secure = h.get('x-forwarded-proto') === 'https' || process.env.COOKIE_SECURE === '1';
  (await cookies()).set(COOKIE, token, { httpOnly: true, sameSite: 'lax', secure, path: '/', expires });
}
export async function clearSessionCookie() { (await cookies()).delete(COOKIE); }

export function hasPerm(role: Role, perm?: Perm) { return !perm || can(role, perm); }

// --- chống dò mật khẩu: tối đa 5 lần sai / 10 phút cho mỗi (IP, email) ---
const fails = new Map<string, { n: number; until: number }>();
export async function loginKey(email: string) {
  const h = await headers();
  return `${(h.get('x-forwarded-for') || 'local').split(',')[0].trim()}|${email.toLowerCase()}`;
}
export function isLocked(key: string): number {
  const f = fails.get(key);
  return f && f.until > Date.now() && f.n >= 5 ? Math.ceil((f.until - Date.now()) / 60000) : 0;
}
export function recordFail(key: string) {
  const f = fails.get(key);
  const now = Date.now();
  fails.set(key, !f || f.until < now ? { n: 1, until: now + 10 * 60000 } : { n: f.n + 1, until: now + 10 * 60000 });
}
export const clearFails = (key: string) => fails.delete(key);
export type { Role };

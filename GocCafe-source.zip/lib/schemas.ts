import { z } from 'zod';

export const optionSchema = z.object({
  name: z.string().trim().min(1, 'Nhập tên topping').max(40),
  price: z.coerce.number().min(0).max(1e7),
  ingredient_id: z.number().int().positive().nullable().default(null),
  qty: z.coerce.number().min(0).max(1e6).default(0),
  active: z.boolean().default(true),
});

const hhmm = z.string().regex(/^(([01]\d|2[0-3]):[0-5]\d)?$/, 'Giờ dạng HH:MM');
const ymd = z.string().regex(/^(\d{4}-\d{2}-\d{2})?$/, 'Ngày dạng YYYY-MM-DD');
export const promoSchema = z.object({
  name: z.string().trim().min(1, 'Nhập tên khuyến mãi').max(60),
  code: z.string().trim().max(30).default(''),
  type: z.enum(['percent', 'amount']),
  value: z.coerce.number().gt(0, 'Giá trị phải lớn hơn 0').max(1e9),
  scope: z.enum(['order', 'category', 'recipe', 'combo']).default('order'),
  target: z.string().trim().max(100).default(''),
  min_total: z.coerce.number().min(0).max(1e9).default(0),
  min_qty: z.coerce.number().int().min(0).max(1000).default(0),
  time_from: hhmm.default(''), time_to: hhmm.default(''),
  days: z.string().trim().regex(/^([1-7](,[1-7])*)?$/, 'Ngày trong tuần dạng 1,2,3 (1 = Thứ hai)').default(''),
  date_from: ymd.default(''), date_to: ymd.default(''),
  active: z.boolean().default(true),
}).refine((d) => d.type !== 'percent' || d.value <= 100, 'Phần trăm tối đa 100')
  .refine((d) => d.scope === 'order' || d.target !== '', 'Chọn nhóm/món áp dụng')
  .refine((d) => d.scope !== 'combo' || d.target.split(',').filter(Boolean).length >= 2, 'Combo cần ít nhất 2 món')
  .refine((d) => (!d.time_from) === (!d.time_to), 'Nhập đủ cả giờ bắt đầu và giờ kết thúc');

export const fixedCostSchema = z.object({
  name: z.string().trim().min(1, 'Nhập tên khoản chi').max(60),
  amount: z.coerce.number().min(0).max(1e10),
  active: z.boolean().default(true),
});

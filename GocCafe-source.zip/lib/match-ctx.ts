import { loadIngredients, loadPreps } from './recipes';
import type { MatchCtx } from './match';

export function buildCtx(): MatchCtx {
  const ings = loadIngredients();
  return {
    groups: new Map(ings.filter((i) => i.group_name).map((i) => [i.id, i.group_name])),
    names: new Map(ings.map((i) => [i.id, i.name])),
    cats: new Map(ings.map((i) => [i.id, i.category])),
    preps: loadPreps(),
  };
}


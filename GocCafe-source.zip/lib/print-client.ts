'use client';
/** In hóa đơn/phiếu pha chế bằng iframe ẩn → không bị chặn popup, giữ nguyên màn hình bán hàng. */
export function printReceipt(orderId: number, kind: 'bill' | 'kitchen' | 'both' = 'both'): Promise<void> {
  return new Promise((resolve) => {
    const f = document.createElement('iframe');
    f.setAttribute('aria-hidden', 'true');
    f.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden';
    f.src = `/receipt/${orderId}?kind=${kind}&auto=1`;
    const finish = () => { window.removeEventListener('message', onMsg); setTimeout(() => f.remove(), 500); resolve(); };
    const onMsg = (e: MessageEvent) => { if (e.origin === location.origin && e.data === 'receipt-printed') finish(); };
    window.addEventListener('message', onMsg);
    setTimeout(finish, 120_000);
    document.body.appendChild(f);
  });
}

/** Ngày theo giờ Việt Nam (UTC+7), dạng YYYY-MM-DD — không phụ thuộc múi giờ máy chủ. */
export const vnDate = (d: Date = new Date()) => new Date(d.getTime() + 7 * 3600_000).toISOString().slice(0, 10);

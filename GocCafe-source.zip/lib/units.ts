import type { BaseUnit } from './types';

/** Đổi lượng + đơn vị công thức sang đơn vị cơ bản (g / ml / cái). */
export function unitInfo(unit: string): { base: BaseUnit; factor: number } | null {
  switch (unit) {
    case 'g': return { base: 'g', factor: 1 };
    case 'kg': return { base: 'g', factor: 1000 };
    case 'ml': return { base: 'ml', factor: 1 };
    case 'lít': case 'l': case 'L': return { base: 'ml', factor: 1000 };
    case 'cái': return { base: 'cái', factor: 1 };
    default: return null;
  }
}
export function toBase(qty: number, unit: string): { qty: number; base: BaseUnit } | null {
  const u = unitInfo(unit);
  return u ? { qty: qty * u.factor, base: u.base } : null;
}
/** Gợi ý quy đổi mặc định khi chọn đơn vị mua. */
export function defaultPack(purchaseUnit: string): { base: BaseUnit; pack: number } {
  switch (purchaseUnit) {
    case 'kg': return { base: 'g', pack: 1000 };
    case 'g': return { base: 'g', pack: 1 };
    case 'lít': return { base: 'ml', pack: 1000 };
    case 'ml': return { base: 'ml', pack: 1 };
    case 'cái': return { base: 'cái', pack: 1 };
    default: return { base: 'cái', pack: 1 };
  }
}

import { norm } from './format';
import { loadIngredients, loadRecipes, mainSize } from './recipes';
import { matchRecipes } from './match';
import { buildCtx } from './match-ctx';
import type { Ingredient, Recipe } from './types';
import { toBase } from './units';

const ALIASES: Record<string, string[]> = {
  'ca phe': ['Espresso', 'Cà phê phin'], 'cafe': ['Espresso', 'Cà phê phin'], 'coffee': ['Espresso'],
  'caramel': ['Syrup caramel', 'Sốt caramel'], 'vanilla': ['Syrup vanilla'], 'socola': ['Sốt chocolate', 'Bột cacao'],
  'chocolate': ['Sốt chocolate', 'Bột cacao'], 'cacao': ['Bột cacao'], 'matcha': ['Matcha Đài Loan'], 'da': ['Đá viên'],
  'da vien': ['Đá viên'], 'dau': ['Dâu tây', 'Syrup dâu'], 'dao': ['Đào ngâm', 'Syrup đào'], 'kem': ['Kem béo', 'Kem tươi (whipping)'],
  'oreo': ['Bánh Oreo'], 'tra': ['Trà đen', 'Trà lài'], 'tra sua': ['Cốt trà sữa'], 'tran chau': ['Trân châu'],
};

export interface Mention { ing: Ingredient; qty?: number } // qty theo đơn vị cơ bản

export function parseMentions(text: string, ings: Ingredient[]): Mention[] {
  const t = norm(text);
  const found = new Map<number, number>(); // id -> vị trí
  const byName = new Map(ings.map((i) => [i.name, i]));
  for (const i of ings) {
    const n = norm(i.name).replace(/\(.*?\)/g, '').trim();
    const pos = t.indexOf(n);
    if (n.length > 2 && pos >= 0) found.set(i.id, pos);
  }
  // alias chỉ áp dụng nếu người dùng chưa gọi tên đầy đủ nguyên liệu cùng họ
  for (const [k, names] of Object.entries(ALIASES).sort((a, b) => b[0].length - a[0].length)) {
    const m = new RegExp(`(^|[^a-z0-9])${k}([^a-z0-9]|$)`).exec(t);
    if (!m) continue;
    const pos = m.index + m[1].length;
    const already = names.some((nm) => { const i = byName.get(nm); return i && found.has(i.id); });
    if (already && k !== 'da') continue;
    for (const nm of names) { const i = byName.get(nm); if (i && !found.has(i.id)) found.set(i.id, pos); }
  }
  return [...found].map(([id, pos]) => {
    const ing = ings.find((x) => x.id === id)!;
    const before = t.slice(Math.max(0, pos - 14), pos);
    const after = t.slice(pos + norm(ing.name).length, pos + norm(ing.name).length + 14);
    const mb = /(\d+(?:[.,]\d+)?)\s*(ml|kg|g|lit|l)\s*$/.exec(before) ?? null;
    const ma = /^\s*[:=]?\s*(\d+(?:[.,]\d+)?)\s*(ml|kg|g|lit|l)\b/.exec(after);
    const m = mb ?? ma;
    let qty: number | undefined;
    if (m) {
      const u = m[2] === 'lit' ? 'lít' : m[2];
      const b = toBase(parseFloat(m[1].replace(',', '.')), u);
      if (b && b.base === ing.base_unit) qty = b.qty;
    }
    return { ing, qty };
  });
}

export interface Suggestion {
  id: number; name: string; category: string; percent: number; missing: string[];
  difficulty: string; time: number; cost: number; price: number; profit: number; margin: number;
  lines: { name: string; quantity: number; unit: string }[]; steps: string[];
  max_cups?: number; note?: string; used?: number;
}

function toSuggestion(r: Recipe, percent: number, missing: string[], cups?: number): Suggestion {
  const m = mainSize(r)!;
  return {
    id: r.id, name: r.name, category: r.category, percent, missing, difficulty: r.difficulty, time: r.preparation_time,
    cost: m.cost, price: m.selling_price, profit: m.profit, margin: m.margin,
    lines: m.lines.map((l) => ({ name: l.name, quantity: l.quantity, unit: l.unit })), steps: r.instructions, max_cups: cups,
  };
}

export function localAssistant(text: string) {
  const ings = loadIngredients();
  const recipes = loadRecipes();
  const mentions = parseMentions(text, ings);
  const wantMatch = /(\d+)\s*món/.exec(norm(text));
  const limit = Math.min(10, wantMatch ? Number(wantMatch[1]) : 5);
  if (!mentions.length) {
    return { mode: 'local' as const, reply: 'Mình chưa nhận ra nguyên liệu nào trong câu của bạn. Hãy liệt kê nguyên liệu đang có, ví dụ: "Tôi có cà phê, sữa đặc, sữa tươi, caramel và đá. Gợi ý 5 món dễ bán."', suggestions: [] as Suggestion[], detected: [] as string[] };
  }
  const have = new Set(mentions.map((m) => m.ing.id));
  const withQty = mentions.filter((m) => m.qty !== undefined);
  let list = matchRecipes(recipes, have, new Set(), buildCtx()).filter((m) => m.percent > 0);
  const easy = (d: string) => (d === 'Dễ' ? 0 : d === 'Trung bình' ? 1 : 2);
  const suggestions: Suggestion[] = [];

  if (withQty.length) {
    // chế độ "dùng hết nguyên liệu có định lượng"
    const targets = new Set(withQty.map((m) => m.ing.id));
    list = list.filter((m) => m.required.some((x) => targets.has(x.id)));
    for (const m of list) {
      const sz = mainSize(m.recipe)!;
      let cups = Infinity;
      for (const q of withQty) {
        const line = sz.lines.find((l) => l.ingredient_id === q.ing.id);
        if (line) cups = Math.min(cups, Math.floor(q.qty! / line.base_qty));
      }
      if (!isFinite(cups) || cups < 1) continue;
      const s = toSuggestion(m.recipe, m.percent, m.missing, cups);
      const used = withQty.filter((q) => sz.lines.some((l) => l.ingredient_id === q.ing.id)).length;
      s.used = used;
      s.note = `Dùng ${used}/${withQty.length} nguyên liệu bạn nêu — pha được tối đa ${cups} ly size M.`;
      suggestions.push(s);
    }
    suggestions.sort((a, b) => (b.used ?? 0) - (a.used ?? 0) || (b.max_cups ?? 0) * b.profit - (a.max_cups ?? 0) * a.profit);
  } else {
    const owned = (m: (typeof list)[number]) => m.required.filter((x) => x.have).length;
    list.sort((a, b) => a.missing.length - b.missing.length || owned(b) - owned(a) || b.percent - a.percent || easy(a.recipe.difficulty) - easy(b.recipe.difficulty) || (mainSize(b.recipe)?.margin ?? 0) - (mainSize(a.recipe)?.margin ?? 0));
    for (const m of list) suggestions.push(toSuggestion(m.recipe, m.percent, m.missing));
  }
  const top = suggestions.slice(0, limit);
  const names = mentions.map((m) => m.ing.name);
  const ready = top.filter((s) => s.missing.length === 0).length;
  const reply = top.length
    ? `Dựa trên ${names.join(', ')}, mình gợi ý ${top.length} món${ready ? ` (${ready} món pha được ngay)` : ''}, ưu tiên món dễ pha và lợi nhuận tốt.`
    : 'Với các nguyên liệu này chưa có công thức nào phù hợp. Thử thêm sữa, đường hoặc đá nhé.';
  return { mode: 'local' as const, reply, suggestions: top, detected: names };
}

/** Nếu có ANTHROPIC_API_KEY thì nhờ Claude trả lời tự do, kèm dữ liệu thật của quán. */
export async function aiAssistant(text: string): Promise<string | null> {
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return null;
  const ings = loadIngredients();
  const catalog = ings.map((i) => `- ${i.name} (${i.category}): ${Math.round(i.unit_cost * 100) / 100}đ/${i.base_unit}, tồn ${i.stock_quantity} ${i.unit}`).join('\n');
  const known = loadRecipes().map((r) => r.name).join(', ');
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({
      model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-5',
      max_tokens: 1800,
      system: `Bạn là chuyên gia pha chế cho quán cafe Việt Nam. Trả lời bằng tiếng Việt, ngắn gọn. Với mỗi món đề xuất, ghi: tên món, nguyên liệu + định lượng (ml/g), cách pha từng bước, giá vốn ước tính (dựa trên đơn giá bên dưới), giá bán đề xuất, lợi nhuận, độ dễ pha. Chỉ dùng nguyên liệu người dùng nêu (đá, nước lọc luôn có). Các món đã có trong menu: ${known}.\nBảng nguyên liệu và đơn giá:\n${catalog}`,
      messages: [{ role: 'user', content: text }],
    }),
  });
  if (!res.ok) throw new Error(`Claude API ${res.status}`);
  const data = (await res.json()) as { content?: { type: string; text?: string }[] };
  return data.content?.filter((c) => c.type === 'text').map((c) => c.text).join('\n') ?? null;
}

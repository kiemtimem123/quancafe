import fs from 'fs';
import path from 'path';
import { getDb } from './db';
import { getSetting } from './settings';

export interface BackupInfo { name: string; size: number; created_at: string; kind: string }
const KEEP = 14;

export const backupDir = () => {
  const d = process.env.BACKUP_DIR || path.join(process.env.DATA_DIR || path.join(process.cwd(), 'data'), 'backups');
  fs.mkdirSync(d, { recursive: true });
  return d;
};
const stamp = () => new Date(Date.now() + 7 * 3600_000).toISOString().replace(/[-:]/g, '').replace('T', '-').slice(0, 15);
const info = (name: string): BackupInfo => {
  const st = fs.statSync(path.join(backupDir(), name));
  return { name, size: st.size, created_at: st.mtime.toISOString(), kind: name.includes('-auto') ? 'auto' : name.includes('-before-restore') ? 'restore' : 'manual' };
};

export function listBackups(): BackupInfo[] {
  return fs.readdirSync(backupDir()).filter((n) => /^cafe-.*\.db$/.test(n)).map(info).sort((a, b) => b.created_at.localeCompare(a.created_at));
}
function prune() { for (const b of listBackups().slice(KEEP)) { try { fs.unlinkSync(path.join(backupDir(), b.name)); } catch { /* bỏ qua */ } } }

/** Sao lưu nhất quán (SQLite online backup, an toàn khi đang chạy). */
export async function createBackup(kind: 'manual' | 'auto' | 'before-restore' = 'manual'): Promise<BackupInfo> {
  const name = `cafe-${stamp()}-${kind}.db`;
  await getDb().backup(path.join(backupDir(), name));
  prune();
  return info(name);
}

/** Mỗi ngày tự sao lưu 1 lần; trả về bản mới nếu vừa tạo. */
export async function autoBackupIfNeeded(): Promise<BackupInfo | null> {
  const today = new Date(Date.now() + 7 * 3600_000).toISOString().slice(0, 10);
  const last = listBackups().find((b) => b.kind === 'auto');
  if (last && new Date(last.created_at.slice(0, 10)).getTime() >= new Date(today).getTime() - 0 && new Date(last.created_at.slice(0, 10)).toISOString().slice(0, 10) === today) return null;
  void getSetting;
  return createBackup('auto');
}

/** Khôi phục từ bản sao lưu: lưu bản hiện tại trước, rồi chép đè dữ liệu. */
export async function restoreBackup(name: string) {
  if (!/^cafe-[\w-]+\.db$/.test(name)) throw new Error('Tên bản sao lưu không hợp lệ');
  const src = path.join(backupDir(), name);
  if (!fs.existsSync(src)) throw new Error('Không tìm thấy bản sao lưu');
  await createBackup('before-restore');
  const db = getDb();
  db.exec(`ATTACH DATABASE '${src.replace(/'/g, "''")}' AS bk`);
  try {
    const tables = (db.prepare("SELECT name FROM bk.sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all() as { name: string }[]).map((t) => t.name);
    const mine = new Set((db.prepare("SELECT name FROM main.sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all() as { name: string }[]).map((t) => t.name));
    db.exec('PRAGMA foreign_keys=OFF; BEGIN');
    for (const t of tables) if (mine.has(t)) { db.exec(`DELETE FROM main."${t}"`); db.exec(`INSERT INTO main."${t}" SELECT * FROM bk."${t}"`); }
    db.exec('COMMIT; PRAGMA foreign_keys=ON');
  } catch (e) { try { db.exec('ROLLBACK'); } catch { /* */ } throw e; }
  finally { db.exec('DETACH DATABASE bk'); }
}

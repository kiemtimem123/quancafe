import ExcelJS from 'exceljs';
import { getDb } from './db';
import { getWaste, loadIngredients, loadRecipes } from './recipes';
import { PURCHASE_UNITS } from './types';
import type { Ingredient } from './types';

const BROWN = 'FF6F4E37';
const MONEY = '#,##0"đ"';
const MONEY2 = '#,##0.00"đ"';
const PCT = '0.0%';

function header(ws: ExcelJS.Worksheet, widths: number[]) {
  const r = ws.getRow(1);
  r.height = 26;
  r.eachCell((c) => {
    c.font = { bold: true, color: { argb: 'FFFFFFFF' } };
    c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: BROWN } };
    c.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true };
  });
  widths.forEach((w, i) => { ws.getColumn(i + 1).width = w; });
  ws.views = [{ state: 'frozen', ySplit: 1 }];
}

/** Cột của bảng nguyên liệu — dùng chung cho file mẫu, xuất và nhập (khứ hồi được). */
export const ING_HEADERS = ['Tên nguyên liệu', 'Phân loại', 'Đơn vị mua', 'Đơn vị pha chế', 'Quy cách (1 đơn vị mua = ? đơn vị pha chế)', 'Giá nhập (đ / đơn vị mua)', 'Tồn kho (theo đơn vị mua)', 'Tồn tối thiểu (cảnh báo)', 'Nhà cung cấp', 'Ghi chú', 'Nhóm thay thế'];

export function addIngredientSheet(wb: ExcelJS.Workbook, name: string, ings: Ingredient[]) {
  const ws = wb.addWorksheet(name);
  ws.addRow([...ING_HEADERS, 'Giá / đơn vị pha chế (tự tính)']);
  header(ws, [30, 16, 12, 14, 22, 18, 16, 16, 24, 32, 16, 18]);
  for (const i of ings) ws.addRow([i.name, i.category, i.unit, i.base_unit, i.pack_size, i.purchase_price, i.track_stock === false && !i.stock_quantity ? null : i.stock_quantity, i.minimum_stock, i.supplier, i.note, i.group_name ?? '']);
  const last = Math.max(ws.rowCount, 2);
  for (let r = 2; r <= ws.rowCount; r++) {
    const row = ws.getRow(r);
    const price = Number(row.getCell(6).value) || 0, pack = Number(row.getCell(5).value) || 0;
    row.getCell(12).value = { formula: `IF(E${r}>0,F${r}/E${r},0)`, result: pack > 0 ? price / pack : 0 };
    row.getCell(6).numFmt = MONEY; row.getCell(12).numFmt = MONEY2;
    row.getCell(12).font = { color: { argb: 'FF8B6A50' } };
  }
  ws.autoFilter = { from: 'A1', to: `L${last}` };
  return ws;
}

export async function buildCostReport(shopName: string): Promise<Buffer> {
  const db = getDb();
  const waste = getWaste(db);
  const recipes = loadRecipes(db);
  const ings = loadIngredients(db);
  const wb = new ExcelJS.Workbook();
  wb.creator = shopName; wb.created = new Date();

  // --- Tổng quan (điền công thức sau khi biết số dòng) ---
  const sum = wb.addWorksheet('Tổng quan');
  // --- Giá vốn món ---
  const ws = wb.addWorksheet('Giá vốn món');
  ws.addRow(['Món', 'Danh mục', 'Size', 'Giá vốn nguyên liệu', 'Hao phí', 'Tổng giá vốn', 'Giá bán', 'Lợi nhuận gộp', 'Tỷ suất lợi nhuận', 'Tỷ lệ giá vốn / giá bán']);
  header(ws, [30, 16, 8, 18, 14, 16, 14, 16, 16, 18]);
  const rows: { m: number }[] = [];
  for (const r of recipes) for (const s of r.sizes) {
    const n = ws.rowCount + 1;
    const row = ws.addRow([r.name, r.category, s.name, s.raw_cost, s.waste_cost]);
    row.getCell(6).value = { formula: `D${n}+E${n}`, result: s.cost };
    row.getCell(7).value = s.selling_price;
    row.getCell(8).value = { formula: `G${n}-F${n}`, result: s.profit };
    row.getCell(9).value = { formula: `IF(G${n}=0,0,H${n}/G${n})`, result: s.margin / 100 };
    row.getCell(10).value = { formula: `IF(G${n}=0,0,F${n}/G${n})`, result: s.cost_ratio / 100 };
    for (const c of [4, 5, 6, 7, 8]) row.getCell(c).numFmt = MONEY;
    row.getCell(9).numFmt = PCT; row.getCell(10).numFmt = PCT;
    row.getCell(3).alignment = { horizontal: 'center' };
    if (s.name === 'M') rows.push({ m: s.margin });
  }
  const lastR = Math.max(ws.rowCount, 2);
  ws.autoFilter = { from: 'A1', to: `J${lastR}` };
  ws.addConditionalFormatting({ ref: `I2:I${lastR}`, rules: [{ type: 'cellIs', operator: 'lessThan', formulae: [0.5], priority: 1, style: { font: { color: { argb: 'FFB23B2B' }, bold: true } } }] });
  ws.addConditionalFormatting({ ref: `H2:H${lastR}`, rules: [{ type: 'cellIs', operator: 'lessThan', formulae: [0], priority: 2, style: { font: { color: { argb: 'FFB23B2B' }, bold: true } } }] });

  // --- Chi tiết nguyên liệu theo món/size ---
  const det = wb.addWorksheet('Chi tiết nguyên liệu');
  det.addRow(['Món', 'Size', 'Nguyên liệu', 'Định lượng', 'Đơn vị', 'Lượng quy đổi', 'Đơn vị cơ bản', 'Đơn giá / đơn vị cơ bản', 'Thành tiền']);
  header(det, [30, 8, 26, 12, 9, 14, 12, 18, 14]);
  const unitCost = new Map(ings.map((i) => [i.id, i.unit_cost]));
  for (const r of recipes) for (const s of r.sizes) for (const l of s.lines) {
    const n = det.rowCount + 1;
    const uc = unitCost.get(l.ingredient_id) ?? 0;
    const baseUnit = l.unit === 'kg' ? 'g' : l.unit === 'lít' ? 'ml' : l.unit;
    const row = det.addRow([r.name, s.name, l.name, l.quantity, l.unit, l.base_qty, baseUnit, uc]);
    row.getCell(9).value = { formula: `F${n}*H${n}`, result: l.cost };
    row.getCell(8).numFmt = MONEY2; row.getCell(9).numFmt = MONEY;
    row.getCell(2).alignment = { horizontal: 'center' };
  }
  det.autoFilter = { from: 'A1', to: `I${Math.max(det.rowCount, 2)}` };

  addIngredientSheet(wb, 'Nguyên liệu', ings);

  // --- Tổng quan ---
  sum.getColumn(1).width = 34; sum.getColumn(2).width = 22;
  sum.addRow([`BÁO CÁO GIÁ VỐN — ${shopName}`]).font = { bold: true, size: 16, color: { argb: BROWN } };
  sum.addRow([`Xuất ngày ${new Date().toLocaleDateString('vi-VN')}`]).font = { color: { argb: 'FF8B6A50' } };
  sum.addRow([]);
  const avgM = rows.length ? rows.reduce((a, b) => a + b.m, 0) / rows.length / 100 : 0;
  const lines: [string, ExcelJS.CellValue, string?][] = [
    ['Số món', recipes.length], ['Số nguyên liệu', ings.length], ['Hao phí khi tính giá vốn', waste / 100, '0.0%'],
    ['Tỷ suất lợi nhuận trung bình (size M)', { formula: `AVERAGEIF('Giá vốn món'!C:C,"M",'Giá vốn món'!I:I)`, result: avgM }, PCT],
    ['Số dòng món/size có tỷ suất < 50%', { formula: `COUNTIF('Giá vốn món'!I2:I${lastR},"<0.5")`, result: 0 }, '0'],
  ];
  lines[4][1] = { formula: `COUNTIF('Giá vốn món'!I2:I${lastR},"<0.5")`, result: recipes.flatMap((r) => r.sizes).filter((s) => s.margin < 50).length };
  for (const [k, v, fmt] of lines) { const r = sum.addRow([k, v]); r.getCell(1).font = { bold: true }; if (fmt) r.getCell(2).numFmt = fmt; r.getCell(2).alignment = { horizontal: 'right' }; }
  sum.addRow([]);
  sum.addRow(['Ghi chú: Giá vốn = Σ(định lượng × đơn giá) + hao phí. Các cột Tổng giá vốn, Lợi nhuận, Tỷ suất là công thức Excel — sửa Giá bán để xem lại lợi nhuận.']).font = { italic: true, color: { argb: 'FF8B6A50' } };
  sum.mergeCells(`A${sum.rowCount}:B${sum.rowCount}`);
  sum.getRow(sum.rowCount).alignment = { wrapText: true, vertical: 'top' }; sum.getRow(sum.rowCount).height = 48;

  return Buffer.from(await wb.xlsx.writeBuffer());
}

/** File mẫu để nhập nguyên liệu hàng loạt. */
export async function buildIngredientTemplate(): Promise<Buffer> {
  const wb = new ExcelJS.Workbook();
  const ex: Partial<Ingredient>[] = [
    { name: 'Sữa tươi không đường', category: 'Sữa & Kem', unit: 'lít', base_unit: 'ml', pack_size: 1000, purchase_price: 35000, stock_quantity: 10, minimum_stock: 3, supplier: 'Đại lý Sữa Xanh', note: '' },
    { name: 'Sữa đặc', category: 'Sữa & Kem', unit: 'lon', base_unit: 'ml', pack_size: 300, purchase_price: 25000, stock_quantity: 20, minimum_stock: 6, supplier: '', note: 'Lon 380g ≈ 300ml' },
    { name: 'Cà phê rang xay', category: 'Cà phê', unit: 'kg', base_unit: 'g', pack_size: 1000, purchase_price: 180000, stock_quantity: 5, minimum_stock: 1, supplier: '', note: '' },
  ];
  const ws = addIngredientSheet(wb, 'Nguyên liệu', ex as Ingredient[]);
  for (let r = 2; r <= 500; r++) {
    ws.getCell(`C${r}`).dataValidation = { type: 'list', allowBlank: true, formulae: [`"${PURCHASE_UNITS.join(',')}"`] };
    ws.getCell(`D${r}`).dataValidation = { type: 'list', allowBlank: true, formulae: ['"g,ml,cái"'] };
    ws.getCell(`E${r}`).dataValidation = { type: 'decimal', operator: 'greaterThan', formulae: [0], allowBlank: true, showErrorMessage: true, error: 'Quy cách phải lớn hơn 0' };
    ws.getCell(`F${r}`).dataValidation = { type: 'decimal', operator: 'greaterThanOrEqual', formulae: [0], allowBlank: true, showErrorMessage: true, error: 'Giá nhập không được âm' };
    if (r > 4) { ws.getCell(`F${r}`).numFmt = MONEY; }
  }
  ws.getColumn(12).hidden = false;
  const g = wb.addWorksheet('Hướng dẫn');
  g.getColumn(1).width = 110;
  [
    'HƯỚNG DẪN NHẬP NGUYÊN LIỆU HÀNG LOẠT',
    '1. Điền mỗi nguyên liệu một dòng ở sheet "Nguyên liệu" (xóa 3 dòng ví dụ nếu không cần), rồi tải lên trong mục Nguyên liệu → Nhập từ Excel.',
    '2. Bắt buộc: Tên nguyên liệu, Giá nhập. Các cột khác có thể bỏ trống (hệ thống tự suy ra từ đơn vị mua nếu là kg, g, lít, ml, cái).',
    `3. Đơn vị mua: ${PURCHASE_UNITS.join(', ')}.   Đơn vị pha chế: g, ml hoặc cái.`,
    '4. Quy cách = 1 đơn vị mua chứa bao nhiêu đơn vị pha chế. VD: 1 lon sữa đặc = 300 ml → Đơn vị mua "lon", pha chế "ml", quy cách 300. 1 kg cà phê → "kg", "g", 1000.',
    '5. Tên đã có trong hệ thống: có thể chọn cập nhật (ghi đè giá, quy cách, tồn kho…) hoặc bỏ qua. Cột bỏ trống sẽ giữ nguyên giá trị cũ.',
    '6. Mẹo: bấm "Xuất Excel" ở trang Nguyên liệu để lấy danh sách hiện tại, sửa giá/tồn kho rồi nhập lại.',
    '7. Hệ thống cũng đọc được bảng giá có cột: Tên | Giá Nhập | Số lượng | Đơn vị (như bảng tính cost của quán).',
  ].forEach((t, i) => { const c = g.addRow([t]).getCell(1); c.alignment = { wrapText: true, vertical: 'top' }; if (i === 0) c.font = { bold: true, size: 14, color: { argb: BROWN } }; });
  wb.views = [{ x: 0, y: 0, width: 10000, height: 20000, firstSheet: 0, activeTab: 0, visibility: 'visible' }];
  return Buffer.from(await wb.xlsx.writeBuffer());
}

export async function buildIngredientExport(): Promise<Buffer> {
  const wb = new ExcelJS.Workbook();
  addIngredientSheet(wb, 'Nguyên liệu', loadIngredients());
  return Buffer.from(await wb.xlsx.writeBuffer());
}

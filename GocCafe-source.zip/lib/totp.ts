import crypto from 'crypto';

const A = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
export function newSecret(bytes = 20): string {
  const b = crypto.randomBytes(bytes);
  let bits = '', out = '';
  for (const x of b) bits += x.toString(2).padStart(8, '0');
  for (let i = 0; i + 5 <= bits.length; i += 5) out += A[parseInt(bits.slice(i, i + 5), 2)];
  return out;
}
function decode(s: string): Buffer {
  let bits = '';
  for (const ch of s.replace(/=+$/, '').toUpperCase()) { const v = A.indexOf(ch); if (v >= 0) bits += v.toString(2).padStart(5, '0'); }
  const out: number[] = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) out.push(parseInt(bits.slice(i, i + 8), 2));
  return Buffer.from(out);
}
export function hotp(secret: string, counter: number): string {
  const buf = Buffer.alloc(8);
  buf.writeBigUInt64BE(BigInt(counter));
  const h = crypto.createHmac('sha1', decode(secret)).update(buf).digest();
  const o = h[h.length - 1] & 0xf;
  const n = ((h[o] & 0x7f) << 24) | (h[o + 1] << 16) | (h[o + 2] << 8) | h[o + 3];
  return String(n % 1_000_000).padStart(6, '0');
}
/** Kiểm tra mã 6 số, chấp nhận lệch ±1 bước (30 giây). */
export function verifyTotp(secret: string, code: string, now = Date.now()): boolean {
  if (!/^\d{6}$/.test(code)) return false;
  const c = Math.floor(now / 30_000);
  return [-1, 0, 1].some((d) => crypto.timingSafeEqual(Buffer.from(hotp(secret, c + d)), Buffer.from(code)));
}
export const otpauthUri = (secret: string, account: string, issuer = 'Góc Cafe') => `otpauth://totp/${encodeURIComponent(issuer)}:${encodeURIComponent(account)}?secret=${secret}&issuer=${encodeURIComponent(issuer)}&algorithm=SHA1&digits=6&period=30`;

const sha = (s: string) => crypto.createHash('sha256').update(s).digest('hex');
export function newRecoveryCodes(n = 8): { plain: string[]; hashed: string[] } {
  const plain = Array.from({ length: n }, () => crypto.randomBytes(5).toString('hex').toUpperCase().replace(/(.{5})(.{5})/, '$1-$2'));
  return { plain, hashed: plain.map((c) => sha(c.replace('-', ''))) };
}
/** Dùng một mã khôi phục (mỗi mã chỉ một lần). Trả về danh sách còn lại, hoặc null nếu sai. */
export function useRecovery(hashed: string[], input: string): string[] | null {
  const h = sha(input.toUpperCase().replace(/[^A-Z0-9]/g, ''));
  const i = hashed.indexOf(h);
  return i < 0 ? null : hashed.filter((_, k) => k !== i);
}

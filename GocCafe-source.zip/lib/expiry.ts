import { getDb } from './db';
import { audit } from './audit';
import { moveStock } from './stock';
import { dayDiff, WARN_DAYS_DEFAULT } from './batches-pure';
import { getNumSetting } from './settings';
import { vnDate } from './time';

export interface ExpiryRow { id: number; ingredient_id: number; name: string; category: string; unit: string; qty: number; received_on: string; expires_on: string | null; days: number | null; status: 'expired' | 'soon' | 'ok' | 'none' }

/** Các lô còn hàng của nguyên liệu có theo dõi hạn, kèm tình trạng. */
export function listExpiry(): { today: string; warn_days: number; rows: ExpiryRow[]; removed: ReturnType<typeof recentlyRemoved> } {
  sweepExpired(true);
  const db = getDb();
  const today = vnDate();
  const warn = getNumSetting('expiry_warn_days', WARN_DAYS_DEFAULT);
  const raw = db.prepare(`SELECT b.id, b.ingredient_id, i.name, i.category, i.unit, b.qty, b.received_on, b.expires_on FROM batches b JOIN ingredients i ON i.id=b.ingredient_id
    WHERE b.qty>0 AND i.track_expiry=1 ORDER BY COALESCE(b.expires_on,'9999'), i.name`).all() as Omit<ExpiryRow, 'days' | 'status'>[];
  const rows = raw.map((r) => {
    const days = r.expires_on ? dayDiff(today, r.expires_on) : null;
    return { ...r, days, status: days === null ? 'none' : days < 0 ? 'expired' : days <= warn ? 'soon' : 'ok' } as ExpiryRow;
  });
  return { today, warn_days: warn, rows, removed: recentlyRemoved() };
}

export const AUTO_NOTE = 'Tự loại: hết hạn sử dụng';
let lastSweep = 0;
/** Tự loại các lô đã quá hạn khỏi kho (trừ tồn, ghi sổ hao hụt). Chạy nhẹ, tối đa mỗi 60 giây. */
export function sweepExpired(force = false) {
  if (!force && Date.now() - lastSweep < 60_000) return 0;
  lastSweep = Date.now();
  const db = getDb();
  const rows = db.prepare(`SELECT b.id, b.ingredient_id, b.qty, b.expires_on, i.name, i.unit FROM batches b JOIN ingredients i ON i.id=b.ingredient_id
    WHERE b.qty>0 AND i.track_expiry=1 AND b.expires_on IS NOT NULL AND b.expires_on < ?`).all(vnDate()) as { id: number; ingredient_id: number; qty: number; expires_on: string; name: string; unit: string }[];
  if (!rows.length) return 0;
  db.transaction(() => {
    for (const b of rows) {
      db.prepare('UPDATE batches SET qty=0 WHERE id=?').run(b.id);
      moveStock(b.ingredient_id, -b.qty, 'waste', { note: `${AUTO_NOTE} (HSD ${b.expires_on})`, user: 'Hệ thống', db, skipBatches: true });
      audit(null, 'waste', 'ingredient', b.ingredient_id, `Tự loại lô hết hạn ${b.name}: ${b.qty} ${b.unit}, HSD ${b.expires_on}`);
    }
  })();
  return rows.length;
}

/** Các lô đã tự loại trong vài ngày gần đây (để báo cho người dùng biết). */
export function recentlyRemoved(days = 3) {
  return getDb().prepare(`SELECT m.id, i.name, i.unit, -m.delta AS qty, m.note, m.created_at FROM stock_moves m JOIN ingredients i ON i.id=m.ingredient_id
    WHERE m.kind='waste' AND m.note LIKE ? AND m.created_at >= datetime('now', ?) ORDER BY m.id DESC LIMIT 30`).all(`${AUTO_NOTE}%`, `-${days} day`) as { id: number; name: string; unit: string; qty: number; note: string; created_at: string }[];
}

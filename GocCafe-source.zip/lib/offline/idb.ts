/** Kho dữ liệu trên thiết bị (IndexedDB): bản sao dữ liệu + hàng đợi thao tác chờ đồng bộ. */
const DB = 'cafe-offline';
let dbp: Promise<IDBDatabase> | null = null;

function open(): Promise<IDBDatabase> {
  if (!dbp) {
    dbp = new Promise((res, rej) => {
      const r = indexedDB.open(DB, 1);
      r.onupgradeneeded = () => {
        const d = r.result;
        d.createObjectStore('kv');
        d.createObjectStore('outbox', { keyPath: 'seq', autoIncrement: true });
      };
      r.onsuccess = () => res(r.result);
      r.onerror = () => { dbp = null; rej(r.error); };
    });
  }
  return dbp;
}
async function tx<T>(store: string, mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T> | void): Promise<T> {
  const d = await open();
  return new Promise((res, rej) => {
    const t = d.transaction(store, mode);
    const rq = fn(t.objectStore(store));
    t.oncomplete = () => res((rq ? rq.result : undefined) as T);
    t.onerror = () => rej(t.error);
    t.onabort = () => rej(t.error);
  });
}

export const kvGet = <T>(k: string) => tx<T | undefined>('kv', 'readonly', (s) => s.get(k));
export const kvSet = (k: string, v: unknown) => tx('kv', 'readwrite', (s) => s.put(v, k)).then(() => undefined);
export const kvDel = (k: string) => tx('kv', 'readwrite', (s) => s.delete(k)).then(() => undefined);

export interface Op {
  seq?: number;
  kind: string; // order | void | shift | brew | stock | take | favorite | settings
  label: string; // mô tả hiển thị cho người dùng
  method: string;
  url: string;
  body?: unknown;
  key: string; // khóa chống ghi trùng
  at: string; // thời điểm thao tác (ISO)
  ref?: number; // id đơn cục bộ liên quan (kind=order|void)
  error?: string; // lỗi từ máy chủ (bị từ chối)
}
export const outboxAll = () => tx<Op[]>('outbox', 'readonly', (s) => s.getAll());
export const outboxAdd = (op: Op) => tx<IDBValidKey>('outbox', 'readwrite', (s) => s.add(op));
export const outboxPut = (op: Op) => tx('outbox', 'readwrite', (s) => s.put(op)).then(() => undefined);
export const outboxDel = (seq: number) => tx('outbox', 'readwrite', (s) => s.delete(seq)).then(() => undefined);

export async function clearAllLocal() {
  try {
    await tx('kv', 'readwrite', (s) => s.clear());
    await tx('outbox', 'readwrite', (s) => s.clear());
  } catch { /* bỏ qua */ }
}

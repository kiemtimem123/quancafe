'use client';
/**
 * Chế độ offline-first.
 * - Mỗi máy giữ một bản sao dữ liệu (IndexedDB). Khi mất mạng, các màn hình vẫn đọc/ghi trên bản sao này.
 * - Mọi thao tác ghi lúc offline được xếp vào hàng đợi (outbox) và tự gửi lên máy chủ khi có mạng lại,
 *   theo đúng thứ tự, mỗi thao tác có khóa chống ghi trùng.
 */
import { useSyncExternalStore } from 'react';
import { clearAllLocal, kvGet, kvSet, outboxAdd, outboxAll, outboxDel, outboxPut, type Op } from './idb';
import type { Availability, Ingredient, MatchResult, Recipe } from '../types';
import type { Order, OrderItem, OrderOption, ShiftSummary } from '../orders';
import type { Option } from '../options';
import { bestPromo, vnNow, type Promo, type PLine } from '../promo-pure';
import { LOYALTY_DEFAULT, normPhone, pointsEarned, redeem, validPhone } from '../loyalty-pure';
import type { Prep } from '../pure';
import { computeAvailability, suggestAlternatives } from '../availability';
import { makeConsumer } from '../consume';
import { calcDiscount } from '../order-math';
import { matchRecipes } from '../match';
import { can, type SessionUser } from '../roles';
import { vnDate } from '../time';
import { addDays, consumeFefo, dayDiff, expiryOf, WARN_DAYS_DEFAULT, type Batch } from '../batches-pure';

type Ded = { ingredient_id: number; qty: number };
type LOrder = Order & { ded: Ded[] };
interface LCust { id: number; phone: string; name: string; points: number; visits: number; total_spent: number; last_visit: string | null }
interface Settings { loyalty_earn_per?: number; loyalty_point_value?: number; expiry_warn_days?: number; waste_percent: number; shop_name: string; shop_address: string; shop_phone: string; receipt_footer: string; paper_width: string; table_count: number; has_qr: boolean; bank_info: string }
interface ShiftHistory { id: number; closed_at: string; closed_by: string; order_count: number; void_count: number; cash_total: number; transfer_total: number; opening_cash: number; expected_cash: number; counted_cash: number | null; diff: number | null; note: string }
interface Snap {
  at: string; user: SessionUser; can_cost: boolean; recipes: Recipe[]; categories: { name: string; icon: string }[]; ingredients: Ingredient[];
  options?: Option[]; promos?: Promo[]; customers?: LCust[];
  preps: [number, Prep][]; batches: Batch[]; removed?: { id: number; name: string; unit: string; qty: number; note: string; created_at: string }[]; settings: Settings; qr_image: string; orders: LOrder[]; closed_until: number;
  shift: { summary: ShiftSummary; history: ShiftHistory[] };
}

export interface SyncState { reachable: boolean; pending: number; failed: number; syncing: boolean; lastSync: string | null; authExpired: boolean; hasSnapshot: boolean; ops: Op[] }
let state: SyncState = { reachable: true, pending: 0, failed: 0, syncing: false, lastSync: null, authExpired: false, hasSnapshot: false, ops: [] };
const subs = new Set<() => void>();
const setState = (p: Partial<SyncState>) => { state = { ...state, ...p }; subs.forEach((f) => f()); };
export const getSyncState = () => state;
export const subscribeSync = (f: () => void) => { subs.add(f); return () => { subs.delete(f); }; };
const SERVER_STATE = { ...state };
export const useSync = () => useSyncExternalStore(subscribeSync, getSyncState, () => SERVER_STATE);

export class LocalError extends Error {
  constructor(public status: number, message: string, public details?: unknown) { super(message); }
}
const NEED_NET = 'Chức năng này cần kết nối mạng. Kết nối lại rồi thử lại nhé.';
const LOCAL_BASE = 1_000_000_000; // id đơn tạo lúc offline: luôn lớn hơn id thật

/* ---------------- bản sao cục bộ ---------------- */
let snap: Snap | null = null;
let version = 0; // tăng mỗi lần ghi cục bộ — để biết có nên ghi đè bản sao bằng dữ liệu mới tải về không
let chain: Promise<unknown> = Promise.resolve();
const serial = <T>(fn: () => Promise<T>): Promise<T> => { const p = chain.then(fn, fn); chain = p.catch(() => {}); return p; };

async function getSnap(): Promise<Snap> {
  if (!snap) snap = (await kvGet<Snap>('snap')) ?? null;
  if (!snap) throw new LocalError(503, 'Chưa có dữ liệu lưu trên máy này. Hãy mở app khi có mạng ít nhất một lần.');
  if (sweepLocal(snap)) await save();
  return snap;
}
const save = async () => { if (snap) { version++; await kvSet('snap', snap); } };
const clone = <T>(x: T): T => JSON.parse(JSON.stringify(x));
const nowSql = () => new Date().toISOString().replace('T', ' ').slice(0, 19);
const uid = () => (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`).replace(/[^\w-]/g, '');

/** Tự loại lô quá hạn khỏi kho (máy chủ cũng làm đúng như vậy khi đồng bộ). */
function sweepLocal(s: Snap): boolean {
  const today = vnDate();
  const dead = (s.batches ?? []).filter((b) => b.qty > 0 && b.expires_on && b.expires_on < today && s.ingredients.find((i) => i.id === b.ingredient_id)?.track_expiry);
  if (!dead.length) return false;
  s.removed = s.removed ?? [];
  for (const b of dead) {
    const ing = s.ingredients.find((i) => i.id === b.ingredient_id)!;
    ing.stock_quantity = Math.max(0, Math.round((ing.stock_quantity - b.qty) * 1e6) / 1e6);
    s.removed.unshift({ id: -b.id, name: ing.name, unit: ing.unit, qty: b.qty, note: `Tự loại: hết hạn sử dụng (HSD ${b.expires_on})`, created_at: nowSql() });
  }
  s.batches = s.batches.filter((b) => !dead.includes(b));
  recompute(s);
  return true;
}

function recompute(s: Snap) {
  const preps = new Map(s.preps);
  for (const i of s.ingredients) {
    i.low_stock = i.track_stock && i.minimum_stock > 0 && i.stock_quantity <= i.minimum_stock;
    i.out_of_stock = i.track_stock && i.stock_quantity <= 0;
    i.expiry = i.track_expiry ? expiryOf((s.batches ?? []).filter((b) => b.ingredient_id === i.id), vnDate(), s.settings.expiry_warn_days ?? WARN_DAYS_DEFAULT) : null;
  }
  const byId = new Map(s.ingredients.map((i) => [i.id, i]));
  for (const o of s.options ?? []) { const ing = o.ingredient_id ? byId.get(o.ingredient_id) : undefined; o.available = !ing || !ing.track_stock || ing.stock_quantity * ing.pack_size >= o.qty - 1e-9; }
  for (const r of s.recipes) {
    r.availability = computeAvailability(r.sizes.find((x) => x.name === 'M') ?? r.sizes[0], s.ingredients, preps);
    for (const sz of r.sizes) for (const l of sz.lines) { const ing = byId.get(l.ingredient_id); if (ing) l.stock_ok = !ing.track_stock || ing.stock_quantity * ing.pack_size >= l.base_qty; }
  }
}

export const hasSnapshot = async () => { try { await getSnap(); return true; } catch { return false; } };

let refreshing: Promise<void> | null = null;
let lastRefresh = 0;
/** Tải bản sao mới nhất từ máy chủ (bỏ qua nếu đang có thao tác chờ đồng bộ hoặc vừa ghi cục bộ). */
export function refreshSnapshot(force = false): Promise<void> {
  if (refreshing) return refreshing;
  if (!force && Date.now() - lastRefresh < 20_000) return Promise.resolve();
  refreshing = (async () => {
    const v = version;
    try {
      if ((await outboxAll()).length) return;
      const res = await fetch('/api/offline/snapshot', { cache: 'no-store' });
      if (res.status === 401) return;
      if (!res.ok) return;
      const d = (await res.json()) as Snap;
      if (v !== version || (await outboxAll()).length) return; // có thay đổi cục bộ trong lúc tải → giữ bản cục bộ
      snap = d; lastRefresh = Date.now();
      await kvSet('snap', d);
      setState({ hasSnapshot: true, lastSync: d.at });
    } catch { /* mất mạng: giữ bản cũ */ } finally { refreshing = null; }
  })();
  return refreshing;
}
let refreshTimer: ReturnType<typeof setTimeout> | undefined;
/** Sau mỗi thao tác ghi thành công khi online: cập nhật lại bản sao sau ít giây. */
export function scheduleRefresh() { clearTimeout(refreshTimer); refreshTimer = setTimeout(() => { void refreshSnapshot(true); }, 2500); }

/* ---------------- hàng đợi ---------------- */
async function loadOps() {
  const ops = await outboxAll();
  setState({ ops, pending: ops.filter((o) => !o.error).length, failed: ops.filter((o) => !!o.error).length });
  return ops;
}
async function enqueue(op: Omit<Op, 'key' | 'at'> & { key?: string }) {
  await outboxAdd({ ...op, key: op.key ?? uid(), at: new Date().toISOString() });
  await loadOps();
}
export const pendingCount = () => state.pending + state.failed;

let flushing: Promise<void> | null = null;
/** Gửi lần lượt các thao tác chờ lên máy chủ. Dừng lại khi mất mạng / hết phiên đăng nhập. */
export function flush(): Promise<void> {
  if (flushing) return flushing;
  flushing = (async () => {
    setState({ syncing: true });
    try {
      const idmap = (await kvGet<Record<string, number>>('idmap')) ?? {};
      const failedRefs = new Set<number>();
      let ops = await loadOps();
      for (const op of ops) {
        if (op.error) { if (op.ref && op.kind === 'order') failedRefs.add(op.ref); continue; }
        let url = op.url;
        let body = op.body as Record<string, unknown> | undefined;
        if (op.kind === 'void' || op.ref) {
          const lid = op.ref ?? 0;
          if (lid >= LOCAL_BASE) {
            if (failedRefs.has(lid)) { op.error = 'Đơn gốc chưa đồng bộ được nên thao tác này bị bỏ qua'; await outboxPut(op); continue; }
            const real = idmap[String(lid)];
            if (!real && op.kind === 'void') { op.error = 'Không tìm thấy đơn đã đồng bộ'; await outboxPut(op); continue; }
            if (real) url = url.replace(String(lid), String(real));
          }
        }
        let res: Response;
        try {
          res = await fetch(url, { method: op.method, headers: { 'content-type': 'application/json', 'x-op-key': op.key }, body: body ? JSON.stringify(body) : undefined, cache: 'no-store' });
        } catch { setState({ reachable: false }); break; }
        if (res.headers.get('x-offline')) { setState({ reachable: false }); break; }
        if (res.status === 401) { setState({ authExpired: true }); break; }
        setState({ reachable: true, authExpired: false });
        if (res.status >= 500) break;
        const data = (await res.json().catch(() => ({}))) as { error?: string; order?: { id: number }; ok?: boolean };
        if (!res.ok) {
          // 409 khi hủy đơn đã hủy / 404 đơn mất: coi là đã xong nếu chỉ là trùng lặp
          if (op.kind === 'void' && /đã hủy/.test(data.error ?? '')) { await outboxDel(op.seq!); continue; }
          op.error = data.error || `Máy chủ từ chối (${res.status})`;
          if (op.kind === 'order' && op.ref) failedRefs.add(op.ref);
          await outboxPut(op);
          continue;
        }
        if (op.kind === 'order' && op.ref && data.order) { idmap[String(op.ref)] = data.order.id; await kvSet('idmap', idmap); }
        await outboxDel(op.seq!);
        ops = await loadOps();
      }
      await loadOps();
      if (!state.pending && state.reachable) { await refreshSnapshot(true); setState({ lastSync: new Date().toISOString() }); }
    } finally { setState({ syncing: false }); flushing = null; }
  })();
  return flushing;
}
export async function retryFailed() {
  const ops = await outboxAll();
  for (const o of ops) if (o.error) { delete o.error; await outboxPut(o); }
  await loadOps();
  await flush();
}
export async function discardOp(seq: number) { await outboxDel(seq); await loadOps(); }
/** Bỏ mọi thao tác lỗi rồi nạp lại bản sao từ máy chủ. */
export async function discardFailed() {
  for (const o of await outboxAll()) if (o.error && o.seq) await outboxDel(o.seq);
  await loadOps();
  await refreshSnapshot(true);
}

/* ---------------- phát hiện mạng ---------------- */
let started = false;
export const markOffline = () => { if (state.reachable) setState({ reachable: false }); };
async function probe() {
  try {
    const r = await fetch('/api/auth/me', { cache: 'no-store' });
    if (r.headers.get('x-offline')) return false;
    return true;
  } catch { return false; }
}
export function startEngine() {
  if (started || typeof window === 'undefined') return;
  started = true;
  void loadOps();
  void hasSnapshot().then((h) => setState({ hasSnapshot: h, lastSync: snap?.at ?? null }));
  const check = async () => {
    const ok = navigator.onLine && (await probe());
    if (ok && !state.reachable) setState({ reachable: true });
    if (!ok && state.reachable) setState({ reachable: false });
    if (ok && (state.pending > 0)) void flush();
  };
  window.addEventListener('online', check);
  window.addEventListener('offline', () => setState({ reachable: false }));
  setInterval(check, 8000);
  void check();
  if (navigator.onLine) void flush().then(() => refreshSnapshot());
}
export const shouldTryNetwork = () => (typeof navigator === 'undefined' ? true : navigator.onLine) && state.reachable;

export async function clearOffline() {
  snap = null; version++;
  await clearAllLocal();
  setState({ pending: 0, failed: 0, ops: [], hasSnapshot: false, lastSync: null });
}

/* ---------------- đọc cục bộ ---------------- */
const slimAv = (r: Recipe) => ({ id: r.id, name: r.name, category: r.category, image: r.image, availability: r.availability as Availability });

function shiftNow(s: Snap): ShiftSummary {
  const from = s.closed_until;
  const rows = s.orders.filter((o) => o.id > from).sort((a, b) => a.id - b.id);
  const paid = rows.filter((r) => r.status === 'paid');
  return {
    from_order_id: from + 1, to_order_id: rows.length ? rows[rows.length - 1].id : from, orders: paid.length, voids: rows.length - paid.length,
    cash: paid.filter((r) => r.payment === 'cash').reduce((a, r) => a + r.total, 0), transfer: paid.filter((r) => r.payment === 'transfer').reduce((a, r) => a + r.total, 0),
    discount: paid.reduce((a, r) => a + r.discount, 0), cups: paid.reduce((a, o) => a + o.items.reduce((x, i) => x + i.quantity, 0), 0), total: paid.reduce((a, r) => a + r.total, 0), since: rows[0]?.created_at ?? null,
  };
}
const loyaltyOf = (s: Snap) => ({ earn_per: s.settings.loyalty_earn_per ?? LOYALTY_DEFAULT.earn_per, point_value: s.settings.loyalty_point_value ?? LOYALTY_DEFAULT.point_value });
const strip = (o: LOrder): Order => { const { ded: _d, ...rest } = o; void _d; return clone(rest as Order); };

async function readLocal(url: string): Promise<unknown> {
  const u = new URL(url, location.origin);
  const p = u.pathname;
  let m: RegExpMatchArray | null;
  if (p === '/api/auth/me') { const s = await getSnap(); return { user: s.user, needsSetup: false }; }
  const s = await getSnap();
  if (p === '/api/recipes') return clone({ recipes: s.recipes, categories: s.categories });
  if ((m = p.match(/^\/api\/recipes\/(\d+)$/))) {
    const r = s.recipes.find((x) => x.id === Number(m![1]));
    if (!r) throw new LocalError(404, 'Không tìm thấy món');
    return clone({ recipe: r });
  }
  if (p === '/api/ingredients') return clone({ ingredients: s.ingredients });
  if (p === '/api/availability') {
    const items = s.recipes.map((r) => ({ ...slimAv(r), alternatives: r.availability!.status === 'ok' ? [] : suggestAlternatives(r, s.recipes).map((a) => ({ ...slimAv(a), margin: undefined })) }));
    const rank = { out: 0, low: 1, ok: 2 } as const;
    items.sort((a, b) => rank[a.availability.status] - rank[b.availability.status] || (a.availability.cups ?? 1e9) - (b.availability.cups ?? 1e9) || a.name.localeCompare(b.name, 'vi'));
    const n = (k: string) => items.filter((i) => i.availability.status === k).length;
    return clone({ items, counts: { out: n('out'), low: n('low'), ok: n('ok') } });
  }
  if (p === '/api/settings') return clone(s.settings);
  if (p === '/api/options') return clone({ options: s.options ?? [] });
  if (p === '/api/promotions') return clone({ promotions: s.promos ?? [] });
  if (p === '/api/customers/lookup') {
    const ph = normPhone(u.searchParams.get('phone') ?? '');
    return { customer: ph ? clone((s.customers ?? []).find((c) => c.phone === ph) ?? null) : null, loyalty: loyaltyOf(s) };
  }
  if (p === '/api/expiry') {
    const today = vnDate();
    const warn = s.settings.expiry_warn_days ?? WARN_DAYS_DEFAULT;
    const ing = new Map(s.ingredients.map((i) => [i.id, i]));
    const rows = (s.batches ?? []).filter((b) => b.qty > 0 && ing.get(b.ingredient_id)?.track_expiry).map((b) => {
      const i = ing.get(b.ingredient_id)!;
      const days = b.expires_on ? dayDiff(today, b.expires_on) : null;
      return { id: b.id, ingredient_id: i.id, name: i.name, category: i.category, unit: i.unit, qty: b.qty, received_on: b.received_on, expires_on: b.expires_on, days, status: days === null ? 'none' : days < 0 ? 'expired' : days <= warn ? 'soon' : 'ok' };
    }).sort((a, b) => (a.expires_on ?? '9999').localeCompare(b.expires_on ?? '9999') || a.name.localeCompare(b.name, 'vi'));
    return { today, warn_days: warn, rows, removed: clone((s.removed ?? []).slice(0, 30)) };
  }
  if ((m = p.match(/^\/api\/ingredients\/(\d+)\/stock$/))) return { moves: [], prices: [], batches: clone((s.batches ?? []).filter((b) => b.ingredient_id === Number(m![1]) && b.qty > 0).sort((a, b) => (a.expires_on ?? '9999').localeCompare(b.expires_on ?? '9999'))) };
  if (p === '/api/settings/qr') return { qr_image: s.qr_image };
  if (p === '/api/orders/shift') return clone({ summary: shiftNow(s), history: s.shift.history });
  if (p === '/api/orders') {
    const d = u.searchParams.get('date') ?? '';
    const date = /^\d{4}-\d{2}-\d{2}$/.test(d) ? d : vnDate();
    return { date, orders: s.orders.filter((o) => o.order_date === date).sort((a, b) => b.id - a.id).map(strip), closed_until: s.closed_until };
  }
  if ((m = p.match(/^\/api\/orders\/(\d+)$/))) {
    let id = Number(m[1]);
    const map = (await kvGet<Record<string, number>>('idmap')) ?? {};
    if (map[String(id)]) id = map[String(id)];
    const o = s.orders.find((x) => x.id === id);
    if (!o) throw new LocalError(404, 'Không tìm thấy đơn (có thể đã đồng bộ — mở lại từ danh sách đơn)');
    const out = strip(o);
    return { order: { ...out, items: out.items.map((i) => ({ ...i, unit_cost: 0 })) } };
  }
  throw new LocalError(503, NEED_NET);
}

/* ---------------- ghi cục bộ ---------------- */
/** Trừ lô theo thứ tự sắp hết hạn trước. */
function takeBatches(s: Snap, ingredientId: number, qty: number) {
  if (!s.batches || qty <= 1e-12) return;
  const mine = s.batches.filter((b) => b.ingredient_id === ingredientId);
  for (const t of consumeFefo(mine, qty)) { const b = mine.find((x) => x.id === t.id)!; b.qty = Math.max(0, b.qty - t.take); }
  s.batches = s.batches.filter((b) => b.qty > 1e-9);
}
function applyDeduct(s: Snap, deduct: Map<number, number>): Ded[] {
  const byId = new Map(s.ingredients.map((i) => [i.id, i]));
  const out: Ded[] = [];
  deduct.forEach((base, iid) => {
    const ing = byId.get(iid);
    if (!ing) return;
    const q = base / ing.pack_size;
    const before = ing.stock_quantity;
    ing.stock_quantity = Math.max(0, Math.round((before - q) * 1e6) / 1e6);
    takeBatches(s, iid, before - ing.stock_quantity);
    out.push({ ingredient_id: iid, qty: Math.min(q, before) });
  });
  return out;
}
const checkSize = (r: Recipe | undefined, size: string) => {
  if (!r) throw new LocalError(404, 'Có món không còn tồn tại trong hệ thống');
  const sz = r.sizes.find((x) => x.name === size);
  if (!sz) throw new LocalError(400, `${r.name} chưa có size ${size}`);
  if (sz.selling_price <= 0) throw new LocalError(400, `${r.name} (${size}) chưa có giá bán`);
  return sz;
};
const money = (n: number) => `${Math.round(n).toLocaleString('vi-VN')}đ`;

interface NewOrderBody { key?: string; table_name?: string; note?: string; payment: 'cash' | 'transfer'; cash_received?: number; discount?: { type: 'amount' | 'percent'; value: number }; items: { recipe_id: number; size: 'S' | 'M' | 'L'; quantity: number; note?: string; options?: { id: number; qty: number }[] }[]; force?: boolean; promo_code?: string; customer?: { phone: string; name?: string }; redeem_points?: number }

async function createLocalOrder(b: NewOrderBody): Promise<unknown> {
  const s = await getSnap();
  if (!b.items?.length) throw new LocalError(400, 'Đơn chưa có món nào');
  if (b.key) { const ex = s.orders.find((o) => (o as LOrder & { key?: string }).key === b.key); if (ex) return { order: strip(ex) }; }
  const byRecipe = new Map(s.recipes.map((r) => [r.id, r]));
  const optById = new Map((s.options ?? []).map((o) => [o.id, o]));
  const consumer = makeConsumer(s.ingredients);
  const canForce = can(s.user.role, 'edit_ingredients') && !!b.force;
  const lines: { r: Recipe; size: string; qty: number; price: number; cost: number; note: string; opts: OrderOption[] }[] = [];
  const blocked: number[] = [];
  for (const it of b.items) {
    const r = byRecipe.get(it.recipe_id);
    const sz = checkSize(r, it.size);
    const before = consumer.res.short.length;
    consumer.use(sz, it.quantity, canForce);
    const opts: OrderOption[] = [];
    let optPrice = 0, optCost = 0;
    for (const oi of it.options ?? []) {
      const o = optById.get(oi.id);
      if (!o || !o.active) throw new LocalError(400, 'Có topping không còn được bán');
      const oq = Math.max(1, Math.min(10, Math.floor(oi.qty || 1)));
      if (o.ingredient_id && o.qty > 0) consumer.useIngredient(o.ingredient_id, o.qty * oq * it.quantity, canForce);
      opts.push({ id: o.id, name: o.name, price: o.price, qty: oq });
      optPrice += o.price * oq; optCost += o.cost * oq;
    }
    if (consumer.res.short.length > before) blocked.push(r!.id);
    lines.push({ r: r!, size: it.size, qty: it.quantity, price: sz.selling_price + optPrice, cost: Math.round(sz.cost + optCost), note: (it.note ?? '').trim().slice(0, 120), opts });
  }
  if (consumer.res.short.length && !canForce) throw new LocalError(409, `Không đủ nguyên liệu: ${consumer.res.short.join(', ')}`, { short: consumer.res.short, recipes: [...new Set(blocked)] });
  const subtotal = lines.reduce((a, l) => a + l.price * l.qty, 0);
  const pl: PLine[] = lines.map((l) => ({ recipe_id: l.r.id, category: l.r.category, quantity: l.qty, unit_price: l.price }));
  const bp = bestPromo(s.promos ?? [], pl, subtotal, vnNow(), b.promo_code ?? '');
  if (b.promo_code?.trim() && bp.codeError && !bp.result) throw new LocalError(400, bp.codeError);
  const promoDisc = bp.result?.discount ?? 0;
  const man = calcDiscount(subtotal - promoDisc, b.discount);
  // khách thân thiết (tra trong bản sao trên máy; khách mới được tạo khi đồng bộ)
  const cfg = loyaltyOf(s);
  const phone = b.customer?.phone ? normPhone(b.customer.phone) : '';
  if (phone && !validPhone(phone)) throw new LocalError(400, 'Số điện thoại khách không hợp lệ');
  s.customers = s.customers ?? [];
  let cust = phone ? s.customers.find((c) => c.phone === phone) : undefined;
  if (phone && !cust) { cust = { id: -(s.customers.length + 1), phone, name: (b.customer?.name ?? '').trim().slice(0, 60), points: 0, visits: 0, total_spent: 0, last_visit: null }; s.customers.unshift(cust); }
  const rd = cust ? redeem(b.redeem_points ?? 0, cust.points, subtotal - promoDisc - man.discount, cfg) : { points: 0, discount: 0 };
  const discount = promoDisc + man.discount + rd.discount;
  const label = [bp.result && `KM ${bp.result.label}`, man.label, rd.points && `Điểm ×${rd.points}`].filter(Boolean).join(' + ');
  const total = subtotal - discount;
  if (b.payment === 'cash' && b.cash_received !== undefined && b.cash_received < total) throw new LocalError(400, 'Tiền khách đưa chưa đủ');
  const earned = cust ? pointsEarned(total, cfg) : 0;

  const date = vnDate();
  const seqNo = (await kvGet<number>('localSeq')) ?? 0;
  const n = seqNo + 1;
  await kvSet('localSeq', n);
  const id = LOCAL_BASE + n;
  const dayLocal = s.orders.filter((o) => o.order_date === date && o.id >= LOCAL_BASE).length + 1;
  const code = `${date.slice(8, 10)}${date.slice(5, 7)}-L${String(dayLocal).padStart(2, '0')}`;
  const ded = applyDeduct(s, consumer.res.deduct);
  const items: OrderItem[] = lines.map((l, i) => ({ id: id * 100 + i, recipe_id: l.r.id, name: l.r.name, category: l.r.category, size: l.size, quantity: l.qty, unit_price: l.price, unit_cost: s.can_cost ? l.cost : 0, note: l.note, options: l.opts }));
  const order: LOrder & { key?: string } = {
    id, order_date: date, seq: 0, code, status: 'paid', table_name: b.table_name || 'Mang đi', note: (b.note ?? '').trim().slice(0, 200), subtotal, discount, discount_label: label, total,
    payment: b.payment, cash_received: b.payment === 'cash' ? b.cash_received ?? null : null, customer_phone: cust?.phone ?? '', customer_name: cust?.name ?? '', points_earned: earned, points_used: rd.points,
    user_name: s.user.name, created_at: nowSql(), voided_at: null, void_reason: '', voided_by: '', items, ded, key: b.key,
  };
  if (cust) { cust.points = Math.max(0, cust.points - rd.points + earned); cust.visits += 1; cust.total_spent += total; cust.last_visit = nowSql(); }
  s.orders.unshift(order);
  recompute(s);
  s.shift.summary = shiftNow(s);
  await save();
  const body = { ...b, offline: true, at: new Date().toISOString(), force: undefined, key: b.key ?? uid(), promo: promoDisc > 0 ? { label: bp.result!.label, discount: promoDisc } : undefined, promo_code: undefined, redeem_points: rd.points || undefined };
  await enqueue({ kind: 'order', label: `Đơn ${code} · ${lines.reduce((a, l) => a + l.qty, 0)} ly · ${money(total)}`, method: 'POST', url: '/api/orders', body, ref: id, key: body.key });
  return { order: strip(order) };
}

async function voidLocal(id: number, reason: string): Promise<unknown> {
  const s = await getSnap();
  if (!can(s.user.role, 'void_order')) throw new LocalError(403, 'Bạn không có quyền thực hiện thao tác này');
  const map = (await kvGet<Record<string, number>>('idmap')) ?? {};
  if (map[String(id)]) id = map[String(id)];
  const o = s.orders.find((x) => x.id === id);
  if (!o) throw new LocalError(404, 'Không tìm thấy đơn');
  if (o.status === 'void') throw new LocalError(400, 'Đơn này đã hủy');
  if (id <= s.closed_until) throw new LocalError(400, 'Đơn thuộc ca đã chốt, không thể hủy');
  o.status = 'void'; o.voided_at = nowSql(); o.void_reason = reason; o.voided_by = s.user.name;
  const byId = new Map(s.ingredients.map((i) => [i.id, i]));
  for (const d of o.ded) { const ing = byId.get(d.ingredient_id); if (ing) ing.stock_quantity = Math.round((ing.stock_quantity + d.qty) * 1e6) / 1e6; }
  const vc = o.customer_phone ? (s.customers ?? []).find((c) => c.phone === o.customer_phone) : undefined;
  if (vc) { vc.points = Math.max(0, vc.points - o.points_earned + o.points_used); vc.visits = Math.max(0, vc.visits - 1); vc.total_spent = Math.max(0, vc.total_spent - o.total); }
  recompute(s);
  s.shift.summary = shiftNow(s);
  await save();
  await enqueue({ kind: 'void', label: `Hủy đơn ${o.code} (${money(o.total)})`, method: 'DELETE', url: `/api/orders/${id}`, body: { reason }, ref: id >= LOCAL_BASE ? id : undefined });
  return { order: strip(o) };
}

async function closeShiftLocal(b: { opening_cash?: number; counted_cash?: number; note?: string }): Promise<unknown> {
  const s = await getSnap();
  const sum = shiftNow(s);
  if (sum.to_order_id < sum.from_order_id) throw new LocalError(400, 'Chưa có đơn nào để chốt ca');
  const opening = Number(b.opening_cash) || 0;
  const expected = opening + sum.cash;
  const diff = b.counted_cash === undefined ? null : b.counted_cash - expected;
  const histId = (s.shift.history[0]?.id ?? 0) + 1;
  s.shift.history.unshift({ id: histId, closed_at: nowSql(), closed_by: s.user.name, order_count: sum.orders, void_count: sum.voids, cash_total: sum.cash, transfer_total: sum.transfer, opening_cash: opening, expected_cash: expected, counted_cash: b.counted_cash ?? null, diff, note: b.note ?? '' });
  s.closed_until = sum.to_order_id;
  s.shift.summary = shiftNow(s);
  await save();
  await enqueue({ kind: 'shift', label: `Chốt ca (${sum.orders} đơn, ${money(sum.total)})`, method: 'POST', url: '/api/orders/shift', body: { opening_cash: opening, counted_cash: b.counted_cash, note: b.note ?? '' } });
  return { shift: { id: histId, ...sum, expected_cash: expected, counted_cash: b.counted_cash ?? null, diff, opening_cash: opening } };
}

async function brewLocal(id: number, b: { size: 'S' | 'M' | 'L'; quantity?: number; force?: boolean }): Promise<unknown> {
  const s = await getSnap();
  const r = s.recipes.find((x) => x.id === id);
  if (!r) throw new LocalError(404, 'Không tìm thấy món');
  const sz = r.sizes.find((x) => x.name === b.size);
  if (!sz) throw new LocalError(400, `Món này chưa có size ${b.size}`);
  const qty = b.quantity ?? 1;
  const c = makeConsumer(s.ingredients);
  c.use(sz, qty, !!b.force);
  if (c.res.short.length && !b.force) throw new LocalError(409, `Không đủ tồn kho: ${c.res.short.join(', ')}`, { short: c.res.short });
  applyDeduct(s, c.res.deduct);
  recompute(s);
  await save();
  await enqueue({ kind: 'brew', label: `Pha ${qty} ${r.name} (${b.size})`, method: 'POST', url: `/api/recipes/${id}/brew`, body: { size: b.size, quantity: qty, force: true } });
  return { ok: true, short: c.res.short, substitutes: Array.from(new Set(c.res.substitutes)) };
}

async function stockLocal(id: number, b: { kind: 'purchase' | 'adjust' | 'waste'; quantity: number; unit_price?: number; note?: string; expires_on?: string }): Promise<unknown> {
  const s = await getSnap();
  if (!can(s.user.role, 'edit_ingredients')) throw new LocalError(403, 'Bạn không có quyền thực hiện thao tác này');
  const ing = s.ingredients.find((x) => x.id === id);
  if (!ing) throw new LocalError(404, 'Không tìm thấy nguyên liệu');
  if (ing.has_prep && b.unit_price !== undefined) throw new LocalError(400, 'Bán thành phẩm tự tính giá, không nhập giá');
  if (b.kind !== 'adjust' && !(b.quantity > 0)) throw new LocalError(400, 'Số lượng phải lớn hơn 0');
  if (!ing.track_stock && b.kind !== 'waste') ing.track_stock = true;
  const cur = ing.stock_quantity;
  const next = b.kind === 'purchase' ? cur + b.quantity : b.kind === 'waste' ? cur - b.quantity : b.quantity;
  ing.stock_quantity = Math.max(0, Math.round(next * 1e6) / 1e6);
  const real = ing.stock_quantity - cur;
  if (real < 0) takeBatches(s, id, -real);
  else if (real > 0 && b.kind === 'purchase' && ing.track_expiry) {
    const today = vnDate();
    const exp = b.expires_on ?? (ing.shelf_life_days > 0 ? addDays(today, ing.shelf_life_days) : null);
    s.batches = s.batches ?? [];
    s.batches.push({ id: -(Date.now() % 1e9) - s.batches.length, ingredient_id: id, qty: real, received_on: today, expires_on: exp, unit_price: b.unit_price ?? null, note: b.note ?? '' });
  }
  if (b.kind === 'purchase' && b.unit_price !== undefined && b.unit_price !== ing.purchase_price && s.can_cost) { ing.purchase_price = b.unit_price; ing.unit_cost = b.unit_price / ing.pack_size; }
  recompute(s);
  await save();
  const L = { purchase: 'Nhập kho', adjust: 'Kiểm kê', waste: 'Hao hụt' }[b.kind];
  await enqueue({ kind: 'stock', label: `${L} ${ing.name}: ${b.quantity} ${ing.unit}`, method: 'POST', url: `/api/ingredients/${id}/stock`, body: b });
  return { balance: ing.stock_quantity, alerts: [], threshold: 0 };
}

async function takeLocal(b: { items: { id: number; counted: number }[]; note?: string }): Promise<unknown> {
  const s = await getSnap();
  if (!can(s.user.role, 'edit_ingredients')) throw new LocalError(403, 'Bạn không có quyền thực hiện thao tác này');
  const byId = new Map(s.ingredients.map((i) => [i.id, i]));
  let changed = 0;
  const diffs: { id: number; name: string; delta: number }[] = [];
  for (const it of b.items) {
    const ing = byId.get(it.id);
    if (!ing || Math.abs(ing.stock_quantity - it.counted) < 1e-9) continue;
    diffs.push({ id: ing.id, name: ing.name, delta: it.counted - ing.stock_quantity });
    if (it.counted < ing.stock_quantity) takeBatches(s, ing.id, ing.stock_quantity - it.counted);
    ing.stock_quantity = it.counted; changed++;
  }
  recompute(s);
  await save();
  await enqueue({ kind: 'take', label: `Kiểm kê ${b.items.length} nguyên liệu (lệch ${changed})`, method: 'POST', url: '/api/stock/take', body: b });
  return { changed, diffs };
}

async function discardBatchLocal(id: number): Promise<unknown> {
  const s = await getSnap();
  if (!can(s.user.role, 'edit_ingredients')) throw new LocalError(403, 'Bạn không có quyền thực hiện thao tác này');
  const b = (s.batches ?? []).find((x) => x.id === id);
  if (!b) throw new LocalError(404, 'Không tìm thấy lô hàng');
  const ing = s.ingredients.find((x) => x.id === b.ingredient_id);
  if (ing) ing.stock_quantity = Math.max(0, Math.round((ing.stock_quantity - b.qty) * 1e6) / 1e6);
  s.batches = s.batches.filter((x) => x.id !== id);
  recompute(s);
  await save();
  await enqueue({ kind: 'batch', label: `Hủy lô ${ing?.name ?? ''} (${b.qty} ${ing?.unit ?? ''})`, method: 'DELETE', url: `/api/batches/${id}` });
  return { ok: true };
}

async function favLocal(id: number): Promise<unknown> {
  const s = await getSnap();
  const r = s.recipes.find((x) => x.id === id);
  if (!r) throw new LocalError(404, 'Không tìm thấy món');
  r.favorite = !r.favorite;
  await save();
  await enqueue({ kind: 'favorite', label: `${r.favorite ? 'Yêu thích' : 'Bỏ yêu thích'} ${r.name}`, method: 'POST', url: `/api/recipes/${id}/favorite` });
  return { favorite: r.favorite };
}

async function settingsLocal(b: Record<string, unknown>): Promise<unknown> {
  const s = await getSnap();
  if (!can(s.user.role, 'edit_ingredients')) throw new LocalError(403, 'Bạn không có quyền thực hiện thao tác này');
  if ('waste_percent' in b) throw new LocalError(503, 'Đổi % hao phí làm giá vốn thay đổi nên cần kết nối mạng.');
  Object.assign(s.settings, Object.fromEntries(Object.entries(b).filter(([, v]) => v !== undefined)));
  await save();
  await enqueue({ kind: 'settings', label: 'Đổi cài đặt quán', method: 'PUT', url: '/api/settings', body: b });
  return clone(s.settings);
}

async function matchLocal(b: { have: number[]; priority?: number[] }): Promise<unknown> {
  const s = await getSnap();
  const pr = b.priority ?? [];
  const have = new Set([...b.have, ...pr]);
  const ctx = {
    groups: new Map(s.ingredients.filter((i) => i.group_name).map((i) => [i.id, i.group_name] as [number, string])),
    names: new Map(s.ingredients.map((i) => [i.id, i.name] as [number, string])),
    cats: new Map(s.ingredients.map((i) => [i.id, i.category] as [number, string])),
    preps: new Map(s.preps),
  };
  const results: MatchResult[] = matchRecipes(s.recipes, have, new Set(pr), ctx);
  return clone({ results });
}

/** Điểm vào: thực hiện một yêu cầu API hoàn toàn trên máy (dùng khi offline). */
export function localRequest<T>(method: string, url: string, body?: unknown): Promise<T> {
  const u = new URL(url, location.origin);
  const p = u.pathname;
  const go = async (): Promise<unknown> => {
    let m: RegExpMatchArray | null;
    if (method === 'GET') return readLocal(url);
    if (method === 'POST' && p === '/api/match') return matchLocal(body as never);
    if (method === 'POST' && p === '/api/orders') return createLocalOrder(body as NewOrderBody);
    if (method === 'POST' && p === '/api/orders/shift') return closeShiftLocal((body ?? {}) as never);
    if (method === 'DELETE' && (m = p.match(/^\/api\/orders\/(\d+)$/))) return voidLocal(Number(m[1]), String((body as { reason?: string } | undefined)?.reason ?? '').slice(0, 200));
    if (method === 'POST' && (m = p.match(/^\/api\/recipes\/(\d+)\/brew$/))) return brewLocal(Number(m[1]), body as never);
    if (method === 'POST' && (m = p.match(/^\/api\/recipes\/(\d+)\/favorite$/))) return favLocal(Number(m[1]));
    if (method === 'POST' && (m = p.match(/^\/api\/ingredients\/(\d+)\/stock$/))) return stockLocal(Number(m[1]), body as never);
    if (method === 'DELETE' && (m = p.match(/^\/api\/batches\/(\d+)$/))) return discardBatchLocal(Number(m[1]));
    if (method === 'POST' && p === '/api/stock/take') return takeLocal(body as never);
    if (method === 'PUT' && p === '/api/settings') return settingsLocal((body ?? {}) as never);
    if (method === 'POST' && p === '/api/auth/logout') return { ok: true };
    throw new LocalError(503, NEED_NET);
  };
  return (method === 'GET' ? go() : serial(go)) as Promise<T>;
}

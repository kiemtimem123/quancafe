import type Database from 'better-sqlite3';
import { getDb } from './db';
import { loadIngredients } from './recipes';
import type { Ingredient } from './types';

export interface Option { id: number; name: string; price: number; ingredient_id: number | null; qty: number; active: boolean; sort: number; cost: number; available: boolean; ingredient_name: string }

/** Topping / tuỳ chọn có giá. `cost` và `available` tính từ nguyên liệu gắn kèm (nếu có). */
export function loadOptions(db: Database.Database = getDb(), ings?: Ingredient[]): Option[] {
  const all = ings ?? loadIngredients(db);
  const by = new Map(all.map((i) => [i.id, i]));
  const rows = db.prepare('SELECT * FROM options ORDER BY sort, id').all() as { id: number; name: string; price: number; ingredient_id: number | null; qty: number; active: number; sort: number }[];
  return rows.map((r) => {
    const ing = r.ingredient_id ? by.get(r.ingredient_id) : undefined;
    return {
      id: r.id, name: r.name, price: r.price, ingredient_id: r.ingredient_id, qty: r.qty, active: !!r.active, sort: r.sort,
      cost: ing ? ing.unit_cost * r.qty : 0,
      available: !ing || !ing.track_stock || ing.stock_quantity * ing.pack_size >= r.qty - 1e-9,
      ingredient_name: ing?.name ?? '',
    };
  });
}

import fs from 'fs';
import path from 'path';
import nodemailer from 'nodemailer';
import { getDb } from './db';

/** Cấu hình thông báo lưu trong bảng settings (khóa bắt đầu bằng n_). Mật khẩu/token không bao giờ trả về trình duyệt. */
export const NOTIFY_KEYS = ['n_tg_token', 'n_tg_chat', 'n_zalo_token', 'n_zalo_chat', 'n_order_alert', 'n_smtp_host', 'n_smtp_port', 'n_smtp_user', 'n_smtp_pass', 'n_smtp_from', 'n_mail_to', 'n_report_enabled', 'n_report_time', 'n_backup_send'] as const;
export type NotifyKey = (typeof NOTIFY_KEYS)[number];
const SECRET: NotifyKey[] = ['n_tg_token', 'n_smtp_pass', 'n_zalo_token'];

export function getNotify(): Record<NotifyKey, string> {
  const rows = getDb().prepare("SELECT key, value FROM settings WHERE key LIKE 'n\\_%' ESCAPE '\\'").all() as { key: string; value: string }[];
  const m = Object.fromEntries(rows.map((r) => [r.key, r.value]));
  return Object.fromEntries(NOTIFY_KEYS.map((k) => [k, m[k] ?? (k === 'n_report_time' ? '22:00' : k === 'n_smtp_port' ? '587' : k === 'n_backup_send' ? 'none' : k === 'n_order_alert' ? '1' : '')])) as Record<NotifyKey, string>;
}
export function publicNotify() {
  const c = getNotify();
  return { ...Object.fromEntries(NOTIFY_KEYS.filter((k) => !SECRET.includes(k)).map((k) => [k, c[k]])), has_tg_token: !!c.n_tg_token, has_zalo_token: !!c.n_zalo_token, has_smtp_pass: !!c.n_smtp_pass };
}
export function saveNotify(d: Partial<Record<NotifyKey, string>>) {
  const up = getDb().prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)');
  for (const [k, v] of Object.entries(d)) {
    if (!(NOTIFY_KEYS as readonly string[]).includes(k) || v === undefined) continue;
    if (SECRET.includes(k as NotifyKey) && v === '') continue; // để trống = giữ nguyên
    up.run(k, v);
  }
}
export const telegramReady = () => { const c = getNotify(); return !!(c.n_tg_token && c.n_tg_chat); };
export const zaloReady = () => { const c = getNotify(); return !!(c.n_zalo_token && c.n_zalo_chat); };
export const emailReady = () => { const c = getNotify(); return !!(c.n_smtp_host && c.n_smtp_user && c.n_smtp_pass && c.n_mail_to); };

export interface Sent { ok: boolean; error?: string }
export async function sendTelegram(text: string, file?: string): Promise<Sent> {
  const c = getNotify();
  if (!telegramReady()) return { ok: false, error: 'Chưa cấu hình Telegram' };
  try {
    const url = `https://api.telegram.org/bot${c.n_tg_token}/${file ? 'sendDocument' : 'sendMessage'}`;
    let res: Response;
    if (file) {
      const fd = new FormData();
      fd.append('chat_id', c.n_tg_chat);
      fd.append('caption', text.slice(0, 1000));
      fd.append('document', new Blob([fs.readFileSync(file)]), path.basename(file));
      res = await fetch(url, { method: 'POST', body: fd, signal: AbortSignal.timeout(60_000) });
    } else {
      res = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ chat_id: c.n_tg_chat, text: text.slice(0, 4000) }), signal: AbortSignal.timeout(20_000) });
    }
    if (!res.ok) { const j = (await res.json().catch(() => ({}))) as { description?: string }; return { ok: false, error: `Telegram: ${j.description ?? res.status}` }; }
    return { ok: true };
  } catch (e) { return { ok: false, error: `Telegram: ${e instanceof Error ? e.message : 'lỗi mạng'}` }; }
}
/** Zalo Bot (bot.zapps.me): token nằm trong URL, chat_id là người nhận (nhắn bot trước để lấy). */
export async function sendZalo(text: string): Promise<Sent> {
  const c = getNotify();
  if (!zaloReady()) return { ok: false, error: 'Chưa cấu hình Zalo' };
  try {
    const res = await fetch(`https://bot-api.zaloplatforms.com/bot${c.n_zalo_token}/sendMessage`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ chat_id: c.n_zalo_chat, text: text.slice(0, 2000) }), signal: AbortSignal.timeout(20_000) });
    const j = (await res.json().catch(() => ({}))) as { ok?: boolean; description?: string };
    if (!res.ok || j.ok === false) return { ok: false, error: `Zalo: ${j.description ?? res.status}` };
    return { ok: true };
  } catch (e) { return { ok: false, error: `Zalo: ${e instanceof Error ? e.message : 'lỗi mạng'}` }; }
}
/** Lấy chat_id của những người đã nhắn bot gần đây (để quản lý khỏi phải tự dò). */
export async function zaloRecentChats(token: string): Promise<{ id: string; name: string }[]> {
  const res = await fetch(`https://bot-api.zaloplatforms.com/bot${token}/getUpdates`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ timeout: 1 }), signal: AbortSignal.timeout(15_000) });
  const j = (await res.json().catch(() => ({}))) as { ok?: boolean; description?: string; result?: unknown };
  if (!res.ok || j.ok === false) throw new Error(j.description ?? `HTTP ${res.status}`);
  const arr = Array.isArray(j.result) ? j.result : j.result ? [j.result] : [];
  const seen = new Map<string, string>();
  for (const u of arr as { message?: { chat?: { id?: string; display_name?: string }; from?: { display_name?: string } } }[]) {
    const id = u.message?.chat?.id; if (id) seen.set(id, u.message?.from?.display_name ?? u.message?.chat?.display_name ?? '');
  }
  return [...seen].map(([id, name]) => ({ id, name }));
}
export async function sendEmail(subject: string, text: string, to?: string, file?: string): Promise<Sent> {
  const c = getNotify();
  if (!c.n_smtp_host || !c.n_smtp_user || !c.n_smtp_pass) return { ok: false, error: 'Chưa cấu hình email (SMTP)' };
  const dest = to ?? c.n_mail_to;
  if (!dest) return { ok: false, error: 'Chưa có email nhận' };
  try {
    const port = Number(c.n_smtp_port) || 587;
    const tr = nodemailer.createTransport({ host: c.n_smtp_host, port, secure: port === 465, auth: { user: c.n_smtp_user, pass: c.n_smtp_pass }, connectionTimeout: 15_000, socketTimeout: 60_000 });
    await tr.sendMail({ from: c.n_smtp_from || c.n_smtp_user, to: dest, subject, text, attachments: file ? [{ filename: path.basename(file), path: file }] : undefined });
    return { ok: true };
  } catch (e) { return { ok: false, error: `Email: ${e instanceof Error ? e.message : 'lỗi gửi'}` }; }
}
/** Gửi qua mọi kênh đã cấu hình. */
export async function sendAll(subject: string, text: string, file?: string): Promise<{ sent: string[]; errors: string[] }> {
  const sent: string[] = [], errors: string[] = [];
  if (telegramReady()) { const r = await sendTelegram(text, file); (r.ok ? sent : errors).push(r.ok ? 'Telegram' : r.error!); }
  if (zaloReady() && !file) { const r = await sendZalo(text); (r.ok ? sent : errors).push(r.ok ? 'Zalo' : r.error!); }
  if (emailReady()) { const r = await sendEmail(subject, text, undefined, file); (r.ok ? sent : errors).push(r.ok ? 'Email' : r.error!); }
  if (!sent.length && !errors.length) errors.push('Chưa cấu hình Zalo, Telegram hoặc email');
  return { sent, errors };
}

/** Báo ngay khi khách đặt đơn qua QR: Zalo/Telegram/email (chạy nền, lỗi không ảnh hưởng đơn). */
export function notifyNewCustomerOrder(o: { code: string; table_name: string; total: number; lines: string[]; note?: string; customer_name?: string; customer_phone?: string }) {
  try {
    if (getNotify().n_order_alert === '0') return;
    const text = `🔔 ĐƠN MỚI ${o.code} · ${o.table_name}\n${o.lines.join('\n')}\nTổng: ${o.total.toLocaleString('vi-VN')}đ${o.customer_name || o.customer_phone ? `\nKhách: ${[o.customer_name, o.customer_phone].filter(Boolean).join(' · ')}` : ''}${o.note ? `\nGhi chú: ${o.note}` : ''}\n→ Mở app, mục “Đơn khách đặt qua QR” để nhận đơn.`;
    void sendAll(`Đơn mới ${o.code}`, text).catch(() => {});
  } catch { /* bỏ qua */ }
}

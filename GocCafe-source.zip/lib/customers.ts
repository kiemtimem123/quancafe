import { getDb } from './db';
import { LOYALTY_DEFAULT, type LoyaltyCfg } from './loyalty-pure';

export interface Customer { id: number; phone: string; name: string; points: number; visits: number; total_spent: number; last_visit: string | null; created_at: string }

export function loyaltyCfg(): LoyaltyCfg {
  const rows = getDb().prepare("SELECT key, value FROM settings WHERE key IN ('loyalty_earn_per','loyalty_point_value')").all() as { key: string; value: string }[];
  const m = Object.fromEntries(rows.map((r) => [r.key, Number(r.value)]));
  return { earn_per: Number.isFinite(m.loyalty_earn_per) && m.loyalty_earn_per >= 0 ? m.loyalty_earn_per : LOYALTY_DEFAULT.earn_per, point_value: Number.isFinite(m.loyalty_point_value) && m.loyalty_point_value >= 0 ? m.loyalty_point_value : LOYALTY_DEFAULT.point_value };
}
export const findCustomer = (phone: string) => getDb().prepare('SELECT * FROM customers WHERE phone=?').get(phone) as Customer | undefined;

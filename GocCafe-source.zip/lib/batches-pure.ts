/** Lô nguyên liệu & hạn sử dụng — dùng chung cho máy chủ và chế độ offline. */
export interface Batch { id: number; ingredient_id: number; qty: number; received_on: string; expires_on: string | null; unit_price: number | null; note: string }
export interface Expiry { status: 'ok' | 'soon' | 'expired'; next_date: string | null; days: number | null; soon_qty: number; expired_qty: number }
export const WARN_DAYS_DEFAULT = 3;

export const dayDiff = (from: string, to: string) => Math.round((Date.parse(to) - Date.parse(from)) / 864e5);
export const addDays = (date: string, n: number) => new Date(Date.parse(date) + n * 864e5).toISOString().slice(0, 10);

/** Tình trạng hạn dùng của một nguyên liệu từ các lô còn hàng (null nếu không có lô nào có hạn). */
export function expiryOf(batches: Batch[], today: string, warn: number): Expiry | null {
  const open = batches.filter((b) => b.qty > 1e-9 && b.expires_on);
  if (!open.length) return null;
  let expired = 0, soon = 0, next: string | null = null;
  for (const b of open) {
    const d = dayDiff(today, b.expires_on!);
    if (d < 0) expired += b.qty; else if (d <= warn) soon += b.qty;
    if (!next || b.expires_on! < next) next = b.expires_on;
  }
  return { status: expired > 0 ? 'expired' : soon > 0 ? 'soon' : 'ok', next_date: next, days: dayDiff(today, next!), soon_qty: soon, expired_qty: expired };
}

/** Dùng lô sắp hết hạn trước (FEFO); lô không ghi hạn dùng sau cùng. Trả về phần trừ từng lô. */
export function consumeFefo(batches: Batch[], qty: number): { id: number; take: number }[] {
  const order = batches.filter((b) => b.qty > 1e-9).sort((a, b) => (a.expires_on ?? '9999') .localeCompare(b.expires_on ?? '9999') || a.received_on.localeCompare(b.received_on) || a.id - b.id);
  const out: { id: number; take: number }[] = [];
  let left = qty;
  for (const b of order) {
    if (left <= 1e-9) break;
    const t = Math.min(b.qty, left);
    out.push({ id: b.id, take: t });
    left -= t;
  }
  return out;
}

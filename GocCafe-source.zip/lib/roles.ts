export type Role = 'admin' | 'manager' | 'staff';
export type Perm = 'edit_recipes' | 'edit_ingredients' | 'view_cost' | 'view_dashboard' | 'manage_users' | 'view_audit' | 'void_order';

export const ROLES: Role[] = ['admin', 'manager', 'staff'];
export const ROLE_LABEL: Record<Role, string> = { admin: 'Quản trị viên', manager: 'Quản lý', staff: 'Nhân viên pha chế' };
export const ROLE_DESC: Record<Role, string> = {
  admin: 'Toàn quyền, kể cả quản lý người dùng',
  manager: 'Sửa công thức, nguyên liệu, giá; xem giá vốn & dashboard',
  staff: 'Tìm món, xem công thức, pha chế, in — không thấy giá vốn/lợi nhuận',
};
const PERMS: Record<Role, Perm[]> = {
  admin: ['edit_recipes', 'edit_ingredients', 'view_cost', 'view_dashboard', 'manage_users', 'view_audit', 'void_order'],
  manager: ['edit_recipes', 'edit_ingredients', 'view_cost', 'view_dashboard', 'void_order'],
  staff: [],
};
export const can = (role: Role | undefined | null, perm: Perm) => !!role && PERMS[role]?.includes(perm);
export interface SessionUser { id: number; name: string; email: string; role: Role }

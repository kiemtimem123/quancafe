import { ALWAYS_AVAILABLE, type MatchResult, type Recipe } from './types';
import { mainSize, type Prep } from './pure';

export interface MatchCtx {
  groups: Map<number, string>; // ingredient id -> group_name
  names: Map<number, string>;
  cats: Map<number, string>;
  preps: Map<number, Prep>;
}

/** Nguyên liệu bắt buộc của món (bỏ nhóm luôn có sẵn & dòng tùy chọn). */
export function requiredIngredients(r: Recipe): { id: number; name: string }[] {
  const base = mainSize(r);
  if (!base) return [];
  return base.lines.filter((l) => !l.optional && !ALWAYS_AVAILABLE.includes(l.category)).map((l) => ({ id: l.ingredient_id, name: l.name }));
}

/** Tập nguyên liệu "coi như có": đã chọn + bán thành phẩm làm được từ nguyên liệu đang có (lặp đến khi ổn định). */
function expandHave(have: Set<number>, ctx: MatchCtx): Map<number, { via?: 'prep'; by?: string }> {
  const res = new Map<number, { via?: 'prep'; by?: string }>();
  have.forEach((id) => res.set(id, {}));
  let changed = true;
  while (changed) {
    changed = false;
    ctx.preps.forEach((p, id) => {
      if (res.has(id)) return;
      const ok = p.lines.every((l) => {
        if (ALWAYS_AVAILABLE.includes(ctx.cats.get(l.component_id) ?? '')) return true;
        return res.has(l.component_id) || hasViaGroup(l.component_id, res, ctx);
      });
      if (ok && p.lines.length) {
        res.set(id, { via: 'prep', by: 'tự làm' });
        changed = true;
      }
    });
  }
  return res;
}

function hasViaGroup(id: number, res: Map<number, unknown>, ctx: MatchCtx): string | null {
  const g = ctx.groups.get(id);
  if (!g) return null;
  let found: string | null = null;
  res.forEach((_v, other) => {
    if (!found && other !== id && ctx.groups.get(other) === g) found = ctx.names.get(other) ?? '';
  });
  return found;
}

export function matchRecipes(recipes: Recipe[], have: Set<number>, priority: Set<number>, ctx: MatchCtx): MatchResult[] {
  const out: MatchResult[] = [];
  const eff = expandHave(have, ctx);
  for (const r of recipes) {
    const base = mainSize(r);
    if (!base) continue;
    const req = requiredIngredients(r);
    if (!req.length) continue;
    const marked = req.map((x) => {
      const direct = eff.get(x.id);
      if (direct) return { ...x, have: true, ...(direct.via ? { via: direct.via, by: direct.by } : {}) };
      const sub = hasViaGroup(x.id, eff, ctx);
      if (sub) return { ...x, have: true, via: 'substitute' as const, by: sub };
      return { ...x, have: false };
    });
    const missing = marked.filter((x) => !x.have).map((x) => x.name);
    const priority_used = req.filter((x) => priority.has(x.id)).length;
    const optional = base.lines
      .filter((l) => l.optional && !ALWAYS_AVAILABLE.includes(l.category))
      .map((l) => ({ id: l.ingredient_id, name: l.name, have: eff.has(l.ingredient_id) || !!hasViaGroup(l.ingredient_id, eff, ctx) }));
    out.push({ recipe: r, required: marked, optional, missing, percent: ((req.length - missing.length) / req.length) * 100, priority_used });
  }
  const margin = (m: MatchResult) => mainSize(m.recipe)?.margin ?? 0;
  if (priority.size) {
    out.sort((a, b) => b.priority_used - a.priority_used || a.missing.length - b.missing.length || margin(b) - margin(a));
  } else {
    out.sort((a, b) => a.missing.length - b.missing.length || b.percent - a.percent || margin(b) - margin(a) || a.recipe.name.localeCompare(b.recipe.name, 'vi'));
  }
  return out;
}

import type Database from 'better-sqlite3';
import { getDb } from './db';
import type { Promo } from './promo-pure';

export function loadPromos(db: Database.Database = getDb(), onlyActive = false): Promo[] {
  const rows = db.prepare(`SELECT * FROM promotions ${onlyActive ? 'WHERE active=1' : ''} ORDER BY id DESC`).all() as (Omit<Promo, 'active'> & { active: number })[];
  return rows.map((r) => ({ ...r, active: !!r.active }));
}

import { getDb } from './db';

export interface Actor { id: number; name: string }

/** Ghi nhật ký thao tác. Không bao giờ làm hỏng thao tác chính nếu ghi lỗi. */
export function audit(user: Actor | null, action: string, entity: string, entityId: number | null, summary: string) {
  try {
    getDb().prepare('INSERT INTO audit_log (user_id, user_name, action, entity, entity_id, summary) VALUES (?,?,?,?,?,?)')
      .run(user?.id ?? null, user?.name ?? '', action, entity, entityId, summary.slice(0, 500));
  } catch (e) { console.error('audit failed', e); }
}

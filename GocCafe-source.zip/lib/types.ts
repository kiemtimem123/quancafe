export type BaseUnit = 'g' | 'ml' | 'cái';
export const PURCHASE_UNITS = ['g', 'kg', 'ml', 'lít', 'cái', 'gói', 'chai', 'lon', 'hộp', 'bịch'] as const;
export const RECIPE_UNITS = ['g', 'kg', 'ml', 'lít', 'cái'] as const;
export const SIZES = ['S', 'M', 'L'] as const;
export type Size = (typeof SIZES)[number];

export const ING_CATEGORIES = [
  'Cà phê', 'Sữa & Kem', 'Trà', 'Matcha & Bột', 'Syrup & Sốt', 'Trái cây', 'Topping', 'Đồ uống', 'Cơ bản', 'Bao bì', 'Khác',
] as const;
/** Nhóm luôn có sẵn: không tính là "thiếu" khi tìm món */
export const ALWAYS_AVAILABLE = ['Cơ bản', 'Bao bì'];

export const RECIPE_CATEGORIES: { name: string; icon: string }[] = [
  { name: 'Cà phê', icon: '☕' },
  { name: 'Trà sữa', icon: '🧋' },
  { name: 'Matcha', icon: '🍵' },
  { name: 'Trà trái cây', icon: '🍹' },
  { name: 'Đá xay', icon: '🥤' },
  { name: 'Chocolate', icon: '🍫' },
  { name: 'Sinh tố', icon: '🍓' },
  { name: 'Nước ép', icon: '🍊' },
  { name: 'Soda', icon: '🧃' },
];
export const DIFFICULTIES = ['Dễ', 'Trung bình', 'Khó'] as const;

export interface Ingredient {
  id: number;
  name: string;
  category: string;
  unit: string; // đơn vị mua (kg, lon...)
  base_unit: BaseUnit; // đơn vị nhỏ nhất dùng pha chế
  pack_size: number; // số base_unit trong 1 đơn vị mua
  purchase_price: number; // giá cho 1 đơn vị mua
  stock_quantity: number; // theo đơn vị mua
  minimum_stock: number;
  supplier: string;
  note: string;
  unit_cost: number; // giá / 1 base_unit (tính)
  low_stock: boolean;
  out_of_stock: boolean; // đang theo dõi tồn và đã hết
  track_stock: boolean;
  group_name: string; // nhóm thay thế lẫn nhau khi tìm món
  has_prep: boolean; // bán thành phẩm tự pha (giá vốn tự tính)
  track_expiry: boolean; // có theo dõi hạn sử dụng
  shelf_life_days: number; // hạn dùng mặc định (ngày) khi nhập lô, 0 = tự nhập
  expiry: import('./batches-pure').Expiry | null;
  created_at: string;
  updated_at: string;
}

export interface RecipeLine {
  ingredient_id: number;
  name: string;
  category: string;
  quantity: number;
  unit: string;
  base_qty: number;
  cost: number;
  stock_ok: boolean;
  optional: boolean;
}
export interface SizeDetail {
  name: Size;
  selling_price: number;
  lines: RecipeLine[];
  raw_cost: number;
  waste_cost: number;
  cost: number;
  profit: number;
  margin: number; // % lợi nhuận gộp trên giá bán
  cost_ratio: number;
}
export interface Recipe {
  id: number;
  name: string;
  category: string;
  description: string;
  image: string;
  difficulty: string;
  preparation_time: number;
  instructions: string[];
  favorite: boolean;
  created_at: string;
  updated_at: string;
  sizes: SizeDetail[];
  availability?: Availability;
}
export interface Availability {
  status: 'ok' | 'low' | 'out';
  cups: number | null; // số ly size M còn pha được (null = không giới hạn/không theo dõi)
  out: string[]; // nguyên liệu đã hết
  limiting: string[]; // nguyên liệu giới hạn số ly
  substitutes: string[]; // đang phải dùng nguyên liệu thay thế
}
export interface MatchResult {
  recipe: Recipe;
  required: { id: number; name: string; have: boolean; via?: 'substitute' | 'prep'; by?: string }[];
  optional: { id: number; name: string; have: boolean }[];
  missing: string[];
  percent: number;
  priority_used: number;
}

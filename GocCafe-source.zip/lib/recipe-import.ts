import ExcelJS from 'exceljs';
import { norm } from './format';
import { getDb } from './db';
import { parseNum } from './ingredient-import';
import { loadIngredients, saveRecipe, validateLines, type RecipeInput } from './recipes';
import { RECIPE_UNITS, SIZES, type Size } from './types';
import { audit } from './audit';

export interface ParsedLine { name: string; quantity: number; unit?: string; optional: boolean }
export interface ParsedRecipe {
  row: number; name: string; category?: string; time?: number; difficulty?: string; description?: string; instructions: string[];
  sizes: { name: Size; price: number; lines: ParsedLine[] }[];
  errors: string[]; warnings: string[];
}
export interface RecipePlan extends ParsedRecipe { action: 'create' | 'update' | 'skip' | 'error'; reason?: string; existing_id?: number; input?: RecipeInput }

const cellText = (v: ExcelJS.CellValue): string => {
  if (v == null) return '';
  if (typeof v === 'object') {
    if ('result' in v) return cellText(v.result as ExcelJS.CellValue);
    if ('formula' in v || 'sharedFormula' in v) return '';
    if ('richText' in v) return v.richText.map((t) => t.text).join('');
    if ('text' in v) return String(v.text);
    if ('error' in v) return '';
  }
  return String(v).trim();
};
const numOf = (v: ExcelJS.CellValue) => {
  if (v && typeof v === 'object' && 'result' in v && typeof v.result === 'number') return v.result;
  return parseNum(v);
};

export function guessRecipeCategory(name: string): string {
  const n = norm(name);
  const rules: [RegExp, string][] = [
    [/tra sua|milk tea/, 'Trà sữa'], [/matcha/, 'Matcha'], [/da xay|frappe|smoothie/, 'Đá xay'], [/sinh to/, 'Sinh tố'],
    [/soda/, 'Soda'], [/cacao|chocolate|socola/, 'Chocolate'], [/ep\b|nuoc ep|cam vat/, 'Nước ép'],
    [/ca phe|cafe|bac xiu|espresso|latte|americano|cappuccino/, 'Cà phê'], [/tra\b/, 'Trà trái cây'],
  ];
  for (const [re, c] of rules) if (re.test(n + ' ')) return c;
  return 'Cà phê';
}

const HDR: Record<string, string[]> = {
  name: ['mon', 'ten mon'], category: ['danh muc', 'nhom mon'], size: ['size'], price: ['gia ban'],
  ing: ['nguyen lieu', 'ten nguyen lieu'], qty: ['dinh luong', 'so luong'], unit: ['don vi'], optional: ['tuy chon', 'khong bat buoc'],
  steps: ['cach lam', 'cac buoc', 'huong dan'], time: ['thoi gian', 'thoi gian pha'], diff: ['do kho'], desc: ['mo ta'],
};
const fieldOf = (s: string) => { const t = norm(s.replace(/\(.*?\)/g, '')).replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim(); return Object.entries(HDR).find(([, l]) => l.includes(t))?.[0]; };

export async function parseRecipeFile(buf: Buffer): Promise<{ recipes: ParsedRecipe[]; format: 'mau' | 'bang-tinh' }> {
  if (buf.length < 4 || buf[0] !== 0x50 || buf[1] !== 0x4b) throw new Error('File không phải Excel (.xlsx).');
  const wb = new ExcelJS.Workbook();
  try { await wb.xlsx.load(buf as unknown as ExcelJS.Buffer); } catch { throw new Error('Không đọc được file Excel — file có thể bị hỏng hoặc có mật khẩu.'); }
  for (const ws of wb.worksheets) {
    for (let r = 1; r <= Math.min(ws.rowCount, 40); r++) {
      const cols: Record<string, number> = {};
      ws.getRow(r).eachCell({ includeEmpty: false }, (c, col) => { const f = fieldOf(cellText(c.value)); if (f && !(f in cols)) cols[f] = col; });
      if (cols.name && cols.ing && cols.qty) return { recipes: readTemplate(ws, r, cols), format: 'mau' };
    }
  }
  for (const ws of wb.worksheets) {
    for (let r = 1; r <= Math.min(ws.rowCount, 40); r++) {
      const row = ws.getRow(r);
      const nameCol = [2, 3, 1].find((c) => norm(cellText(row.getCell(c).value)) === 'ten');
      if (nameCol && /^nl\s*1$/i.test(cellText(row.getCell(nameCol + 1).value).replace(/\s/g, ' '))) return { recipes: readBlocks(ws, r, nameCol), format: 'bang-tinh' };
    }
  }
  throw new Error('Không nhận ra định dạng. Dùng file mẫu (cột: Món, Danh mục, Size, Giá bán, Nguyên liệu, Định lượng, Đơn vị…) hoặc bảng tính cost của quán (Tên | NL 1 | NL 2 …).');
}

function readTemplate(ws: ExcelJS.Worksheet, hr: number, c: Record<string, number>): ParsedRecipe[] {
  const out: ParsedRecipe[] = [];
  const map = new Map<string, ParsedRecipe>();
  let cur: ParsedRecipe | undefined;
  let curSize = 'M';
  for (let r = hr + 1; r <= ws.rowCount; r++) {
    const row = ws.getRow(r);
    const g = (f: string) => (c[f] ? cellText(row.getCell(c[f]).value) : '');
    const name = g('name').replace(/\s+/g, ' ');
    const ing = g('ing');
    if (!name && !ing) continue;
    if (name) {
      curSize = 'M';
      cur = map.get(norm(name));
      if (!cur) { cur = { row: r, name, instructions: [], sizes: [], errors: [], warnings: [] }; map.set(norm(name), cur); out.push(cur); if (out.length > 500) throw new Error('Tối đa 500 món mỗi lần nhập.'); }
      const cat = g('category'); if (cat) cur.category = cat;
      const t = g('time'); if (t && isFinite(parseNum(t))) cur.time = Math.round(parseNum(t));
      const d = g('diff'); if (d) cur.difficulty = d;
      const ds = g('desc'); if (ds) cur.description = ds.slice(0, 300);
      const st = g('steps'); if (st && !cur.instructions.length) cur.instructions = st.split(/\r?\n|;/).map((x) => x.replace(/^\s*\d+[.)]\s*/, '').trim()).filter(Boolean);
    }
    if (!cur) continue;
    if (!ing) continue;
    if (g('size')) curSize = g('size').toUpperCase();
    const sizeRaw = curSize;
    if (!(SIZES as readonly string[]).includes(sizeRaw)) { cur.errors.push(`Dòng ${r}: size "${sizeRaw}" phải là S, M hoặc L`); continue; }
    const size = sizeRaw as Size;
    let sz = cur.sizes.find((s) => s.name === size);
    const priceTxt = g('price');
    const price = priceTxt ? parseNum(priceTxt) : NaN;
    if (!sz) { sz = { name: size, price: isFinite(price) ? price : 0, lines: [] }; cur.sizes.push(sz); }
    else if (isFinite(price) && !sz.price) sz.price = price;
    const q = numOf(row.getCell(c.qty).value);
    if (!isFinite(q) || q <= 0) { cur.errors.push(`Dòng ${r}: định lượng "${g('qty')}" không hợp lệ`); continue; }
    const unit = g('unit') ? (g('unit').toLowerCase() === 'l' ? 'lít' : g('unit').toLowerCase()) : undefined;
    if (unit && !(RECIPE_UNITS as readonly string[]).includes(unit)) { cur.errors.push(`Dòng ${r}: đơn vị "${unit}" không hợp lệ (g, kg, ml, lít, cái)`); continue; }
    sz.lines.push({ name: ing, quantity: q, unit, optional: /^(x|1|co|có|yes|y|true)$/i.test(g('optional')) });
  }
  return out;
}

/** Bảng tính cost của quán: mỗi món 3 dòng — dòng tên nguyên liệu, dòng định lượng, dòng thành tiền (bỏ qua). */
function readBlocks(ws: ExcelJS.Worksheet, hr: number, nameCol: number): ParsedRecipe[] {
  const out: ParsedRecipe[] = [];
  const priceCol = (() => { for (let c = nameCol + 1; c <= nameCol + 14; c++) if (norm(cellText(ws.getRow(hr).getCell(c).value)).startsWith('gia ban')) return c; return nameCol + 9; })();
  const seen = new Set<string>();
  for (let r = hr + 1; r < ws.rowCount; r++) {
    const row = ws.getRow(r), next = ws.getRow(r + 1);
    const name = cellText(row.getCell(nameCol).value).replace(/\s+/g, ' ');
    if (!name || norm(name) !== norm(cellText(next.getCell(nameCol).value)) || seen.has(norm(name))) continue;
    const names: string[] = [], qtys: number[] = [];
    let isNames = false;
    for (let k = 1; k <= 8; k++) {
      const t = cellText(row.getCell(nameCol + k).value);
      const q = numOf(next.getCell(nameCol + k).value);
      if (t && !isFinite(parseNum(t)) && isFinite(q) && q > 0) { names.push(t); qtys.push(q); isNames = true; }
    }
    if (!isNames) continue;
    seen.add(norm(name));
    const price = numOf(row.getCell(priceCol).value);
    const rec: ParsedRecipe = { row: r, name, instructions: [], sizes: [{ name: 'M', price: isFinite(price) ? price : 0, lines: names.map((n, i) => ({ name: n.replace(/\s+/g, ' '), quantity: qtys[i], optional: false })) }], errors: [], warnings: [] };
    if (!isFinite(price) || price <= 0) rec.warnings.push('Chưa có giá bán — nếu là bán thành phẩm hãy tạo ở Nguyên liệu → “Tự làm?”');
    out.push(rec);
  }
  return out;
}

/** Tìm nguyên liệu theo tên: khớp chính xác → chứa nhau → trùng từ. */
function makeResolver() {
  const ings = loadIngredients(getDb());
  const key = (x: string) => norm(x).replace(/[^a-z0-9]+/g, ' ').trim();
  const exact = new Map(ings.map((i) => [key(i.name), i]));
  const alias: Record<string, string> = { 'bo ly muong': 'ly ong hut nap', 'ly': 'ly ong hut nap', 'cafe': 'ca phe', 'cafe phin': 'ca phe phin', 'cafe may': 'espresso', 'ca phe may': 'espresso' };
  const tok = (s: string) => new Set(norm(s).replace(/[^a-z0-9 ]/g, ' ').split(/\s+/).filter((t) => t.length > 1));
  return (raw: string) => {
    let n = key(raw);
    n = alias[n] ?? n;
    const e = exact.get(n);
    if (e) return { ing: e };
    const aliasHit = ings.find((i) => key(i.name).startsWith(n) || (n.startsWith(key(i.name)) && key(i.name).length >= 4));
    const contains = ings.filter((i) => key(i.name).includes(n) || (key(i.name).length >= 4 && n.includes(key(i.name))));
    if (contains.length === 1) return { ing: contains[0], fuzzy: true };
    if (aliasHit && !contains.length) return { ing: aliasHit, fuzzy: true };
    const t = tok(raw); let best: (typeof ings)[number] | undefined, score = 0;
    for (const i of ings) { const u = tok(i.name); const inter = [...t].filter((x) => u.has(x)).length; const s = inter / (t.size + u.size - inter || 1); if (s > score) { score = s; best = i; } }
    return score >= 0.5 && best ? { ing: best, fuzzy: true } : {};
  };
}

export function planRecipeImport(recipes: ParsedRecipe[], onDuplicate: 'update' | 'skip'): RecipePlan[] {
  const db = getDb();
  const resolve = makeResolver();
  const existing = new Map((db.prepare('SELECT id, name FROM recipes').all() as { id: number; name: string }[]).map((r) => [norm(r.name), r.id]));
  const cats = new Set((db.prepare('SELECT name FROM categories').all() as { name: string }[]).map((c) => c.name));
  return recipes.map((p) => {
    const warnings = [...p.warnings];
    const errors = [...p.errors];
    if (p.name.length > 80) errors.push('Tên món dài quá 80 ký tự');
    if (!p.sizes.length) errors.push('Món chưa có nguyên liệu');
    const sizes: RecipeInput['sizes'] = [];
    for (const s of p.sizes) {
      const lines: RecipeInput['sizes'][number]['lines'] = [];
      const used = new Set<number>();
      for (const l of s.lines) {
        const m = resolve(l.name);
        if (!m.ing) { errors.push(`Không tìm thấy nguyên liệu "${l.name}" — thêm vào kho trước hoặc sửa tên cho khớp`); continue; }
        if (m.fuzzy) warnings.push(`"${l.name}" → ${m.ing.name} (khớp gần đúng)`);
        if (used.has(m.ing.id)) { errors.push(`"${m.ing.name}" bị lặp trong size ${s.name}`); continue; }
        used.add(m.ing.id);
        lines.push({ ingredient_id: m.ing.id, quantity: l.quantity, unit: l.unit ?? m.ing.base_unit, optional: l.optional });
      }
      sizes.push({ name: s.name, selling_price: s.price, lines });
    }
    let category = p.category && cats.has(p.category) ? p.category : undefined;
    if (p.category && !category) { const f = [...cats].find((c) => norm(c) === norm(p.category!)); category = f; if (!f) warnings.push(`Danh mục "${p.category}" chưa có — tự đoán theo tên món`); }
    category ??= guessRecipeCategory(p.name);
    const diff = (['Dễ', 'Trung bình', 'Khó'] as const).find((d) => norm(d) === norm(p.difficulty ?? '')) ?? 'Dễ';
    const input: RecipeInput = { name: p.name, category, description: p.description ?? '', image: '', difficulty: diff, preparation_time: Math.min(240, Math.max(1, p.time ?? 3)), instructions: p.instructions, sizes };
    if (!errors.length) { const e = validateLines(input, db); if (e) errors.push(e); }
    const base = { ...p, warnings, errors };
    if (errors.length) return { ...base, action: 'error' as const, reason: errors.join('; ') };
    const ex = existing.get(norm(p.name));
    if (!ex) return { ...base, action: 'create' as const, input };
    if (onDuplicate === 'skip') return { ...base, action: 'skip' as const, existing_id: ex, reason: 'Đã có món này — bỏ qua' };
    // cập nhật: giữ ảnh cũ + cách làm cũ nếu file không có
    const old = db.prepare('SELECT image, instructions, description FROM recipes WHERE id=?').get(ex) as { image: string; instructions: string; description: string };
    input.image = old.image;
    if (!input.instructions.length) { try { input.instructions = JSON.parse(old.instructions); } catch { /* bỏ qua */ } }
    if (!input.description) input.description = old.description;
    return { ...base, action: 'update' as const, existing_id: ex, input };
  });
}

export function commitRecipePlan(plan: RecipePlan[], user: { id: number; name: string } | null) {
  let created = 0, updated = 0;
  getDb().transaction(() => {
    for (const p of plan) {
      if (!p.input) continue;
      if (p.action === 'create') { saveRecipe(p.input); created++; }
      else if (p.action === 'update') { saveRecipe(p.input, p.existing_id); updated++; }
    }
  })();
  audit(user, 'import', 'recipe', null, `Nhập Excel công thức: thêm ${created}, cập nhật ${updated}`);
  return { created, updated };
}

/** Khuyến mãi / voucher / combo — thuần (không DB) để dùng chung cho máy chủ, POS và chế độ offline. */
export interface Promo {
  id: number; name: string; code: string; // code rỗng = tự áp dụng; có code = voucher khách nhập
  type: 'percent' | 'amount'; value: number;
  scope: 'order' | 'category' | 'recipe' | 'combo'; target: string; // category: tên nhóm · recipe: id món · combo: "id1,id2" (cần đủ các món)
  min_total: number; min_qty: number;
  time_from: string; time_to: string; // "HH:MM" (happy hour); rỗng = cả ngày
  days: string; // "1,2,3" (1=Thứ hai … 7=Chủ nhật); rỗng = mọi ngày
  date_from: string; date_to: string; active: boolean;
}
export interface PLine { recipe_id: number; category: string; quantity: number; unit_price: number }
export interface Now { date: string; time: string; dow: number }

/** Thời điểm theo giờ Việt Nam. */
export function vnNow(d: Date = new Date()): Now {
  const v = new Date(d.getTime() + 7 * 3600_000);
  const iso = v.toISOString();
  return { date: iso.slice(0, 10), time: iso.slice(11, 16), dow: v.getUTCDay() === 0 ? 7 : v.getUTCDay() };
}

export function promoActiveNow(p: Promo, now: Now): boolean {
  if (!p.active) return false;
  if (p.date_from && now.date < p.date_from) return false;
  if (p.date_to && now.date > p.date_to) return false;
  if (p.days && !p.days.split(',').map((x) => x.trim()).includes(String(now.dow))) return false;
  if (p.time_from && p.time_to) {
    const inRange = p.time_from <= p.time_to ? now.time >= p.time_from && now.time <= p.time_to : now.time >= p.time_from || now.time <= p.time_to; // qua đêm
    if (!inRange) return false;
  }
  return true;
}

export interface PromoResult { promo: Promo; discount: number; label: string }
export function evalPromo(p: Promo, lines: PLine[], subtotal: number, now: Now): PromoResult | null {
  if (!promoActiveNow(p, now) || p.value <= 0) return null;
  if (p.min_total > 0 && subtotal < p.min_total) return null;
  let base = 0, qty = 0, sets = 1;
  if (p.scope === 'order') { base = subtotal; qty = lines.reduce((a, l) => a + l.quantity, 0); }
  else if (p.scope === 'category') { const ls = lines.filter((l) => l.category === p.target); base = ls.reduce((a, l) => a + l.unit_price * l.quantity, 0); qty = ls.reduce((a, l) => a + l.quantity, 0); }
  else if (p.scope === 'recipe') { const ls = lines.filter((l) => String(l.recipe_id) === p.target.trim()); base = ls.reduce((a, l) => a + l.unit_price * l.quantity, 0); qty = ls.reduce((a, l) => a + l.quantity, 0); }
  else {
    const ids = p.target.split(',').map((x) => x.trim()).filter(Boolean);
    if (ids.length < 2) return null;
    const per = ids.map((id) => lines.filter((l) => String(l.recipe_id) === id));
    sets = Math.min(...per.map((ls) => ls.reduce((a, l) => a + l.quantity, 0)));
    if (sets < 1) return null;
    base = per.reduce((a, ls) => a + (ls[0]?.unit_price ?? 0), 0) * sets; qty = sets;
  }
  if (base <= 0 || (p.min_qty > 0 && qty < p.min_qty)) return null;
  const raw = p.type === 'percent' ? Math.round((base * Math.min(100, p.value)) / 100) : Math.round(p.value * (p.scope === 'combo' ? sets : 1));
  const discount = Math.min(raw, base, subtotal);
  return discount > 0 ? { promo: p, discount, label: p.name } : null;
}

/** Chọn khuyến mãi tốt nhất (không cộng dồn): voucher nhập tay (nếu hợp lệ) hoặc khuyến mãi tự động. */
export function bestPromo(promos: Promo[], lines: PLine[], subtotal: number, now: Now, code = ''): { result: PromoResult | null; codeError?: string } {
  const c = code.trim().toLowerCase();
  let codeResult: PromoResult | null = null;
  let codeError: string | undefined;
  if (c) {
    const vp = promos.filter((p) => p.code.trim().toLowerCase() === c);
    if (!vp.length) codeError = 'Mã giảm giá không tồn tại';
    else {
      codeResult = vp.map((p) => evalPromo(p, lines, subtotal, now)).filter((x): x is PromoResult => !!x).sort((a, b) => b.discount - a.discount)[0] ?? null;
      if (!codeResult) codeError = 'Mã chưa đủ điều kiện áp dụng cho đơn này (hạn dùng, giờ, món hoặc giá trị tối thiểu)';
    }
  }
  const auto = promos.filter((p) => !p.code.trim()).map((p) => evalPromo(p, lines, subtotal, now)).filter((x): x is PromoResult => !!x).sort((a, b) => b.discount - a.discount)[0] ?? null;
  const result = codeResult && (!auto || codeResult.discount >= auto.discount) ? codeResult : auto;
  return { result, codeError };
}

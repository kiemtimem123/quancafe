/** Tính giảm giá — dùng chung cho máy chủ và chế độ offline để hai bên ra cùng một số tiền. */
export function calcDiscount(subtotal: number, d?: { type: 'amount' | 'percent'; value: number }): { discount: number; label: string } {
  if (!d || !(d.value > 0)) return { discount: 0, label: '' };
  const raw = d.type === 'percent' ? Math.round((subtotal * Math.min(100, d.value)) / 100) : Math.round(d.value);
  return { discount: Math.min(raw, subtotal), label: d.type === 'percent' ? `Giảm ${d.value}%` : 'Giảm giá' };
}

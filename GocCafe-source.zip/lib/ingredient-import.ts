import ExcelJS from 'exceljs';
import { norm } from './format';
import { getDb } from './db';
import { PURCHASE_UNITS, type BaseUnit } from './types';
import { defaultPack } from './units';

type Field = 'name' | 'category' | 'unit_buy' | 'base_unit' | 'unit_any' | 'pack_size' | 'price' | 'stock' | 'min_stock' | 'supplier' | 'note';
const ALIASES: Record<Field, string[]> = {
  name: ['ten nguyen lieu', 'ten', 'nguyen lieu', 'ten nl'],
  category: ['phan loai', 'nhom', 'danh muc', 'loai'],
  unit_buy: ['don vi mua', 'dvt mua', 'don vi nhap'],
  base_unit: ['don vi pha che', 'don vi dung pha che', 'dv pha che', 'don vi co ban'],
  unit_any: ['don vi', 'dvt', 'don vi tinh'],
  pack_size: ['quy cach', 'quy doi', 'so luong'],
  price: ['gia nhap', 'don gia nhap', 'gia mua'],
  stock: ['ton kho', 'ton', 'so luong ton'],
  min_stock: ['ton toi thieu', 'canh bao', 'muc canh bao', 'ton kho toi thieu'],
  supplier: ['nha cung cap', 'ncc'],
  note: ['ghi chu', 'luu y', 'note'],
};
const hnorm = (s: string) => norm(s.replace(/\(.*?\)/g, ' ')).replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
const FIELD_OF = new Map<string, Field>();
for (const [f, list] of Object.entries(ALIASES) as [Field, string[]][]) for (const a of list) FIELD_OF.set(a, f);

export interface ParsedRow {
  row: number; name: string; category?: string; unit?: string; base_unit?: BaseUnit; pack_size?: number;
  purchase_price?: number; stock_quantity?: number; minimum_stock?: number; supplier?: string; note?: string;
  errors: string[]; warnings: string[]; derived_unit?: boolean;
}
export interface ParseResult { rows: ParsedRow[]; format: 'mau' | 'bang-tinh'; sheet: string; headerRow: number }

function cellText(v: ExcelJS.CellValue): string {
  if (v == null) return '';
  if (typeof v === 'object') {
    if ('result' in v) return cellText(v.result as ExcelJS.CellValue);
    if ('formula' in v || 'sharedFormula' in v) return '';
    if ('richText' in v) return v.richText.map((t) => t.text).join('');
    if ('text' in v) return String(v.text);
    if ('error' in v) return String(v.error);
    if (v instanceof Date) return v.toISOString();
  }
  return String(v).trim();
}
const isUncalc = (v: ExcelJS.CellValue | undefined) => typeof v === 'object' && v !== null && ('formula' in v || 'sharedFormula' in v) && (!('result' in v) || v.result === undefined || v.result === null);
const isErr = (v: ExcelJS.CellValue) => typeof v === 'object' && v !== null && (('error' in v) || ('result' in v && typeof v.result === 'object' && v.result !== null && 'error' in (v.result as object)));

/** "25.000đ" → 25000 · "1,5" → 1.5 · "0.5" → 0.5 · số → giữ nguyên. NaN nếu không đọc được. */
export function parseNum(v: ExcelJS.CellValue): number {
  if (typeof v === 'number') return v;
  if (typeof v === 'object' && v !== null && 'result' in v && typeof v.result === 'number') return v.result;
  let s = cellText(v).replace(/(đ|vnđ|vnd|₫)/gi, '').replace(/\s/g, '');
  if (!s) return NaN;
  if (/^\d{1,3}([.,]\d{3})+$/.test(s)) s = s.replace(/[.,]/g, '');
  else if (s.includes(',') && s.includes('.')) s = s.lastIndexOf(',') > s.lastIndexOf('.') ? s.replace(/\./g, '').replace(',', '.') : s.replace(/,/g, '');
  else s = s.replace(',', '.');
  return /^-?\d*\.?\d+$/.test(s) ? Number(s) : NaN;
}

const COUNT_WORDS = ['cai', 'bo', 'vien', 'qua', 'mieng', 'hat', 'bong', 'trai', 'goi', 'lon', 'chai', 'hop', 'bich', 'cuon', 'to'];
function purchaseUnit(raw: string): string | null {
  const t = norm(raw.replace(/^[\d.,\s]+/, ''));
  const map: Record<string, string> = { g: 'g', gram: 'g', kg: 'kg', ml: 'ml', l: 'lít', lit: 'lít', cai: 'cái', goi: 'gói', chai: 'chai', lon: 'lon', hop: 'hộp', bich: 'bịch', thung: 'hộp', bo: 'cái', vien: 'cái', qua: 'cái', mieng: 'cái', hat: 'cái', bong: 'cái' };
  return map[t] ?? null;
}
function baseFrom(raw: string): { base: BaseUnit; mult: number } | null {
  const t = norm(raw.replace(/^[\d.,\s]+/, ''));
  if (t === 'g' || t === 'gram') return { base: 'g', mult: 1 };
  if (t === 'kg') return { base: 'g', mult: 1000 };
  if (t === 'ml') return { base: 'ml', mult: 1 };
  if (t === 'l' || t === 'lit') return { base: 'ml', mult: 1000 };
  if (COUNT_WORDS.includes(t)) return { base: 'cái', mult: 1 };
  return null;
}

export async function parseIngredientFile(buf: Buffer): Promise<ParseResult> {
  if (buf.length < 4 || buf[0] !== 0x50 || buf[1] !== 0x4b) throw new Error('File không phải Excel (.xlsx). Hãy lưu file ở định dạng .xlsx rồi thử lại.');
  const wb = new ExcelJS.Workbook();
  try { await wb.xlsx.load(buf as unknown as ExcelJS.Buffer); } catch { throw new Error('Không đọc được file Excel — file có thể bị hỏng hoặc có mật khẩu.'); }

  // tìm sheet + dòng tiêu đề: dòng có cột "Tên…" và "Giá nhập"
  for (const ws of wb.worksheets) {
    if (ws.rowCount > 20000) continue;
    for (let r = 1; r <= Math.min(ws.rowCount, 40); r++) {
      const found: { col: number; f: Field }[] = [];
      ws.getRow(r).eachCell({ includeEmpty: false }, (c, col) => { const f = FIELD_OF.get(hnorm(cellText(c.value))); if (f) found.push({ col, f }); });
      const price = found.find((x) => x.f === 'price');
      if (!price) continue;
      const nameCol = found.filter((x) => x.f === 'name' && x.col <= price.col).sort((a, b) => b.col - a.col)[0];
      if (!nameCol) continue;
      const pick = (f: Field) => found.filter((x) => x.f === f && x.col >= nameCol.col).sort((a, b) => a.col - b.col)[0]?.col;
      const cols = Object.fromEntries((Object.keys(ALIASES) as Field[]).map((f) => [f, f === 'name' ? nameCol.col : pick(f)])) as Record<Field, number | undefined>;
      const template = cols.unit_buy !== undefined || cols.base_unit !== undefined;
      return { rows: readRows(ws, r, cols, template), format: template ? 'mau' : 'bang-tinh', sheet: ws.name, headerRow: r };
    }
  }
  throw new Error('Không tìm thấy dòng tiêu đề. File cần có ít nhất 2 cột "Tên nguyên liệu" và "Giá nhập". Tải file mẫu để xem định dạng.');
}

function readRows(ws: ExcelJS.Worksheet, headerRow: number, cols: Record<Field, number | undefined>, template: boolean): ParsedRow[] {
  const out: ParsedRow[] = [];
  const get = (row: ExcelJS.Row, f: Field) => (cols[f] === undefined ? undefined : row.getCell(cols[f]!).value);
  const has = (v: ExcelJS.CellValue | undefined) => v !== undefined && v !== null && cellText(v) !== '';
  for (let r = headerRow + 1; r <= ws.rowCount; r++) {
    const row = ws.getRow(r);
    const name = cellText(get(row, 'name')).replace(/\s+/g, ' ').trim();
    if (!name) continue;
    if (out.length >= 2000) throw new Error('File có quá nhiều dòng (tối đa 2000 nguyên liệu mỗi lần nhập).');
    const p: ParsedRow = { row: r, name, errors: [], warnings: [] };
    if (name.length > 80) p.errors.push('Tên dài quá 80 ký tự');

    const cat = cellText(get(row, 'category')); if (cat) p.category = cat.slice(0, 40);
    const sup = cellText(get(row, 'supplier')); if (sup) p.supplier = sup.slice(0, 80);
    const note = cellText(get(row, 'note')); if (note) p.note = note.slice(0, 200);

    const pv = get(row, 'price');
    if (isErr(pv ?? null)) p.errors.push('Giá nhập bị lỗi công thức (ví dụ #DIV/0!)');
    else if (isUncalc(pv)) p.errors.push('Giá nhập là công thức chưa có kết quả — mở file bằng Excel, lưu lại (Ctrl+S) rồi nhập lại, hoặc dán giá trị vào ô');
    else if (!has(pv)) p.errors.push('Thiếu giá nhập');
    else { const n = parseNum(pv!); if (!isFinite(n)) p.errors.push(`Giá nhập "${cellText(pv!)}" không phải số`); else if (n < 0) p.errors.push('Giá nhập không được âm'); else { p.purchase_price = n; if (n === 0) p.warnings.push('Giá nhập = 0'); } }

    for (const [f, key, label] of [['stock', 'stock_quantity', 'Tồn kho'], ['min_stock', 'minimum_stock', 'Tồn tối thiểu']] as const) {
      const v = get(row, f);
      if (has(v)) { const n = parseNum(v!); if (!isFinite(n) || n < 0) p.errors.push(`${label} "${cellText(v!)}" không hợp lệ`); else p[key] = n; }
    }

    const packV = get(row, 'pack_size');
    let pack: number | undefined;
    if (has(packV)) { const n = parseNum(packV!); if (!isFinite(n) || n <= 0) p.errors.push(`Quy cách/số lượng "${cellText(packV!)}" phải là số lớn hơn 0`); else pack = n; }

    if (template) {
      const ub = cellText(get(row, 'unit_buy'));
      if (ub) { const u = purchaseUnit(ub); if (!u || !(PURCHASE_UNITS as readonly string[]).includes(u)) p.errors.push(`Đơn vị mua "${ub}" không hợp lệ (dùng: ${PURCHASE_UNITS.join(', ')})`); else p.unit = u; }
      const bu = cellText(get(row, 'base_unit'));
      if (bu) { const b = ['g', 'ml', 'cái'].find((x) => norm(x) === norm(bu)); if (!b) p.errors.push(`Đơn vị pha chế "${bu}" phải là g, ml hoặc cái`); else p.base_unit = b as BaseUnit; }
      if (pack !== undefined) p.pack_size = pack;
      // suy ra phần thiếu từ đơn vị mua chuẩn
      if (p.unit && ['kg', 'g', 'lít', 'ml', 'cái'].includes(p.unit)) {
        const d = defaultPack(p.unit);
        if (!p.base_unit) p.base_unit = d.base;
        if (p.pack_size === undefined && p.base_unit === d.base) p.pack_size = d.pack;
      }
    } else {
      // Bảng tính của quán: Đơn vị = đơn vị pha chế; Số lượng = số đơn vị đó trong 1 lần nhập
      const ua = cellText(get(row, 'unit_any'));
      let base: BaseUnit = 'g', mult = 1;
      if (!ua) p.warnings.push('Thiếu đơn vị — tạm dùng g');
      else { const b = baseFrom(ua); if (b) { base = b.base; mult = b.mult; } else p.warnings.push(`Đơn vị lạ "${ua}" — tạm dùng cái`), (base = 'cái'); }
      p.base_unit = base;
      p.pack_size = pack !== undefined ? pack * mult : undefined;
      if (p.pack_size === undefined && !p.errors.some((e) => e.startsWith('Quy cách'))) p.errors.push('Thiếu số lượng (quy cách)');
      const ps = p.pack_size;
      p.derived_unit = true;
      p.unit = ps === 1 ? base : base === 'g' && ps === 1000 ? 'kg' : base === 'ml' && ps === 1000 ? 'lít' : base === 'cái' ? 'gói' : 'gói';
    }
    if (!template || !p.errors.length) {
      if (p.unit === undefined && !p.errors.length) p.errors.push('Thiếu đơn vị mua');
      if (p.base_unit === undefined && !p.errors.length) p.errors.push('Thiếu đơn vị pha chế');
      if (p.pack_size === undefined && !p.errors.length) p.errors.push('Thiếu quy cách (1 đơn vị mua = ? đơn vị pha chế)');
    }
    out.push(p);
  }
  return out;
}

export type Action = 'create' | 'update' | 'skip' | 'error';
export interface PlanRow extends ParsedRow { action: Action; reason?: string; existing_id?: number; final?: { name: string; category: string; unit: string; base_unit: BaseUnit; pack_size: number; purchase_price: number; stock_quantity: number; minimum_stock: number; supplier: string; note: string } }

export function planImport(rows: ParsedRow[], onDuplicate: 'update' | 'skip'): PlanRow[] {
  const db = getDb();
  const existing = new Map((db.prepare('SELECT * FROM ingredients').all() as { id: number; name: string; category: string; unit: string; base_unit: BaseUnit; pack_size: number; purchase_price: number; stock_quantity: number; minimum_stock: number; supplier: string; note: string }[]).map((e) => [norm(e.name), e]));
  const usedIds = new Set((db.prepare('SELECT DISTINCT ingredient_id i FROM recipe_ingredients').all() as { i: number }[]).map((x) => x.i));
  const seen = new Set<string>();
  return rows.map((p) => {
    const key = norm(p.name);
    if (p.errors.length) return { ...p, action: 'error' as const, reason: p.errors.join('; ') };
    if (seen.has(key)) return { ...p, action: 'error' as const, reason: 'Trùng tên với dòng phía trên trong file' };
    seen.add(key);
    const ex = existing.get(key);
    if (!ex) {
      return { ...p, action: 'create' as const, final: { name: p.name, category: p.category ?? 'Khác', unit: p.unit!, base_unit: p.base_unit!, pack_size: p.pack_size!, purchase_price: p.purchase_price!, stock_quantity: p.stock_quantity ?? 0, minimum_stock: p.minimum_stock ?? 0, supplier: p.supplier ?? '', note: p.note ?? '' } };
    }
    if (onDuplicate === 'skip') return { ...p, action: 'skip' as const, existing_id: ex.id, reason: 'Đã có trong hệ thống — bỏ qua' };
    if (usedIds.has(ex.id) && p.base_unit !== ex.base_unit) return { ...p, action: 'error' as const, reason: `Không đổi được đơn vị pha chế (${ex.base_unit} → ${p.base_unit}) vì đang dùng trong công thức` };
    return { ...p, action: 'update' as const, existing_id: ex.id, final: {
      name: ex.name, category: p.category ?? ex.category, unit: p.derived_unit && p.pack_size === ex.pack_size && p.base_unit === ex.base_unit ? ex.unit : (p.unit ?? ex.unit), base_unit: p.base_unit ?? ex.base_unit, pack_size: p.pack_size ?? ex.pack_size,
      purchase_price: p.purchase_price!, stock_quantity: p.stock_quantity ?? ex.stock_quantity, minimum_stock: p.minimum_stock ?? ex.minimum_stock, supplier: p.supplier ?? ex.supplier, note: p.note ?? ex.note } };
  });
}

export function commitPlan(plan: PlanRow[]) {
  const db = getDb();
  const ins = db.prepare('INSERT INTO ingredients (name, category, unit, base_unit, pack_size, purchase_price, stock_quantity, minimum_stock, supplier, note) VALUES (?,?,?,?,?,?,?,?,?,?)');
  const upd = db.prepare("UPDATE ingredients SET category=?, unit=?, base_unit=?, pack_size=?, purchase_price=?, stock_quantity=?, minimum_stock=?, supplier=?, note=?, updated_at=datetime('now') WHERE id=?");
  let created = 0, updated = 0;
  db.transaction(() => {
    for (const r of plan) {
      const f = r.final; if (!f) continue;
      if (r.action === 'create') { ins.run(f.name, f.category, f.unit, f.base_unit, f.pack_size, f.purchase_price, f.stock_quantity, f.minimum_stock, f.supplier, f.note); created++; }
      else if (r.action === 'update') { upd.run(f.category, f.unit, f.base_unit, f.pack_size, f.purchase_price, f.stock_quantity, f.minimum_stock, f.supplier, f.note, r.existing_id); updated++; }
    }
  })();
  return { created, updated };
}

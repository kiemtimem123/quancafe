/** VietQR (chuẩn EMVCo/NAPAS 247): tạo chuỗi QR chuyển khoản có sẵn số tiền & nội dung — chạy hoàn toàn trên máy, không cần mạng. */
export const BANKS: { bin: string; name: string }[] = [
  { bin: '970436', name: 'Vietcombank' }, { bin: '970415', name: 'VietinBank' }, { bin: '970418', name: 'BIDV' }, { bin: '970405', name: 'Agribank' },
  { bin: '970407', name: 'Techcombank' }, { bin: '970422', name: 'MB Bank' }, { bin: '970416', name: 'ACB' }, { bin: '970432', name: 'VPBank' },
  { bin: '970423', name: 'TPBank' }, { bin: '970403', name: 'Sacombank' }, { bin: '970437', name: 'HDBank' }, { bin: '970441', name: 'VIB' },
  { bin: '970443', name: 'SHB' }, { bin: '970426', name: 'MSB' }, { bin: '970448', name: 'OCB' }, { bin: '970440', name: 'SeABank' },
  { bin: '970431', name: 'Eximbank' }, { bin: '970454', name: 'Viet Capital Bank' }, { bin: '970429', name: 'SCB' }, { bin: '970438', name: 'BaoViet Bank' },
  { bin: '970414', name: 'Oceanbank' }, { bin: '970425', name: 'An Binh Bank (ABBank)' }, { bin: '970449', name: 'LienVietPostBank' }, { bin: '970457', name: 'Woori Bank' },
  { bin: '970458', name: 'UOB' }, { bin: '970409', name: 'Bac A Bank' }, { bin: '970412', name: 'PVcomBank' }, { bin: '970428', name: 'Nam A Bank' },
  { bin: '970400', name: 'SaigonBank' }, { bin: '970433', name: 'VietBank' }, { bin: '970419', name: 'NCB' }, { bin: '970446', name: 'Co-op Bank' },
];
const f = (id: string, v: string) => `${id}${String(v.length).padStart(2, '0')}${v}`;
export function crc16(s: string): string {
  let crc = 0xffff;
  for (let i = 0; i < s.length; i++) {
    crc ^= s.charCodeAt(i) << 8;
    for (let b = 0; b < 8; b++) crc = crc & 0x8000 ? ((crc << 1) ^ 0x1021) & 0xffff : (crc << 1) & 0xffff;
  }
  return crc.toString(16).toUpperCase().padStart(4, '0');
}
/** Bỏ dấu, chỉ giữ chữ-số-khoảng trắng, tối đa 25 ký tự (giới hạn nội dung chuyển khoản). */
export const memoText = (s: string) => s.normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D').replace(/[^A-Za-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 25);

export function vietQrPayload(o: { bin: string; account: string; amount?: number; memo?: string }): string {
  const acct = f('00', o.bin) + f('01', o.account);
  const merchant = f('00', 'A000000727') + f('01', acct) + f('02', 'QRIBFTTA');
  const amount = o.amount && o.amount > 0 ? String(Math.round(o.amount)) : '';
  let s = f('00', '01') + f('01', amount ? '12' : '11') + f('38', merchant) + f('53', '704') + (amount ? f('54', amount) : '') + f('58', 'VN');
  const memo = memoText(o.memo ?? '');
  if (memo) s += f('62', f('08', memo));
  s += '6304';
  return s + crc16(s);
}
export const bankConfigured = (c: { bank_bin?: string; bank_account?: string }) => !!c.bank_bin && /^\d{6}$/.test(c.bank_bin) && !!c.bank_account && /^\d{4,20}$/.test(c.bank_account);

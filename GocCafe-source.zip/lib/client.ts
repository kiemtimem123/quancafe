'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { flush, getSyncState, localRequest, markOffline, refreshSnapshot, scheduleRefresh, shouldTryNetwork, startEngine } from './offline/engine';

const NET_MSG = 'Không kết nối được máy chủ. Kiểm tra mạng rồi thử lại.';
const uidk = () => (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}${Math.random().toString(36).slice(2)}`).replace(/[^\w-]/g, '');
// các API chỉ chạy được khi có mạng (không có bản cục bộ) — báo lỗi mạng như cũ thay vì ghi nhầm
const AUTH_ONLY = /^\/api\/auth\/(login|setup|password)/;

type Fail = Error & { status?: number; details?: unknown };
const asErr = (e: unknown): Fail => {
  const x = e as { message?: string; status?: number; details?: unknown };
  const err = new Error(x.message || 'Có lỗi xảy ra') as Fail;
  err.status = x.status; err.details = x.details;
  return err;
};

export async function api<T = unknown>(url: string, init?: { method?: string; body?: unknown }): Promise<T> {
  const method = init?.method ?? 'GET';
  const write = method !== 'GET';
  const local = () => localRequest<T>(method, url, init?.body).catch((e) => { throw asErr(e); });
  if (AUTH_ONLY.test(url)) return net<T>(url, method, init?.body, undefined);
  if (!shouldTryNetwork()) return local();
  // còn thao tác chờ đồng bộ: gửi đi trước để dữ liệu đọc về là mới nhất
  if (!write && getSyncState().pending > 0 && !/^\/api\/auth\//.test(url)) await flush().catch(() => {});
  const opKey = write ? uidk() : undefined;
  let out: T;
  try {
    out = await net<T>(url, method, init?.body, opKey);
  } catch (e) {
    if ((e as { offline?: boolean }).offline) { markOffline(); return local(); }
    throw e;
  }
  if (write && !/^\/api\/auth\//.test(url)) scheduleRefresh();
  else if (!write && url.startsWith('/api/auth/me')) { startEngine(); void refreshSnapshot(); }
  return out;
}

async function net<T>(url: string, method: string, body: unknown, opKey?: string): Promise<T> {
  let res: Response;
  try {
    const headers: Record<string, string> = {};
    if (body !== undefined) headers['content-type'] = 'application/json';
    if (opKey) headers['x-op-key'] = opKey;
    res = await fetch(url, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined, cache: 'no-store' });
  } catch {
    const e = new Error(NET_MSG) as Error & { offline?: boolean };
    e.offline = true;
    throw e;
  }
  if (res.headers.get('x-offline')) { const e = new Error(NET_MSG) as Error & { offline?: boolean }; e.offline = true; throw e; }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error((data as { error?: string }).error || `Lỗi ${res.status}`) as Fail;
    err.status = res.status;
    err.details = (data as { details?: unknown }).details;
    throw err;
  }
  return data as T;
}

export function useApi<T>(url: string | null) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(!!url);
  const seq = useRef(0);
  const load = useCallback(async () => {
    if (!url) return;
    const my = ++seq.current;
    setLoading(true);
    setError(null);
    try {
      const d = await api<T>(url);
      if (my === seq.current) setData(d);
    } catch (e) {
      if (my === seq.current) setError(e instanceof Error ? e.message : 'Có lỗi xảy ra');
    } finally {
      if (my === seq.current) setLoading(false);
    }
  }, [url]);
  useEffect(() => { load(); }, [load]);
  return { data, error, loading, reload: load, setData };
}

export function useLocalState<T>(key: string, initial: T) {
  const [v, setV] = useState<T>(initial);
  const ready = useRef(false);
  useEffect(() => {
    try { const s = localStorage.getItem(key); if (s) setV(JSON.parse(s)); } catch { /* bỏ qua */ }
    ready.current = true;
  }, [key]);
  useEffect(() => {
    if (!ready.current) return;
    try { localStorage.setItem(key, JSON.stringify(v)); } catch { /* bỏ qua */ }
  }, [key, v]);
  return [v, setV] as const;
}

/** Tải file từ API (có cookie đăng nhập); lỗi JSON được ném ra để hiện thông báo thay vì rời trang. */
export async function downloadFile(url: string, fallbackName: string) {
  let res: Response;
  try { res = await fetch(url, { cache: 'no-store' }); } catch { throw new Error('Không kết nối được máy chủ. Kiểm tra mạng rồi thử lại.'); }
  if (!res.ok) { const d = await res.json().catch(() => ({})); throw new Error((d as { error?: string }).error || `Lỗi ${res.status}`); }
  const cd = res.headers.get('content-disposition') || '';
  const m = /filename\*=UTF-8''([^;]+)/i.exec(cd);
  const name = m ? decodeURIComponent(m[1]) : fallbackName;
  const blob = await res.blob();
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}

/** Id trong đường dẫn (/recipes/12, /receipt/5…). Đọc từ URL thật để trang "khung" lưu sẵn vẫn đúng khi mở offline. */
export function useRouteId(fromParams: string) {
  const [id] = useState(() => (typeof window === 'undefined' ? fromParams : window.location.pathname.split('/')[2] || fromParams));
  return id;
}

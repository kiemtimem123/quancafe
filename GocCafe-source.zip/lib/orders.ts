import { getDb } from './db';
import { ApiError } from './api';
import { loadIngredients, loadRecipes } from './recipes';
import { makeConsumer } from './consume';
import { moveStock } from './stock';
import { audit } from './audit';
import { vnDate } from './time';
import { calcDiscount } from './order-math';
import { loadOptions } from './options';
import { loadPromos } from './promos';
import { bestPromo, vnNow, type PLine } from './promo-pure';
import { loyaltyCfg } from './customers';
import { normPhone, pointsEarned, redeem, validPhone } from './loyalty-pure';
import type { SessionUser } from './roles';

export interface OrderOption { id: number; name: string; price: number; qty: number }
export interface OrderItem { id: number; recipe_id: number | null; name: string; category: string; size: string; quantity: number; unit_price: number; unit_cost: number; note: string; options: OrderOption[] }
export interface Order {
  id: number; order_date: string; seq: number; code: string; status: 'paid' | 'void'; table_name: string; note: string;
  subtotal: number; discount: number; discount_label: string; total: number; payment: 'cash' | 'transfer'; cash_received: number | null;
  customer_phone: string; customer_name: string; points_earned: number; points_used: number;
  user_name: string; created_at: string; voided_at: string | null; void_reason: string; voided_by: string; items: OrderItem[];
}
export interface NewOrder {
  key?: string; table_name: string; note?: string; payment: 'cash' | 'transfer'; cash_received?: number;
  discount?: { type: 'amount' | 'percent'; value: number };
  items: { recipe_id: number; size: 'S' | 'M' | 'L'; quantity: number; note?: string; options?: { id: number; qty: number }[] }[];
  promo_code?: string;
  customer?: { phone: string; name?: string };
  redeem_points?: number;
  force?: boolean;
  /** Đơn bán lúc offline: đã pha & giao khách nên luôn ghi nhận, kể cả khi kho báo thiếu; khuyến mãi/điểm đã áp ở máy bán được giữ nguyên */
  offline?: boolean;
  promo?: { label: string; discount: number };
  /** Thời điểm bán thật (ISO) — dùng khi đồng bộ đơn offline */
  at?: string;
}

const code = (date: string, seq: number) => `${date.slice(8, 10)}${date.slice(5, 7)}-${String(seq).padStart(3, '0')}`;
type OrderRow = Omit<Order, 'code' | 'items'>;

function hydrate(rows: OrderRow[]): Order[] {
  if (!rows.length) return [];
  const db = getDb();
  const items = db.prepare(`SELECT * FROM order_items WHERE order_id IN (${rows.map(() => '?').join(',')}) ORDER BY id`).all(...rows.map((r) => r.id)) as (Omit<OrderItem, 'options'> & { order_id: number; options: string })[];
  const by = new Map<number, OrderItem[]>();
  for (const it of items) {
    let opts: OrderOption[] = [];
    try { opts = JSON.parse(it.options || '[]'); } catch { /* bỏ qua */ }
    (by.get(it.order_id) ?? by.set(it.order_id, []).get(it.order_id)!).push({ ...it, options: opts });
  }
  return rows.map((r) => ({ ...r, code: code(r.order_date, r.seq), items: by.get(r.id) ?? [] }));
}
export const getOrder = (id: number) => hydrate(getDb().prepare('SELECT * FROM orders WHERE id=?').all(id) as OrderRow[])[0];
export const listOrders = (date: string) => hydrate(getDb().prepare('SELECT * FROM orders WHERE order_date=? ORDER BY id DESC').all(date) as OrderRow[]);

/** Tạo đơn: tính giá ở máy chủ, kiểm tra tồn kho, trừ kho, ghi doanh thu, áp khuyến mãi/điểm — trong một giao dịch. */
export function createOrder(input: NewOrder, user: SessionUser, canForce: boolean): Order {
  const db = getDb();
  if (input.key) {
    const ex = db.prepare('SELECT id FROM orders WHERE client_key=?').get(input.key) as { id: number } | undefined;
    if (ex) return getOrder(ex.id)!; // gửi lại do mạng chập chờn → trả đơn cũ, không tạo trùng
  }
  const id = db.transaction(() => {
    const recipes = new Map(loadRecipes(db).map((r) => [r.id, r]));
    const ings = loadIngredients(db);
    const options = new Map(loadOptions(db, ings).map((o) => [o.id, o]));
    const consumer = makeConsumer(ings);
    const force = (!!input.force && canForce) || !!input.offline;
    const lines: { r: ReturnType<typeof recipes.get> & object; size: string; qty: number; price: number; cost: number; note: string; opts: OrderOption[] }[] = [];
    const blocked: number[] = [];
    for (const it of input.items) {
      const r = recipes.get(it.recipe_id);
      if (!r) throw new ApiError(404, 'Có món không còn tồn tại trong hệ thống');
      const sz = r.sizes.find((s) => s.name === it.size);
      if (!sz) throw new ApiError(400, `${r.name} chưa có size ${it.size}`);
      if (sz.selling_price <= 0) throw new ApiError(400, `${r.name} (${it.size}) chưa có giá bán`);
      const before = consumer.res.short.length;
      consumer.use(sz, it.quantity, force);
      const opts: OrderOption[] = [];
      let optPrice = 0, optCost = 0;
      for (const oi of it.options ?? []) {
        const o = options.get(oi.id);
        if (!o || (!o.active && !input.offline)) throw new ApiError(400, 'Có topping không còn được bán');
        const oq = Math.max(1, Math.min(10, Math.floor(oi.qty || 1)));
        if (o.ingredient_id && o.qty > 0) consumer.useIngredient(o.ingredient_id, o.qty * oq * it.quantity, force);
        opts.push({ id: o.id, name: o.name, price: o.price, qty: oq });
        optPrice += o.price * oq; optCost += o.cost * oq;
      }
      if (consumer.res.short.length > before) blocked.push(r.id);
      lines.push({ r, size: it.size, qty: it.quantity, price: sz.selling_price + optPrice, cost: Math.round(sz.cost + optCost), note: (it.note ?? '').trim().slice(0, 120), opts });
    }
    if (consumer.res.short.length && !force) {
      throw new ApiError(409, `Không đủ nguyên liệu: ${consumer.res.short.join(', ')}`, { short: consumer.res.short, recipes: [...new Set(blocked)] });
    }
    const subtotal = lines.reduce((a, l) => a + l.price * l.qty, 0);
    const soldAt = input.at && Number.isFinite(Date.parse(input.at)) && Date.parse(input.at) <= Date.now() + 60_000 && Date.parse(input.at) > Date.now() - 14 * 864e5 ? new Date(input.at) : null;
    const when = soldAt ?? new Date();

    // 1) khuyến mãi / voucher (không cộng dồn)
    let promoDisc = 0; let promoLabel = '';
    if (input.offline) { if (input.promo) { promoDisc = Math.max(0, Math.min(Math.round(input.promo.discount), subtotal)); promoLabel = input.promo.label.slice(0, 60); } }
    else {
      const pl: PLine[] = lines.map((l) => ({ recipe_id: l.r.id, category: l.r.category, quantity: l.qty, unit_price: l.price }));
      const bp = bestPromo(loadPromos(db, true), pl, subtotal, vnNow(when), input.promo_code ?? '');
      if (input.promo_code?.trim() && bp.codeError && !bp.result) throw new ApiError(400, bp.codeError);
      if (bp.result) { promoDisc = bp.result.discount; promoLabel = bp.result.label; }
    }
    // 2) giảm giá tay
    const man = calcDiscount(subtotal - promoDisc, input.discount);
    // 3) điểm thân thiết
    type Cust = { id: number; phone: string; name: string; points: number };
    let cust = null as Cust | null;
    const cfg = loyaltyCfg();
    const phone = input.customer?.phone ? normPhone(input.customer.phone) : '';
    if (phone) {
      if (!validPhone(phone)) throw new ApiError(400, 'Số điện thoại khách không hợp lệ');
      const nm = (input.customer?.name ?? '').trim().slice(0, 60);
      db.prepare('INSERT OR IGNORE INTO customers (phone, name) VALUES (?, ?)').run(phone, nm);
      cust = db.prepare('SELECT id, phone, name, points FROM customers WHERE phone=?').get(phone) as Cust;
      if (nm && !cust!.name) { db.prepare('UPDATE customers SET name=? WHERE id=?').run(nm, cust!.id); cust!.name = nm; }
    }
    const rd = cust ? redeem(input.redeem_points ?? 0, input.offline ? Number.MAX_SAFE_INTEGER : cust.points, subtotal - promoDisc - man.discount, cfg) : { points: 0, discount: 0 };
    const discount = promoDisc + man.discount + rd.discount;
    const label = [promoLabel && `KM ${promoLabel}`, man.label, rd.points && `Điểm ×${rd.points}`].filter(Boolean).join(' + ');
    const total = subtotal - discount;
    if (input.payment === 'cash' && input.cash_received !== undefined && input.cash_received < total) throw new ApiError(400, 'Tiền khách đưa chưa đủ');
    const earned = cust ? pointsEarned(total, cfg) : 0;

    const date = vnDate(when);
    const seq = ((db.prepare('SELECT MAX(seq) m FROM orders WHERE order_date=?').get(date) as { m: number | null }).m ?? 0) + 1;
    const oid = Number(db.prepare(`INSERT INTO orders (order_date, seq, client_key, table_name, note, subtotal, discount, discount_label, total, payment, cash_received, user_id, user_name, created_at, customer_id, customer_phone, customer_name, points_earned, points_used) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(date, seq, input.key ?? null, input.table_name, (input.note ?? '').trim().slice(0, 200), subtotal, discount, label, total, input.payment, input.payment === 'cash' ? input.cash_received ?? null : null, user.id, user.name,
        when.toISOString().replace('T', ' ').slice(0, 19), cust?.id ?? null, cust?.phone ?? '', cust?.name ?? '', earned, rd.points).lastInsertRowid);
    const insItem = db.prepare('INSERT INTO order_items (order_id, recipe_id, name, category, size, quantity, unit_price, unit_cost, note, options) VALUES (?,?,?,?,?,?,?,?,?,?)');
    const insSale = db.prepare("INSERT INTO sales (recipe_id, recipe_name, category, size, quantity, revenue, unit_cost, sold_on, source, order_id) VALUES (?,?,?,?,?,?,?,?,'order',?)");
    let allocated = 0;
    lines.forEach((l, i) => {
      insItem.run(oid, l.r.id, l.r.name, l.r.category, l.size, l.qty, l.price, l.cost, l.note, JSON.stringify(l.opts));
      const gross = l.price * l.qty;
      // chia giảm giá theo tỷ lệ để doanh thu từng món phản ánh số tiền thực thu
      const rev = i === lines.length - 1 ? total - allocated : Math.round(subtotal ? (gross * total) / subtotal : 0);
      allocated += rev;
      insSale.run(l.r.id, l.r.name, l.r.category, l.size, l.qty, rev, l.cost, date, oid);
    });
    const insDed = db.prepare('INSERT INTO order_deductions (order_id, ingredient_id, qty) VALUES (?,?,?)');
    const byId = new Map(ings.map((i) => [i.id, i]));
    consumer.res.deduct.forEach((base, iid) => {
      const ing = byId.get(iid)!;
      const q = base / ing.pack_size;
      const before = ing.stock_quantity;
      moveStock(iid, -q, 'brew', { note: `Đơn #${code(date, seq)}`, user: user.name, db });
      // lưu đúng phần thực sự đã trừ (không âm) để hoàn kho chính xác
      insDed.run(oid, iid, Math.min(q, before));
    });
    if (cust) db.prepare("UPDATE customers SET points=MAX(0, points - ? + ?), visits=visits+1, total_spent=total_spent+?, last_visit=? WHERE id=?").run(rd.points, earned, total, when.toISOString().replace('T', ' ').slice(0, 19), cust.id);
    return oid;
  })();
  const order = getOrder(id)!;
  audit(user, 'order', 'order', id, `Đơn #${order.code}: ${order.items.reduce((a, i) => a + i.quantity, 0)} ly, ${Math.round(order.total).toLocaleString('vi-VN')}đ (${order.payment === 'cash' ? 'tiền mặt' : 'chuyển khoản'})`);
  return order;
}

export const lastShiftEnd = () => (getDb().prepare('SELECT MAX(to_order_id) m FROM shift_closes').get() as { m: number | null }).m ?? 0;

export function voidOrder(id: number, reason: string, user: SessionUser): Order {
  const db = getDb();
  const o = getOrder(id);
  if (!o) throw new ApiError(404, 'Không tìm thấy đơn');
  if (o.status === 'void') throw new ApiError(400, 'Đơn này đã hủy');
  if (id <= lastShiftEnd()) throw new ApiError(400, 'Đơn thuộc ca đã chốt, không thể hủy');
  db.transaction(() => {
    db.prepare("UPDATE orders SET status='void', voided_at=datetime('now'), void_reason=?, voided_by=? WHERE id=?").run(reason, user.name, id);
    for (const d of db.prepare('SELECT ingredient_id, qty FROM order_deductions WHERE order_id=?').all(id) as { ingredient_id: number; qty: number }[]) {
      if (db.prepare('SELECT 1 FROM ingredients WHERE id=?').get(d.ingredient_id)) moveStock(d.ingredient_id, d.qty, 'adjust', { note: `Hoàn kho do hủy đơn #${o.code}`, user: user.name, db });
    }
    db.prepare('DELETE FROM sales WHERE order_id=?').run(id);
    const cid = (db.prepare('SELECT customer_id FROM orders WHERE id=?').get(id) as { customer_id: number | null }).customer_id;
    if (cid) db.prepare('UPDATE customers SET points=MAX(0, points - ? + ?), visits=MAX(0, visits-1), total_spent=MAX(0, total_spent-?) WHERE id=?').run(o.points_earned, o.points_used, o.total, cid);
  })();
  audit(user, 'void', 'order', id, `Hủy đơn #${o.code} (${Math.round(o.total).toLocaleString('vi-VN')}đ)${reason ? `: ${reason}` : ''}`);
  return getOrder(id)!;
}

export interface ShiftSummary { from_order_id: number; to_order_id: number; orders: number; voids: number; cash: number; transfer: number; discount: number; cups: number; total: number; since: string | null }
/** Tổng kết các đơn từ lần chốt ca gần nhất đến giờ. */
export function shiftSummary(): ShiftSummary {
  const db = getDb();
  const from = lastShiftEnd();
  const rows = db.prepare('SELECT id, status, total, payment, discount, created_at FROM orders WHERE id>? ORDER BY id').all(from) as { id: number; status: string; total: number; payment: string; discount: number; created_at: string }[];
  const paid = rows.filter((r) => r.status === 'paid');
  const cups = paid.length ? (db.prepare(`SELECT COALESCE(SUM(quantity),0) c FROM order_items WHERE order_id IN (${paid.map(() => '?').join(',')})`).get(...paid.map((r) => r.id)) as { c: number }).c : 0;
  return {
    from_order_id: from + 1, to_order_id: rows.length ? rows[rows.length - 1].id : from, orders: paid.length, voids: rows.length - paid.length,
    cash: paid.filter((r) => r.payment === 'cash').reduce((a, r) => a + r.total, 0), transfer: paid.filter((r) => r.payment === 'transfer').reduce((a, r) => a + r.total, 0),
    discount: paid.reduce((a, r) => a + r.discount, 0), cups, total: paid.reduce((a, r) => a + r.total, 0), since: rows[0]?.created_at ?? null,
  };
}

export function closeShift(opts: { opening_cash: number; counted_cash?: number; note: string }, user: SessionUser) {
  const s = shiftSummary();
  if (s.to_order_id < s.from_order_id) throw new ApiError(400, 'Chưa có đơn nào để chốt ca');
  const expected = opts.opening_cash + s.cash;
  const diff = opts.counted_cash === undefined ? null : opts.counted_cash - expected;
  const db = getDb();
  const id = Number(db.prepare('INSERT INTO shift_closes (closed_by, from_order_id, to_order_id, order_count, void_count, cash_total, transfer_total, discount_total, opening_cash, expected_cash, counted_cash, diff, note) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)')
    .run(user.name, s.from_order_id, s.to_order_id, s.orders, s.voids, s.cash, s.transfer, s.discount, opts.opening_cash, expected, opts.counted_cash ?? null, diff, opts.note).lastInsertRowid);
  audit(user, 'shift', 'shift', id, `Chốt ca: ${s.orders} đơn, tiền mặt ${Math.round(s.cash).toLocaleString('vi-VN')}đ, chuyển khoản ${Math.round(s.transfer).toLocaleString('vi-VN')}đ${diff ? `, lệch ${Math.round(diff).toLocaleString('vi-VN')}đ` : ''}`);
  return { id, ...s, expected_cash: expected, counted_cash: opts.counted_cash ?? null, diff, opening_cash: opts.opening_cash };
}

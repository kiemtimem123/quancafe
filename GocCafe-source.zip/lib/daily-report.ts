import { getDb } from './db';
import { loadIngredients } from './recipes';
import { listExpiry } from './expiry';
import { vnDate } from './time';

const vnd = (n: number) => `${Math.round(n).toLocaleString('vi-VN')}đ`;

/** Nội dung báo cáo cuối ngày (văn bản thuần để gửi Telegram/email). */
export function buildDailyReport(date = vnDate()): { subject: string; text: string } {
  const db = getDb();
  const o = db.prepare(`SELECT COUNT(*) n, COALESCE(SUM(total),0) rev, COALESCE(SUM(discount),0) disc,
      COALESCE(SUM(CASE WHEN payment='cash' THEN total END),0) cash, COALESCE(SUM(CASE WHEN payment='transfer' THEN total END),0) tr
    FROM orders WHERE order_date=? AND status='paid'`).get(date) as { n: number; rev: number; disc: number; cash: number; tr: number };
  const voids = (db.prepare("SELECT COUNT(*) c FROM orders WHERE order_date=? AND status='void'").get(date) as { c: number }).c;
  const s = db.prepare('SELECT COALESCE(SUM(quantity),0) cups, COALESCE(SUM(revenue),0) rev, COALESCE(SUM(quantity*unit_cost),0) cost FROM sales WHERE sold_on=?').get(date) as { cups: number; rev: number; cost: number };
  const top = db.prepare('SELECT recipe_name n, SUM(quantity) q FROM sales WHERE sold_on=? GROUP BY recipe_name ORDER BY q DESC LIMIT 3').all(date) as { n: string; q: number }[];
  const ex = listExpiry();
  const soon = ex.rows.filter((r) => r.status === 'soon' || r.status === 'expired');
  const low = loadIngredients(db).filter((i) => i.track_stock && i.low_stock);
  const L: string[] = [`📊 Báo cáo ngày ${date.split('-').reverse().join('/')}`, ''];
  L.push(`💰 Doanh thu: ${vnd(o.rev)} (${o.n} đơn, ${s.cups} ly)`);
  L.push(`   Tiền mặt ${vnd(o.cash)} · Chuyển khoản ${vnd(o.tr)}`);
  if (o.disc > 0) L.push(`   Giảm giá: ${vnd(o.disc)}`);
  if (s.cost > 0) L.push(`📈 Lãi gộp ước tính: ${vnd(s.rev - s.cost)} (${s.rev ? Math.round(((s.rev - s.cost) / s.rev) * 100) : 0}%)`);
  if (voids) L.push(`🚫 Đơn hủy: ${voids}`);
  if (top.length) L.push('', '🏆 Bán chạy: ' + top.map((t) => `${t.n} (${t.q})`).join(', '));
  if (soon.length) L.push('', '⏰ Hạn sử dụng cần chú ý:', ...soon.slice(0, 8).map((r) => `  • ${r.name} ${r.qty} ${r.unit} — ${r.status === 'expired' ? 'quá hạn' : r.days === 0 ? 'hết hạn hôm nay' : `còn ${r.days} ngày`}`));
  if (ex.removed.length) L.push('', `🗑 Đã tự loại khỏi kho: ${ex.removed.slice(0, 5).map((x) => `${x.name} ${x.qty}${x.unit}`).join(', ')}`);
  if (low.length) L.push('', '⚠ Sắp hết hàng: ' + low.slice(0, 10).map((i) => i.name).join(', '));
  return { subject: `Báo cáo ngày ${date.split('-').reverse().join('/')}: ${vnd(o.rev)}`, text: L.join('\n') };
}

import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import sharp from 'sharp';
import { ApiError } from './api';
import { getDb } from './db';

export const MAX_UPLOAD = 8 * 1024 * 1024;
export const IMAGE_URL_RE = /^\/api\/images\/([a-f0-9]{32})\.webp$/;
const dir = () => { const d = path.join(process.env.DATA_DIR || path.join(process.cwd(), 'data'), 'uploads'); fs.mkdirSync(d, { recursive: true }); return d; };
export const imagePath = (name: string) => path.join(dir(), name);

/** Nhận diện định dạng thật bằng magic bytes (không tin phần mở rộng/MIME do client gửi). */
function sniff(b: Buffer): 'jpeg' | 'png' | 'gif' | 'webp' | null {
  if (b.length < 12) return null;
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'jpeg';
  if (b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'png';
  if (b.subarray(0, 4).toString('ascii') === 'GIF8') return 'gif';
  if (b.subarray(0, 4).toString('ascii') === 'RIFF' && b.subarray(8, 12).toString('ascii') === 'WEBP') return 'webp';
  return null;
}

/** Kiểm tra, xoay theo EXIF, thu nhỏ ≤1200px, bỏ metadata, lưu WebP. Trả về URL phục vụ ảnh. */
export async function saveImage(buf: Buffer): Promise<string> {
  if (buf.length === 0) throw new ApiError(400, 'File ảnh rỗng');
  if (buf.length > MAX_UPLOAD) throw new ApiError(413, 'Ảnh quá lớn (tối đa 8MB)');
  if (!sniff(buf)) throw new ApiError(400, 'Chỉ hỗ trợ ảnh JPG, PNG, WebP hoặc GIF');
  let out: Buffer;
  try {
    out = await sharp(buf, { limitInputPixels: 60e6 }).rotate().resize({ width: 1200, height: 1200, fit: 'inside', withoutEnlargement: true }).webp({ quality: 82 }).toBuffer();
  } catch {
    throw new ApiError(400, 'Không đọc được ảnh, file có thể bị hỏng');
  }
  cleanupOrphans();
  const name = crypto.randomBytes(16).toString('hex');
  fs.writeFileSync(imagePath(`${name}.webp`), out);
  return `/api/images/${name}.webp`;
}

export function removeImage(url: string | null | undefined) {
  const m = url ? IMAGE_URL_RE.exec(url) : null;
  if (!m) return;
  try { fs.unlinkSync(imagePath(`${m[1]}.webp`)); } catch { /* đã xóa */ }
}

/** Xóa ảnh đã tải lên nhưng không món nào dùng (quá 1 giờ) — ví dụ người dùng tải rồi bấm Hủy. */
export function cleanupOrphans() {
  try {
    const used = new Set((getDb().prepare("SELECT image FROM recipes WHERE image LIKE '/api/images/%'").all() as { image: string }[]).map((r) => r.image));
    for (const f of fs.readdirSync(dir())) {
      const p = imagePath(f);
      if (!used.has(`/api/images/${f}`) && Date.now() - fs.statSync(p).mtimeMs > 3600_000) fs.unlinkSync(p);
    }
  } catch { /* bỏ qua */ }
}

/** Nhân bản ảnh nội bộ để hai món không dùng chung một file (xóa món này không làm mất ảnh món kia). */
export function copyImage(url: string): string {
  const m = IMAGE_URL_RE.exec(url);
  if (!m) return url;
  try {
    const name = crypto.randomBytes(16).toString('hex');
    fs.copyFileSync(imagePath(`${m[1]}.webp`), imagePath(`${name}.webp`));
    return `/api/images/${name}.webp`;
  } catch { return ''; }
}

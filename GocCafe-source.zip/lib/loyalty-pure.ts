/** Điểm thân thiết: tích 1 điểm cho mỗi `earn_per` đồng; 1 điểm quy đổi `point_value` đồng. */
export interface LoyaltyCfg { earn_per: number; point_value: number }
export const LOYALTY_DEFAULT: LoyaltyCfg = { earn_per: 10000, point_value: 500 };
export const normPhone = (s: string) => { const d = s.replace(/\D/g, ''); return d.startsWith('84') && d.length >= 11 ? '0' + d.slice(2) : d; };
export const validPhone = (s: string) => /^0\d{9,10}$/.test(normPhone(s));
export const pointsEarned = (total: number, cfg: LoyaltyCfg) => (cfg.earn_per > 0 ? Math.floor(Math.max(0, total) / cfg.earn_per) : 0);
/** Số điểm thực dùng được và số tiền giảm (không vượt quá số tiền còn lại). */
export function redeem(requested: number, balance: number, remaining: number, cfg: LoyaltyCfg): { points: number; discount: number } {
  if (cfg.point_value <= 0) return { points: 0, discount: 0 };
  const maxByTotal = Math.floor(Math.max(0, remaining) / cfg.point_value);
  const points = Math.max(0, Math.min(Math.floor(requested), balance, maxByTotal));
  return { points, discount: points * cfg.point_value };
}

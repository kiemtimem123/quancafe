// File khởi động cho hosting Node.js (cPanel "Setup Node.js App", Plesk, Passenger…). Chạy: node server.js
process.env.NODE_ENV = 'production';
const http = require('http');
const next = require('next');
const port = Number(process.env.PORT) || 3000;
const app = next({ dev: false, dir: __dirname });
const handle = app.getRequestHandler();
app.prepare().then(() => {
  http.createServer((req, res) => handle(req, res)).listen(port, () => console.log('Góc Cafe chạy ở cổng ' + port));
}).catch((e) => { console.error(e); process.exit(1); });

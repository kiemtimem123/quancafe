'use client';
import { useEffect } from 'react';
import { usePathname } from 'next/navigation';
import { clearOffline, startEngine, useSync } from '@/lib/offline/engine';

/** Đăng ký service worker (bản production), tải sẵn trang & tệp để dùng được khi mất mạng, hiện thanh báo offline. */
export function Pwa() {
  const sync = useSync();
  const customerPage = usePathname() === '/order'; // trang khách quét QR: không chạy bộ máy offline của nhân viên
  useEffect(() => {
    if (customerPage) return;
    startEngine();
    if (!('serviceWorker' in navigator) || process.env.NODE_ENV !== 'production') return;
    navigator.serviceWorker.register('/sw.js').then(() => navigator.serviceWorker.ready).then(warm).catch(() => {});
  }, [customerPage]);
  if (customerPage || sync.reachable) return null;
  return (
    <div className="no-print fixed inset-x-0 top-0 z-[60] bg-espresso px-4 py-1.5 text-center text-xs font-semibold text-white" role="status">
      📴 Đang offline — vẫn bán hàng, in hóa đơn, nhập kho… bình thường{sync.pending ? ` · ${sync.pending} thao tác chờ đồng bộ` : ''}
    </div>
  );
}

/** Lưu sẵn mọi trang + JS/CSS của bản build hiện tại (chỉ chạy lại khi có bản build mới). */
async function warm() {
  try {
    const meta = (await (await fetch('/precache.json', { cache: 'no-store' })).json()) as { build: string; pages: string[]; files: string[] };
    const key = `warm:${meta.build}`;
    if (localStorage.getItem(key) === 'done') return;
    const urls = [...meta.pages, ...meta.files];
    let i = 0;
    await Promise.all(Array.from({ length: 6 }, async () => {
      while (i < urls.length) {
        const u = urls[i++];
        try { await fetch(u, { credentials: 'same-origin', headers: u.startsWith('/_next') ? {} : { accept: 'text/html' } }); } catch { /* bỏ qua */ }
      }
    }));
    localStorage.setItem(key, 'done');
  } catch { /* bỏ qua */ }
}
export const clearOfflineCache = async () => {
  try { (await navigator.serviceWorker?.getRegistration())?.active?.postMessage('clear'); } catch { /* bỏ qua */ }
  try { for (const k of Object.keys(localStorage)) if (k.startsWith('warm:')) localStorage.removeItem(k); } catch { /* bỏ qua */ }
  await clearOffline();
};

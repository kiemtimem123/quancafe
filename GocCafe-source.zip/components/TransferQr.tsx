'use client';
import { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { bankConfigured, vietQrPayload, BANKS } from '@/lib/vietqr';

export interface BankCfg { bank_bin?: string; bank_account?: string; bank_holder?: string }
/** QR chuyển khoản VietQR có sẵn số tiền (tạo ngay trên máy, không cần mạng). Trả null nếu chưa cấu hình tài khoản. */
export function TransferQr({ cfg, amount, memo, size = 176 }: { cfg: BankCfg; amount: number; memo: string; size?: number }) {
  const [img, setImg] = useState('');
  const ok = bankConfigured(cfg);
  useEffect(() => {
    if (!ok) return;
    let alive = true;
    QRCode.toDataURL(vietQrPayload({ bin: cfg.bank_bin!, account: cfg.bank_account!, amount, memo }), { width: size * 2, margin: 1, errorCorrectionLevel: 'M' }).then((u) => { if (alive) setImg(u); }).catch(() => {});
    return () => { alive = false; };
  }, [ok, cfg.bank_bin, cfg.bank_account, amount, memo, size]);
  if (!ok) return null;
  const bank = BANKS.find((b) => b.bin === cfg.bank_bin)?.name ?? '';
  return (
    <div className="text-center">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      {img ? <img src={img} alt="QR chuyển khoản" style={{ width: size, height: size }} className="mx-auto object-contain" /> : <div style={{ width: size, height: size }} className="mx-auto" />}
      <p className="mt-1 text-xs font-semibold">{bank} · {cfg.bank_account}</p>
      {cfg.bank_holder && <p className="text-xs">{cfg.bank_holder}</p>}
    </div>
  );
}

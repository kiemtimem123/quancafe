'use client';
import Link from 'next/link';
import { useApi } from '@/lib/client';

export interface ExpiryRowT { id: number; ingredient_id: number; name: string; category: string; unit: string; qty: number; received_on: string; expires_on: string | null; days: number | null; status: 'expired' | 'soon' | 'ok' | 'none' }
export interface RemovedT { id: number; name: string; unit: string; qty: number; note: string; created_at: string }
export interface ExpiryData { today: string; warn_days: number; rows: ExpiryRowT[]; removed?: RemovedT[] }
export const dmy = (s: string | null) => (s ? `${s.slice(8, 10)}/${s.slice(5, 7)}/${s.slice(0, 4)}` : '—');
export const daysText = (d: number | null) => (d === null ? 'không ghi hạn' : d < 0 ? `quá hạn ${-d} ngày` : d === 0 ? 'hết hạn hôm nay' : `còn ${d} ngày`);

/** Thanh cảnh báo nguyên liệu sắp/đã hết hạn (ẩn khi mọi thứ còn hạn). */
export function ExpiryBanner() {
  const { data } = useApi<ExpiryData>('/api/expiry');
  if (!data) return null;
  const expired = data.rows.filter((r) => r.status === 'expired');
  const soon = data.rows.filter((r) => r.status === 'soon');
  const removed = data.removed ?? [];
  if (!expired.length && !soon.length && !removed.length) return null;
  const names = (xs: ExpiryRowT[]) => [...new Set(xs.map((x) => x.name))].slice(0, 4).join(', ') + ([...new Set(xs.map((x) => x.name))].length > 4 ? '…' : '');
  return (
    <Link href="/expiry" className={`block rounded-2xl p-3 text-sm ${expired.length || (!soon.length && removed.length) ? 'bg-danger-soft text-danger' : 'bg-warn-soft text-[#8a5a00]'}`} role="alert">
      <b>{expired.length ? '⛔' : '⏰'} Hạn sử dụng:</b>{' '}
      {expired.length > 0 && <span><b>{expired.length} lô đã hết hạn</b> ({names(expired)}). </span>}
      {soon.length > 0 && <span><b>{soon.length} lô sắp hết hạn</b> trong {data.warn_days} ngày ({names(soon)}). </span>}
      {removed.length > 0 && <span>🗑 Đã tự loại khỏi kho {removed.length} lô hết hạn ({[...new Set(removed.map((x) => x.name))].slice(0, 3).join(', ')}). </span>}
      <u>Xem chi tiết</u>
    </Link>
  );
}

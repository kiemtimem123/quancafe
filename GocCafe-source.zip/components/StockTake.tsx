'use client';
import { useMemo, useState } from 'react';
import { api } from '@/lib/client';
import type { Ingredient } from '@/lib/types';
import { norm, num } from '@/lib/format';
import { Modal, Spinner } from './ui';
import { useToast } from './Toast';

/** Kiểm kê hàng loạt: nhập số đếm được, chỉ ghi các dòng có chênh lệch. */
export function StockTake({ open, all, onClose, onDone }: { open: boolean; all: Ingredient[]; onClose: () => void; onDone: () => void }) {
  const toast = useToast();
  const [vals, setVals] = useState<Record<number, string>>({});
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const list = useMemo(() => all.filter((i) => i.track_stock && (!q || norm(i.name).includes(norm(q)))), [all, q]);
  const changed = all.filter((i) => vals[i.id] !== undefined && vals[i.id] !== '' && Math.abs(Number(vals[i.id]) - i.stock_quantity) > 1e-9);
  const submit = async () => {
    if (changed.some((i) => !(Number(vals[i.id]) >= 0))) return setErr('Số đếm không được âm');
    setBusy(true); setErr('');
    try {
      const r = await api<{ changed: number }>('/api/stock/take', { method: 'POST', body: { items: changed.map((i) => ({ id: i.id, counted: Number(vals[i.id]) })) } });
      toast.ok(`Đã kiểm kê — điều chỉnh ${r.changed} nguyên liệu`); setVals({}); onDone(); onClose();
    } catch (e) { setErr(e instanceof Error ? e.message : 'Lỗi'); } finally { setBusy(false); }
  };
  return (
    <Modal open={open} onClose={onClose} title="Kiểm kê kho" wide>
      <div className="space-y-3">
        <p className="text-sm text-mocha">Nhập số đếm thực tế ở những nguyên liệu bạn đã đếm; để trống = giữ nguyên. Chênh lệch sẽ được ghi vào sổ kho.</p>
        <input className="input" placeholder="🔍 Lọc nguyên liệu…" value={q} onChange={(e) => setQ(e.target.value)} />
        {err && <p className="rounded-xl bg-danger-soft p-3 text-sm text-danger" role="alert">{err}</p>}
        <div className="max-h-[50vh] overflow-auto rounded-2xl border border-[#eadfcd]">
          <table className="w-full text-sm"><thead className="sticky top-0 bg-cream text-left text-mocha"><tr><th className="p-2">Nguyên liệu</th><th className="p-2 text-right">Hệ thống</th><th className="p-2">Đếm được</th><th className="p-2 text-right">Lệch</th></tr></thead>
            <tbody>{list.map((i) => {
              const v = vals[i.id]; const d = v !== undefined && v !== '' ? Number(v) - i.stock_quantity : 0;
              return <tr key={i.id} className="border-t border-[#f3ebdd]"><td className="p-2 font-semibold">{i.name}</td><td className="p-2 text-right">{num(i.stock_quantity, 2)} {i.unit}</td>
                <td className="p-2"><input type="number" min={0} step="any" inputMode="decimal" className="input !min-h-9 !w-28" aria-label={`Đếm ${i.name}`} value={v ?? ''} onChange={(e) => setVals({ ...vals, [i.id]: e.target.value })} /></td>
                <td className={`p-2 text-right font-semibold ${d < 0 ? 'text-danger' : d > 0 ? 'text-leaf-dark' : ''}`}>{d ? (d > 0 ? '+' : '') + num(d, 2) : ''}</td></tr>;
            })}</tbody></table>
        </div>
        <button className="btn btn-green btn-lg w-full" disabled={busy || changed.length === 0} onClick={submit}>{busy ? <Spinner /> : '✔'} Ghi kiểm kê ({changed.length} dòng lệch)</button>
      </div>
    </Modal>
  );
}

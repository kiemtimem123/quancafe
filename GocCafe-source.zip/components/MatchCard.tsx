'use client';
import Link from 'next/link';
import type { MatchResult } from '@/lib/types';
import { mainOf } from '@/lib/pick';
import { pct, vnd } from '@/lib/format';
import { RecipeThumb } from './ui';
import { useAuth } from './Auth';
import { AlternativesBox, AvailBadge, type AvailItem } from './Availability';

export function MatchCard({ m, showPriority, avail }: { m: MatchResult; showPriority?: boolean; avail?: AvailItem }) {
  const r = m.recipe;
  const { can } = useAuth();
  const s = mainOf(r);
  const n = m.missing.length;
  return (
    <article className="card pop flex flex-col overflow-hidden sm:flex-row">
      <RecipeThumb category={r.category} image={r.image} className="h-28 w-full shrink-0 sm:h-auto sm:w-36" />
      <div className="flex flex-1 flex-col gap-3 p-4">
        <div className="flex flex-wrap items-center gap-2">
          <h3 className="text-lg font-bold">{r.name}</h3>
          {n === 0 ? <span className="tag tag-ok">Pha được ngay – 100%</span>
            : <span className={`tag ${n <= 2 ? 'tag-warn' : 'tag-miss'}`}>Thiếu {n} nguyên liệu – {pct(m.percent)}</span>}
          <AvailBadge a={r.availability} />
          {showPriority && m.priority_used > 0 && <span className="tag tag-neutral">♻ Dùng {m.priority_used} NL cần tận dụng</span>}
        </div>
        <div className="flex flex-wrap gap-1.5" aria-label="Nguyên liệu">
          {m.required.map((x) => (
            <span key={x.id} className={`tag ${x.have ? 'tag-ok' : 'tag-miss'}`}>{x.name} {x.have ? '✓' : '❌'}{x.via === 'substitute' && <em className="ml-1 text-[11px] not-italic opacity-80">(thay bằng {x.by})</em>}{x.via === 'prep' && <em className="ml-1 text-[11px] not-italic opacity-80">(tự làm mẻ)</em>}</span>
          ))}
          {m.optional.map((x) => <span key={`o${x.id}`} className={`tag ${x.have ? 'tag-neutral' : 'tag-neutral opacity-60'}`}>+ {x.name} (tùy chọn){x.have ? ' ✓' : ''}</span>)}
        </div>
        {avail && avail.availability.status !== 'ok' && <AlternativesBox item={avail} compact />}
        <div className="mt-auto flex flex-wrap items-center justify-between gap-2">
          <p className="text-sm text-mocha">⏱ {r.preparation_time} phút · {r.difficulty}{s && <> · Giá bán {vnd(s.selling_price)}{can('view_cost') && <> · Lãi {pct(s.margin)}</>}</>}</p>
          <Link href={`/recipes/${r.id}`} className="btn btn-primary">XEM CÔNG THỨC →</Link>
        </div>
      </div>
    </article>
  );
}

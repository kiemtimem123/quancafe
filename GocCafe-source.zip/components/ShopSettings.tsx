'use client';
import { useEffect, useRef, useState } from 'react';
import { api } from '@/lib/client';
import { Modal, Spinner } from './ui';
import { BANKS } from '@/lib/vietqr';
import { useToast } from './Toast';

interface S { shop_name: string; shop_address: string; shop_phone: string; receipt_footer: string; paper_width: '58' | '80'; table_count: number; has_qr: boolean; bank_info: string; bank_bin: string; bank_account: string; bank_holder: string; loyalty_earn_per: number; loyalty_point_value: number }

/** Cài đặt hóa đơn: thông tin quán, khổ giấy, số bàn, ảnh QR chuyển khoản. */
export function ShopSettings({ open, onClose, onSaved }: { open: boolean; onClose: () => void; onSaved: () => void }) {
  const toast = useToast();
  const [f, setF] = useState<S | null>(null);
  const [qr, setQr] = useState('');
  const [busy, setBusy] = useState(false);
  const [qrBusy, setQrBusy] = useState(false);
  const [err, setErr] = useState('');
  const file = useRef<HTMLInputElement>(null);
  const loadQr = () => api<{ qr_image: string }>('/api/settings/qr').then((r) => setQr(r.qr_image)).catch(() => setQr(''));
  useEffect(() => {
    if (!open) return;
    setErr('');
    api<S>('/api/settings').then((s) => { setF(s); if (s.has_qr) loadQr(); else setQr(''); }).catch((e) => setErr(e.message));
  }, [open]);
  if (!open) return null;
  const set = (p: Partial<S>) => setF((x) => x && { ...x, ...p });
  const save = async () => {
    if (!f) return; setBusy(true); setErr('');
    try {
      await api('/api/settings', { method: 'PUT', body: { shop_name: f.shop_name, shop_address: f.shop_address, shop_phone: f.shop_phone, receipt_footer: f.receipt_footer, paper_width: f.paper_width, table_count: Number(f.table_count) || 0, bank_info: f.bank_info, bank_bin: f.bank_bin, bank_account: f.bank_account.trim(), bank_holder: f.bank_holder, loyalty_earn_per: Number(f.loyalty_earn_per) || 0, loyalty_point_value: Number(f.loyalty_point_value) || 0 } });
      toast.ok('Đã lưu cài đặt hóa đơn'); onSaved(); onClose();
    } catch (e) { setErr(e instanceof Error ? e.message : 'Lỗi'); } finally { setBusy(false); }
  };
  const upload = async (fl?: File) => {
    if (!fl) return; setQrBusy(true); setErr('');
    try {
      const fd = new FormData(); fd.append('file', fl);
      const res = await fetch('/api/settings/qr', { method: 'POST', body: fd });
      const d = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(d.error || `Lỗi ${res.status}`);
      toast.ok('Đã cập nhật ảnh QR'); set({ has_qr: true }); await loadQr(); onSaved();
    } catch (e) { setErr(e instanceof Error ? e.message : 'Không tải được ảnh'); } finally { setQrBusy(false); if (file.current) file.current.value = ''; }
  };
  const delQr = async () => { try { await api('/api/settings/qr', { method: 'DELETE' }); setQr(''); set({ has_qr: false }); toast.ok('Đã xóa ảnh QR'); onSaved(); } catch (e) { setErr(e instanceof Error ? e.message : 'Lỗi'); } };
  return (
    <Modal open onClose={onClose} title="Cài đặt hóa đơn">
      {!f ? <p className="flex justify-center p-6"><Spinner /></p> : (
        <div className="space-y-3">
          {err && <p className="rounded-xl bg-danger-soft p-3 text-sm text-danger" role="alert">{err}</p>}
          <div><label className="label" htmlFor="ss1">Tên quán</label><input id="ss1" className="input" value={f.shop_name} onChange={(e) => set({ shop_name: e.target.value })} /></div>
          <div><label className="label" htmlFor="ss2">Địa chỉ</label><input id="ss2" className="input" value={f.shop_address} onChange={(e) => set({ shop_address: e.target.value })} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="label" htmlFor="ss3">Điện thoại</label><input id="ss3" className="input" inputMode="tel" value={f.shop_phone} onChange={(e) => set({ shop_phone: e.target.value })} /></div>
            <div><label className="label" htmlFor="ss4">Số bàn</label><input id="ss4" type="number" min={0} max={60} className="input" value={f.table_count} onChange={(e) => set({ table_count: Number(e.target.value) })} /></div>
          </div>
          <div><label className="label" htmlFor="ss5">Lời cuối hóa đơn</label><input id="ss5" className="input" value={f.receipt_footer} onChange={(e) => set({ receipt_footer: e.target.value })} /></div>
          <div><p className="label">Khổ giấy máy in nhiệt</p><div className="flex gap-2">{(['58', '80'] as const).map((w) => <button key={w} className="chip flex-1 justify-center" aria-pressed={f.paper_width === w} onClick={() => set({ paper_width: w })}>{w}mm</button>)}</div>
            <p className="mt-1 text-xs text-mocha">Trong hộp thoại in của trình duyệt, chọn đúng máy in nhiệt và tắt “Đầu trang và chân trang” để hóa đơn gọn.</p></div>
          <div className="space-y-2 rounded-2xl bg-cream p-3">
            <p className="label">🏦 Tài khoản nhận tiền — tự tạo QR VietQR có sẵn số tiền</p>
            <select className="input" value={f.bank_bin} onChange={(e) => set({ bank_bin: e.target.value })} aria-label="Ngân hàng"><option value="">— Chưa chọn ngân hàng —</option>{BANKS.map((b) => <option key={b.bin} value={b.bin}>{b.name}</option>)}</select>
            <div className="grid grid-cols-2 gap-2"><input className="input" inputMode="numeric" placeholder="Số tài khoản" value={f.bank_account} onChange={(e) => set({ bank_account: e.target.value.replace(/\D/g, '') })} aria-label="Số tài khoản" /><input className="input" placeholder="Tên chủ tài khoản" value={f.bank_holder} onChange={(e) => set({ bank_holder: e.target.value })} aria-label="Tên chủ tài khoản" /></div>
            <p className="text-xs text-mocha">Khi khách chuyển khoản, màn hình bán hàng và hóa đơn hiện QR đúng số tiền. Nên thử quét bằng app ngân hàng một lần để chắc đúng tài khoản. Nếu chưa nhập, app dùng ảnh QR cố định bên dưới.</p>
          </div>
          <div className="grid grid-cols-2 gap-3 rounded-2xl bg-cream p-3">
            <div><label className="label" htmlFor="ly1">Tích 1 điểm / mỗi (đ)</label><input id="ly1" type="number" min={0} className="input" value={f.loyalty_earn_per} onChange={(e) => set({ loyalty_earn_per: Number(e.target.value) })} /></div>
            <div><label className="label" htmlFor="ly2">1 điểm = (đ giảm)</label><input id="ly2" type="number" min={0} className="input" value={f.loyalty_point_value} onChange={(e) => set({ loyalty_point_value: Number(e.target.value) })} /></div>
          </div>
          <div className="rounded-2xl bg-cream p-3">
            <p className="label">QR chuyển khoản (in trên hóa đơn khi khách chuyển khoản)</p>
            <div className="flex items-center gap-3">
              {qr ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={qr} alt="QR chuyển khoản" className="h-24 w-24 rounded-lg bg-white object-contain p-1" /> : <div className="flex h-24 w-24 items-center justify-center rounded-lg bg-white text-xs text-mocha">Chưa có QR</div>}
              <div className="space-y-2"><button className="btn btn-primary btn-sm" disabled={qrBusy} onClick={() => file.current?.click()}>{qrBusy ? <Spinner /> : '⬆'} {qr ? 'Đổi ảnh QR' : 'Tải ảnh QR'}</button>
                {qr && <button className="btn btn-ghost btn-sm" onClick={delQr}>Xóa QR</button>}
                <input ref={file} type="file" accept="image/*" className="hidden" onChange={(e) => upload(e.target.files?.[0])} /></div>
            </div>
            <div className="mt-3"><label className="label" htmlFor="ss6">Thông tin tài khoản in dưới QR (tuỳ chọn)</label><input id="ss6" className="input" placeholder="VD: Vietcombank · 0123456789 · NGUYEN VAN A" value={f.bank_info} onChange={(e) => set({ bank_info: e.target.value })} /></div>
          </div>
          <button className="btn btn-green btn-lg w-full" onClick={save} disabled={busy}>{busy ? <Spinner /> : '💾'} Lưu</button>
        </div>
      )}
    </Modal>
  );
}

'use client';
import { clearOfflineCache } from './Pwa';
import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { api } from '@/lib/client';
import { pendingCount } from '@/lib/offline/engine';
import { can as canRole, type Perm, type SessionUser } from '@/lib/roles';
import { Header } from './Header';
import { Loading } from './ui';

interface AuthCtx { user: SessionUser | null; needsSetup: boolean; loading: boolean; refresh: () => Promise<void>; logout: () => Promise<void>; can: (p: Perm) => boolean }
const Ctx = createContext<AuthCtx>({ user: null, needsSetup: false, loading: true, refresh: async () => {}, logout: async () => {}, can: () => false });
export const useAuth = () => useContext(Ctx);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [needsSetup, setNeedsSetup] = useState(false);
  const [loading, setLoading] = useState(true);
  const refresh = useCallback(async () => {
    try {
      const r = await api<{ user: SessionUser | null; needsSetup: boolean }>('/api/auth/me');
      setUser(r.user); setNeedsSetup(r.needsSetup);
    } catch { setUser(null); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { refresh(); }, [refresh]);
  const logout = useCallback(async () => { if (pendingCount() > 0 && !confirm(`Còn ${pendingCount()} thao tác chưa đồng bộ. Đăng xuất sẽ MẤT chúng. Vẫn đăng xuất?`)) return; try { await api('/api/auth/logout', { method: 'POST', body: {} }); } finally { await clearOfflineCache(); setUser(null); window.location.href = '/login'; } }, []);
  const can = useCallback((p: Perm) => canRole(user?.role, p), [user]);
  return <Ctx.Provider value={{ user, needsSetup, loading, refresh, logout, can }}>{children}</Ctx.Provider>;
}

/** Khung trang: ẩn header ở /login, chuyển hướng nếu chưa đăng nhập. */
export function Shell({ children }: { children: ReactNode }) {
  const { user, loading } = useAuth();
  const path = usePathname();
  const router = useRouter();
  const isLogin = path === '/login';
  useEffect(() => { if (!loading && !user && !isLogin && path !== '/order') router.replace('/login'); }, [loading, user, isLogin, router, path]);
  if (path === '/order') return <>{children}</>; // trang khách đặt món: công khai, không cần đăng nhập
  if (path.startsWith('/receipt/')) return loading || !user ? <p className="p-4">Đang tải…</p> : <>{children}</>;
  if (isLogin) return <main className="mx-auto max-w-6xl px-4 py-8">{children}</main>;
  if (loading || !user) return <main className="mx-auto max-w-3xl px-4 py-10"><Loading rows={2} /></main>;
  return (
    <>
      <Header />
      <main className="mx-auto max-w-6xl px-4 pb-28 pt-5 lg:pb-12">{children}</main>
    </>
  );
}

export function Forbidden({ what = 'trang này' }: { what?: string }) {
  return (
    <div className="card mx-auto max-w-md px-6 py-10 text-center">
      <div className="text-5xl">🔒</div>
      <p className="mt-3 text-lg font-bold">Bạn không có quyền truy cập {what}</p>
      <p className="mt-1 text-sm text-mocha">Liên hệ quản lý quán nếu bạn cần quyền này.</p>
    </div>
  );
}

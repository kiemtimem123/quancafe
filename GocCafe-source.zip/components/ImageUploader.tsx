'use client';
import { useRef, useState } from 'react';
import { Spinner, RecipeThumb } from './ui';
import { useToast } from './Toast';

const MAX_SIDE = 1600;
const OK_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];

/** Thu nhỏ ảnh chụp từ điện thoại trước khi gửi để tải nhanh, tiết kiệm 4G. */
async function shrink(file: File): Promise<Blob> {
  try {
    if (file.type === 'image/gif') return file;
    const bmp = await createImageBitmap(file, { imageOrientation: 'from-image' });
    const scale = Math.min(1, MAX_SIDE / Math.max(bmp.width, bmp.height));
    if (scale === 1 && file.size < 1.5 * 1024 * 1024) { bmp.close(); return file; }
    const c = document.createElement('canvas');
    c.width = Math.round(bmp.width * scale); c.height = Math.round(bmp.height * scale);
    c.getContext('2d')!.drawImage(bmp, 0, 0, c.width, c.height);
    bmp.close();
    const blob = await new Promise<Blob | null>((r) => c.toBlob(r, 'image/jpeg', 0.88));
    return blob && blob.size < file.size ? blob : file;
  } catch { return file; }
}

/** Kiểm tra, thu nhỏ rồi tải ảnh lên máy chủ; trả về đường dẫn ảnh. Ném lỗi có thông báo tiếng Việt. */
export async function uploadImageFile(file: File): Promise<string> {
  if (!OK_TYPES.includes(file.type)) throw new Error('Chỉ hỗ trợ ảnh JPG, PNG, WebP hoặc GIF');
  if (file.size > 25 * 1024 * 1024) throw new Error('Ảnh quá lớn (tối đa 25MB)');
  const blob = await shrink(file);
  if (blob.size > 8 * 1024 * 1024) throw new Error('Ảnh vẫn quá lớn sau khi nén (tối đa 8MB)');
  const fd = new FormData();
  fd.append('file', blob, file.name);
  let res: Response;
  try { res = await fetch('/api/images', { method: 'POST', body: fd }); } catch { throw new Error('Không kết nối được máy chủ. Thử lại sau.'); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Lỗi ${res.status}`);
  return data.url as string;
}

/** Nút đổi ảnh một chạm: chọn/chụp ảnh → tải lên → gọi onUploaded(url) để lưu ngay. */
export function QuickImageButton({ onUploaded, hasImage, className = '' }: { onUploaded: (url: string) => Promise<void> | void; hasImage: boolean; className?: string }) {
  const toast = useToast();
  const input = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  return (
    <>
      <button type="button" className={className || 'btn btn-ghost'} disabled={busy} onClick={(e) => { e.preventDefault(); e.stopPropagation(); input.current?.click(); }}>{busy ? <Spinner /> : '📷'} {hasImage ? 'Đổi ảnh' : 'Thêm ảnh'}</button>
      <input ref={input} type="file" accept="image/jpeg,image/png,image/webp,image/gif" className="hidden" onChange={async (e) => {
        const f = e.target.files?.[0]; if (!f) return;
        setBusy(true);
        try { await onUploaded(await uploadImageFile(f)); } catch (err) { toast.err(err instanceof Error ? err.message : 'Không tải được ảnh'); }
        finally { setBusy(false); if (input.current) input.current.value = ''; }
      }} />
    </>
  );
}

export function ImageUploader({ value, category, onChange }: { value: string; category: string; onChange: (url: string) => void }) {
  const toast = useToast();
  const input = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [showUrl, setShowUrl] = useState(false);

  const pick = async (file: File | undefined) => {
    if (!file) return;
    setBusy(true);
    try {
      onChange(await uploadImageFile(file));
      toast.ok('Đã tải ảnh lên — nhớ bấm Lưu để áp dụng');
    } catch (e) { toast.err(e instanceof Error ? e.message : 'Không tải được ảnh'); }
    finally { setBusy(false); if (input.current) input.current.value = ''; }
  };

  return (
    <div className="sm:col-span-2">
      <span className="label">Hình ảnh món</span>
      <div className="flex flex-wrap items-center gap-4">
        <div className="relative h-28 w-28 shrink-0 overflow-hidden rounded-2xl border border-[#eadfcd]">
          <RecipeThumb category={category} image={value} className="h-full w-full" />
          {busy && <div className="absolute inset-0 flex items-center justify-center bg-white/70"><Spinner /></div>}
        </div>
        <div className="space-y-2">
          <div className="flex flex-wrap gap-2">
            <button type="button" className="btn btn-ghost" onClick={() => input.current?.click()} disabled={busy}>📷 {value ? 'Đổi ảnh' : 'Chọn / chụp ảnh'}</button>
            {value && <button type="button" className="btn btn-danger" onClick={() => onChange('')} disabled={busy}>Xóa ảnh</button>}
          </div>
          <p className="text-xs text-mocha">JPG, PNG, WebP, GIF — tự thu nhỏ & tối ưu. {!value && 'Chưa có ảnh: dùng hình minh họa theo danh mục.'}</p>
          <button type="button" className="text-xs underline text-mocha" onClick={() => setShowUrl(!showUrl)}>{showUrl ? 'Ẩn' : 'Hoặc dán đường dẫn ảnh'}</button>
        </div>
        <input ref={input} type="file" accept="image/jpeg,image/png,image/webp,image/gif" className="hidden" onChange={(e) => pick(e.target.files?.[0])} aria-label="Chọn file ảnh" />
      </div>
      {showUrl && <input className="input mt-2" value={value.startsWith('/api/images/') ? '' : value} onChange={(e) => onChange(e.target.value.trim())} placeholder="https://…" aria-label="Đường dẫn ảnh" />}
    </div>
  );
}

'use client';
import { useEffect, useState } from 'react';
import { api } from '@/lib/client';
import { Modal, Spinner } from './ui';
import { useToast } from './Toast';

/** Bật/tắt xác thực 2 bước (ứng dụng Google Authenticator, Authy, Microsoft Authenticator…). */
export function Security2FA({ open, onClose }: { open: boolean; onClose: () => void }) {
  const toast = useToast();
  const [enabled, setEnabled] = useState<boolean | null>(null);
  const [setup, setSetup] = useState<{ secret: string; qr: string } | null>(null);
  const [code, setCode] = useState('');
  const [pw, setPw] = useState('');
  const [recovery, setRecovery] = useState<string[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  useEffect(() => { if (open) { setEnabled(null); setSetup(null); setCode(''); setPw(''); setRecovery(null); setErr(''); api<{ enabled: boolean }>('/api/auth/2fa').then((r) => setEnabled(r.enabled)).catch((e) => setErr(e.message)); } }, [open]);
  const act = async (body: Record<string, unknown>, ok: (r: never) => void) => {
    setBusy(true); setErr('');
    try { ok((await api('/api/auth/2fa', { method: 'POST', body })) as never); } catch (e) { setErr(e instanceof Error ? e.message : 'Lỗi'); } finally { setBusy(false); }
  };
  return (
    <Modal open={open} onClose={onClose} title="🔐 Xác thực 2 bước">
      <div className="space-y-3 text-sm">
        {err && <p className="rounded-xl bg-danger-soft p-3 font-semibold text-danger" role="alert">{err}</p>}
        {enabled === null && !err && <p className="flex justify-center p-4"><Spinner /></p>}
        {recovery && (<>
          <p className="rounded-xl bg-leaf-soft p-3 font-semibold text-leaf-dark">✅ Đã bật xác thực 2 bước.</p>
          <p><b>Mã khôi phục</b> (mỗi mã dùng một lần, khi mất điện thoại). Hãy chép lại và cất nơi an toàn — sẽ không hiện lại:</p>
          <div className="grid grid-cols-2 gap-1 rounded-xl bg-cream p-3 font-mono text-base font-bold">{recovery.map((c) => <span key={c}>{c}</span>)}</div>
          <button className="btn btn-green w-full" onClick={onClose}>Tôi đã lưu</button>
        </>)}
        {!recovery && enabled === false && !setup && (<>
          <p>Khi bật, ngoài mật khẩu còn cần mã 6 số từ ứng dụng trên điện thoại mỗi lần đăng nhập. Nên bật cho tài khoản chủ quán / quản trị.</p>
          <button className="btn btn-green btn-lg w-full" disabled={busy} onClick={() => act({ action: 'setup' }, (r: { secret: string; qr: string }) => setSetup(r))}>{busy ? <Spinner /> : 'Bật xác thực 2 bước'}</button>
        </>)}
        {!recovery && setup && (<>
          <ol className="list-decimal space-y-1 pl-5"><li>Mở ứng dụng Authenticator (Google/Microsoft/Authy) → thêm tài khoản → quét mã QR.</li><li>Nhập mã 6 số đang hiện trong ứng dụng để xác nhận.</li></ol>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={setup.qr} alt="Mã QR xác thực" className="mx-auto h-48 w-48" />
          <p className="text-center text-xs text-mocha">Không quét được? Nhập khóa: <b className="font-mono">{setup.secret}</b></p>
          <input className="input text-center text-2xl tracking-widest" inputMode="numeric" maxLength={6} placeholder="000000" value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))} aria-label="Mã 6 số" />
          <button className="btn btn-green btn-lg w-full" disabled={busy || code.length !== 6} onClick={() => act({ action: 'enable', code }, (r: { recovery: string[] }) => { setRecovery(r.recovery); setEnabled(true); toast.ok('Đã bật xác thực 2 bước'); })}>{busy ? <Spinner /> : 'Xác nhận & bật'}</button>
        </>)}
        {!recovery && enabled === true && (<>
          <p className="rounded-xl bg-leaf-soft p-3 font-semibold text-leaf-dark">✅ Xác thực 2 bước đang bật.</p>
          <p>Để tắt, nhập mật khẩu và mã 6 số hiện tại:</p>
          <input className="input" type="password" autoComplete="current-password" placeholder="Mật khẩu" value={pw} onChange={(e) => setPw(e.target.value)} />
          <input className="input" inputMode="numeric" maxLength={6} placeholder="Mã 6 số" value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))} />
          <button className="btn btn-danger w-full" disabled={busy || !pw || code.length !== 6} onClick={() => act({ action: 'disable', password: pw, code }, () => { setEnabled(false); setCode(''); setPw(''); toast.ok('Đã tắt xác thực 2 bước'); })}>Tắt xác thực 2 bước</button>
        </>)}
      </div>
    </Modal>
  );
}

'use client';
import { ExcelImport } from './ExcelImport';
import { vnd } from '@/lib/format';

const TAG: Record<string, [string, string]> = { create: ['tag-ok', 'Thêm mới'], update: ['tag-warn', 'Cập nhật'], skip: ['tag-neutral', 'Bỏ qua'], error: ['tag-miss', 'Lỗi'] };
/* eslint-disable @typescript-eslint/no-explicit-any */
export function ImportRecipes({ open, onClose, onDone }: { open: boolean; onClose: () => void; onDone: () => void }) {
  return (
    <ExcelImport open={open} onClose={onClose} onDone={onDone} title="Nhập công thức từ Excel" endpoint="/api/recipes/import" templateUrl="/api/recipes/import/template" templateName="mau-nhap-cong-thuc.xlsx" dup
      hint={<>Dùng file mẫu, hoặc nhập thẳng <b>bảng tính cost của quán</b> (Tên | NL 1 | NL 2 … mỗi món 3 dòng). Nguyên liệu phải có sẵn trong kho.</>}
      okCount={(p) => p.summary.create + p.summary.update} errCount={(p) => p.summary.error}
      commitLabel={(n) => `Nhập ${n} món`} doneMsg={(r) => `Đã nhập: ${r.created} món mới, ${r.updated} cập nhật`}
      table={(p) => (
        <table className="w-full min-w-[620px] text-sm"><thead className="sticky top-0 bg-cream text-left text-mocha"><tr><th className="p-2">Món</th><th className="p-2">Kết quả</th><th className="p-2">Danh mục</th><th className="p-2">Size</th><th className="p-2 text-right">Giá bán</th><th className="p-2">Ghi chú</th></tr></thead>
          <tbody>{p.rows.map((r: any, i: number) => (
            <tr key={i} className="border-t border-[#f3ebdd]"><td className="p-2 font-semibold">{r.name}<span className="block text-xs font-normal text-mocha">{r.lines} nguyên liệu</span></td>
              <td className="p-2"><span className={`tag ${TAG[r.action][0]}`}>{TAG[r.action][1]}</span></td><td className="p-2">{r.category ?? '—'}</td><td className="p-2">{r.sizes.join(', ')}</td>
              <td className="p-2 text-right">{r.price ? vnd(r.price) : '—'}</td><td className="p-2 text-xs text-mocha">{r.reason ?? r.warnings.join('; ')}</td></tr>))}</tbody></table>
      )} />
  );
}

'use client';
import { useRef, useState } from 'react';
import { Modal, Spinner } from './ui';
import { useToast } from './Toast';
import { DownloadButton } from './DownloadButton';
import { num, vnd } from '@/lib/format';

interface Row { row: number; name: string; action: 'create' | 'update' | 'skip' | 'error'; reason?: string; warnings: string[]; final?: { category: string; unit: string; base_unit: string; pack_size: number; purchase_price: number; stock_quantity: number } }
interface Preview { format: 'mau' | 'bang-tinh'; sheet: string; summary: { create: number; update: number; skip: number; error: number; total: number }; rows: Row[] }

const TAG: Record<Row['action'], [string, string]> = { create: ['tag-ok', 'Thêm mới'], update: ['tag-warn', 'Cập nhật'], skip: ['tag-neutral', 'Bỏ qua'], error: ['tag-miss', 'Lỗi'] };

export function ImportIngredients({ open, onClose, onDone }: { open: boolean; onClose: () => void; onDone: () => void }) {
  const toast = useToast();
  const input = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [prev, setPrev] = useState<Preview | null>(null);
  const [onDup, setOnDup] = useState<'update' | 'skip'>('update');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [filter, setFilter] = useState<'all' | Row['action']>('all');

  const reset = () => { setFile(null); setPrev(null); setErr(''); setFilter('all'); if (input.current) input.current.value = ''; };
  const close = () => { reset(); onClose(); };

  const send = async (f: File, mode: 'preview' | 'commit', dup = onDup) => {
    const fd = new FormData(); fd.append('file', f); fd.append('mode', mode); fd.append('on_duplicate', dup);
    let res: Response;
    try { res = await fetch('/api/ingredients/import', { method: 'POST', body: fd }); } catch { throw new Error('Không kết nối được máy chủ. Kiểm tra mạng rồi thử lại.'); }
    const d = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(d.error || `Lỗi ${res.status}`);
    return d;
  };
  const pick = async (f: File | undefined) => {
    if (!f) return;
    setErr(''); setPrev(null);
    if (!/\.xlsx$/i.test(f.name)) { setErr('Chỉ hỗ trợ file Excel .xlsx. Nếu đang dùng .xls hoặc .csv, hãy "Lưu thành" .xlsx.'); return; }
    if (f.size > 5 * 1024 * 1024) { setErr('File quá lớn (tối đa 5MB).'); return; }
    setFile(f); setBusy(true);
    try { setPrev(await send(f, 'preview')); } catch (e) { setErr(e instanceof Error ? e.message : 'Lỗi'); setFile(null); } finally { setBusy(false); }
  };
  const changeDup = async (v: 'update' | 'skip') => {
    setOnDup(v); if (!file) return; setBusy(true);
    try { setPrev(await send(file, 'preview', v)); } catch (e) { setErr(e instanceof Error ? e.message : 'Lỗi'); } finally { setBusy(false); }
  };
  const commit = async () => {
    if (!file) return; setBusy(true); setErr('');
    try {
      const r = await send(file, 'commit');
      toast.ok(`Đã nhập: ${r.created} thêm mới, ${r.updated} cập nhật`); onDone(); close();
    } catch (e) { setErr(e instanceof Error ? e.message : 'Lỗi'); } finally { setBusy(false); }
  };

  const ok = prev ? prev.summary.create + prev.summary.update : 0;
  const rows = prev?.rows.filter((r) => filter === 'all' || r.action === filter) ?? [];
  return (
    <Modal open={open} onClose={close} title="Nhập nguyên liệu từ Excel" wide>
      <div className="space-y-4">
        <div className="flex flex-wrap items-center gap-2 rounded-2xl bg-cream p-3 text-sm">
          <span className="font-semibold">Chưa có file?</span>
          <DownloadButton url="/api/ingredients/template" filename="mau-nhap-nguyen-lieu.xlsx" className="btn btn-ghost btn-sm">Tải file mẫu</DownloadButton>
          <span className="text-mocha">Hoặc dùng bảng tính có cột <b>Tên · Giá nhập · Số lượng · Đơn vị</b> của quán.</span>
        </div>

        <label className="flex cursor-pointer flex-col items-center gap-1 rounded-2xl border-2 border-dashed border-latte bg-white p-6 text-center hover:bg-foam"
          onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); pick(e.dataTransfer.files?.[0]); }}>
          <span className="text-3xl">📄</span>
          <b>{file ? file.name : 'Chọn file .xlsx hoặc kéo thả vào đây'}</b>
          <span className="text-xs text-mocha">Tối đa 5MB · 2000 dòng</span>
          <input ref={input} type="file" className="hidden" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" onChange={(e) => pick(e.target.files?.[0])} />
        </label>

        {busy && !prev && <p className="flex items-center justify-center gap-2 text-mocha"><Spinner /> Đang đọc file…</p>}
        {err && <p className="rounded-xl bg-danger-soft p-3 text-sm font-semibold text-danger" role="alert">{err}</p>}

        {prev && (
          <>
            <p className="text-sm text-mocha">Sheet “{prev.sheet}” · định dạng {prev.format === 'mau' ? 'file mẫu' : 'bảng tính của quán'} · {prev.summary.total} dòng</p>
            <div className="flex flex-wrap gap-2" role="group" aria-label="Lọc dòng">
              {([['all', `Tất cả (${prev.summary.total})`], ['create', `Thêm mới (${prev.summary.create})`], ['update', `Cập nhật (${prev.summary.update})`], ['skip', `Bỏ qua (${prev.summary.skip})`], ['error', `Lỗi (${prev.summary.error})`]] as const).map(([k, l]) => (
                <button key={k} className="chip" aria-pressed={filter === k} onClick={() => setFilter(k)}>{l}</button>))}
            </div>
            <div className="flex flex-wrap items-center gap-3 text-sm">
              <span className="font-semibold">Nguyên liệu đã có trong hệ thống:</span>
              <label className="flex items-center gap-1"><input type="radio" name="dup" checked={onDup === 'update'} onChange={() => changeDup('update')} /> Cập nhật</label>
              <label className="flex items-center gap-1"><input type="radio" name="dup" checked={onDup === 'skip'} onChange={() => changeDup('skip')} /> Bỏ qua</label>
              {busy && <Spinner />}
            </div>
            <div className="max-h-[40vh] overflow-auto rounded-2xl border border-[#eadfcd]">
              <table className="w-full min-w-[620px] text-sm">
                <thead className="sticky top-0 bg-cream text-left text-mocha"><tr><th className="p-2">Dòng</th><th className="p-2">Nguyên liệu</th><th className="p-2">Kết quả</th><th className="p-2 text-right">Giá nhập</th><th className="p-2">Quy cách</th><th className="p-2">Ghi chú</th></tr></thead>
                <tbody>{rows.map((r) => (
                  <tr key={r.row} className="border-t border-[#f3ebdd]">
                    <td className="p-2 text-mocha">{r.row}</td><td className="p-2 font-semibold">{r.name}</td>
                    <td className="p-2"><span className={`tag ${TAG[r.action][0]}`}>{TAG[r.action][1]}</span></td>
                    <td className="p-2 text-right">{r.final ? `${vnd(r.final.purchase_price)}/${r.final.unit}` : '—'}</td>
                    <td className="p-2">{r.final ? `1 ${r.final.unit} = ${num(r.final.pack_size, 2)} ${r.final.base_unit}` : '—'}</td>
                    <td className="p-2 text-xs text-mocha">{r.reason ?? r.warnings.join('; ')}</td>
                  </tr>))}
                  {rows.length === 0 && <tr><td colSpan={6} className="p-4 text-center text-mocha">Không có dòng nào.</td></tr>}</tbody>
              </table>
            </div>
            {prev.summary.error > 0 && <p className="text-sm text-danger">Các dòng lỗi sẽ được bỏ qua. Sửa file rồi chọn lại nếu muốn nhập cả những dòng này.</p>}
            <div className="flex gap-2">
              <button className="btn btn-green btn-lg flex-1" disabled={busy || ok === 0} onClick={commit}>{busy ? <Spinner /> : '✔'} Nhập {ok} nguyên liệu</button>
              <button className="btn btn-ghost btn-lg" onClick={reset} disabled={busy}>Chọn file khác</button>
            </div>
          </>
        )}
      </div>
    </Modal>
  );
}

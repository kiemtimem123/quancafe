'use client';
import { useState, type ReactNode } from 'react';
import { downloadFile } from '@/lib/client';
import { Spinner } from './ui';
import { useToast } from './Toast';

export function DownloadButton({ url, filename, children, className = 'btn btn-ghost' }: { url: string; filename: string; children: ReactNode; className?: string }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  return (
    <button className={className} disabled={busy} onClick={async () => {
      setBusy(true);
      try { await downloadFile(url, filename); toast.ok('Đã tải file Excel'); } catch (e) { toast.err(e instanceof Error ? e.message : 'Không tải được file'); } finally { setBusy(false); }
    }}>{busy ? <Spinner /> : '⬇'} {children}</button>
  );
}

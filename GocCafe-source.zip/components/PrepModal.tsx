'use client';
import { useEffect, useMemo, useState } from 'react';
import { api } from '@/lib/client';
import type { Ingredient } from '@/lib/types';
import { num, vnd } from '@/lib/format';
import { Modal, Spinner } from './ui';
import { useToast } from './Toast';
import type { MarginAlertT } from './MarginAlerts';

interface Line { component_id: string; quantity: string; unit: string }
const UNITS: Record<string, string[]> = { g: ['g', 'kg'], ml: ['ml', 'lít'], 'cái': ['cái'] };

/** Công thức bán thành phẩm (cốt trà, syrup tự nấu, kem mặn…) + nút "Làm mẻ". */
export function PrepModal({ ing, all, seeCost, onClose, onDone }: { ing: Ingredient | null; all: Ingredient[]; seeCost: boolean; onClose: () => void; onDone: (a?: MarginAlertT[], t?: number) => void }) {
  const toast = useToast();
  const [yieldQty, setYieldQty] = useState('1000');
  const [instr, setInstr] = useState('');
  const [lines, setLines] = useState<Line[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [exists, setExists] = useState(false);
  const [busy, setBusy] = useState('');
  const [err, setErr] = useState('');
  const [batches, setBatches] = useState('1');
  const byId = useMemo(() => new Map(all.map((i) => [i.id, i])), [all]);

  useEffect(() => {
    if (!ing) return;
    setLoaded(false); setErr('');
    api<{ prep: { yield_qty: number; instructions: string; lines: { component_id: number; quantity: number; unit: string }[] } | null }>(`/api/ingredients/${ing.id}/prep`).then(({ prep }) => {
      setExists(!!prep);
      setYieldQty(String(prep?.yield_qty ?? (ing.base_unit === 'cái' ? 10 : 1000)));
      setInstr(prep?.instructions ?? '');
      setLines(prep ? prep.lines.map((l) => ({ component_id: String(l.component_id), quantity: String(l.quantity), unit: l.unit })) : [{ component_id: '', quantity: '', unit: ing.base_unit }]);
      setLoaded(true);
    }).catch((e) => setErr(e instanceof Error ? e.message : 'Lỗi'));
  }, [ing?.id]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!ing) return null;

  const setLine = (i: number, p: Partial<Line>) => setLines((ls) => ls.map((l, k) => (k === i ? { ...l, ...p } : l)));
  const options = all.filter((c) => c.id !== ing.id);
  const save = async () => {
    setBusy('save'); setErr('');
    try {
      const body = { yield_qty: Number(yieldQty), instructions: instr, lines: lines.filter((l) => l.component_id).map((l) => ({ component_id: Number(l.component_id), quantity: Number(l.quantity), unit: l.unit })) };
      const r = await api<{ alerts?: MarginAlertT[]; threshold?: number }>(`/api/ingredients/${ing.id}/prep`, { method: 'PUT', body });
      toast.ok('Đã lưu công thức bán thành phẩm'); setExists(true); onDone(r.alerts, r.threshold); onClose();
    } catch (e) { setErr(e instanceof Error ? e.message : 'Lỗi'); } finally { setBusy(''); }
  };
  const make = async (force = false) => {
    setBusy('make'); setErr('');
    try {
      const r = await api<{ added: number }>(`/api/ingredients/${ing.id}/make`, { method: 'POST', body: { batches: Number(batches), force } });
      toast.ok(`Đã làm ${batches} mẻ — thêm ${num(r.added)} ${ing.base_unit} vào kho`); onDone(); onClose();
    } catch (e) {
      const er = e as Error & { status?: number };
      if (er.status === 409 && confirm(`${er.message}\n\nVẫn ghi nhận làm mẻ (tồn thành phần về 0)?`)) return make(true);
      setErr(er.message);
    } finally { setBusy(''); }
  };
  return (
    <Modal open onClose={onClose} title={`Bán thành phẩm: ${ing.name}`} wide>
      {!loaded ? <p className="flex justify-center p-6"><Spinner /></p> : (
        <div className="space-y-4">
          <p className="rounded-xl bg-cream p-3 text-sm">Khai báo công thức làm <b>{ing.name}</b> từ các nguyên liệu khác. Giá vốn sẽ <b>tự tính</b> theo giá nguyên liệu và tự cập nhật vào các món dùng nó.</p>
          {err && <p className="rounded-xl bg-danger-soft p-3 text-sm text-danger" role="alert">{err}</p>}
          <div className="grid gap-3 sm:grid-cols-2">
            <div><label className="label" htmlFor="py">1 mẻ cho ra bao nhiêu {ing.base_unit}?</label><input id="py" type="number" min={0} step="any" className="input" value={yieldQty} onChange={(e) => setYieldQty(e.target.value)} /></div>
            <div className="flex items-end text-sm text-mocha">{seeCost && ing.has_prep && <>Giá vốn hiện tại: <b className="ml-1 text-espresso">{num(ing.unit_cost, 2)}đ/{ing.base_unit}</b></>}</div>
          </div>
          <div className="space-y-2">
            <p className="label">Thành phần của 1 mẻ</p>
            {lines.map((l, i) => {
              const c = byId.get(Number(l.component_id));
              const units = c ? UNITS[c.base_unit] : ['g', 'kg', 'ml', 'lít', 'cái'];
              return (
                <div key={i} className="flex flex-wrap items-center gap-2">
                  <select className="input !w-auto min-w-0 flex-1 basis-44" aria-label="Thành phần" value={l.component_id} onChange={(e) => { const nc = byId.get(Number(e.target.value)); setLine(i, { component_id: e.target.value, unit: nc ? UNITS[nc.base_unit][0] : l.unit }); }}>
                    <option value="">— chọn nguyên liệu —</option>{options.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}</select>
                  <input className="input !w-24" type="number" min={0} step="any" aria-label="Định lượng" value={l.quantity} onChange={(e) => setLine(i, { quantity: e.target.value })} />
                  <select className="input !w-20" aria-label="Đơn vị" value={l.unit} onChange={(e) => setLine(i, { unit: e.target.value })}>{units.map((u) => <option key={u}>{u}</option>)}</select>
                  <button className="btn btn-ghost btn-sm" onClick={() => setLines(lines.filter((_, k) => k !== i))} aria-label="Bỏ dòng">✕</button>
                </div>
              );
            })}
            <button className="btn btn-ghost btn-sm" onClick={() => setLines([...lines, { component_id: '', quantity: '', unit: 'g' }])}>+ Thêm thành phần</button>
          </div>
          <div><label className="label" htmlFor="pi">Cách làm (tuỳ chọn)</label><textarea id="pi" className="input" rows={2} value={instr} onChange={(e) => setInstr(e.target.value)} /></div>
          <div className="flex flex-wrap gap-2">
            <button className="btn btn-green btn-lg flex-1" onClick={save} disabled={!!busy}>{busy === 'save' ? <Spinner /> : '💾'} Lưu công thức</button>
            {exists && <button className="btn btn-danger" disabled={!!busy} onClick={async () => { if (!confirm('Bỏ công thức bán thành phẩm? Nguyên liệu trở về dạng mua ngoài với giá nhập đã lưu — hãy kiểm tra lại giá.')) return; try { await api(`/api/ingredients/${ing.id}/prep`, { method: 'DELETE' }); toast.ok('Đã bỏ công thức'); onDone(); onClose(); } catch (e) { setErr(e instanceof Error ? e.message : 'Lỗi'); } }}>Bỏ công thức</button>}
          </div>
          {exists && (
            <div className="rounded-2xl border border-leaf/40 bg-leaf-soft p-3">
              <p className="font-bold text-leaf-dark">🍳 Làm mẻ</p>
              <p className="text-xs text-mocha">Trừ kho các thành phần và cộng vào kho {ing.name}.</p>
              <div className="mt-2 flex items-center gap-2"><input className="input !w-24" type="number" min={1} max={100} value={batches} onChange={(e) => setBatches(e.target.value)} aria-label="Số mẻ" /><span className="text-sm">mẻ</span>
                <button className="btn btn-primary" onClick={() => make()} disabled={!!busy}>{busy === 'make' ? <Spinner /> : 'Làm mẻ'}</button></div>
            </div>
          )}
        </div>
      )}
    </Modal>
  );
}

'use client';
import { useEffect, useState } from 'react';
import { Modal } from './ui';

interface BIP extends Event { prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> }
/** Nút "Cài ứng dụng": cài thẳng nếu trình duyệt hỗ trợ, nếu không thì hướng dẫn theo thiết bị. */
export function InstallApp({ className = 'block w-full rounded-lg px-3 py-2 text-left text-sm hover:bg-cream' }: { className?: string }) {
  const [ev, setEv] = useState<BIP | null>(null);
  const [open, setOpen] = useState(false);
  const [installed, setInstalled] = useState(false);
  useEffect(() => {
    setInstalled(window.matchMedia('(display-mode: standalone)').matches);
    const h = (e: Event) => { e.preventDefault(); setEv(e as BIP); };
    window.addEventListener('beforeinstallprompt', h);
    return () => window.removeEventListener('beforeinstallprompt', h);
  }, []);
  if (installed) return null;
  const ua = typeof navigator !== 'undefined' ? navigator.userAgent : '';
  const ios = /iPhone|iPad|iPod/.test(ua);
  return (
    <>
      <button className={className} onClick={async () => { if (ev) { await ev.prompt(); setEv(null); } else setOpen(true); }}>📲 Cài ứng dụng lên màn hình</button>
      <Modal open={open} onClose={() => setOpen(false)} title="Cài ứng dụng">
        <div className="space-y-3 text-sm">
          {!window.isSecureContext && <p className="rounded-xl bg-warn-soft p-3 text-[#8a5a00]">Trang đang chạy không có HTTPS nên trình duyệt không cho cài/offline. Xem hướng dẫn HTTPS trong DEPLOY.md.</p>}
          <div className={ios ? 'font-semibold' : ''}><p className="font-bold">iPhone / iPad (Safari)</p><p>Bấm nút Chia sẻ ⬆ → “Thêm vào MH chính” (Add to Home Screen).</p></div>
          <div className={!ios ? 'font-semibold' : ''}><p className="font-bold">Android (Chrome)</p><p>Bấm menu ⋮ → “Cài đặt ứng dụng” / “Thêm vào màn hình chính”.</p></div>
          <div><p className="font-bold">Máy tính (Chrome/Edge)</p><p>Bấm biểu tượng cài đặt ⊕ ở cuối thanh địa chỉ.</p></div>
          <p className="text-mocha">Sau khi cài, mở app một lần khi có mạng để tải dữ liệu offline.</p>
        </div>
      </Modal>
    </>
  );
}

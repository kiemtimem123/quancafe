'use client';
import { useRef, useState, type ReactNode } from 'react';
import { Modal, Spinner } from './ui';
import { useToast } from './Toast';
import { DownloadButton } from './DownloadButton';

/* eslint-disable @typescript-eslint/no-explicit-any */
export interface ExcelImportProps {
  open: boolean; onClose: () => void; onDone: () => void; title: string; endpoint: string; templateUrl: string; templateName: string; hint: ReactNode;
  dup?: boolean;
  okCount: (p: any) => number; errCount: (p: any) => number;
  table: (p: any) => ReactNode; commitLabel: (ok: number) => string; doneMsg: (r: any) => string;
}

export function ExcelImport(p: ExcelImportProps) {
  const toast = useToast();
  const input = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [prev, setPrev] = useState<any>(null);
  const [onDup, setOnDup] = useState<'update' | 'skip'>('update');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const reset = () => { setFile(null); setPrev(null); setErr(''); if (input.current) input.current.value = ''; };
  const close = () => { reset(); p.onClose(); };
  const send = async (f: File, mode: 'preview' | 'commit', dup = onDup) => {
    const fd = new FormData(); fd.append('file', f); fd.append('mode', mode); fd.append('on_duplicate', dup);
    let res: Response;
    try { res = await fetch(p.endpoint, { method: 'POST', body: fd }); } catch { throw new Error('Không kết nối được máy chủ. Kiểm tra mạng rồi thử lại.'); }
    const d = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(d.error || `Lỗi ${res.status}`);
    return d;
  };
  const pick = async (f?: File) => {
    if (!f) return; setErr(''); setPrev(null);
    if (!/\.xlsx$/i.test(f.name)) return setErr('Chỉ hỗ trợ file Excel .xlsx.');
    if (f.size > 5 * 1024 * 1024) return setErr('File quá lớn (tối đa 5MB).');
    setFile(f); setBusy(true);
    try { setPrev(await send(f, 'preview')); } catch (e) { setErr(e instanceof Error ? e.message : 'Lỗi'); setFile(null); } finally { setBusy(false); }
  };
  const changeDup = async (v: 'update' | 'skip') => { setOnDup(v); if (!file) return; setBusy(true); try { setPrev(await send(file, 'preview', v)); } catch (e) { setErr(e instanceof Error ? e.message : 'Lỗi'); } finally { setBusy(false); } };
  const commit = async () => {
    if (!file) return; setBusy(true); setErr('');
    try { const r = await send(file, 'commit'); toast.ok(p.doneMsg(r)); p.onDone(); close(); } catch (e) { setErr(e instanceof Error ? e.message : 'Lỗi'); } finally { setBusy(false); }
  };
  const ok = prev ? p.okCount(prev) : 0;
  return (
    <Modal open={p.open} onClose={close} title={p.title} wide>
      <div className="space-y-4">
        <div className="flex flex-wrap items-center gap-2 rounded-2xl bg-cream p-3 text-sm">
          <DownloadButton url={p.templateUrl} filename={p.templateName} className="btn btn-ghost btn-sm">Tải file mẫu</DownloadButton><span className="text-mocha">{p.hint}</span>
        </div>
        <label className="flex cursor-pointer flex-col items-center gap-1 rounded-2xl border-2 border-dashed border-latte bg-white p-6 text-center hover:bg-foam" onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); pick(e.dataTransfer.files?.[0]); }}>
          <span className="text-3xl">📄</span><b>{file ? file.name : 'Chọn file .xlsx hoặc kéo thả vào đây'}</b><span className="text-xs text-mocha">Tối đa 5MB</span>
          <input ref={input} type="file" className="hidden" accept=".xlsx" onChange={(e) => pick(e.target.files?.[0])} />
        </label>
        {busy && !prev && <p className="flex items-center justify-center gap-2 text-mocha"><Spinner /> Đang đọc file…</p>}
        {err && <p className="rounded-xl bg-danger-soft p-3 text-sm font-semibold text-danger" role="alert">{err}</p>}
        {prev && (<>
          {p.dup && <div className="flex flex-wrap items-center gap-3 text-sm"><span className="font-semibold">Món đã có trong hệ thống:</span>
            <label className="flex items-center gap-1"><input type="radio" name="dup" checked={onDup === 'update'} onChange={() => changeDup('update')} /> Cập nhật</label>
            <label className="flex items-center gap-1"><input type="radio" name="dup" checked={onDup === 'skip'} onChange={() => changeDup('skip')} /> Bỏ qua</label>{busy && <Spinner />}</div>}
          <div className="max-h-[40vh] overflow-auto rounded-2xl border border-[#eadfcd]">{p.table(prev)}</div>
          {p.errCount(prev) > 0 && <p className="text-sm text-danger">{p.errCount(prev)} dòng lỗi sẽ được bỏ qua. Sửa file rồi chọn lại nếu muốn nhập cả những dòng này.</p>}
          <div className="flex gap-2"><button className="btn btn-green btn-lg flex-1" disabled={busy || ok === 0} onClick={commit}>{busy ? <Spinner /> : '✔'} {p.commitLabel(ok)}</button><button className="btn btn-ghost btn-lg" onClick={reset} disabled={busy}>Chọn file khác</button></div>
        </>)}
      </div>
    </Modal>
  );
}

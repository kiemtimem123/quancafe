'use client';
import { ExcelImport } from './ExcelImport';
import { vnd } from '@/lib/format';
/* eslint-disable @typescript-eslint/no-explicit-any */
export function ImportSales({ open, onClose, onDone }: { open: boolean; onClose: () => void; onDone: () => void }) {
  return (
    <ExcelImport open={open} onClose={onClose} onDone={onDone} title="Nhập số liệu bán hàng từ Excel" endpoint="/api/sales/import" templateUrl="/api/sales/template" templateName="mau-nhap-ban-hang.xlsx"
      hint={<>Cột: <b>Ngày · Món · Size · Số lượng</b> (tuỳ chọn: Doanh thu). Xuất từ phần mềm bán hàng rồi đổi tên cột cho khớp.</>}
      okCount={(p) => p.summary.ok} errCount={(p) => p.summary.error} commitLabel={(n) => `Nhập ${n} dòng`} doneMsg={(r) => `Đã nhập ${r.inserted} dòng bán hàng`}
      table={(p) => (
        <table className="w-full min-w-[560px] text-sm"><thead className="sticky top-0 bg-cream text-left text-mocha"><tr><th className="p-2">Dòng</th><th className="p-2">Ngày</th><th className="p-2">Món</th><th className="p-2">Size</th><th className="p-2 text-right">SL</th><th className="p-2 text-right">Doanh thu</th><th className="p-2">Kết quả</th></tr></thead>
          <tbody>{p.rows.map((r: any) => <tr key={r.row} className="border-t border-[#f3ebdd]"><td className="p-2 text-mocha">{r.row}</td><td className="p-2">{r.date || '—'}</td><td className="p-2 font-semibold">{r.recipe}</td><td className="p-2">{r.size}</td><td className="p-2 text-right">{r.quantity}</td><td className="p-2 text-right">{r.revenue ? vnd(r.revenue) : 'theo giá bán'}</td>
            <td className="p-2">{r.error ? <span className="tag tag-miss">{r.error}</span> : <span className="tag tag-ok">OK</span>}</td></tr>)}
            {p.summary.total > p.rows.length && <tr><td colSpan={7} className="p-2 text-center text-xs text-mocha">… hiển thị {p.rows.length}/{p.summary.total} dòng đầu</td></tr>}</tbody></table>
      )} />
  );
}

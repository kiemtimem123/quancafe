'use client';
import { createContext, useCallback, useContext, useState, type ReactNode } from 'react';

type T = { id: number; kind: 'ok' | 'err'; msg: string };
const Ctx = createContext<(kind: 'ok' | 'err', msg: string) => void>(() => {});
export const useToast = () => {
  const push = useContext(Ctx);
  return { ok: (m: string) => push('ok', m), err: (m: string) => push('err', m) };
};

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<T[]>([]);
  const push = useCallback((kind: 'ok' | 'err', msg: string) => {
    const id = Date.now() + Math.random();
    setItems((x) => [...x, { id, kind, msg }]);
    setTimeout(() => setItems((x) => x.filter((i) => i.id !== id)), kind === 'err' ? 6000 : 3000);
  }, []);
  return (
    <Ctx.Provider value={push}>
      {children}
      <div className="no-print fixed inset-x-0 top-3 z-[100] flex flex-col items-center gap-2 px-3 pointer-events-none" role="status" aria-live="polite">
        {items.map((t) => (
          <div key={t.id} className={`pop pointer-events-auto max-w-md rounded-2xl px-4 py-3 text-sm font-semibold shadow-lg ${t.kind === 'ok' ? 'bg-leaf-dark text-white' : 'bg-danger text-white'}`}>
            {t.kind === 'ok' ? '✓ ' : '⚠ '}{t.msg}
          </div>
        ))}
      </div>
    </Ctx.Provider>
  );
}

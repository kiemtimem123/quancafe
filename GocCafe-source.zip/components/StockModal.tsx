'use client';
import { useEffect, useState } from 'react';
import { api } from '@/lib/client';
import type { Ingredient } from '@/lib/types';
import { num, vnd } from '@/lib/format';
import { Modal, Spinner } from './ui';
import { useToast } from './Toast';
import type { MarginAlertT } from './MarginAlerts';

interface Move { id: number; label: string; delta: number; balance: number; unit_price: number | null; note: string; user_name: string; created_at: string }
interface Batch { id: number; qty: number; received_on: string; expires_on: string | null }
interface Hist { moves: Move[]; prices: { price: number; created_at: string }[]; batches?: Batch[] }
const addD = (n: number) => new Date(Date.now() + 7 * 3600_000 + n * 864e5).toISOString().slice(0, 10);
type Kind = 'purchase' | 'adjust' | 'waste';
const dt = (s: string) => new Date(s.replace(' ', 'T') + 'Z').toLocaleString('vi-VN', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });

export function StockModal({ ing, seeCost, onClose, onDone }: { ing: Ingredient | null; seeCost: boolean; onClose: () => void; onDone: (alerts?: MarginAlertT[], threshold?: number) => void }) {
  const toast = useToast();
  const [kind, setKind] = useState<Kind>('purchase');
  const [qty, setQty] = useState('');
  const [price, setPrice] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [hist, setHist] = useState<Hist | null>(null);
  const [tab, setTab] = useState<'act' | 'moves' | 'prices' | 'batches'>('act');
  const [exp, setExp] = useState('');

  const load = async (id: number) => { try { setHist(await api<Hist>(`/api/ingredients/${id}/stock`)); } catch { setHist({ moves: [], prices: [], batches: [] }); } };
  useEffect(() => {
    if (!ing) return;
    setKind('purchase'); setQty(''); setNote(''); setErr(''); setTab('act'); setPrice(ing.has_prep ? '' : String(ing.purchase_price)); setHist(null); setExp(ing.shelf_life_days > 0 ? addD(ing.shelf_life_days) : '');
    load(ing.id);
  }, [ing?.id]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!ing) return null;

  const submit = async () => {
    const n = Number(qty);
    if (qty === '' || !isFinite(n) || n < 0 || (kind !== 'adjust' && n <= 0)) return setErr(kind === 'adjust' ? 'Nhập số lượng đếm được' : 'Nhập số lượng lớn hơn 0');
    setBusy(true); setErr('');
    try {
      const body: Record<string, unknown> = { kind, quantity: n, note };
      if (kind === 'purchase' && price !== '' && !ing.has_prep) body.unit_price = Number(price);
      if (kind === 'purchase' && ing.track_expiry && exp) body.expires_on = exp;
      const r = await api<{ balance: number; alerts: MarginAlertT[]; threshold: number }>(`/api/ingredients/${ing.id}/stock`, { method: 'POST', body });
      toast.ok(`Đã ghi sổ kho — tồn mới ${num(r.balance, 2)} ${ing.unit}`);
      setQty(''); setNote(''); load(ing.id); onDone(r.alerts, r.threshold);
    } catch (e) { setErr(e instanceof Error ? e.message : 'Lỗi'); } finally { setBusy(false); }
  };
  const priceChanged = kind === 'purchase' && price !== '' && Number(price) !== ing.purchase_price && !ing.has_prep;
  return (
    <Modal open onClose={onClose} title={`Kho: ${ing.name}`}>
      <p className="mb-3 text-sm text-mocha">Tồn hiện tại: <b className="text-espresso">{num(ing.stock_quantity, 2)} {ing.unit}</b>{ing.minimum_stock > 0 && <> · cảnh báo khi ≤ {num(ing.minimum_stock, 2)}</>}</p>
      <div className="mb-3 flex gap-2" role="tablist">
        {([['act', 'Ghi sổ'], ...(ing.track_expiry ? [['batches', 'Lô & hạn dùng']] : []), ['moves', 'Lịch sử kho'], ...(seeCost ? [['prices', 'Lịch sử giá']] : [])] as [typeof tab, string][]).map(([k, l]) => <button key={k} role="tab" className="chip" aria-pressed={tab === k} onClick={() => setTab(k)}>{l}</button>)}
      </div>
      {tab === 'act' && (
        <div className="space-y-3">
          {err && <p className="rounded-xl bg-danger-soft p-3 text-sm text-danger" role="alert">{err}</p>}
          <div className="flex gap-2">{([['purchase', '📥 Nhập kho'], ['adjust', '🧮 Kiểm kê'], ['waste', '🗑 Hao hụt']] as [Kind, string][]).map(([k, l]) => <button key={k} className="chip flex-1 justify-center" aria-pressed={kind === k} onClick={() => { setKind(k); setErr(''); }}>{l}</button>)}</div>
          <div><label className="label" htmlFor="sq">{kind === 'adjust' ? `Số đếm được thực tế (${ing.unit})` : kind === 'purchase' ? `Số lượng nhập thêm (${ing.unit})` : `Số lượng hao hụt/hủy (${ing.unit})`}</label>
            <input id="sq" type="number" min={0} step="any" inputMode="decimal" className="input" value={qty} onChange={(e) => setQty(e.target.value)} autoFocus /></div>
          {kind === 'purchase' && seeCost && !ing.has_prep && <div><label className="label" htmlFor="sp">Giá nhập lần này (đ / {ing.unit})</label><input id="sp" type="number" min={0} className="input" value={price} onChange={(e) => setPrice(e.target.value)} />
            {priceChanged && <p className="mt-1 text-xs font-semibold text-[#8a5a00]">Giá đổi {vnd(ing.purchase_price)} → {vnd(Number(price))}: giá vốn các món sẽ được tính lại.</p>}</div>}
          {kind === 'purchase' && ing.track_expiry && <div><label className="label" htmlFor="se">Hạn sử dụng của lô này</label><input id="se" type="date" className="input" value={exp} min={addD(0)} onChange={(e) => setExp(e.target.value)} />
            <div className="mt-1 flex flex-wrap gap-1.5">{[3, 7, 14, 30, 90].map((n) => <button key={n} type="button" className="chip" onClick={() => setExp(addD(n))}>+{n} ngày</button>)}<button type="button" className="chip" onClick={() => setExp('')}>Không ghi</button></div></div>}
          <div><label className="label" htmlFor="sn">Ghi chú</label><input id="sn" className="input" value={note} onChange={(e) => setNote(e.target.value)} placeholder={kind === 'purchase' ? 'VD: hóa đơn #123' : kind === 'waste' ? 'VD: hết hạn, đổ vỡ' : 'VD: kiểm kê cuối tuần'} /></div>
          <button className="btn btn-green btn-lg w-full" onClick={submit} disabled={busy}>{busy ? <Spinner /> : '💾'} Ghi sổ</button>
        </div>
      )}
      {tab === 'batches' && (!hist ? <p className="flex justify-center p-4"><Spinner /></p> : !hist.batches?.length ? <p className="p-4 text-center text-mocha">Chưa có lô nào có theo dõi hạn. Nhập kho kèm hạn sử dụng để tạo lô.</p> : (
        <ul className="max-h-[50vh] divide-y divide-[#f3ebdd] overflow-auto text-sm">{hist.batches.map((b) => {
          const d = b.expires_on ? Math.round((Date.parse(b.expires_on) - Date.parse(addD(0))) / 864e5) : null;
          return <li key={b.id} className="flex items-center justify-between gap-2 p-2"><span><b>{num(b.qty, 2)} {ing.unit}</b><span className="block text-xs text-mocha">Nhập {b.received_on.split('-').reverse().join('/')}</span></span>
            <span className={`tag ${d === null ? 'tag-neutral' : d < 0 ? 'tag-miss' : d <= 3 ? 'tag-warn' : 'tag-ok'}`}>{b.expires_on ? `${b.expires_on.split('-').reverse().join('/')} · ${d! < 0 ? `quá ${-d!} ngày` : `còn ${d} ngày`}` : 'không ghi hạn'}</span></li>;
        })}</ul>))}
      {tab === 'moves' && (!hist ? <p className="flex justify-center p-4"><Spinner /></p> : hist.moves.length === 0 ? <p className="p-4 text-center text-mocha">Chưa có giao dịch.</p> : (
        <div className="max-h-[50vh] overflow-auto"><table className="w-full text-sm"><thead className="text-left text-mocha"><tr><th className="p-2">Thời gian</th><th className="p-2">Loại</th><th className="p-2 text-right">+/−</th><th className="p-2 text-right">Tồn</th></tr></thead>
          <tbody>{hist.moves.map((m) => <tr key={m.id} className="border-t border-[#f3ebdd]"><td className="p-2 whitespace-nowrap text-xs text-mocha">{dt(m.created_at)}</td><td className="p-2">{m.label}<span className="block text-xs text-mocha">{[m.user_name, m.note].filter(Boolean).join(' · ')}</span></td>
            <td className={`p-2 text-right font-semibold ${m.delta < 0 ? 'text-danger' : 'text-leaf-dark'}`}>{m.delta > 0 ? '+' : ''}{num(m.delta, 2)}</td><td className="p-2 text-right">{num(m.balance, 2)}</td></tr>)}</tbody></table></div>))}
      {tab === 'prices' && (!hist ? <p className="flex justify-center p-4"><Spinner /></p> : hist.prices.length === 0 ? <p className="p-4 text-center text-mocha">Chưa có lịch sử giá.</p> : (
        <ul className="max-h-[50vh] divide-y divide-[#f3ebdd] overflow-auto text-sm">{hist.prices.map((p, i) => {
          const prev = hist.prices[i + 1]?.price; const d = prev ? ((p.price - prev) / prev) * 100 : null;
          return <li key={i} className="flex items-center justify-between p-2"><span className="text-xs text-mocha">{dt(p.created_at)}</span><span><b>{vnd(p.price)}</b>/{ing.unit}{d !== null && Math.abs(d) >= 0.05 && <span className={`ml-2 text-xs font-semibold ${d > 0 ? 'text-danger' : 'text-leaf-dark'}`}>{d > 0 ? '▲' : '▼'} {Math.abs(d).toFixed(1)}%</span>}</span></li>;
        })}</ul>))}
    </Modal>
  );
}

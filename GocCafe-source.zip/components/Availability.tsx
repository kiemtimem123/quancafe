'use client';
import Link from 'next/link';
import type { Availability } from '@/lib/types';
import { RecipeThumb } from './ui';

export interface AvailItem { id: number; name: string; category: string; image: string; availability: Availability; alternatives: Omit<AvailItem, 'alternatives'>[] }

export function AvailBadge({ a }: { a?: Availability }) {
  if (!a || a.cups === null) return null;
  if (a.status === 'out') return <span className="tag tag-miss">🚫 Hết hàng</span>;
  if (a.status === 'low') return <span className="tag tag-warn">⚠ Còn ~{a.cups} ly</span>;
  return null;
}

/** Lý do hết hàng + món thay thế còn hàng. */
export function AlternativesBox({ item, compact }: { item: AvailItem; compact?: boolean }) {
  const a = item.availability;
  if (a.status === 'ok') return null;
  return (
    <div className={`rounded-2xl p-3 text-sm ${a.status === 'out' ? 'bg-danger-soft' : 'bg-warn-soft'}`}>
      <p className={`font-semibold ${a.status === 'out' ? 'text-danger' : 'text-[#8a5a00]'}`}>
        {a.status === 'out' ? `🚫 Hết hàng — thiếu ${a.out.join(', ') || 'nguyên liệu'}` : `⚠ Sắp hết — còn khoảng ${a.cups} ly (giới hạn bởi ${a.limiting.join(', ')})`}
      </p>
      {item.alternatives.length > 0 && (
        <div className="mt-2">
          <p className="mb-1.5 text-xs font-bold uppercase tracking-wide text-mocha">Gợi ý món khác còn hàng</p>
          <div className={compact ? 'flex flex-wrap gap-2' : 'grid gap-2 sm:grid-cols-2'}>
            {item.alternatives.map((x) => (
              <Link key={x.id} href={`/recipes/${x.id}`} className="flex items-center gap-2 rounded-xl bg-white p-1.5 pr-3 shadow-sm hover:shadow-md">
                <RecipeThumb category={x.category} image={x.image} className="h-10 w-10 shrink-0 rounded-lg" />
                <span className="min-w-0"><b className="block truncate text-espresso">{x.name}</b><span className="text-xs text-mocha">{x.availability.cups !== null ? `còn ~${x.availability.cups} ly` : x.category}</span></span>
              </Link>
            ))}
          </div>
        </div>
      )}
      {item.alternatives.length === 0 && a.status === 'out' && <p className="mt-1 text-mocha">Chưa tìm được món thay thế phù hợp.</p>}
    </div>
  );
}

'use client';
import Link from 'next/link';
import { Modal } from './ui';
import { pct, vnd } from '@/lib/format';

export interface MarginAlertT { id: number; name: string; before: number; after: number; cost_before: number; cost_after: number }
export function MarginAlerts({ alerts, threshold, onClose }: { alerts: MarginAlertT[]; threshold: number; onClose: () => void }) {
  return (
    <Modal open={alerts.length > 0} onClose={onClose} title="⚠ Cảnh báo lợi nhuận">
      <p className="mb-3 text-sm text-mocha">Thay đổi giá vừa rồi làm {alerts.length} món có lợi nhuận gộp thấp hơn mức tối thiểu {threshold}%. Cân nhắc tăng giá bán hoặc đổi công thức.</p>
      <ul className="space-y-2">
        {alerts.map((a) => (
          <li key={a.id} className="flex items-center justify-between gap-2 rounded-xl bg-warn-soft p-3 text-sm">
            <Link href={`/recipes/${a.id}`} className="font-bold hover:underline" onClick={onClose}>{a.name}</Link>
            <span className="text-right">{pct(a.before)} → <b className="text-danger">{pct(a.after)}</b><span className="block text-xs text-mocha">giá vốn {vnd(a.cost_before)} → {vnd(a.cost_after)}</span></span>
          </li>
        ))}
      </ul>
      <button className="btn btn-primary mt-4 w-full" onClick={onClose}>Đã hiểu</button>
    </Modal>
  );
}

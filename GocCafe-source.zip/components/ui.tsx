'use client';
import { useEffect, useState, type ReactNode } from 'react';
import { RECIPE_CATEGORIES } from '@/lib/types';

export const catIcon = (c: string) => RECIPE_CATEGORIES.find((x) => x.name === c)?.icon ?? '🥤';

export function Loading({ rows = 3 }: { rows?: number }) {
  return (
    <div className="space-y-3" aria-busy="true" aria-label="Đang tải">
      {Array.from({ length: rows }).map((_, i) => <div key={i} className="skeleton h-24" />)}
    </div>
  );
}
export function ErrorBox({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="card border-danger/30 bg-danger-soft p-5 text-center" role="alert">
      <p className="font-semibold text-danger">⚠ {message}</p>
      {onRetry && <button className="btn btn-ghost mt-3" onClick={onRetry}>Thử lại</button>}
    </div>
  );
}
export function Empty({ icon = '☕', title, hint, action }: { icon?: string; title: string; hint?: string; action?: ReactNode }) {
  return (
    <div className="card px-6 py-10 text-center">
      <div className="text-5xl">{icon}</div>
      <p className="mt-3 text-lg font-bold">{title}</p>
      {hint && <p className="mt-1 text-sm text-mocha">{hint}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function Modal({ open, onClose, title, children, wide }: { open: boolean; onClose: () => void; title: string; children: ReactNode; wide?: boolean }) {
  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', h);
    document.body.style.overflow = 'hidden';
    return () => { window.removeEventListener('keydown', h); document.body.style.overflow = ''; };
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="no-print fixed inset-0 z-50 flex items-end justify-center bg-espresso/50 sm:items-center sm:p-4" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div role="dialog" aria-modal="true" aria-label={title} className={`pop flex max-h-[92vh] w-full flex-col rounded-t-3xl bg-foam shadow-2xl sm:rounded-3xl ${wide ? 'sm:max-w-3xl' : 'sm:max-w-lg'}`}>
        <div className="flex items-center justify-between border-b border-[#eadfcd] px-5 py-3">
          <h2 className="text-lg font-bold">{title}</h2>
          <button className="btn btn-ghost btn-sm" onClick={onClose} aria-label="Đóng">✕</button>
        </div>
        <div className="overflow-y-auto p-5">{children}</div>
      </div>
    </div>
  );
}

export function Spinner() { return <span className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" aria-hidden />; }

export function RecipeThumb({ category, image, className = '' }: { category: string; image?: string; className?: string }) {
  const g: Record<string, string> = {
    'Cà phê': 'from-[#8b6a50] to-[#3b2a20]', 'Trà sữa': 'from-[#d9b99b] to-[#a67c5b]', 'Matcha': 'from-[#a9c9a0] to-[#4a7552]',
    'Trà trái cây': 'from-[#f6c28b] to-[#e07b53]', 'Đá xay': 'from-[#c9b6d9] to-[#8a6fa8]', 'Chocolate': 'from-[#8a5a44] to-[#4a2c20]',
    'Sinh tố': 'from-[#f4b6c2] to-[#d6627b]', 'Nước ép': 'from-[#ffd37a] to-[#f09a2b]', 'Soda': 'from-[#a6d8e8] to-[#4b9cc4]',
  };
  const [broken, setBroken] = useState(false);
  useEffect(() => setBroken(false), [image]);
  if (image && !broken) {
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={image} alt="" className={`object-cover ${className}`} loading="lazy" onError={() => setBroken(true)} />;
  }
  return (
    <div className={`flex items-center justify-center bg-gradient-to-br ${g[category] ?? 'from-latte to-coffee'} ${className}`} aria-hidden>
      <span className="drop-shadow-md" style={{ fontSize: 'clamp(2rem, 6vw, 3.5rem)' }}>{catIcon(category)}</span>
    </div>
  );
}

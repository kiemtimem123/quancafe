'use client';
import { useMemo, useState } from 'react';
import type { Ingredient } from '@/lib/types';
import { norm } from '@/lib/format';
import { Modal } from './ui';

export function IngredientPicker({ open, onClose, title, ingredients, selected, onChange }: {
  open: boolean; onClose: () => void; title: string; ingredients: Ingredient[]; selected: number[]; onChange: (ids: number[]) => void;
}) {
  const [q, setQ] = useState('');
  const set = useMemo(() => new Set(selected), [selected]);
  const groups = useMemo(() => {
    const nq = norm(q);
    const m = new Map<string, Ingredient[]>();
    for (const i of ingredients) {
      if (i.category === 'Cơ bản' || i.category === 'Bao bì') continue; // luôn có sẵn
      if (nq && !norm(i.name).includes(nq)) continue;
      (m.get(i.category) ?? m.set(i.category, []).get(i.category)!).push(i);
    }
    return [...m];
  }, [ingredients, q]);
  const toggle = (id: number) => onChange(set.has(id) ? selected.filter((x) => x !== id) : [...selected, id]);
  return (
    <Modal open={open} onClose={onClose} title={title} wide>
      <input className="input mb-3" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Tìm nguyên liệu…" aria-label="Tìm nguyên liệu" />
      <div className="mb-3 flex flex-wrap gap-2">
        <button className="btn btn-ghost btn-sm" onClick={() => onChange(ingredients.filter((i) => i.stock_quantity > 0 && i.category !== 'Cơ bản' && i.category !== 'Bao bì').map((i) => i.id))}>Chọn theo tồn kho hiện có</button>
        <button className="btn btn-ghost btn-sm" onClick={() => onChange([])}>Bỏ chọn tất cả</button>
      </div>
      {groups.length === 0 && <p className="py-6 text-center text-mocha">Không có nguyên liệu phù hợp.</p>}
      {groups.map(([cat, list]) => (
        <section key={cat} className="mb-4">
          <h3 className="mb-2 text-xs font-bold uppercase tracking-wide text-mocha">{cat}</h3>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
            {list.map((i) => (
              <label key={i.id} className={`flex min-h-[48px] cursor-pointer items-center gap-2 rounded-xl border-2 px-3 py-2 text-sm font-medium transition ${set.has(i.id) ? 'border-leaf-dark bg-leaf-soft' : 'border-[#eadfcd] bg-white hover:border-latte'}`}>
                <input type="checkbox" className="h-5 w-5 accent-[#4a7552]" checked={set.has(i.id)} onChange={() => toggle(i.id)} />
                <span>{i.name}</span>
              </label>
            ))}
          </div>
        </section>
      ))}
      <div className="sticky bottom-0 -mx-5 -mb-5 border-t border-[#eadfcd] bg-foam p-4">
        <button className="btn btn-green btn-lg w-full" onClick={onClose}>Xong — đã chọn {selected.length} nguyên liệu</button>
      </div>
    </Modal>
  );
}

'use client';
import { useState } from 'react';
import { discardFailed, discardOp, flush, refreshSnapshot, retryFailed, useSync } from '@/lib/offline/engine';
import { Modal } from './ui';

const dt = (s: string) => new Date(s).toLocaleString('vi-VN', { timeZone: 'Asia/Ho_Chi_Minh', day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });

/** Nút trạng thái đồng bộ ở thanh trên: số thao tác chờ gửi, lỗi, và bảng chi tiết. */
export function SyncStatus() {
  const s = useSync();
  const [open, setOpen] = useState(false);
  const cls = !s.reachable ? 'bg-espresso text-white' : s.failed ? 'bg-danger-soft text-danger' : s.pending ? 'bg-warn-soft text-[#8a5a00]' : 'bg-leaf-soft text-leaf-dark';
  const text = !s.reachable ? `📴 Offline${s.pending ? ` · ${s.pending}` : ''}` : s.failed ? `⚠ ${s.failed} lỗi` : s.pending ? `🔄 ${s.pending}` : '✓';
  return (
    <>
      <button className={`shrink-0 rounded-full px-2.5 py-1.5 text-xs font-bold ${cls}`} onClick={() => setOpen(true)} aria-label="Trạng thái đồng bộ">{s.syncing ? '🔄' : text}</button>
      {open && (
        <Modal open title="Đồng bộ dữ liệu" onClose={() => setOpen(false)}>
          <div className="space-y-3 text-sm">
            <p>{!s.reachable ? '📴 Đang offline — mọi thao tác được lưu trên máy này và tự gửi lên khi có mạng.' : '🌐 Đã kết nối máy chủ.'}</p>
            {s.authExpired && <p className="rounded-xl bg-warn-soft p-2.5 font-semibold text-[#8a5a00]">Phiên đăng nhập đã hết hạn. Đăng nhập lại để gửi các thao tác đang chờ (dữ liệu trên máy vẫn được giữ).</p>}
            <p className="text-mocha">{s.hasSnapshot ? `Dữ liệu trên máy cập nhật lúc ${s.lastSync ? dt(s.lastSync) : '—'}.` : 'Máy chưa có dữ liệu offline — hãy mở app khi có mạng.'}</p>
            {s.ops.length === 0 ? <p className="py-3 text-center text-mocha">Không có thao tác nào chờ đồng bộ.</p> : (
              <ul className="divide-y divide-[#f3ebdd]">
                {s.ops.map((o) => (
                  <li key={o.seq} className="flex items-start justify-between gap-2 py-2">
                    <div className="min-w-0"><p className="font-semibold">{o.label}</p><p className="text-xs text-mocha">{dt(o.at)}</p>{o.error && <p className="text-xs font-semibold text-danger">Bị từ chối: {o.error}</p>}</div>
                    {o.error ? <button className="btn btn-ghost btn-sm" onClick={() => o.seq && discardOp(o.seq)}>Bỏ</button> : <span className="tag tag-neutral">chờ</span>}
                  </li>
                ))}
              </ul>
            )}
            <div className="flex flex-wrap gap-2">
              <button className="btn btn-primary" disabled={!s.reachable || s.syncing} onClick={() => flush()}>Đồng bộ ngay</button>
              {s.failed > 0 && <button className="btn btn-ghost" onClick={() => retryFailed()}>Thử lại thao tác lỗi</button>}
              {s.failed > 0 && <button className="btn btn-danger" onClick={() => { if (confirm('Bỏ các thao tác lỗi và nạp lại dữ liệu từ máy chủ?')) discardFailed(); }}>Bỏ thao tác lỗi</button>}
              <button className="btn btn-ghost" disabled={!s.reachable || s.pending > 0} onClick={() => refreshSnapshot(true)}>Làm mới dữ liệu offline</button>
            </div>
          </div>
        </Modal>
      )}
    </>
  );
}

'use client';
import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';

function beep() {
  try {
    const A = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const c = new A(); const o = c.createOscillator(); const g = c.createGain();
    o.connect(g); g.connect(c.destination); o.frequency.value = 880; g.gain.value = 0.15; o.start(); o.stop(c.currentTime + 0.25);
    setTimeout(() => { const o2 = c.createOscillator(); o2.connect(g); o2.frequency.value = 1175; o2.start(); o2.stop(c.currentTime + 0.25); }, 300);
  } catch { /* trình duyệt chặn âm thanh khi chưa tương tác */ }
}
/** Chuông báo có đơn khách đặt qua QR: hỏi máy chủ mỗi 10 giây, kêu khi có đơn mới. */
export function QrOrderBell() {
  const [n, setN] = useState(0);
  const last = useRef(0);
  useEffect(() => {
    let alive = true;
    const tick = async () => {
      try {
        const r = await fetch('/api/customer-orders/count', { cache: 'no-store' });
        if (!r.ok) return;
        const { pending } = (await r.json()) as { pending: number };
        if (!alive) return;
        if (pending > last.current) beep();
        last.current = pending; setN(pending);
      } catch { /* offline: bỏ qua */ }
    };
    tick(); const t = setInterval(tick, 10_000);
    return () => { alive = false; clearInterval(t); };
  }, []);
  if (!n) return null;
  return <Link href="/customer-orders" className="relative shrink-0 rounded-full bg-warn px-2.5 py-1.5 text-xs font-extrabold text-espresso" aria-label={`${n} đơn khách đặt chờ xác nhận`}>🔔 {n}</Link>;
}

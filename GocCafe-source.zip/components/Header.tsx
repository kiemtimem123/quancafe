'use client';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useState } from 'react';
import { RECIPE_CATEGORIES } from '@/lib/types';
import { ROLE_LABEL } from '@/lib/roles';
import { api } from '@/lib/client';
import { useAuth } from './Auth';
import { Modal, Spinner } from './ui';
import { useToast } from './Toast';
import { SyncStatus } from './SyncStatus';
import { InstallApp } from './InstallApp';
import { QrOrderBell } from './QrOrderBell';
import { Security2FA } from './Security2FA';

export function Header() {
  const path = usePathname();
  const router = useRouter();
  const { user, can, logout } = useAuth();
  const toast = useToast();
  const [q, setQ] = useState('');
  const [pw, setPw] = useState(false);
  const [sec, setSec] = useState(false);
  const [f, setF] = useState({ current: '', next: '', again: '' });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  const NAV = [
    { href: '/pos', label: 'Bán hàng', icon: '🧾' },
    { href: '/', label: 'Tìm món', icon: '🔎' },
    { href: '/recipes', label: 'Công thức', icon: '📖' },
    { href: '/ingredients', label: 'Nguyên liệu', icon: '🫘' },
    ...(can('view_dashboard') ? [{ href: '/dashboard', label: 'Quản lý', icon: '📊' }] : []),
  ];
  const DESKTOP = [...NAV.filter((n) => n.href !== '/'), { href: '/orders', label: 'Đơn hàng', icon: '📋' }, { href: '/assistant', label: 'Trợ lý AI', icon: '✨' }];
  const active = (h: string) => (h === '/' ? path === '/' : path.startsWith(h));
  const submit = (e: React.FormEvent) => { e.preventDefault(); router.push(q.trim() ? `/recipes?q=${encodeURIComponent(q.trim())}` : '/recipes'); };
  const changePw = async () => {
    setErr('');
    if (f.next.length < 8) return setErr('Mật khẩu mới tối thiểu 8 ký tự');
    if (f.next !== f.again) return setErr('Mật khẩu nhập lại không khớp');
    setBusy(true);
    try { await api('/api/auth/password', { method: 'POST', body: { current: f.current, next: f.next } }); toast.ok('Đã đổi mật khẩu'); setPw(false); setF({ current: '', next: '', again: '' }); }
    catch (e) { setErr(e instanceof Error ? e.message : 'Lỗi'); } finally { setBusy(false); }
  };
  const closeDetails = (e: React.MouseEvent<HTMLElement>) => { (e.currentTarget.closest('details') as HTMLDetailsElement).open = false; };

  return (
    <>
      <header className="no-print sticky top-0 z-40 border-b border-[#eadfcd] bg-foam/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-2.5">
          <Link href="/" className="flex shrink-0 items-center gap-2 font-extrabold text-coffee">
            <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-coffee text-xl text-white">☕</span>
            <span className="hidden text-lg leading-tight sm:block">Góc Cafe<small className="block text-[11px] font-medium text-mocha">Công thức & pha chế</small></span>
          </Link>
          <form onSubmit={submit} className="min-w-0 flex-1" role="search">
            <input className="input" value={q} onChange={(e) => setQ(e.target.value)} placeholder="🔍 Tìm món, nguyên liệu, danh mục…" aria-label="Tìm món" />
          </form>
          <nav className="hidden items-center gap-1 lg:flex" aria-label="Điều hướng chính">
            {DESKTOP.map((n) => (
              <Link key={n.href} href={n.href} className={`rounded-xl px-3 py-2 text-sm font-semibold ${active(n.href) ? 'bg-coffee text-white' : 'text-coffee hover:bg-cream'}`}>{n.label}</Link>
            ))}
            <details className="relative">
              <summary className="cursor-pointer list-none rounded-xl px-3 py-2 text-sm font-semibold text-coffee hover:bg-cream">Danh mục ▾</summary>
              <div className="card absolute right-0 mt-2 grid w-56 gap-1 p-2 shadow-xl">
                {RECIPE_CATEGORIES.map((c) => <Link key={c.name} href={`/recipes?cat=${encodeURIComponent(c.name)}`} className="rounded-lg px-3 py-2 text-sm hover:bg-cream" onClick={closeDetails}>{c.icon} {c.name}</Link>)}
              </div>
            </details>
          </nav>
          <QrOrderBell />
          <SyncStatus />
          <details className="relative shrink-0">
            <summary className="flex h-10 w-10 cursor-pointer list-none items-center justify-center rounded-full bg-leaf-soft font-bold text-leaf-dark" aria-label="Tài khoản">{user?.name?.[0]?.toUpperCase() ?? '?'}</summary>
            <div className="card absolute right-0 mt-2 w-64 p-2 shadow-xl">
              <div className="border-b border-[#eadfcd] px-3 py-2"><p className="font-bold">{user?.name}</p><p className="truncate text-xs text-mocha">{user?.email}</p><span className="tag tag-neutral mt-1">{user ? ROLE_LABEL[user.role] : ''}</span></div>
              <div className="mt-1 border-t border-[#eadfcd] pt-1"><p className="px-3 py-1 text-[11px] font-bold uppercase tracking-wide text-mocha">Công cụ</p>
                <Link href="/customer-orders" className="block rounded-lg px-3 py-2 text-sm hover:bg-cream" onClick={closeDetails}>📲 Đơn khách đặt qua QR</Link>
                {can('edit_ingredients') && <Link href="/table-qr" className="block rounded-lg px-3 py-2 text-sm hover:bg-cream" onClick={closeDetails}>🔳 In mã QR cho bàn</Link>}
                <Link href="/orders" className="block rounded-lg px-3 py-2 text-sm hover:bg-cream" onClick={closeDetails}>📋 Đơn hàng hôm nay</Link>
                <Link href="/assistant" className="block rounded-lg px-3 py-2 text-sm hover:bg-cream" onClick={closeDetails}>✨ Trợ lý AI</Link>
                <Link href="/availability" className="block rounded-lg px-3 py-2 text-sm hover:bg-cream" onClick={closeDetails}>📦 Tình trạng món (còn/hết)</Link>
                <Link href="/expiry" className="block rounded-lg px-3 py-2 text-sm hover:bg-cream" onClick={closeDetails}>⏰ Hạn sử dụng</Link>
                <Link href="/kitchen" className="block rounded-lg px-3 py-2 text-sm hover:bg-cream" onClick={closeDetails}>🍳 Màn hình bếp</Link>
                {can('edit_ingredients') && <Link href="/shopping" className="block rounded-lg px-3 py-2 text-sm hover:bg-cream" onClick={closeDetails}>🛒 Danh sách cần mua</Link>}
                {can('view_dashboard') && <Link href="/sales" className="block rounded-lg px-3 py-2 text-sm hover:bg-cream" onClick={closeDetails}>🧾 Bán hàng & lợi nhuận</Link>}
                {can('edit_ingredients') && <Link href="/purchases" className="block rounded-lg px-3 py-2 text-sm hover:bg-cream" onClick={closeDetails}>📑 Đặt hàng nhà cung cấp</Link>}
                {can('edit_ingredients') && <Link href="/options" className="block rounded-lg px-3 py-2 text-sm hover:bg-cream" onClick={closeDetails}>🧋 Topping & tùy chọn</Link>}
                {can('edit_ingredients') && <Link href="/promotions" className="block rounded-lg px-3 py-2 text-sm hover:bg-cream" onClick={closeDetails}>🎁 Khuyến mãi & voucher</Link>}
                {can('view_dashboard') && <Link href="/customers" className="block rounded-lg px-3 py-2 text-sm hover:bg-cream" onClick={closeDetails}>🤝 Khách thân thiết</Link>}
                {can('view_dashboard') && <Link href="/profit" className="block rounded-lg px-3 py-2 text-sm hover:bg-cream" onClick={closeDetails}>💰 Lợi nhuận & điểm hòa vốn</Link>}
                {can('view_dashboard') && <Link href="/waste" className="block rounded-lg px-3 py-2 text-sm hover:bg-cream" onClick={closeDetails}>🗑 Hao hụt & thất thoát</Link>}
                {can('view_dashboard') && <Link href="/forecast" className="block rounded-lg px-3 py-2 text-sm hover:bg-cream" onClick={closeDetails}>📈 Dự báo nhập hàng</Link>}
                {can('view_dashboard') && <Link href="/insights" className="block rounded-lg px-3 py-2 text-sm hover:bg-cream" onClick={closeDetails}>⏱ Giờ cao điểm & nhân viên</Link>}
                {can('view_audit') && <Link href="/audit" className="block rounded-lg px-3 py-2 text-sm hover:bg-cream" onClick={closeDetails}>📜 Nhật ký thao tác</Link>}</div>
              {can('manage_users') && <Link href="/backup" className="block rounded-lg px-3 py-2 text-sm hover:bg-cream" onClick={closeDetails}>💾 Sao lưu & khôi phục</Link>}
              {can('manage_users') && <Link href="/notify" className="block rounded-lg px-3 py-2 text-sm hover:bg-cream" onClick={closeDetails}>🔔 Thông báo & báo cáo tự động</Link>}
              <InstallApp />
              {can('manage_users') && <Link href="/users" className="mt-1 block rounded-lg px-3 py-2 text-sm hover:bg-cream" onClick={closeDetails}>👥 Quản lý người dùng</Link>}
              <button className="block w-full rounded-lg px-3 py-2 text-left text-sm hover:bg-cream" onClick={(e) => { closeDetails(e); setErr(''); setPw(true); }}>🔑 Đổi mật khẩu</button>
              <button className="block w-full rounded-lg px-3 py-2 text-left text-sm hover:bg-cream" onClick={(e) => { closeDetails(e); setSec(true); }}>🔐 Xác thực 2 bước</button>
              <button className="block w-full rounded-lg px-3 py-2 text-left text-sm text-danger hover:bg-danger-soft" onClick={logout}>⎋ Đăng xuất</button>
            </div>
          </details>
        </div>
      </header>
      <nav className={`no-print fixed inset-x-0 bottom-0 z-40 grid border-t border-[#eadfcd] bg-foam pb-[env(safe-area-inset-bottom)] lg:hidden ${NAV.length === 5 ? 'grid-cols-5' : 'grid-cols-4'}`} aria-label="Điều hướng">
        {NAV.map((n) => (
          <Link key={n.href} href={n.href} className={`flex min-h-[58px] flex-col items-center justify-center gap-0.5 text-[11px] font-semibold ${active(n.href) ? 'text-coffee' : 'text-mocha/70'}`}>
            <span className={`flex h-7 w-12 items-center justify-center rounded-full text-lg ${active(n.href) ? 'bg-leaf-soft' : ''}`}>{n.icon}</span>{n.label}
          </Link>
        ))}
      </nav>
      <Security2FA open={sec} onClose={() => setSec(false)} />
      <Modal open={pw} onClose={() => setPw(false)} title="Đổi mật khẩu">
        <div className="space-y-3">
          {err && <p className="rounded-xl bg-danger-soft p-3 text-sm text-danger" role="alert">{err}</p>}
          <div><label className="label" htmlFor="p0">Mật khẩu hiện tại</label><input id="p0" type="password" autoComplete="current-password" className="input" value={f.current} onChange={(e) => setF({ ...f, current: e.target.value })} /></div>
          <div><label className="label" htmlFor="p1">Mật khẩu mới (tối thiểu 8 ký tự)</label><input id="p1" type="password" autoComplete="new-password" className="input" value={f.next} onChange={(e) => setF({ ...f, next: e.target.value })} /></div>
          <div><label className="label" htmlFor="p2">Nhập lại mật khẩu mới</label><input id="p2" type="password" autoComplete="new-password" className="input" value={f.again} onChange={(e) => setF({ ...f, again: e.target.value })} /></div>
          <button className="btn btn-green btn-lg w-full" onClick={changePw} disabled={busy}>{busy ? <Spinner /> : 'Đổi mật khẩu'}</button>
          <p className="text-xs text-mocha">Các thiết bị khác đang đăng nhập sẽ bị đăng xuất.</p>
        </div>
      </Modal>
    </>
  );
}

'use client';
import { useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { api, useApi } from '@/lib/client';
import { DIFFICULTIES, RECIPE_CATEGORIES, SIZES, type Ingredient, type Recipe, type Size } from '@/lib/types';
import { toBase } from '@/lib/units';
import { pct, vnd } from '@/lib/format';
import { ErrorBox, Loading, Spinner } from './ui';
import { useToast } from './Toast';
import { ImageUploader } from './ImageUploader';

interface Line { key: number; ingredient_id: number | ''; quantity: string; unit: string }
interface SizeState { enabled: boolean; price: string; lines: Line[] }
let k = 1;
const emptySizes = (): Record<Size, SizeState> => ({ S: { enabled: false, price: '', lines: [] }, M: { enabled: true, price: '', lines: [] }, L: { enabled: false, price: '', lines: [] } });
const unitsFor = (base?: string) => (base === 'g' ? ['g', 'kg'] : base === 'ml' ? ['ml', 'lít'] : base === 'cái' ? ['cái'] : ['g', 'ml', 'cái']);

export function RecipeForm({ recipe }: { recipe?: Recipe }) {
  const router = useRouter();
  const toast = useToast();
  const ingQ = useApi<{ ingredients: Ingredient[] }>('/api/ingredients');
  const setQ = useApi<{ waste_percent: number }>('/api/settings');
  const ings = useMemo(() => ingQ.data?.ingredients ?? [], [ingQ.data]);
  const byId = useMemo(() => new Map(ings.map((i) => [i.id, i])), [ings]);

  const [f, setF] = useState(() => ({
    name: recipe?.name ?? '', category: recipe?.category ?? RECIPE_CATEGORIES[0].name, description: recipe?.description ?? '', image: recipe?.image ?? '',
    difficulty: recipe?.difficulty ?? 'Dễ', time: String(recipe?.preparation_time ?? 3), steps: recipe?.instructions.length ? [...recipe.instructions] : [''],
  }));
  const [sizes, setSizes] = useState<Record<Size, SizeState>>(() => {
    const s = emptySizes();
    if (recipe) for (const rs of recipe.sizes) s[rs.name] = { enabled: true, price: String(rs.selling_price), lines: rs.lines.map((l) => ({ key: k++, ingredient_id: l.ingredient_id, quantity: String(l.quantity), unit: l.unit })) };
    return s;
  });
  const [active, setActive] = useState<Size>('M');
  const [factor, setFactor] = useState<Record<string, string>>({ S: '0.75', L: '1.3' });
  const [saving, setSaving] = useState(false);
  const [errs, setErrs] = useState<string[]>([]);

  const waste = (setQ.data?.waste_percent ?? 5) / 100;
  const costOf = (s: SizeState) => {
    const raw = s.lines.reduce((a, l) => {
      const ing = l.ingredient_id === '' ? undefined : byId.get(l.ingredient_id);
      const b = toBase(Number(l.quantity) || 0, l.unit);
      return ing && b && b.base === ing.base_unit ? a + b.qty * ing.unit_cost : a;
    }, 0);
    return raw * (1 + waste);
  };

  const patchSize = (n: Size, p: Partial<SizeState>) => setSizes((s) => ({ ...s, [n]: { ...s[n], ...p } }));
  const patchLine = (n: Size, key: number, p: Partial<Line>) => setSizes((s) => ({ ...s, [n]: { ...s[n], lines: s[n].lines.map((l) => (l.key === key ? { ...l, ...p } : l)) } }));
  const pickIng = (n: Size, key: number, id: number | '') => { const ing = id === '' ? undefined : byId.get(id); patchLine(n, key, { ingredient_id: id, unit: ing ? ing.base_unit : 'g' }); };
  const addLine = (n: Size) => patchSize(n, { lines: [...sizes[n].lines, { key: k++, ingredient_id: '', quantity: '', unit: 'g' }] });

  const scaleFrom = (target: Size) => {
    const m = sizes.M; const fc = Number(factor[target]);
    if (!m.lines.length) return toast.err('Hãy nhập công thức size M trước');
    if (!(fc > 0)) return toast.err('Hệ số phải lớn hơn 0');
    const lines = m.lines.map((l) => {
      const ing = l.ingredient_id === '' ? undefined : byId.get(l.ingredient_id);
      const q = Number(l.quantity) || 0;
      const fixed = ing && (ing.category === 'Bao bì' || ing.name === 'Xí muội');
      let nq = fixed ? q : q * fc;
      nq = ing?.base_unit === 'cái' || l.unit === 'cái' ? Math.max(1, Math.round(nq)) : nq >= 20 ? Math.round(nq / 5) * 5 : Math.round(nq * 2) / 2;
      return { ...l, key: k++, quantity: String(nq) };
    });
    const price = Math.round(((Number(m.price) || 0) * (target === 'S' ? 0.85 : 1.2)) / 1000) * 1000;
    patchSize(target, { enabled: true, lines, price: String(price || '') });
    setActive(target);
    toast.ok(`Đã tạo size ${target} từ size M (× ${fc})`);
  };

  const validate = (): string[] => {
    const e: string[] = [];
    if (!f.name.trim()) e.push('Nhập tên món');
    if (!(Number(f.time) >= 1)) e.push('Thời gian pha tối thiểu 1 phút');
    const on = SIZES.filter((n) => sizes[n].enabled);
    if (!on.length) e.push('Bật ít nhất 1 size');
    for (const n of on) {
      const s = sizes[n];
      if (!(Number(s.price) >= 0) || s.price === '') e.push(`Size ${n}: nhập giá bán`);
      if (!s.lines.length) e.push(`Size ${n}: thêm ít nhất 1 nguyên liệu`);
      const seen = new Set<number>();
      for (const l of s.lines) {
        if (l.ingredient_id === '') { e.push(`Size ${n}: có dòng chưa chọn nguyên liệu`); continue; }
        if (!(Number(l.quantity) > 0)) e.push(`Size ${n}: "${byId.get(l.ingredient_id)?.name}" chưa có định lượng`);
        if (seen.has(l.ingredient_id)) e.push(`Size ${n}: "${byId.get(l.ingredient_id)?.name}" bị lặp`);
        seen.add(l.ingredient_id);
      }
    }
    return [...new Set(e)];
  };

  const save = async () => {
    const e = validate(); setErrs(e);
    if (e.length) { toast.err(e[0]); return; }
    setSaving(true);
    try {
      const body = {
        name: f.name.trim(), category: f.category, description: f.description, image: f.image, difficulty: f.difficulty, preparation_time: Number(f.time),
        instructions: f.steps.map((s) => s.trim()).filter(Boolean),
        sizes: SIZES.filter((n) => sizes[n].enabled).map((n) => ({ name: n, selling_price: Number(sizes[n].price), lines: sizes[n].lines.map((l) => ({ ingredient_id: l.ingredient_id as number, quantity: Number(l.quantity), unit: l.unit })) })),
      };
      const res = recipe
        ? await api<{ recipe: Recipe }>(`/api/recipes/${recipe.id}`, { method: 'PUT', body })
        : await api<{ recipe: Recipe }>('/api/recipes', { method: 'POST', body });
      toast.ok(recipe ? 'Đã lưu công thức' : 'Đã thêm món mới');
      router.push(`/recipes/${res.recipe.id}`);
    } catch (e2) { toast.err(e2 instanceof Error ? e2.message : 'Không lưu được'); setSaving(false); }
  };

  if (ingQ.loading) return <Loading rows={3} />;
  if (ingQ.error) return <ErrorBox message={ingQ.error} onRetry={ingQ.reload} />;
  const cur = sizes[active];
  const cost = costOf(cur); const price = Number(cur.price) || 0;

  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-extrabold">{recipe ? `CHỈNH SỬA: ${recipe.name}` : 'THÊM MÓN MỚI'}</h1>
      {errs.length > 0 && <div className="rounded-2xl bg-danger-soft p-4 text-sm text-danger" role="alert"><b>Cần sửa:</b><ul className="list-disc pl-5">{errs.map((x) => <li key={x}>{x}</li>)}</ul></div>}

      <section className="card grid gap-4 p-5 sm:grid-cols-2">
        <div className="sm:col-span-2"><label className="label" htmlFor="n">Tên món *</label><input id="n" className="input" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} placeholder="VD: Cà phê sữa đá" /></div>
        <div><label className="label" htmlFor="c">Danh mục</label><select id="c" className="input" value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })}>{RECIPE_CATEGORIES.map((c) => <option key={c.name}>{c.name}</option>)}</select></div>
        <div className="grid grid-cols-2 gap-3"><div><label className="label" htmlFor="d">Độ khó</label><select id="d" className="input" value={f.difficulty} onChange={(e) => setF({ ...f, difficulty: e.target.value })}>{DIFFICULTIES.map((d) => <option key={d}>{d}</option>)}</select></div>
          <div><label className="label" htmlFor="t">Thời gian (phút)</label><input id="t" type="number" min={1} className="input" value={f.time} onChange={(e) => setF({ ...f, time: e.target.value })} /></div></div>
        <div className="sm:col-span-2"><label className="label" htmlFor="ds">Mô tả</label><input id="ds" className="input" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></div>
        <ImageUploader value={f.image} category={f.category} onChange={(image) => setF((x) => ({ ...x, image }))} />
      </section>

      <section className="card p-5">
        <div className="mb-3 flex flex-wrap items-center gap-2" role="tablist">
          {SIZES.map((n) => (
            <div key={n} className={`flex items-center gap-1 rounded-2xl border-2 px-2 py-1 ${active === n ? 'border-coffee bg-cream' : 'border-[#eadfcd]'}`}>
              <input type="checkbox" className="h-5 w-5 accent-[#4a7552]" checked={sizes[n].enabled} onChange={(e) => { patchSize(n, { enabled: e.target.checked }); if (e.target.checked) setActive(n); }} aria-label={`Bật size ${n}`} />
              <button className="px-2 py-1 font-bold" onClick={() => setActive(n)} role="tab" aria-selected={active === n}>Size {n}</button>
            </div>
          ))}
        </div>
        <div className="mb-4 flex flex-wrap items-end gap-3 rounded-2xl bg-cream p-3 text-sm">
          <span className="font-semibold">Nhân công thức từ size M:</span>
          {(['S', 'L'] as const).map((t) => (
            <span key={t} className="flex items-center gap-1">→ {t} ×<input className="input !min-h-9 !w-20 !py-1" inputMode="decimal" value={factor[t]} onChange={(e) => setFactor({ ...factor, [t]: e.target.value })} aria-label={`Hệ số size ${t}`} /><button className="btn btn-ghost btn-sm" onClick={() => scaleFrom(t)}>Tạo size {t}</button></span>
          ))}
        </div>

        {!cur.enabled ? <p className="rounded-xl bg-cream p-4 text-center text-mocha">Size {active} đang tắt. Tích ô bên trên để bật.</p> : (
          <div className="space-y-3">
            <div className="max-w-xs"><label className="label" htmlFor="p">Giá bán size {active} (đ)</label><input id="p" type="number" min={0} step={500} className="input" value={cur.price} onChange={(e) => patchSize(active, { price: e.target.value })} /></div>
            <div className="space-y-2">
              {cur.lines.length === 0 && <p className="text-sm text-mocha">Chưa có nguyên liệu. Bấm “+ Thêm nguyên liệu”.</p>}
              {cur.lines.map((l) => {
                const ing = l.ingredient_id === '' ? undefined : byId.get(l.ingredient_id);
                const b = toBase(Number(l.quantity) || 0, l.unit);
                const lc = ing && b ? b.qty * ing.unit_cost : 0;
                return (
                  <div key={l.key} className="grid grid-cols-12 items-center gap-2 rounded-xl border border-[#eadfcd] p-2">
                    <select className="input col-span-12 sm:col-span-5" value={l.ingredient_id} onChange={(e) => pickIng(active, l.key, e.target.value ? Number(e.target.value) : '')} aria-label="Nguyên liệu">
                      <option value="">— Chọn nguyên liệu —</option>
                      {[...new Set(ings.map((i) => i.category))].map((c) => <optgroup key={c} label={c}>{ings.filter((i) => i.category === c).map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}</optgroup>)}
                    </select>
                    <input className="input col-span-4 sm:col-span-2" inputMode="decimal" placeholder="Lượng" value={l.quantity} onChange={(e) => patchLine(active, l.key, { quantity: e.target.value })} aria-label="Định lượng" />
                    <select className="input col-span-3 sm:col-span-2" value={l.unit} onChange={(e) => patchLine(active, l.key, { unit: e.target.value })} aria-label="Đơn vị">{unitsFor(ing?.base_unit).map((u) => <option key={u}>{u}</option>)}</select>
                    <span className="col-span-3 text-right text-sm text-mocha sm:col-span-2">{vnd(lc)}</span>
                    <button className="btn btn-danger btn-sm col-span-2 sm:col-span-1" onClick={() => patchSize(active, { lines: cur.lines.filter((x) => x.key !== l.key) })} aria-label="Xóa dòng">✕</button>
                  </div>
                );
              })}
            </div>
            <button className="btn btn-ghost" onClick={() => addLine(active)}>+ Thêm nguyên liệu</button>
            <div className="grid grid-cols-3 gap-2 rounded-2xl bg-leaf-soft p-3 text-center text-sm text-leaf-dark">
              <div><b className="block text-lg">{vnd(cost)}</b>Giá vốn (gồm hao phí {Math.round(waste * 100)}%)</div>
              <div><b className="block text-lg">{vnd(price - cost)}</b>Lợi nhuận</div>
              <div><b className="block text-lg">{price > 0 ? pct(((price - cost) / price) * 100) : '—'}</b>Tỷ suất</div>
            </div>
          </div>
        )}
      </section>

      <section className="card p-5">
        <h2 className="mb-3 text-lg font-bold">Cách pha</h2>
        <div className="space-y-2">
          {f.steps.map((s, i) => (
            <div key={i} className="flex items-center gap-2">
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-leaf-dark text-sm font-bold text-white">{i + 1}</span>
              <input className="input" value={s} onChange={(e) => setF({ ...f, steps: f.steps.map((x, j) => (j === i ? e.target.value : x)) })} placeholder={`Bước ${i + 1}`} aria-label={`Bước ${i + 1}`} />
              <button className="btn btn-ghost btn-sm" disabled={i === 0} onClick={() => { const a = [...f.steps]; [a[i - 1], a[i]] = [a[i], a[i - 1]]; setF({ ...f, steps: a }); }} aria-label="Lên">↑</button>
              <button className="btn btn-danger btn-sm" onClick={() => setF({ ...f, steps: f.steps.length > 1 ? f.steps.filter((_, j) => j !== i) : [''] })} aria-label="Xóa bước">✕</button>
            </div>
          ))}
        </div>
        <button className="btn btn-ghost mt-3" onClick={() => setF({ ...f, steps: [...f.steps, ''] })}>+ Thêm bước</button>
      </section>

      <div className="sticky bottom-[68px] z-30 flex gap-2 rounded-2xl bg-foam/95 p-2 shadow-lg backdrop-blur lg:bottom-3">
        <button className="btn btn-green btn-lg flex-1" onClick={save} disabled={saving}>{saving ? <Spinner /> : '💾'} {recipe ? 'Lưu thay đổi' : 'Lưu món mới'}</button>
        <button className="btn btn-ghost btn-lg" onClick={() => router.back()} disabled={saving}>Hủy</button>
      </div>
    </div>
  );
}

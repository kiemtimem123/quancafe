/* Service worker offline-first.
 * - Tệp tĩnh (/_next/static, icon, ảnh món): cache-first
 * - Trang: ưu tiên mạng, mất mạng dùng bản đã lưu (trang động /recipes/N, /receipt/N dùng bản "khung" cùng loại)
 * - API: không cache ở đây — dữ liệu offline do app giữ trong IndexedDB; mất mạng trả 503 + x-offline để app chuyển sang dữ liệu cục bộ */
const VERSION = 'v2';
const STATIC = `static-${VERSION}`;
const RUNTIME = `runtime-${VERSION}`;

self.addEventListener('install', (e) => { e.waitUntil(caches.open(RUNTIME).then((c) => c.addAll(['/offline.html'])).then(() => self.skipWaiting())); });
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => ![STATIC, RUNTIME].includes(k)).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('message', (e) => { if (e.data === 'clear') e.waitUntil(caches.keys().then((ks) => Promise.all(ks.map((k) => caches.delete(k))))); });

const SHELLS = [/^\/recipes\/[^/]+\/edit$/, /^\/recipes\/[^/]+$/, /^\/receipt\/[^/]+$/];
const cacheFirst = (name, req) => caches.open(name).then(async (c) => { const hit = await c.match(req); if (hit) return hit; const res = await fetch(req); if (res.ok) c.put(req, res.clone()); return res; });

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;
  const p = url.pathname;
  if (p.startsWith('/_next/static/') || p.startsWith('/icons/')) { e.respondWith(cacheFirst(STATIC, req)); return; }
  if (p.startsWith('/api/images/') && p !== '/api/images/') { e.respondWith(cacheFirst(RUNTIME, req).catch(() => Response.error())); return; }
  if (p.startsWith('/api/')) {
    e.respondWith(fetch(req).catch(() => new Response(JSON.stringify({ error: 'Đang offline' }), { status: 503, headers: { 'content-type': 'application/json', 'x-offline': '1' } })));
    return;
  }
  if (req.mode !== 'navigate' && !((req.headers.get('accept') || '').includes('text/html') && !req.headers.get('rsc'))) return;
  e.respondWith((async () => {
    const cache = await caches.open(RUNTIME);
    try {
      const res = await fetch(req);
      if (res.ok && !res.redirected) cache.put(new Request(p), res.clone());
      return res;
    } catch {
      const hit = await cache.match(new Request(p));
      if (hit) return hit;
      const shell = SHELLS.find((r) => r.test(p));
      if (shell) { for (const k of await cache.keys()) { const kp = new URL(k.url).pathname; if (shell.test(kp) && SHELLS.findIndex((r) => r.test(kp)) === SHELLS.indexOf(shell)) return cache.match(k); } }
      return (await cache.match('/offline.html')) || Response.error();
    }
  })());
});

'use client';
import { useState } from 'react';
import { api, useApi } from '@/lib/client';
import { vnd } from '@/lib/format';
import { Empty, ErrorBox, Loading, Spinner } from '@/components/ui';
import { useToast } from '@/components/Toast';
import { printReceipt } from '@/lib/print-client';
import type { CustomerOrder } from '@/lib/customer-orders';
import type { Order } from '@/lib/orders';

const hm = (s: string) => new Date(s.replace(' ', 'T') + 'Z').toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Ho_Chi_Minh' });
export default function CustomerOrdersPage() {
  const toast = useToast();
  const { data, error, loading, reload } = useApi<{ pending: CustomerOrder[]; recent: CustomerOrder[] }>('/api/customer-orders?recent=1');
  const [busy, setBusy] = useState<number | null>(null);
  const [pay, setPay] = useState<Record<number, 'cash' | 'transfer'>>({});
  const [shortMsg, setShortMsg] = useState<Record<number, string>>({});
  const act = async (o: CustomerOrder, action: 'accept' | 'reject', force = false) => {
    let reason: string | undefined;
    if (action === 'reject') { reason = prompt('Lý do từ chối (khách sẽ thấy):', 'Món đã hết') ?? undefined; if (reason === undefined) return; }
    setBusy(o.id);
    try {
      const r = await api<{ status: string; order?: Order }>(`/api/customer-orders/${o.id}`, { method: 'POST', body: { action, payment: pay[o.id] ?? o.pay_pref, reason, force: force || undefined } });
      toast.ok(action === 'accept' ? `Đã nhận đơn ${o.code}` : 'Đã từ chối đơn');
      setShortMsg((m) => { const x = { ...m }; delete x[o.id]; return x; });
      if (action === 'accept' && r.order) printReceipt(r.order.id, 'kitchen');
      reload();
    } catch (e) {
      const er = e as Error & { status?: number };
      if (er.status === 409) setShortMsg((m) => ({ ...m, [o.id]: er.message })); else toast.err(er.message);
    } finally { setBusy(null); }
  };
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2"><div><h1 className="text-2xl font-extrabold">ĐƠN KHÁCH ĐẶT QUA QR</h1><p className="text-sm text-mocha">Khách quét mã trên bàn → đơn hiện ở đây. Bấm “Nhận đơn” để trừ kho, in phiếu pha và tính doanh thu.</p></div><button className="btn btn-ghost" onClick={reload}>↻ Làm mới</button></div>
      {error && <ErrorBox message={error} onRetry={reload} />}
      {loading && !data && <Loading rows={3} />}
      {data && data.pending.length === 0 && <Empty icon="📲" title="Chưa có đơn khách đặt" hint="Đơn mới sẽ tự hiện ở đây và có chấm đỏ trên thanh trên." />}
      {data?.pending.map((o) => (
        <div key={o.id} className="card space-y-3 border-2 border-warn p-4">
          <div className="flex flex-wrap items-center justify-between gap-2"><p className="text-lg font-extrabold">{o.code} · {o.table_name}</p><p className="text-sm text-mocha">{hm(o.created_at)}{o.customer_name && ` · ${o.customer_name}`}{o.customer_phone && ` · ${o.customer_phone}`}</p></div>
          <ul className="space-y-1 text-sm">{o.items.map((i, k) => <li key={k} className="flex justify-between"><span>{i.quantity} × {i.name} ({i.size}){i.options.length > 0 && <span className="block text-xs font-semibold text-leaf-dark">{i.options.map((x) => `+ ${x.name}${x.qty > 1 ? ` ×${x.qty}` : ''}`).join(', ')}</span>}{i.note && <em className="block text-xs text-mocha">• {i.note}</em>}</span><span>{vnd(i.unit_price * i.quantity)}</span></li>)}</ul>
          {o.note && <p className="rounded-lg bg-cream p-2 text-sm">Ghi chú: {o.note}</p>}
          <div className="flex flex-wrap items-center justify-between gap-2"><b className="text-xl">{vnd(o.total)}</b>
            <div className="flex gap-1.5">{([['cash', '💵 Tiền mặt'], ['transfer', '🏦 Chuyển khoản']] as const).map(([k, l]) => <button key={k} className="chip" aria-pressed={(pay[o.id] ?? o.pay_pref) === k} onClick={() => setPay((p) => ({ ...p, [o.id]: k }))}>{l}</button>)}</div></div>
          {shortMsg[o.id] && <div className="space-y-2 rounded-xl bg-danger-soft p-3 text-sm"><p className="font-bold text-danger">🚫 {shortMsg[o.id]}</p><button className="btn btn-danger btn-sm" onClick={() => confirm('Vẫn nhận đơn và trừ kho về 0?') && act(o, 'accept', true)}>Vẫn nhận (bỏ qua kiểm tra kho)</button></div>}
          <div className="flex gap-2"><button className="btn btn-green btn-lg flex-1" disabled={busy === o.id} onClick={() => act(o, 'accept')}>{busy === o.id ? <Spinner /> : '✔'} Nhận đơn</button><button className="btn btn-danger" disabled={busy === o.id} onClick={() => act(o, 'reject')}>Từ chối</button></div>
        </div>
      ))}
      {data && data.recent.length > 0 && <div className="card divide-y divide-[#f3ebdd]"><p className="p-3 font-bold">Đã xử lý hôm nay</p>{data.recent.map((o) => (
        <div key={o.id} className="flex items-center justify-between gap-2 p-3 text-sm"><div><p className="font-semibold">{o.code} · {o.table_name} · {vnd(o.total)}</p><p className="text-xs text-mocha">{o.status === 'accepted' ? `Đã nhận → hóa đơn #${o.order_code}` : `Từ chối${o.reject_reason ? `: ${o.reject_reason}` : ''}`} · {o.decided_by}</p></div>
          <span className={`tag ${o.status === 'accepted' ? 'tag-ok' : 'tag-neutral'}`}>{o.status === 'accepted' ? 'Đã nhận' : 'Từ chối'}</span></div>))}</div>}
    </div>
  );
}

'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useApi } from '@/lib/client';
import { Empty, ErrorBox, Loading, RecipeThumb } from '@/components/ui';
import { AlternativesBox, type AvailItem } from '@/components/Availability';
import { useAuth } from '@/components/Auth';

type Tab = 'bad' | 'out' | 'low' | 'ok';
export default function AvailabilityPage() {
  const { can } = useAuth();
  const { data, error, loading, reload } = useApi<{ items: AvailItem[]; counts: { out: number; low: number; ok: number } }>('/api/availability');
  const [tab, setTab] = useState<Tab>('bad');
  const items = (data?.items ?? []).filter((i) => (tab === 'bad' ? i.availability.status !== 'ok' : i.availability.status === tab));
  const c = data?.counts;
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div><h1 className="text-2xl font-extrabold">TÌNH TRẠNG MÓN</h1><p className="text-sm text-mocha">Tính theo tồn kho hiện tại (đã tính nguyên liệu thay thế và bán thành phẩm có thể làm mẻ).</p></div>
        <button className="btn btn-ghost" onClick={reload}>↻ Làm mới</button>
      </div>
      {c && (
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="rounded-2xl bg-danger-soft p-3"><p className="text-2xl font-extrabold text-danger">{c.out}</p><p className="text-xs">Hết hàng</p></div>
          <div className="rounded-2xl bg-warn-soft p-3"><p className="text-2xl font-extrabold text-[#8a5a00]">{c.low}</p><p className="text-xs">Sắp hết</p></div>
          <div className="rounded-2xl bg-leaf-soft p-3"><p className="text-2xl font-extrabold text-leaf-dark">{c.ok}</p><p className="text-xs">Còn hàng</p></div>
        </div>
      )}
      <div className="flex flex-wrap gap-2" role="group" aria-label="Lọc">
        {([['bad', 'Cần chú ý'], ['out', 'Hết hàng'], ['low', 'Sắp hết'], ['ok', 'Còn hàng']] as [Tab, string][]).map(([k, l]) => <button key={k} className="chip" aria-pressed={tab === k} onClick={() => setTab(k)}>{l}</button>)}
      </div>
      {error && <ErrorBox message={error} onRetry={reload} />}
      {loading && !data && <Loading rows={4} />}
      {data && items.length === 0 && <Empty icon="✅" title={tab === 'ok' ? 'Chưa có món nào' : 'Không có món nào hết hoặc sắp hết'} hint="Tồn kho đang đủ cho tất cả các món." />}
      <div className="space-y-3">
        {items.map((i) => (
          <article key={i.id} className="card p-3">
            <div className="flex items-center gap-3">
              <RecipeThumb category={i.category} image={i.image} className="h-14 w-14 shrink-0 rounded-xl" />
              <div className="min-w-0 flex-1"><Link href={`/recipes/${i.id}`} className="block truncate font-bold hover:underline">{i.name}</Link>
                <p className="text-xs text-mocha">{i.category}{i.availability.cups !== null && <> · còn ~{i.availability.cups} ly</>}{i.availability.substitutes.length > 0 && <> · đang dùng thay thế: {i.availability.substitutes.join(', ')}</>}</p></div>
              {i.availability.status === 'ok' && <span className="tag tag-ok">Còn hàng</span>}
            </div>
            {i.availability.status !== 'ok' && <div className="mt-3"><AlternativesBox item={i} /></div>}
          </article>
        ))}
      </div>
      {can('edit_ingredients') && <p className="text-sm"><Link href="/shopping" className="font-semibold underline">🛒 Xem danh sách cần mua →</Link></p>}
    </div>
  );
}

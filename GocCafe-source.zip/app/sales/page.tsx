'use client';
import { useMemo, useState } from 'react';
import { api, useApi } from '@/lib/client';
import type { Recipe } from '@/lib/types';
import { num, pct, vnd } from '@/lib/format';
import { Empty, ErrorBox, Loading, Modal, Spinner } from '@/components/ui';
import { useAuth, Forbidden } from '@/components/Auth';
import { useToast } from '@/components/Toast';
import { ImportSales } from '@/components/ImportSales';

interface Agg { key: string; qty: number; revenue: number; cost: number; profit: number; margin: number }
interface Rep {
  from: string; to: string; has_data: boolean;
  total: { qty: number; revenue: number; cost: number; profit: number; margin: number };
  by_recipe: Agg[]; by_category: Agg[]; by_day: Agg[];
  menu: { name: string; qty: number; unit_profit: number; class: 'star' | 'plowhorse' | 'puzzle' | 'dog' }[];
  recent: { id: number; recipe_name: string; size: string; quantity: number; revenue: number; sold_on: string; source: string }[];
}
const ymd = (d: Date) => d.toISOString().slice(0, 10);
const CLASS: Record<string, [string, string, string]> = {
  star: ['⭐ Ngôi sao', 'Bán chạy & lãi cao — giữ vị trí nổi bật trên menu', 'tag-ok'],
  plowhorse: ['🐴 Bán chạy, lãi thấp', 'Cân nhắc tăng giá hoặc giảm định lượng/đổi nguyên liệu', 'tag-warn'],
  puzzle: ['💎 Lãi cao, ít bán', 'Đẩy mạnh: gợi ý khi order, đặt lên đầu menu', 'tag-neutral'],
  dog: ['🐕 Ít bán, lãi thấp', 'Cân nhắc bỏ khỏi menu hoặc làm lại công thức', 'tag-miss'],
};

export default function Sales() {
  const { can } = useAuth();
  const toast = useToast();
  const [days, setDays] = useState(30);
  const range = useMemo(() => ({ to: ymd(new Date()), from: ymd(new Date(Date.now() - (days - 1) * 864e5)) }), [days]);
  const { data, error, loading, reload } = useApi<Rep>(can('view_dashboard') ? `/api/sales?from=${range.from}&to=${range.to}` : null);
  const recipes = useApi<{ recipes: Recipe[] }>(can('view_dashboard') ? '/api/recipes' : null);
  const [importing, setImporting] = useState(false);
  const [adding, setAdding] = useState(false);
  const [f, setF] = useState({ recipe_id: '', size: 'M', quantity: '1', sold_on: ymd(new Date()) });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  if (!can('view_dashboard')) return <Forbidden />;

  const add = async () => {
    if (!f.recipe_id) return setErr('Chọn món');
    setBusy(true); setErr('');
    try { await api('/api/sales', { method: 'POST', body: { recipe_id: Number(f.recipe_id), size: f.size, quantity: Number(f.quantity), sold_on: f.sold_on } }); toast.ok('Đã ghi nhận bán hàng'); setAdding(false); reload(); }
    catch (e) { setErr(e instanceof Error ? e.message : 'Lỗi'); } finally { setBusy(false); }
  };
  const del = async (id: number) => { try { await api(`/api/sales?id=${id}`, { method: 'DELETE' }); toast.ok('Đã xóa'); reload(); } catch (e) { toast.err(e instanceof Error ? e.message : 'Lỗi'); } };
  const maxDay = Math.max(1, ...(data?.by_day ?? []).map((d) => d.revenue));
  const maxCat = Math.max(1, ...(data?.by_category ?? []).map((d) => d.revenue));
  const selected = recipes.data?.recipes.find((r) => String(r.id) === f.recipe_id);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div><h1 className="text-2xl font-extrabold">BÁN HÀNG & LỢI NHUẬN</h1><p className="text-sm text-mocha">Lợi nhuận tính theo giá vốn tại thời điểm ghi nhận.</p></div>
        <div className="flex flex-wrap gap-2"><button className="btn btn-ghost" onClick={() => setImporting(true)}>⬆ Nhập từ Excel</button><button className="btn btn-green btn-lg" onClick={() => { setErr(''); setAdding(true); }}>+ Ghi bán hàng</button></div>
      </div>
      <div className="flex flex-wrap gap-2" role="group" aria-label="Khoảng thời gian">{[7, 30, 90].map((d) => <button key={d} className="chip" aria-pressed={days === d} onClick={() => setDays(d)}>{d} ngày qua</button>)}</div>
      {error && <ErrorBox message={error} onRetry={reload} />}
      {loading && !data && <Loading rows={3} />}
      {data && !data.has_data && <Empty icon="🧾" title="Chưa có số liệu bán hàng" hint="Nhập từ Excel (xuất từ phần mềm bán hàng) hoặc ghi tay từng món." />}
      {data && data.has_data && (<>
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          {[['Doanh thu', vnd(data.total.revenue), ''], ['Giá vốn', vnd(data.total.cost), ''], ['Lợi nhuận gộp', vnd(data.total.profit), 'bg-leaf-soft text-leaf-dark'], ['Tỷ suất · Số ly', `${pct(data.total.margin)} · ${num(data.total.qty, 0)}`, '']].map(([l, v, c]) => (
            <div key={l} className={`card p-4 ${c}`}><p className="text-xs font-semibold uppercase tracking-wide opacity-70">{l}</p><p className="mt-1 text-xl font-extrabold">{v}</p></div>))}
        </div>

        <section className="card p-4"><h2 className="mb-3 font-bold">Doanh thu & lợi nhuận theo ngày</h2>
          {data.by_day.length === 0 ? <p className="text-sm text-mocha">Không có dữ liệu trong khoảng này.</p> : (
            <div className="flex h-40 items-end gap-1 overflow-x-auto" role="img" aria-label="Biểu đồ doanh thu theo ngày">
              {data.by_day.map((d) => (
                <div key={d.key} className="flex h-full min-w-[14px] flex-1 flex-col justify-end" title={`${d.key}: ${vnd(d.revenue)} · lãi ${vnd(d.profit)}`}>
                  <div className="flex w-full flex-col justify-end rounded-t bg-latte" style={{ height: `${(d.revenue / maxDay) * 100}%` }}><div className="w-full bg-leaf" style={{ height: `${d.revenue ? Math.max(0, (d.profit / d.revenue) * 100) : 0}%` }} /></div>
                </div>))}
            </div>)}
          <p className="mt-2 flex gap-4 text-xs text-mocha"><span><i className="mr-1 inline-block h-2 w-2 rounded-sm bg-latte" />Giá vốn (phần trên)</span><span><i className="mr-1 inline-block h-2 w-2 rounded-sm bg-leaf" />Lợi nhuận (phần dưới) — tổng chiều cao = doanh thu</span></p>
        </section>

        <div className="grid gap-4 lg:grid-cols-2">
          <section className="card overflow-hidden"><h2 className="border-b border-[#eadfcd] p-4 font-bold">Món mang lại nhiều lợi nhuận nhất</h2>
            <table className="w-full text-sm"><thead className="text-left text-mocha"><tr><th className="p-2 pl-4">Món</th><th className="p-2 text-right">SL</th><th className="p-2 text-right">Lợi nhuận</th><th className="p-2 pr-4 text-right">Tỷ suất</th></tr></thead>
              <tbody>{data.by_recipe.slice(0, 10).map((r) => <tr key={r.key} className="border-t border-[#f3ebdd]"><td className="p-2 pl-4 font-semibold">{r.key}</td><td className="p-2 text-right">{num(r.qty, 0)}</td><td className="p-2 text-right">{vnd(r.profit)}</td><td className="p-2 pr-4 text-right">{pct(r.margin)}</td></tr>)}</tbody></table></section>
          <section className="card p-4"><h2 className="mb-3 font-bold">Theo danh mục</h2>
            <ul className="space-y-3">{data.by_category.map((c) => <li key={c.key}><div className="flex justify-between text-sm"><b>{c.key}</b><span>{vnd(c.revenue)} · lãi {pct(c.margin)}</span></div><div className="mt-1 h-2.5 rounded-full bg-cream"><div className="h-full rounded-full bg-coffee" style={{ width: `${(c.revenue / maxCat) * 100}%` }} /></div></li>)}</ul></section>
        </div>

        <section className="card p-4"><h2 className="font-bold">Phân tích menu</h2><p className="mb-3 text-sm text-mocha">Xếp món theo mức bán chạy và lợi nhuận mỗi ly.</p>
          <div className="grid gap-3 sm:grid-cols-2">{(['star', 'plowhorse', 'puzzle', 'dog'] as const).map((k) => {
            const list = data.menu.filter((m) => m.class === k);
            return <div key={k} className="rounded-2xl bg-cream p-3"><p className="font-bold">{CLASS[k][0]} <span className="text-sm font-normal text-mocha">({list.length})</span></p><p className="mb-2 text-xs text-mocha">{CLASS[k][1]}</p>
              <div className="flex flex-wrap gap-1.5">{list.slice(0, 12).map((m) => <span key={m.name} className={`tag ${CLASS[k][2]}`}>{m.name}</span>)}{list.length === 0 && <span className="text-xs text-mocha">—</span>}</div></div>;
          })}</div></section>

        <section className="card overflow-hidden"><h2 className="border-b border-[#eadfcd] p-4 font-bold">Ghi nhận gần đây</h2>
          <ul>{data.recent.map((r) => <li key={r.id} className="flex items-center justify-between gap-2 border-b border-[#f3ebdd] px-4 py-2 text-sm last:border-0"><span><b>{r.recipe_name}</b> ({r.size}) × {r.quantity}<span className="block text-xs text-mocha">{r.sold_on} · {r.source === 'excel' ? 'Excel' : r.source === 'manual' ? 'Ghi tay' : r.source === 'order' ? 'Đơn hàng' : 'Dữ liệu mẫu'}</span></span><span className="flex items-center gap-2">{vnd(r.revenue)}<button className="btn btn-ghost btn-sm" onClick={() => del(r.id)} aria-label="Xóa dòng">✕</button></span></li>)}</ul></section>
      </>)}

      <ImportSales open={importing} onClose={() => setImporting(false)} onDone={reload} />
      <Modal open={adding} onClose={() => setAdding(false)} title="Ghi nhận bán hàng">
        <div className="space-y-3">
          {err && <p className="rounded-xl bg-danger-soft p-3 text-sm text-danger" role="alert">{err}</p>}
          <div><label className="label" htmlFor="sr">Món</label><select id="sr" className="input" value={f.recipe_id} onChange={(e) => setF({ ...f, recipe_id: e.target.value })}><option value="">— chọn món —</option>{recipes.data?.recipes.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}</select></div>
          <div className="grid grid-cols-3 gap-2">
            <div><label className="label" htmlFor="ss">Size</label><select id="ss" className="input" value={f.size} onChange={(e) => setF({ ...f, size: e.target.value })}>{(selected?.sizes.map((s) => s.name) ?? ['S', 'M', 'L']).map((s) => <option key={s}>{s}</option>)}</select></div>
            <div><label className="label" htmlFor="sl">Số ly</label><input id="sl" type="number" min={1} className="input" value={f.quantity} onChange={(e) => setF({ ...f, quantity: e.target.value })} /></div>
            <div><label className="label" htmlFor="sd">Ngày</label><input id="sd" type="date" className="input" value={f.sold_on} onChange={(e) => setF({ ...f, sold_on: e.target.value })} /></div>
          </div>
          <button className="btn btn-green btn-lg w-full" onClick={add} disabled={busy}>{busy ? <Spinner /> : '💾'} Ghi nhận</button>
        </div>
      </Modal>
    </div>
  );
}

import type { Metadata, Viewport } from 'next';
import './globals.css';
import { AuthProvider, Shell } from '@/components/Auth';
import { ToastProvider } from '@/components/Toast';
import { Pwa } from '@/components/Pwa';

export const metadata: Metadata = { manifest: '/manifest.webmanifest', appleWebApp: { capable: true, title: 'Góc Cafe', statusBarStyle: 'default' }, icons: { apple: '/icons/icon-192.png' }, title: 'Góc Cafe — Công thức pha chế', description: 'Quản lý công thức, nguyên liệu và tìm món có thể pha từ nguyên liệu đang có.' };
export const viewport: Viewport = { width: 'device-width', initialScale: 1, themeColor: '#6f4e37' };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="vi">
      <body>
        <ToastProvider>
          <AuthProvider><Shell>{children}</Shell></AuthProvider>
          <Pwa />
        </ToastProvider>
      </body>
    </html>
  );
}

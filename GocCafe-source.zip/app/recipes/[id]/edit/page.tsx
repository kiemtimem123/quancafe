'use client';
import { use } from 'react';
import { useApi, useRouteId } from '@/lib/client';
import type { Recipe } from '@/lib/types';
import { RecipeForm } from '@/components/RecipeForm';
import { ErrorBox, Loading } from '@/components/ui';
import { Forbidden, useAuth } from '@/components/Auth';

export default function EditRecipe({ params }: { params: Promise<{ id: string }> }) {
  const id = useRouteId(use(params).id);
  const { can } = useAuth();
  const { data, error, loading, reload } = useApi<{ recipe: Recipe }>(can('edit_recipes') ? `/api/recipes/${id}` : null);
  if (!can('edit_recipes')) return <Forbidden what="mục sửa công thức" />;
  if (loading) return <Loading rows={3} />;
  if (error || !data) return <ErrorBox message={error ?? 'Không tìm thấy món'} onRetry={reload} />;
  return <RecipeForm recipe={data.recipe} />;
}

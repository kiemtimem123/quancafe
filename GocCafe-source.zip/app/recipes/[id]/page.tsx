'use client';
import { use, useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { QuickImageButton } from '@/components/ImageUploader';
import { useRouter } from 'next/navigation';
import { api, useApi, useRouteId } from '@/lib/client';
import type { Recipe, Size } from '@/lib/types';
import { num, pct, vnd } from '@/lib/format';
import { ErrorBox, Loading, Modal, RecipeThumb, Spinner } from '@/components/ui';
import { useToast } from '@/components/Toast';
import { useAuth } from '@/components/Auth';
import { AlternativesBox, type AvailItem } from '@/components/Availability';

export default function RecipePage({ params }: { params: Promise<{ id: string }> }) {
  const id = useRouteId(use(params).id);
  const router = useRouter();
  const toast = useToast();
  const { can } = useAuth();
  const { data, error, loading, reload, setData } = useApi<{ recipe: Recipe }>(`/api/recipes/${id}`);
  const settings = useApi<{ shop_name: string }>('/api/settings');
  const r = data?.recipe;
  const av = useApi<{ items: AvailItem[] }>('/api/availability');
  const availItem = av.data?.items.find((i) => i.id === Number(id));
  const [size, setSize] = useState<Size>('M');
  const [price, setPrice] = useState<string>('');
  const [busy, setBusy] = useState('');
  const [brew, setBrew] = useState(false);
  const [qty, setQty] = useState(1);
  const [confirmDel, setConfirmDel] = useState(false);
  const [short, setShort] = useState<string[] | null>(null);

  useEffect(() => { if (r && !r.sizes.find((s) => s.name === size)) setSize(r.sizes.find((s) => s.name === 'M')?.name ?? r.sizes[0]?.name ?? 'M'); }, [r, size]);
  const cur = r?.sizes.find((s) => s.name === size);
  useEffect(() => { if (cur) setPrice(String(cur.selling_price)); }, [cur?.selling_price, size]); // eslint-disable-line react-hooks/exhaustive-deps

  const sellPrice = Number(price) || 0;
  const calc = useMemo(() => cur ? { profit: sellPrice - cur.cost, margin: sellPrice > 0 ? ((sellPrice - cur.cost) / sellPrice) * 100 : 0 } : null, [cur, sellPrice]);
  const names = useMemo(() => {
    const m = new Map<number, string>();
    r?.sizes.forEach((s) => s.lines.forEach((l) => m.set(l.ingredient_id, l.name)));
    return [...m];
  }, [r]);

  if (loading) return <Loading rows={4} />;
  if (error || !r) return <ErrorBox message={error ?? 'Không tìm thấy món'} onRetry={reload} />;

  const act = async (key: string, fn: () => Promise<void>) => { setBusy(key); try { await fn(); } catch (e) { toast.err(e instanceof Error ? e.message : 'Có lỗi xảy ra'); } finally { setBusy(''); } };
  const savePrice = () => act('price', async () => {
    const body = {
      name: r.name, category: r.category, description: r.description, image: r.image, difficulty: r.difficulty, preparation_time: r.preparation_time, instructions: r.instructions,
      sizes: r.sizes.map((s) => ({ name: s.name, selling_price: s.name === size ? sellPrice : s.selling_price, lines: s.lines.map((l) => ({ ingredient_id: l.ingredient_id, quantity: l.quantity, unit: l.unit, optional: l.optional })) })),
    };
    const res = await api<{ recipe: Recipe }>(`/api/recipes/${r.id}`, { method: 'PUT', body });
    setData(res); toast.ok('Đã lưu giá bán');
  });
  const doBrew = (force = false) => act('brew', async () => {
    try {
      const res = await api<{ substitutes?: string[] }>(`/api/recipes/${r.id}/brew`, { method: 'POST', body: { size, quantity: qty, force } });
      toast.ok(`Đã pha ${qty} ly ${r.name} (size ${size}) và trừ tồn kho${res.substitutes?.length ? ` — dùng ${res.substitutes.join(', ')}` : ''}`); av.reload(); setBrew(false); setShort(null); reload();
    } catch (e) {
      const err = e as Error & { status?: number; details?: { short?: string[] } };
      if (err.status === 409 && err.details?.short) { setShort(err.details.short); return; }
      throw e;
    }
  });
  const saveImage = async (image: string) => {
    const body = {
      name: r.name, category: r.category, description: r.description, image, difficulty: r.difficulty, preparation_time: r.preparation_time, instructions: r.instructions,
      sizes: r.sizes.map((s) => ({ name: s.name, selling_price: s.selling_price, lines: s.lines.map((l) => ({ ingredient_id: l.ingredient_id, quantity: l.quantity, unit: l.unit, optional: l.optional })) })),
    };
    const res = await api<{ recipe: Recipe }>(`/api/recipes/${r.id}`, { method: 'PUT', body });
    setData(res); toast.ok('Đã đổi ảnh món');
  };
  const fav = () => act('fav', async () => { const x = await api<{ favorite: boolean }>(`/api/recipes/${r.id}/favorite`, { method: 'POST' }); setData({ recipe: { ...r, favorite: x.favorite } }); toast.ok(x.favorite ? 'Đã lưu vào yêu thích' : 'Đã bỏ khỏi yêu thích'); });
  const dup = () => act('dup', async () => { const x = await api<{ recipe: Recipe }>(`/api/recipes/${r.id}/duplicate`, { method: 'POST' }); toast.ok('Đã nhân bản công thức'); router.push(`/recipes/${x.recipe.id}/edit`); });
  const del = () => act('del', async () => { await api(`/api/recipes/${r.id}`, { method: 'DELETE' }); toast.ok('Đã xóa món'); router.push('/recipes'); });

  return (
    <>
      <div className="no-print space-y-5">
        <Link href="/recipes" className="text-sm font-semibold text-mocha">← Kho công thức</Link>
        {availItem && availItem.availability.status !== 'ok' && <AlternativesBox item={availItem} />}
        {availItem && availItem.availability.status === 'ok' && availItem.availability.substitutes.length > 0 && <p className="rounded-2xl bg-warn-soft p-3 text-sm font-semibold text-[#8a5a00]">♻ Đang dùng nguyên liệu thay thế: {availItem.availability.substitutes.join(', ')}</p>}
        <section className="card overflow-hidden sm:flex">
          <div className="relative sm:w-64 sm:shrink-0">
            <RecipeThumb category={r.category} image={r.image} className="h-48 w-full sm:h-full" />
            {can('edit_recipes') && <QuickImageButton hasImage={!!r.image} className="no-print absolute bottom-2 right-2 rounded-full bg-white/95 px-3 py-1.5 text-sm font-bold shadow hover:bg-white" onUploaded={saveImage} />}
          </div>
          <div className="flex-1 p-5">
            <h1 className="text-3xl font-extrabold uppercase">{r.name}</h1>
            <p className="mt-1 text-mocha">{r.description}</p>
            <div className="mt-3 flex flex-wrap gap-2 text-sm"><span className="tag tag-neutral">Danh mục: {r.category}</span><span className="tag tag-neutral">⏱ {r.preparation_time} phút</span><span className="tag tag-neutral">Độ khó: {r.difficulty}</span></div>
            <div className="mt-4 flex flex-wrap items-center gap-2" role="tablist" aria-label="Size">
              <span className="text-sm font-semibold text-mocha">Size:</span>
              {r.sizes.map((s) => <button key={s.name} role="tab" aria-selected={size === s.name} className="chip !min-w-14 justify-center !text-base" aria-pressed={size === s.name} onClick={() => setSize(s.name)}>{s.name}</button>)}
            </div>
          </div>
        </section>

        <div className="flex flex-wrap gap-2">
          <button className="btn btn-green btn-lg" onClick={() => { setQty(1); setShort(null); setBrew(true); }}>☕ Pha món này</button>
          <button className="btn btn-ghost" onClick={() => window.print()}>🖨 In công thức</button>
          <button className="btn btn-ghost" onClick={fav} disabled={busy === 'fav'}>{r.favorite ? '❤ Đã yêu thích' : '🤍 Lưu vào yêu thích'}</button>
          {can('edit_recipes') && <>
            <Link href={`/recipes/${r.id}/edit`} className="btn btn-ghost">✏ Chỉnh sửa công thức</Link>
            <button className="btn btn-ghost" onClick={dup} disabled={busy === 'dup'}>⧉ Nhân bản</button>
            <button className="btn btn-danger" onClick={() => setConfirmDel(true)}>🗑 Xóa</button>
          </>}
        </div>

        <div className="grid gap-5 lg:grid-cols-5">
          <section className="card overflow-x-auto p-5 lg:col-span-3">
            <h2 className="mb-3 text-lg font-bold">Nguyên liệu</h2>
            <table className="w-full text-sm">
              <thead><tr className="border-b border-[#eadfcd] text-left text-mocha"><th className="py-2">Nguyên liệu</th>{r.sizes.map((s) => <th key={s.name} className={`py-2 text-right ${s.name === size ? 'font-extrabold text-coffee' : ''}`}>Size {s.name}</th>)}</tr></thead>
              <tbody>
                {names.map(([iid, n]) => (
                  <tr key={iid} className="border-b border-[#f3ebdd]">
                    <td className="py-2 font-medium">{n}{cur?.lines.find((l) => l.ingredient_id === iid && !l.stock_ok) && <span className="tag tag-warn ml-2" title="Tồn kho không đủ">⚠ thiếu tồn</span>}</td>
                    {r.sizes.map((s) => { const l = s.lines.find((x) => x.ingredient_id === iid); return <td key={s.name} className={`py-2 text-right ${s.name === size ? 'font-bold' : 'text-mocha'}`}>{l ? `${num(l.quantity)}${l.unit}` : '—'}</td>; })}
                  </tr>
                ))}
              </tbody>
            </table>
            <h2 className="mb-2 mt-6 text-lg font-bold">Cách pha</h2>
            {r.instructions.length === 0 ? <p className="text-mocha">Chưa có hướng dẫn.</p> : (
              <ol className="space-y-3">{r.instructions.map((s, i) => <li key={i} className="flex gap-3"><span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-leaf-dark font-bold text-white">{i + 1}</span><p className="pt-1"><b className="text-mocha">Bước {i + 1}: </b>{s}</p></li>)}</ol>
            )}
          </section>

          {cur && calc && can('view_cost') && (
            <section className="card h-fit p-5 lg:col-span-2">
              <h2 className="mb-3 text-lg font-bold">Giá vốn — size {cur.name}</h2>
              <ul className="space-y-1 text-sm">{cur.lines.map((l) => <li key={l.ingredient_id} className="flex justify-between"><span>{l.name} <span className="text-mocha">({num(l.quantity)}{l.unit})</span></span><span>{vnd(l.cost)}</span></li>)}
                <li className="flex justify-between text-mocha"><span>Hao phí</span><span>{vnd(cur.waste_cost)}</span></li></ul>
              <div className="mt-3 flex justify-between border-t border-[#eadfcd] pt-3 text-lg font-extrabold"><span>Tổng giá vốn</span><span>{vnd(cur.cost)}</span></div>
              <div className="mt-4"><label className="label" htmlFor="price">Giá bán (đ)</label>
                <div className="flex gap-2"><input id="price" type="number" min={0} step={500} className="input" value={price} onChange={(e) => setPrice(e.target.value)} />
                  <button className="btn btn-primary" onClick={savePrice} hidden={!can('edit_recipes')} disabled={busy === 'price' || sellPrice === cur.selling_price}>{busy === 'price' ? <Spinner /> : 'Lưu'}</button></div></div>
              <dl className="mt-4 grid grid-cols-2 gap-2 text-center">
                <div className="rounded-xl bg-cream p-3"><dt className="text-xs text-mocha">Doanh thu</dt><dd className="font-extrabold">{vnd(sellPrice)}</dd></div>
                <div className="rounded-xl bg-cream p-3"><dt className="text-xs text-mocha">Giá vốn</dt><dd className="font-extrabold">{vnd(cur.cost)}</dd></div>
                <div className={`rounded-xl p-3 ${calc.profit >= 0 ? 'bg-leaf-soft text-leaf-dark' : 'bg-danger-soft text-danger'}`}><dt className="text-xs">Lợi nhuận gộp</dt><dd className="font-extrabold">{vnd(calc.profit)}</dd></div>
                <div className={`rounded-xl p-3 ${calc.profit >= 0 ? 'bg-leaf-soft text-leaf-dark' : 'bg-danger-soft text-danger'}`}><dt className="text-xs">Tỷ suất lợi nhuận</dt><dd className="font-extrabold">{pct(calc.margin)}</dd></div>
              </dl>
            </section>
          )}
        </div>
      </div>

      {/* Bản in cho nhân viên pha chế */}
      {cur && (
        <div className="print-only text-black">
          <p className="text-sm">{settings.data?.shop_name ?? 'Góc Cafe'} — Công thức pha chế</p>
          <h1 className="mt-2 text-5xl font-extrabold uppercase">{r.name}</h1>
          <p className="mt-2 text-3xl font-bold">SIZE {cur.name}</p>
          <p className="mt-1 text-lg">⏱ {r.preparation_time} phút · Độ khó: {r.difficulty}</p>
          <ul className="mt-6 space-y-2 text-3xl">{cur.lines.map((l) => <li key={l.ingredient_id} className="flex justify-between border-b border-dotted border-black/40 pb-1"><span>{l.name}</span><b>{num(l.quantity)}{l.unit}</b></li>)}</ul>
          <h2 className="mt-8 text-2xl font-extrabold">CÁCH PHA</h2>
          <ol className="mt-3 list-decimal space-y-2 pl-8 text-2xl">{r.instructions.map((s, i) => <li key={i}>{s}</li>)}</ol>
        </div>
      )}

      <Modal open={brew} onClose={() => setBrew(false)} title={`Pha ${r.name}`}>
        <div className="space-y-4">
          <p className="text-sm text-mocha">Hệ thống sẽ trừ nguyên liệu trong tồn kho theo công thức size {size}.</p>
          <div className="flex items-center gap-3"><span className="font-semibold">Số ly:</span>
            <button className="btn btn-ghost" onClick={() => setQty(Math.max(1, qty - 1))} aria-label="Giảm">−</button><b className="w-8 text-center text-xl">{qty}</b><button className="btn btn-ghost" onClick={() => setQty(Math.min(100, qty + 1))} aria-label="Tăng">+</button></div>
          {short && <div className="rounded-xl bg-warn-soft p-3 text-sm" role="alert">⚠ Không đủ tồn kho: <b>{short.join(', ')}</b>. Bạn vẫn có thể pha (tồn kho sẽ về 0) hoặc cập nhật tồn kho trước.</div>}
          <div className="flex gap-2"><button className="btn btn-green btn-lg flex-1" disabled={busy === 'brew'} onClick={() => doBrew(!!short)}>{busy === 'brew' ? <Spinner /> : short ? 'Vẫn pha' : 'Xác nhận pha'}</button><button className="btn btn-ghost btn-lg" onClick={() => setBrew(false)}>Hủy</button></div>
        </div>
      </Modal>
      <Modal open={confirmDel} onClose={() => setConfirmDel(false)} title="Xóa món?">
        <p>Bạn chắc chắn muốn xóa <b>{r.name}</b>? Không thể hoàn tác.</p>
        <div className="mt-4 flex gap-2"><button className="btn btn-danger flex-1" onClick={del} disabled={busy === 'del'}>{busy === 'del' ? <Spinner /> : 'Xóa món'}</button><button className="btn btn-ghost" onClick={() => setConfirmDel(false)}>Hủy</button></div>
      </Modal>
    </>
  );
}

'use client';
import { RecipeForm } from '@/components/RecipeForm';
import { Forbidden, useAuth } from '@/components/Auth';
export default function NewRecipe() { const { can } = useAuth(); return can('edit_recipes') ? <RecipeForm /> : <Forbidden what="mục thêm món" />; }

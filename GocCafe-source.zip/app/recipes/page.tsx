'use client';
import { Suspense, useMemo, useState } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { useApi } from '@/lib/client';
import type { Ingredient, Recipe } from '@/lib/types';
import { ALWAYS_AVAILABLE, RECIPE_CATEGORIES } from '@/lib/types';
import { mainOf } from '@/lib/pick';
import { norm, pct, vnd } from '@/lib/format';
import { Empty, ErrorBox, Loading, RecipeThumb } from '@/components/ui';
import { useAuth } from '@/components/Auth';
import { DownloadButton } from '@/components/DownloadButton';
import { ImportRecipes } from '@/components/ImportRecipes';
import { AvailBadge } from '@/components/Availability';

type QF = 'ready' | 'missing' | 'cheap' | 'profit' | 'easy' | 'fast' | 'fav';
const QUICK: [QF, string][] = [['ready', 'Có thể pha ngay'], ['missing', 'Thiếu nguyên liệu'], ['cheap', 'Giá vốn thấp'], ['profit', 'Lợi nhuận cao'], ['easy', 'Dễ pha'], ['fast', 'Pha nhanh'], ['fav', '❤ Yêu thích']];

function List() {
  const sp = useSearchParams();
  const { can } = useAuth();
  const seeCost = can('view_cost');
  const [q, setQ] = useState(sp.get('q') ?? '');
  const [cat, setCat] = useState(sp.get('cat') ?? '');
  const [qf, setQf] = useState<QF[]>([]);
  const [importing, setImporting] = useState(sp.get('import') === '1');
  const r = useApi<{ recipes: Recipe[] }>('/api/recipes');
  const i = useApi<{ ingredients: Ingredient[] }>('/api/ingredients');

  const inStock = useMemo(() => new Set((i.data?.ingredients ?? []).filter((x) => x.stock_quantity > 0).map((x) => x.id)), [i.data]);
  const shown = useMemo(() => {
    const nq = norm(q);
    let list = (r.data?.recipes ?? []).filter((x) => {
      if (cat && x.category !== cat) return false;
      if (nq) {
        const hay = norm([x.name, x.category, x.description, ...x.instructions, ...(mainOf(x)?.lines.map((l) => l.name) ?? [])].join(' | '));
        if (!nq.split(/\s+/).every((w) => hay.includes(w))) return false;
      }
      const m = mainOf(x);
      const makeable = !!m && m.lines.filter((l) => !ALWAYS_AVAILABLE.includes(l.category)).every((l) => inStock.has(l.ingredient_id));
      return qf.every((f) => ({
        ready: makeable, missing: !makeable, cheap: !!m && m.cost <= 8000, profit: !!m && m.margin >= 65,
        easy: x.difficulty === 'Dễ', fast: x.preparation_time <= 3, fav: x.favorite,
      })[f]);
    });
    if (qf.includes('cheap')) list = [...list].sort((a, b) => (mainOf(a)?.cost ?? 0) - (mainOf(b)?.cost ?? 0));
    if (qf.includes('profit')) list = [...list].sort((a, b) => (mainOf(b)?.margin ?? 0) - (mainOf(a)?.margin ?? 0));
    return list;
  }, [r.data, q, cat, qf, inStock]);

  const toggle = (f: QF) => setQf((x) => (x.includes(f) ? x.filter((y) => y !== f) : [...x, f]));
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div><h1 className="text-2xl font-extrabold">KHO CÔNG THỨC</h1><p className="text-sm text-mocha">{r.data ? `${shown.length}/${r.data.recipes.length} món` : ' '}</p></div>
        <div className="flex flex-wrap gap-2">{seeCost && <DownloadButton url="/api/reports/cost" filename="bao-cao-gia-von.xlsx">Báo cáo giá vốn</DownloadButton>}{can('edit_recipes') && <button className="btn btn-ghost" onClick={() => setImporting(true)}>⬆ Nhập từ Excel</button>}{can('edit_recipes') && <Link href="/recipes/new" className="btn btn-green btn-lg">+ Thêm món</Link>}</div>
      </div>
      <input className="input !min-h-[50px]" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Tìm theo tên món, nguyên liệu, danh mục, cách pha… (vd: matcha, sữa)" aria-label="Tìm công thức" />
      <div className="flex gap-2 overflow-x-auto pb-1" role="group" aria-label="Danh mục">
        <button className="chip shrink-0" aria-pressed={!cat} onClick={() => setCat('')}>Tất cả</button>
        {RECIPE_CATEGORIES.map((c) => <button key={c.name} className="chip shrink-0" aria-pressed={cat === c.name} onClick={() => setCat(cat === c.name ? '' : c.name)}>{c.icon} {c.name}</button>)}
      </div>
      <div className="flex flex-wrap gap-2" role="group" aria-label="Bộ lọc nhanh">
        {QUICK.filter(([k]) => seeCost || (k !== 'cheap' && k !== 'profit')).map(([k, l]) => <button key={k} className="chip" aria-pressed={qf.includes(k)} onClick={() => toggle(k)}>{l}</button>)}
      </div>
      {r.error && <ErrorBox message={r.error} onRetry={r.reload} />}
      {r.loading && <Loading rows={4} />}
      {r.data && shown.length === 0 && <Empty icon="🔍" title="Không tìm thấy món phù hợp" hint="Thử bỏ bớt bộ lọc hoặc đổi từ khóa." action={<button className="btn btn-ghost" onClick={() => { setQ(''); setCat(''); setQf([]); }}>Xóa bộ lọc</button>} />}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {shown.map((x) => {
          const m = mainOf(x);
          return (
            <Link key={x.id} href={`/recipes/${x.id}`} className="card pop overflow-hidden transition hover:-translate-y-0.5 hover:shadow-md">
              <RecipeThumb category={x.category} image={x.image} className="h-28 w-full" />
              <div className="p-4">
                <div className="flex items-start justify-between gap-2"><h2 className="font-bold leading-tight">{x.name}{x.favorite && ' ❤'} <AvailBadge a={x.availability} /></h2><span className="tag tag-neutral shrink-0">{x.category}</span></div>
                <p className="mt-1 line-clamp-2 text-sm text-mocha">{x.description}</p>
                {m && !seeCost && <p className="mt-3 text-sm font-bold">{vnd(m.selling_price)}</p>}
                {m && seeCost && <div className="mt-3 grid grid-cols-3 gap-1 text-center text-xs">
                  <div className="rounded-lg bg-cream p-1.5"><b className="block text-sm">{vnd(m.cost)}</b>Giá vốn</div>
                  <div className="rounded-lg bg-cream p-1.5"><b className="block text-sm">{vnd(m.selling_price)}</b>Giá bán</div>
                  <div className="rounded-lg bg-leaf-soft p-1.5 text-leaf-dark"><b className="block text-sm">{pct(m.margin)}</b>Lợi nhuận</div>
                </div>}
                <p className="mt-2 text-xs text-mocha">⏱ {x.preparation_time} phút · {x.difficulty} · Size {x.sizes.map((s) => s.name).join('/')}</p>
              </div>
            </Link>
          );
        })}
      </div>
      <ImportRecipes open={importing} onClose={() => setImporting(false)} onDone={() => r.reload()} />
    </div>
  );
}
export default function Page() { return <Suspense fallback={<Loading rows={4} />}><List /></Suspense>; }

import { redirect } from 'next/navigation';
export default function Page() { redirect('/recipes?import=1'); }

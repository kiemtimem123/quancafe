'use client';
import { useEffect, useState } from 'react';
import { api } from '@/lib/client';
import { useAuth } from '@/components/Auth';
import { Spinner } from '@/components/ui';

export default function Login() {
  const { user, needsSetup, loading, refresh } = useAuth();
  const [f, setF] = useState({ name: '', email: '', password: '', again: '' });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [needCode, setNeedCode] = useState(false);
  const [code, setCode] = useState('');
  const [forgot, setForgot] = useState(false);
  const [rc, setRc] = useState({ code: '', password: '' });
  const [okMsg, setOkMsg] = useState('');
  useEffect(() => { if (!loading && user) window.location.replace('/'); }, [loading, user]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setErr('');
    if (needsSetup) {
      if (f.password.length < 8) return setErr('Mật khẩu tối thiểu 8 ký tự');
      if (f.password !== f.again) return setErr('Mật khẩu nhập lại không khớp');
    }
    setBusy(true);
    try {
      await api(needsSetup ? '/api/auth/setup' : '/api/auth/login', { method: 'POST', body: needsSetup ? { name: f.name, email: f.email, password: f.password } : { email: f.email, password: f.password, code: code || undefined } });
      await refresh();
      window.location.replace('/');
    } catch (e2) {
      const er = e2 as Error & { details?: { needs_code?: boolean } };
      if (er.details?.needs_code) setNeedCode(true);
      setErr(er.message || 'Không đăng nhập được'); setBusy(false);
    }
  };
  const doReset = async (e: React.FormEvent) => {
    e.preventDefault(); setErr(''); setOkMsg('');
    if (rc.password.length < 8) return setErr('Mật khẩu mới tối thiểu 8 ký tự');
    setBusy(true);
    try { await api('/api/auth/reset', { method: 'POST', body: { email: f.email, code: rc.code, password: rc.password } }); setOkMsg('Đã đặt lại mật khẩu. Hãy đăng nhập bằng mật khẩu mới.'); setForgot(false); setF({ ...f, password: '' }); setRc({ code: '', password: '' }); }
    catch (e2) { setErr(e2 instanceof Error ? e2.message : 'Không đặt lại được'); } finally { setBusy(false); }
  };

  if (loading) return <div className="py-20 text-center"><Spinner /></div>;
  return (
    <div className="mx-auto mt-6 max-w-md">
      <div className="mb-6 text-center">
        <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-3xl bg-coffee text-3xl text-white">☕</span>
        <h1 className="mt-3 text-2xl font-extrabold text-coffee">Góc Cafe</h1>
        <p className="text-sm text-mocha">{needsSetup ? 'Thiết lập lần đầu — tạo tài khoản quản trị viên' : 'Đăng nhập để xem công thức pha chế'}</p>
      </div>
      {forgot ? (
        <form onSubmit={doReset} className="card space-y-4 p-6" noValidate>
          <h2 className="font-bold">Đặt lại mật khẩu</h2>
          <p className="text-sm text-mocha">Nhờ quản trị viên tạo &quot;mã đặt lại&quot; cho bạn (trong Quản lý người dùng), rồi nhập vào đây.</p>
          {err && <p className="rounded-xl bg-danger-soft p-3 text-sm font-semibold text-danger" role="alert">{err}</p>}
          <div><label className="label" htmlFor="re">Email</label><input id="re" type="email" className="input" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} required /></div>
          <div><label className="label" htmlFor="rcode">Mã đặt lại</label><input id="rcode" className="input" inputMode="numeric" value={rc.code} onChange={(e) => setRc({ ...rc, code: e.target.value })} required /></div>
          <div><label className="label" htmlFor="rpw">Mật khẩu mới (tối thiểu 8 ký tự)</label><input id="rpw" type="password" className="input" autoComplete="new-password" value={rc.password} onChange={(e) => setRc({ ...rc, password: e.target.value })} required /></div>
          <button className="btn btn-green btn-lg w-full" disabled={busy}>{busy ? <Spinner /> : 'Đặt lại mật khẩu'}</button>
          <button type="button" className="w-full text-sm text-mocha underline" onClick={() => { setForgot(false); setErr(''); }}>Quay lại đăng nhập</button>
        </form>
      ) : (
      <form onSubmit={submit} className="card space-y-4 p-6" noValidate>
        {okMsg && <p className="rounded-xl bg-leaf-soft p-3 text-sm font-semibold text-leaf-dark" role="status">{okMsg}</p>}
        {err && <p className="rounded-xl bg-danger-soft p-3 text-sm font-semibold text-danger" role="alert">{err}</p>}
        {needsSetup && <div><label className="label" htmlFor="name">Họ tên</label><input id="name" className="input" autoComplete="name" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} required /></div>}
        <div><label className="label" htmlFor="email">Email</label><input id="email" type="email" className="input" autoComplete="username" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} required /></div>
        <div><label className="label" htmlFor="pw">Mật khẩu</label><input id="pw" type="password" className="input" autoComplete={needsSetup ? 'new-password' : 'current-password'} value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} required /></div>
        {needsSetup && <div><label className="label" htmlFor="pw2">Nhập lại mật khẩu</label><input id="pw2" type="password" className="input" autoComplete="new-password" value={f.again} onChange={(e) => setF({ ...f, again: e.target.value })} required /></div>}
        {needCode && <div><label className="label" htmlFor="otp">Mã xác thực 2 bước</label><input id="otp" className="input text-center text-xl tracking-widest" inputMode="text" autoComplete="one-time-code" autoFocus value={code} onChange={(e) => setCode(e.target.value)} placeholder="6 số (hoặc mã khôi phục)" /></div>}
        <button className="btn btn-green btn-lg w-full" disabled={busy}>{busy ? <Spinner /> : needsSetup ? 'Tạo tài khoản & bắt đầu' : 'Đăng nhập'}</button>
        {!needsSetup && <button type="button" className="w-full text-center text-xs text-mocha underline" onClick={() => { setForgot(true); setErr(''); setOkMsg(''); }}>Quên mật khẩu?</button>}
      </form>
      )}
    </div>
  );
}

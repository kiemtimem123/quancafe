'use client';
import Link from 'next/link';
import { useApi } from '@/lib/client';
import { num, pct, vnd } from '@/lib/format';
import { ErrorBox, Loading } from '@/components/ui';
import { Forbidden, useAuth } from '@/components/Auth';
import { DownloadButton } from '@/components/DownloadButton';

interface D {
  total_recipes: number; total_ingredients: number; new_recipes: number;
  best_seller: { id: number; name: string; count: number } | null; best_margin: { id: number; name: string; margin: number } | null;
  low_stock: { id: number; name: string; stock: number; minimum: number; unit: string }[];
  top_sellers: { name: string; count: number }[];
  price_chart: { name: string; cost: number; price: number; profit: number }[];
  stock_chart: { name: string; stock: number; minimum: number; unit: string }[];
}

function Stat({ icon, label, value, sub, href, tone }: { icon: string; label: string; value: string | number; sub?: string; href?: string; tone?: string }) {
  const body = <div className={`card h-full p-4 ${tone ?? ''}`}><div className="text-2xl">{icon}</div><p className="mt-1 text-xs font-semibold uppercase tracking-wide text-mocha">{label}</p><p className="text-xl font-extrabold leading-tight sm:text-2xl">{value}</p>{sub && <p className="text-xs text-mocha">{sub}</p>}</div>;
  return href ? <Link href={href} className="block transition hover:-translate-y-0.5">{body}</Link> : body;
}

export default function Dashboard() {
  const { can } = useAuth();
  const { data: d, error, loading, reload } = useApi<D>(can('view_dashboard') ? '/api/dashboard' : null);
  if (!can('view_dashboard')) return <Forbidden what="Dashboard" />;
  if (loading) return <Loading rows={4} />;
  if (error || !d) return <ErrorBox message={error ?? 'Không tải được'} onRetry={reload} />;
  const maxP = Math.max(1, ...d.price_chart.map((r) => r.price));
  const maxS = Math.max(1, ...d.top_sellers.map((r) => r.count));
  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3"><h1 className="text-2xl font-extrabold">DASHBOARD</h1><DownloadButton url="/api/reports/cost" filename="bao-cao-gia-von.xlsx" className="btn btn-green">Báo cáo giá vốn (Excel)</DownloadButton></div>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-3">
        <Stat icon="📖" label="Tổng số món" value={d.total_recipes} href="/recipes" />
        <Stat icon="🫘" label="Tổng số nguyên liệu" value={d.total_ingredients} href="/ingredients" />
        <Stat icon="🔥" label="Món bán chạy" value={d.best_seller?.name ?? '—'} sub={d.best_seller ? `${d.best_seller.count} ly (dữ liệu mẫu)` : 'Chưa có dữ liệu'} href={d.best_seller ? `/recipes/${d.best_seller.id}` : undefined} />
        <Stat icon="💰" label="Món lợi nhuận cao" value={d.best_margin?.name ?? '—'} sub={d.best_margin ? `Lãi gộp ${pct(d.best_margin.margin)}` : ''} href={d.best_margin ? `/recipes/${d.best_margin.id}` : undefined} />
        <Stat icon="⚠" label="Nguyên liệu sắp hết" value={d.low_stock.length} href="/ingredients" tone={d.low_stock.length ? 'bg-warn-soft' : ''} />
        <Stat icon="✨" label="Công thức mới (30 ngày)" value={d.new_recipes} href="/recipes" />
      </div>

      <section className="card p-5">
        <h2 className="text-lg font-bold">Giá vốn · Giá bán · Lợi nhuận (size M, 8 món lãi / ly cao nhất)</h2>
        <div className="mt-1 flex gap-4 text-xs"><span><i className="mr-1 inline-block h-3 w-3 rounded bg-latte" />Giá vốn</span><span><i className="mr-1 inline-block h-3 w-3 rounded bg-coffee" />Giá bán</span><span><i className="mr-1 inline-block h-3 w-3 rounded bg-leaf-dark" />Lợi nhuận</span></div>
        <div className="mt-4 space-y-4">
          {d.price_chart.map((r) => (
            <div key={r.name}>
              <p className="mb-1 text-sm font-semibold">{r.name}</p>
              {([['cost', r.cost, 'bg-latte'], ['price', r.price, 'bg-coffee'], ['profit', r.profit, 'bg-leaf-dark']] as const).map(([k, v, c]) => (
                <div key={k} className="flex items-center gap-2 py-0.5"><div className="h-3.5 flex-1 rounded-full bg-cream"><div className={`h-full rounded-full ${c}`} style={{ width: `${Math.max(1, (v / maxP) * 100)}%` }} /></div><span className="w-20 text-right text-xs tabular-nums">{vnd(v)}</span></div>
              ))}
            </div>
          ))}
        </div>
      </section>

      <div className="grid gap-5 lg:grid-cols-2">
        <section className="card p-5">
          <h2 className="text-lg font-bold">Tồn kho (so với mức cảnh báo)</h2>
          <div className="mt-3 space-y-3">
            {d.stock_chart.map((r) => {
              const ratio = r.stock / r.minimum; const lowS = ratio <= 1;
              return (
                <div key={r.name}><div className="flex justify-between text-sm"><span className="font-semibold">{r.name}</span><span className={lowS ? 'font-bold text-danger' : 'text-mocha'}>{num(r.stock, 2)} {r.unit} {lowS && '⚠'}</span></div>
                  <div className="relative mt-1 h-3.5 rounded-full bg-cream"><div className={`h-full rounded-full ${lowS ? 'bg-danger' : 'bg-leaf-dark'}`} style={{ width: `${Math.min(100, (ratio / 4) * 100)}%` }} /><div className="absolute inset-y-0 w-0.5 bg-espresso/50" style={{ left: '25%' }} title="Mức cảnh báo" /></div></div>
              );
            })}
          </div>
          <p className="mt-3 text-xs text-mocha">Vạch đứng = mức cảnh báo tồn tối thiểu.</p>
        </section>
        <section className="card p-5">
          <h2 className="text-lg font-bold">Món bán chạy (số ly đã pha)</h2>
          <div className="mt-3 space-y-3">
            {d.top_sellers.map((r) => <div key={r.name}><div className="flex justify-between text-sm"><span className="font-semibold">{r.name}</span><span className="text-mocha">{r.count} ly</span></div><div className="mt-1 h-3.5 rounded-full bg-cream"><div className="h-full rounded-full bg-coffee" style={{ width: `${(r.count / maxS) * 100}%` }} /></div></div>)}
          </div>
          <p className="mt-3 text-xs text-mocha">Số liệu ban đầu là dữ liệu mẫu; mỗi lần bấm “Pha món này” sẽ được cộng thêm.</p>
        </section>
      </div>

      {d.low_stock.length > 0 && (
        <section className="card p-5"><h2 className="text-lg font-bold">⚠ Cần nhập thêm</h2>
          <ul className="mt-2 grid gap-1 sm:grid-cols-2">{d.low_stock.map((i) => <li key={i.id} className="flex justify-between rounded-lg bg-warn-soft px-3 py-2 text-sm"><b>{i.name}</b><span>còn {num(i.stock, 2)} {i.unit} (tối thiểu {num(i.minimum, 2)})</span></li>)}</ul></section>
      )}
    </div>
  );
}

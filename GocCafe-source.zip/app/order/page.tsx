'use client';
import { Suspense, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { RecipeThumb } from '@/components/ui';
import { TransferQr } from '@/components/TransferQr';
import { vnd } from '@/lib/format';
import { norm } from '@/lib/format';

interface Item { id: number; name: string; category: string; image: string; description: string; sold_out: boolean; sizes: { name: 'S' | 'M' | 'L'; price: number }[] }
interface Menu { enabled: boolean; shop_name: string; tables?: string[]; bank?: { bank_bin: string; bank_account: string; bank_holder: string } | null; items?: Item[]; options?: { id: number; name: string; price: number }[] }
interface Line { key: string; recipe_id: number; size: 'S' | 'M' | 'L'; quantity: number; note: string; options: { id: number; qty: number }[] }
interface Status { code: string; status: 'pending' | 'accepted' | 'rejected'; total: number; table_name: string; pay_pref: string; order_code: string; reject_reason: string }
const LS = 'qr-order';
const ls = { get: () => { try { return JSON.parse(localStorage.getItem(LS) || 'null') as { id: number; token: string } | null; } catch { return null; } }, set: (v: unknown) => { try { v ? localStorage.setItem(LS, JSON.stringify(v)) : localStorage.removeItem(LS); } catch { /* bỏ qua */ } } };
const uid = () => Math.random().toString(36).slice(2, 10);
const post = async (url: string, body: unknown) => { const r = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }); const d = await r.json().catch(() => ({})); if (!r.ok) throw new Error(d.error || `Lỗi ${r.status}`); return d; };

function Page() {
  const sp = useSearchParams();
  const [menu, setMenu] = useState<Menu | null>(null);
  const [err, setErr] = useState('');
  const [cat, setCat] = useState('Tất cả');
  const [q, setQ] = useState('');
  const [cart, setCart] = useState<Line[]>([]);
  const [pick, setPick] = useState<Item | null>(null);
  const [checkout, setCheckout] = useState(false);
  const [track, setTrack] = useState<{ id: number; token: string } | null>(null);
  const [status, setStatus] = useState<Status | null>(null);
  const [tablePick, setTablePick] = useState('');

  useEffect(() => { setTrack(ls.get()); }, []);
  useEffect(() => { fetch('/api/public/menu').then((r) => r.json()).then(setMenu).catch(() => setErr('Không tải được thực đơn. Vui lòng thử lại.')); }, []);

  const poll = useCallback(async () => {
    if (!track) return;
    try {
      const r = await fetch(`/api/public/order?id=${track.id}&token=${track.token}`);
      if (r.status === 404) { ls.set(null); setTrack(null); return; }
      if (r.ok) setStatus(await r.json());
    } catch { /* mất mạng tạm thời */ }
  }, [track]);
  useEffect(() => { if (!track) return; poll(); const t = setInterval(poll, 5000); return () => clearInterval(t); }, [track, poll]);

  const byId = useMemo(() => new Map((menu?.items ?? []).map((i) => [i.id, i])), [menu]);
  const optBy = useMemo(() => new Map((menu?.options ?? []).map((o) => [o.id, o])), [menu]);
  const cats = useMemo(() => ['Tất cả', ...Array.from(new Set((menu?.items ?? []).map((i) => i.category)))], [menu]);
  const shown = (menu?.items ?? []).filter((i) => (cat === 'Tất cả' || i.category === cat) && (!q || norm(i.name).includes(norm(q))));
  const unit = (l: Line) => (byId.get(l.recipe_id)?.sizes.find((s) => s.name === l.size)?.price ?? 0) + l.options.reduce((a, o) => a + (optBy.get(o.id)?.price ?? 0) * o.qty, 0);
  const total = cart.reduce((a, l) => a + unit(l) * l.quantity, 0);
  const count = cart.reduce((a, l) => a + l.quantity, 0);
  const tableParam = sp.get('table') ?? '';
  const table = menu?.tables?.includes(tableParam) ? tableParam : tablePick;

  if (err) return <Shell name=""><p className="card p-5 text-center text-danger">{err}</p></Shell>;
  if (!menu) return <Shell name=""><p className="py-10 text-center text-mocha">Đang tải thực đơn…</p></Shell>;
  if (!menu.enabled) return <Shell name={menu.shop_name}><div className="card p-6 text-center"><div className="text-5xl">🛎</div><p className="mt-2 font-bold">Quán chưa mở đặt món qua QR</p><p className="text-sm text-mocha">Vui lòng gọi nhân viên để gọi món.</p></div></Shell>;

  if (track && status) {
    const done = status.status !== 'pending';
    return (
      <Shell name={menu.shop_name}>
        <div className="card space-y-3 p-5 text-center">
          <div className="text-5xl">{status.status === 'pending' ? '⏳' : status.status === 'accepted' ? '✅' : '😔'}</div>
          <p className="text-2xl font-extrabold">Đơn {status.code}</p>
          <p className="font-semibold">{status.status === 'pending' ? 'Đã gửi cho quán — vui lòng chờ nhân viên xác nhận…' : status.status === 'accepted' ? `Quán đã nhận đơn và đang pha${status.order_code ? ` (hóa đơn #${status.order_code})` : ''}!` : `Quán chưa nhận được đơn${status.reject_reason ? `: ${status.reject_reason}` : ''}. Vui lòng gọi nhân viên.`}</p>
          <p className="text-mocha">{status.table_name} · {vnd(status.total)}</p>
          {status.status === 'accepted' && status.pay_pref === 'transfer' && menu.bank && (
            <div className="rounded-2xl bg-white p-3"><p className="mb-2 text-sm font-semibold">Quét mã để chuyển khoản {vnd(status.total)}</p><TransferQr cfg={menu.bank} amount={status.total} memo={`Don ${status.order_code || status.code}`} /></div>
          )}
          {status.status === 'accepted' && status.pay_pref !== 'transfer' && <p className="rounded-xl bg-leaf-soft p-2 text-sm font-semibold text-leaf-dark">Thanh toán tiền mặt tại quầy khi nhận món.</p>}
          {done && <button className="btn btn-green btn-lg w-full" onClick={() => { ls.set(null); setTrack(null); setStatus(null); setCart([]); }}>Gọi thêm món</button>}
        </div>
      </Shell>
    );
  }

  return (
    <Shell name={menu.shop_name} sub={table ? `📍 ${table}` : ''}>
      {!table && menu.tables && <TablePicker tables={menu.tables} onPick={setTablePick} />}
      <input className="input mb-3" placeholder="🔍 Tìm món…" value={q} onChange={(e) => setQ(e.target.value)} />
      <div className="mb-3 flex gap-2 overflow-x-auto pb-1">{cats.map((c) => <button key={c} className="chip shrink-0" aria-pressed={cat === c} onClick={() => setCat(c)}>{c}</button>)}</div>
      <div className="grid grid-cols-2 gap-3 pb-28 sm:grid-cols-3">
        {shown.map((i) => (
          <button key={i.id} disabled={i.sold_out} onClick={() => setPick(i)} className={`card overflow-hidden text-left ${i.sold_out ? 'opacity-50' : 'active:scale-[.98]'}`}>
            <RecipeThumb category={i.category} image={i.image} className="h-28 w-full" />
            <div className="p-2.5"><p className="font-bold leading-tight">{i.name}</p><p className="text-sm text-mocha">{i.sold_out ? 'Tạm hết' : `từ ${vnd(Math.min(...i.sizes.map((s) => s.price)))}`}</p></div>
          </button>
        ))}
        {shown.length === 0 && <p className="col-span-full py-8 text-center text-mocha">Không tìm thấy món.</p>}
      </div>
      {count > 0 && <div className="fixed inset-x-0 bottom-0 z-40 border-t border-[#eadfcd] bg-foam p-3 pb-[max(12px,env(safe-area-inset-bottom))]"><button className="btn btn-green btn-lg mx-auto flex w-full max-w-xl justify-between" onClick={() => setCheckout(true)}><span>🛒 {count} món</span><span>Xem đơn · {vnd(total)}</span></button></div>}
      {pick && <PickSheet item={pick} options={menu.options ?? []} onClose={() => setPick(null)} onAdd={(l) => { setCart((c) => { const k = JSON.stringify([l.recipe_id, l.size, l.note, l.options]); const ex = c.find((x) => JSON.stringify([x.recipe_id, x.size, x.note, x.options]) === k); return ex ? c.map((x) => (x === ex ? { ...x, quantity: Math.min(20, x.quantity + l.quantity) } : x)) : [...c, l]; }); setPick(null); }} />}
      {checkout && <CheckoutSheet lines={cart} byId={byId} optBy={optBy} unit={unit} total={total} table={table} tables={menu.tables ?? []} hasBank={!!menu.bank} setCart={setCart} onClose={() => setCheckout(false)} onSent={(r) => { ls.set(r); setTrack(r); setCheckout(false); }} />}
    </Shell>
  );
}

function Shell({ name, sub, children }: { name: string; sub?: string; children: React.ReactNode }) {
  return (
    <div className="mx-auto min-h-screen max-w-3xl px-4 py-4">
      <header className="mb-4 flex items-center gap-3"><div className="flex h-11 w-11 items-center justify-center rounded-xl bg-coffee text-xl text-white">☕</div><div><h1 className="text-xl font-extrabold leading-tight">{name || 'Đặt món'}</h1><p className="text-sm font-semibold text-mocha">Gọi món bằng điện thoại {sub && `· ${sub}`}</p></div></header>
      {children}
    </div>
  );
}

function TablePicker({ tables, onPick }: { tables: string[]; onPick: (t: string) => void }) {
  return (<div className="card mb-3 p-3"><p className="mb-2 text-sm font-bold">Bạn ngồi ở đâu?</p><div className="flex flex-wrap gap-1.5">{tables.map((t) => <button key={t} className="chip" onClick={() => onPick(t)}>{t === 'Mang đi' ? '🥡 Mang đi' : t}</button>)}</div></div>);
}

function Sheet({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 sm:items-center" onClick={onClose} role="dialog" aria-modal="true" aria-label={title}>
      <div className="max-h-[92vh] w-full max-w-xl overflow-y-auto rounded-t-3xl bg-foam p-5 sm:rounded-3xl" onClick={(e) => e.stopPropagation()}>
        <div className="mb-3 flex items-center justify-between"><h2 className="text-lg font-extrabold">{title}</h2><button className="text-2xl leading-none text-mocha" onClick={onClose} aria-label="Đóng">×</button></div>{children}
      </div>
    </div>
  );
}

function PickSheet({ item, options, onClose, onAdd }: { item: Item; options: { id: number; name: string; price: number }[]; onClose: () => void; onAdd: (l: Line) => void }) {
  const [size, setSize] = useState<'S' | 'M' | 'L'>(item.sizes.find((s) => s.name === 'M')?.name ?? item.sizes[0].name);
  const [qty, setQty] = useState(1);
  const [note, setNote] = useState('');
  const [picked, setPicked] = useState<Record<number, number>>({});
  const price = item.sizes.find((s) => s.name === size)!.price + options.reduce((a, o) => a + (picked[o.id] ?? 0) * o.price, 0);
  return (
    <Sheet title={item.name} onClose={onClose}>
      <div className="space-y-4">
        {item.description && <p className="text-sm text-mocha">{item.description}</p>}
        <div><p className="label">Size</p><div className="flex gap-2">{item.sizes.map((s) => <button key={s.name} className="chip flex-1 justify-center !py-2.5" aria-pressed={size === s.name} onClick={() => setSize(s.name)}>{s.name} · {vnd(s.price)}</button>)}</div></div>
        {options.length > 0 && <div><p className="label">Topping</p><div className="flex flex-wrap gap-2">{options.map((o) => { const n = picked[o.id] ?? 0; return <button key={o.id} className="chip" aria-pressed={n > 0} onClick={() => setPicked((p) => ({ ...p, [o.id]: n >= 3 ? 0 : n + 1 }))}>{n > 0 ? `${n}× ` : ''}{o.name} +{vnd(o.price)}</button>; })}</div></div>}
        <div><p className="label">Ghi chú</p><div className="mb-2 flex flex-wrap gap-1.5">{['Ít đường', 'Ít đá', 'Không đá', 'Ít ngọt'].map((n) => <button key={n} className="chip" aria-pressed={note === n} onClick={() => setNote(note === n ? '' : n)}>{n}</button>)}</div><input className="input" maxLength={120} placeholder="Ghi chú khác (tuỳ chọn)" value={note} onChange={(e) => setNote(e.target.value)} /></div>
        <div className="flex items-center gap-3"><button className="btn btn-ghost" onClick={() => setQty(Math.max(1, qty - 1))} aria-label="Giảm">−</button><b className="w-8 text-center text-lg">{qty}</b><button className="btn btn-ghost" onClick={() => setQty(Math.min(20, qty + 1))} aria-label="Tăng">+</button>
          <button className="btn btn-green btn-lg flex-1" onClick={() => onAdd({ key: uid(), recipe_id: item.id, size, quantity: qty, note: note.trim(), options: Object.entries(picked).filter(([, n]) => n > 0).map(([id, n]) => ({ id: Number(id), qty: n })) })}>Thêm · {vnd(price * qty)}</button></div>
      </div>
    </Sheet>
  );
}

function CheckoutSheet({ lines, byId, optBy, unit, total, table, tables, hasBank, setCart, onClose, onSent }: {
  lines: Line[]; byId: Map<number, Item>; optBy: Map<number, { id: number; name: string; price: number }>; unit: (l: Line) => number; total: number; table: string; tables: string[]; hasBank: boolean;
  setCart: (f: (c: Line[]) => Line[]) => void; onClose: () => void; onSent: (r: { id: number; token: string }) => void;
}) {
  const [name, setName] = useState(''); const [phone, setPhone] = useState(''); const [note, setNote] = useState('');
  const [pay, setPay] = useState<'cash' | 'transfer'>('cash'); const [tb, setTb] = useState(table);
  const [busy, setBusy] = useState(false); const [err, setErr] = useState('');
  const sending = useRef(false);
  useEffect(() => { if (!lines.length) onClose(); }, [lines.length, onClose]);
  const send = async () => {
    if (sending.current) return;
    if (!tb) return setErr('Vui lòng chọn bàn hoặc “Mang đi”.');
    sending.current = true; setBusy(true); setErr('');
    try {
      const r = await post('/api/public/order', { table_name: tb, note: note.trim() || undefined, pay_pref: pay, customer_name: name.trim() || undefined, customer_phone: phone.trim() || undefined,
        items: lines.map((l) => ({ recipe_id: l.recipe_id, size: l.size, quantity: l.quantity, note: l.note || undefined, options: l.options.length ? l.options : undefined })) });
      onSent({ id: r.id, token: r.token });
    } catch (e) { setErr(e instanceof Error ? e.message : 'Không gửi được đơn'); sending.current = false; } finally { setBusy(false); }
  };
  return (
    <Sheet title="Đơn của bạn" onClose={onClose}>
      <div className="space-y-4">
        <ul className="divide-y divide-[#f3ebdd]">{lines.map((l) => (
          <li key={l.key} className="flex items-start justify-between gap-2 py-2"><div className="min-w-0"><p className="font-bold">{byId.get(l.recipe_id)?.name} <span className="tag tag-neutral">{l.size}</span></p>
            {l.options.length > 0 && <p className="text-xs font-semibold text-leaf-dark">{l.options.map((o) => `+ ${optBy.get(o.id)?.name}${o.qty > 1 ? ` ×${o.qty}` : ''}`).join(', ')}</p>}{l.note && <p className="text-xs text-mocha">• {l.note}</p>}
            <div className="mt-1 flex items-center gap-2"><button className="btn btn-ghost btn-sm" onClick={() => setCart((c) => (l.quantity > 1 ? c.map((x) => (x.key === l.key ? { ...x, quantity: x.quantity - 1 } : x)) : c.filter((x) => x.key !== l.key)))} aria-label="Giảm">−</button><b>{l.quantity}</b><button className="btn btn-ghost btn-sm" onClick={() => setCart((c) => c.map((x) => (x.key === l.key ? { ...x, quantity: Math.min(20, x.quantity + 1) } : x)))} aria-label="Tăng">+</button></div></div>
            <b className="shrink-0">{vnd(unit(l) * l.quantity)}</b></li>))}</ul>
        {!table && <div><p className="label">Bàn / hình thức</p><div className="flex max-h-24 flex-wrap gap-1.5 overflow-y-auto">{tables.map((t) => <button key={t} className="chip" aria-pressed={tb === t} onClick={() => setTb(t)}>{t === 'Mang đi' ? '🥡 Mang đi' : t}</button>)}</div></div>}
        <div className="grid gap-2 sm:grid-cols-2"><input className="input" placeholder="Tên của bạn (tuỳ chọn)" maxLength={60} value={name} onChange={(e) => setName(e.target.value)} /><input className="input" type="tel" inputMode="tel" placeholder="SĐT để tích điểm (tuỳ chọn)" maxLength={14} value={phone} onChange={(e) => setPhone(e.target.value)} /></div>
        <input className="input" placeholder="Ghi chú cho quán (tuỳ chọn)" maxLength={200} value={note} onChange={(e) => setNote(e.target.value)} />
        <div><p className="label">Thanh toán</p><div className="flex gap-2"><button className="chip flex-1 justify-center !py-2.5" aria-pressed={pay === 'cash'} onClick={() => setPay('cash')}>💵 Tiền mặt tại quầy</button>{hasBank && <button className="chip flex-1 justify-center !py-2.5" aria-pressed={pay === 'transfer'} onClick={() => setPay('transfer')}>🏦 Chuyển khoản</button>}</div></div>
        {err && <p className="rounded-xl bg-danger-soft p-3 text-sm font-semibold text-danger" role="alert">{err}</p>}
        <div className="flex items-center justify-between text-xl font-extrabold"><span>Tổng</span><span>{vnd(total)}</span></div>
        <button className="btn btn-green btn-lg w-full" onClick={send} disabled={busy}>{busy ? 'Đang gửi…' : '✔ Gửi đơn cho quán'}</button>
        <p className="text-center text-xs text-mocha">Quán sẽ xác nhận đơn của bạn. Giá cuối cùng do quán tính theo thực đơn hiện tại.</p>
      </div>
    </Sheet>
  );
}

export default function OrderPage() { return <Suspense fallback={null}><Page /></Suspense>; }

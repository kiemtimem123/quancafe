'use client';
import { useState } from 'react';
import { api, useApi } from '@/lib/client';
import { ROLES, ROLE_DESC, ROLE_LABEL, type Role } from '@/lib/roles';
import { useAuth, Forbidden } from '@/components/Auth';
import { ErrorBox, Loading, Modal, Spinner } from '@/components/ui';
import { useToast } from '@/components/Toast';

interface U { id: number; name: string; email: string; role: Role; active: number; created_at: string | null }
interface Form { id?: number; name: string; email: string; role: Role; active: boolean; password: string }
const blank: Form = { name: '', email: '', role: 'staff', active: true, password: '' };

export default function UsersPage() {
  const { user, can } = useAuth();
  const toast = useToast();
  const { data, error, loading, reload, setData } = useApi<{ users: U[] }>(can('manage_users') ? '/api/users' : null);
  const [form, setForm] = useState<Form | null>(null);
  const [del, setDel] = useState<U | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [codeFor, setCodeFor] = useState<{ name: string; code: string; emailed: boolean } | null>(null);
  const resetCode = async (u: U) => {
    try { const r = await api<{ code: string; emailed: boolean }>(`/api/users/${u.id}/reset-code`, { method: 'POST', body: {} }); setCodeFor({ name: u.name, code: r.code, emailed: r.emailed }); }
    catch (e) { toast.err(e instanceof Error ? e.message : 'Không tạo được mã'); }
  };
  if (!can('manage_users')) return <Forbidden what="mục quản lý người dùng" />;

  const save = async () => {
    if (!form) return;
    setErr('');
    if (!form.name.trim()) return setErr('Nhập tên');
    if (!form.id && !/^\S+@\S+\.\S+$/.test(form.email)) return setErr('Email không hợp lệ');
    if ((!form.id || form.password) && form.password.length < 8) return setErr('Mật khẩu tối thiểu 8 ký tự');
    setBusy(true);
    try {
      const r = form.id
        ? await api<{ users: U[] }>(`/api/users/${form.id}`, { method: 'PUT', body: { name: form.name, role: form.role, active: form.active, password: form.password } })
        : await api<{ users: U[] }>('/api/users', { method: 'POST', body: { name: form.name, email: form.email, role: form.role, password: form.password } });
      setData(r); toast.ok(form.id ? 'Đã cập nhật người dùng' : 'Đã tạo tài khoản'); setForm(null);
    } catch (e) { setErr(e instanceof Error ? e.message : 'Không lưu được'); } finally { setBusy(false); }
  };
  const remove = async () => {
    if (!del) return; setBusy(true);
    try { setData(await api<{ users: U[] }>(`/api/users/${del.id}`, { method: 'DELETE' })); toast.ok('Đã xóa tài khoản'); }
    catch (e) { toast.err(e instanceof Error ? e.message : 'Không xóa được'); } finally { setBusy(false); setDel(null); }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div><h1 className="text-2xl font-extrabold">QUẢN LÝ NGƯỜI DÙNG</h1><p className="text-sm text-mocha">Tạo tài khoản cho nhân viên và phân quyền</p></div>
        <button className="btn btn-green btn-lg" onClick={() => { setErr(''); setForm(blank); }}>+ Thêm người dùng</button>
      </div>
      <div className="grid gap-2 sm:grid-cols-3">{ROLES.map((r) => <div key={r} className="card p-3 text-sm"><b>{ROLE_LABEL[r]}</b><p className="text-mocha">{ROLE_DESC[r]}</p></div>)}</div>
      {error && <ErrorBox message={error} onRetry={reload} />}
      {loading && <Loading rows={3} />}
      {data && (
        <div className="card overflow-x-auto">
          <table className="w-full min-w-[560px] text-sm">
            <thead><tr className="border-b border-[#eadfcd] text-left text-mocha"><th className="p-3">Tên</th><th className="p-3">Email</th><th className="p-3">Vai trò</th><th className="p-3">Trạng thái</th><th className="p-3" /></tr></thead>
            <tbody>{data.users.map((u) => (
              <tr key={u.id} className="border-b border-[#f3ebdd]">
                <td className="p-3 font-bold">{u.name}{u.id === user?.id && <span className="tag tag-neutral ml-2">Bạn</span>}</td>
                <td className="p-3">{u.email}</td>
                <td className="p-3">{ROLE_LABEL[u.role]}</td>
                <td className="p-3">{u.active ? <span className="tag tag-ok">Hoạt động</span> : <span className="tag tag-miss">Đã khóa</span>}</td>
                <td className="whitespace-nowrap p-3 text-right"><button className="btn btn-ghost btn-sm" onClick={() => { setErr(''); setForm({ id: u.id, name: u.name, email: u.email, role: u.role, active: !!u.active, password: '' }); }}>Sửa</button>{' '}
                  {u.id !== user?.id && <button className="btn btn-ghost btn-sm" onClick={() => resetCode(u)} title="Tạo mã để người dùng tự đặt lại mật khẩu">Mã đặt lại</button>}{' '}
                  {u.id !== user?.id && <button className="btn btn-danger btn-sm" onClick={() => setDel(u)}>Xóa</button>}</td>
              </tr>))}</tbody>
          </table>
        </div>
      )}
      <Modal open={!!codeFor} onClose={() => setCodeFor(null)} title="Mã đặt lại mật khẩu">
        {codeFor && <div className="space-y-3 text-center"><p className="text-sm">Đưa mã này cho <b>{codeFor.name}</b>. Họ vào màn hình đăng nhập → &quot;Quên mật khẩu&quot; → nhập email + mã + mật khẩu mới.</p>
          <p className="rounded-2xl bg-cream p-4 font-mono text-3xl font-extrabold tracking-widest">{codeFor.code}</p>
          <p className="text-xs text-mocha">Hiệu lực 30 phút, dùng một lần. {codeFor.emailed ? 'Đã gửi mã qua email của người dùng.' : ''}</p><button className="btn btn-green w-full" onClick={() => setCodeFor(null)}>Đóng</button></div>}
      </Modal>
      <Modal open={!!form} onClose={() => setForm(null)} title={form?.id ? 'Sửa người dùng' : 'Thêm người dùng'}>
        {form && (
          <div className="space-y-3">
            {err && <p className="rounded-xl bg-danger-soft p-3 text-sm text-danger" role="alert">{err}</p>}
            <div><label className="label" htmlFor="un">Họ tên</label><input id="un" className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
            <div><label className="label" htmlFor="ue">Email đăng nhập</label><input id="ue" type="email" className="input" value={form.email} disabled={!!form.id} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
            <div><label className="label" htmlFor="ur">Vai trò</label><select id="ur" className="input" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value as Role })} disabled={form.id === user?.id}>{ROLES.map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}</select><p className="mt-1 text-xs text-mocha">{ROLE_DESC[form.role]}</p></div>
            <div><label className="label" htmlFor="up">{form.id ? 'Đặt lại mật khẩu (bỏ trống nếu giữ nguyên)' : 'Mật khẩu (tối thiểu 8 ký tự)'}</label><input id="up" type="password" autoComplete="new-password" className="input" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></div>
            {form.id && form.id !== user?.id && <label className="flex items-center gap-2 text-sm font-semibold"><input type="checkbox" className="h-5 w-5 accent-[#4a7552]" checked={form.active} onChange={(e) => setForm({ ...form, active: e.target.checked })} /> Cho phép đăng nhập</label>}
            <button className="btn btn-green btn-lg w-full" onClick={save} disabled={busy}>{busy ? <Spinner /> : '💾 Lưu'}</button>
          </div>
        )}
      </Modal>
      <Modal open={!!del} onClose={() => setDel(null)} title="Xóa tài khoản?">
        <p>Xóa tài khoản <b>{del?.name}</b> ({del?.email})? Người này sẽ bị đăng xuất ngay.</p>
        <div className="mt-4 flex gap-2"><button className="btn btn-danger flex-1" onClick={remove} disabled={busy}>{busy ? <Spinner /> : 'Xóa'}</button><button className="btn btn-ghost" onClick={() => setDel(null)}>Hủy</button></div>
      </Modal>
    </div>
  );
}

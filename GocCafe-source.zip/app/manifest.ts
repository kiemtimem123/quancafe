import type { MetadataRoute } from 'next';
export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'Góc Cafe — Công thức pha chế', short_name: 'Góc Cafe', description: 'Tra công thức, tìm món từ nguyên liệu, quản lý kho — dùng được cả khi mất mạng.',
    start_url: '/', scope: '/', display: 'standalone', orientation: 'any', background_color: '#fff6e8', theme_color: '#6f4e37', lang: 'vi',
    icons: [{ src: '/icons/icon-192.png', sizes: '192x192', type: 'image/png' }, { src: '/icons/icon-512.png', sizes: '512x512', type: 'image/png' }, { src: '/icons/maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' }],
    shortcuts: [{ name: 'Màn hình bếp', url: '/kitchen' }, { name: 'Tìm món', url: '/' }],
  };
}

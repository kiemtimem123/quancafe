'use client';
import { useState } from 'react';
import { api, useApi } from '@/lib/client';
import { vnd } from '@/lib/format';
import { Empty, ErrorBox, Loading, Modal, Spinner } from '@/components/ui';
import { Forbidden, useAuth } from '@/components/Auth';
import { useToast } from '@/components/Toast';
import type { Promo } from '@/lib/promo-pure';

interface Recipe { id: number; name: string; category: string }
type Form = { id?: number; name: string; code: string; type: 'percent' | 'amount'; value: string; scope: Promo['scope']; target: string; min_total: string; min_qty: string; time_from: string; time_to: string; days: string; date_from: string; date_to: string; active: boolean };
const blank: Form = { name: '', code: '', type: 'percent', value: '10', scope: 'order', target: '', min_total: '', min_qty: '', time_from: '', time_to: '', days: '', date_from: '', date_to: '', active: true };
const DOW = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'];

export default function PromotionsPage() {
  const { can } = useAuth();
  const toast = useToast();
  const ok = can('edit_ingredients');
  const pr = useApi<{ promotions: Promo[] }>(ok ? '/api/promotions' : null);
  const rc = useApi<{ recipes: Recipe[]; categories: { name: string }[] }>(ok ? '/api/recipes' : null);
  const [f, setF] = useState<Form | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  if (!ok) return <Forbidden />;
  const recipes = rc.data?.recipes ?? [];
  const rname = (id: string) => recipes.find((r) => String(r.id) === id)?.name ?? `#${id}`;
  const describe = (p: Promo) => {
    const v = p.type === 'percent' ? `Giảm ${p.value}%` : `Giảm ${vnd(p.value)}`;
    const sc = p.scope === 'order' ? 'toàn đơn' : p.scope === 'category' ? `nhóm ${p.target}` : p.scope === 'recipe' ? rname(p.target) : `combo ${p.target.split(',').map(rname).join(' + ')}`;
    const c = [p.min_total ? `đơn từ ${vnd(p.min_total)}` : '', p.min_qty ? `từ ${p.min_qty} ly` : '', p.time_from ? `${p.time_from}–${p.time_to}` : '', p.days ? p.days.split(',').map((d) => DOW[Number(d) - 1]).join(' ') : '', p.date_from || p.date_to ? `${p.date_from || '…'} → ${p.date_to || '…'}` : ''].filter(Boolean).join(' · ');
    return `${v} • ${sc}${c ? ' • ' + c : ''}`;
  };
  const toggleDay = (d: number) => { if (!f) return; const s = new Set(f.days.split(',').filter(Boolean)); s.has(String(d)) ? s.delete(String(d)) : s.add(String(d)); setF({ ...f, days: [...s].sort().join(',') }); };
  const toggleCombo = (id: number) => { if (!f) return; const s = new Set(f.target.split(',').filter(Boolean)); s.has(String(id)) ? s.delete(String(id)) : s.add(String(id)); setF({ ...f, target: [...s].join(',') }); };
  const save = async () => {
    if (!f) return;
    setErr(''); setBusy(true);
    try {
      const body = { name: f.name, code: f.code, type: f.type, value: Number(f.value || 0), scope: f.scope, target: f.scope === 'order' ? '' : f.target, min_total: Number(f.min_total || 0), min_qty: Number(f.min_qty || 0), time_from: f.time_from, time_to: f.time_to, days: f.days, date_from: f.date_from, date_to: f.date_to, active: f.active };
      await api(f.id ? `/api/promotions/${f.id}` : '/api/promotions', { method: f.id ? 'PUT' : 'POST', body });
      toast.ok('Đã lưu khuyến mãi'); setF(null); pr.reload();
    } catch (e) { setErr(e instanceof Error ? e.message : 'Lỗi'); } finally { setBusy(false); }
  };
  const del = async (p: Promo) => {
    if (!confirm(`Xóa khuyến mãi "${p.name}"?`)) return;
    try { await api(`/api/promotions/${p.id}`, { method: 'DELETE' }); pr.reload(); } catch (e) { toast.err(e instanceof Error ? e.message : 'Lỗi'); }
  };
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div><h1 className="text-2xl font-extrabold">KHUYẾN MÃI & VOUCHER</h1><p className="text-sm text-mocha">Không có mã = tự áp dụng (happy hour, combo…). Có mã = khách đọc mã, thu ngân nhập. Mỗi đơn áp dụng 1 khuyến mãi tốt nhất.</p></div>
        <button className="btn btn-green btn-lg" onClick={() => { setErr(''); setF(blank); }}>+ Thêm khuyến mãi</button>
      </div>
      {pr.error && <ErrorBox message={pr.error} onRetry={pr.reload} />}
      {pr.loading && !pr.data && <Loading rows={3} />}
      {pr.data && pr.data.promotions.length === 0 && <Empty icon="🎁" title="Chưa có khuyến mãi" hint="Ví dụ: Happy hour 14–16h giảm 20% trà; Combo cà phê + bánh giảm 10.000đ; Mã KHAITRUONG giảm 15%." />}
      <ul className="grid gap-2 sm:grid-cols-2">
        {pr.data?.promotions.map((p) => (
          <li key={p.id} className={`card p-3 ${p.active ? '' : 'opacity-50'}`}>
            <div className="flex items-start gap-2"><div className="min-w-0 flex-1"><b>{p.name}</b> {p.code && <span className="tag tag-neutral">Mã: {p.code}</span>} {!p.active && <span className="tag tag-neutral">Tắt</span>}<p className="text-sm text-mocha">{describe(p)}</p></div>
              <button className="btn btn-ghost btn-sm" onClick={() => { setErr(''); setF({ id: p.id, name: p.name, code: p.code, type: p.type, value: String(p.value), scope: p.scope, target: p.target, min_total: p.min_total ? String(p.min_total) : '', min_qty: p.min_qty ? String(p.min_qty) : '', time_from: p.time_from, time_to: p.time_to, days: p.days, date_from: p.date_from, date_to: p.date_to, active: p.active }); }}>Sửa</button>
              <button className="btn btn-danger btn-sm" onClick={() => del(p)}>Xóa</button></div>
          </li>
        ))}
      </ul>
      <Modal open={!!f} onClose={() => setF(null)} title={f?.id ? 'Sửa khuyến mãi' : 'Thêm khuyến mãi'} wide>
        {f && <div className="space-y-3">
          {err && <p className="rounded-xl bg-danger-soft p-3 text-sm text-danger" role="alert">{err}</p>}
          <div className="grid gap-3 sm:grid-cols-2">
            <div><label className="label" htmlFor="pn">Tên</label><input id="pn" className="input" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
            <div><label className="label" htmlFor="pc">Mã voucher (để trống = tự áp dụng)</label><input id="pc" className="input uppercase" value={f.code} onChange={(e) => setF({ ...f, code: e.target.value.replace(/\s/g, '') })} /></div>
            <div><label className="label" htmlFor="pt">Kiểu giảm</label><select id="pt" className="input" value={f.type} onChange={(e) => setF({ ...f, type: e.target.value as Form['type'] })}><option value="percent">Phần trăm (%)</option><option value="amount">Số tiền (đ)</option></select></div>
            <div><label className="label" htmlFor="pv">Giá trị</label><input id="pv" inputMode="numeric" className="input" value={f.value} onChange={(e) => setF({ ...f, value: e.target.value.replace(/[^\d]/g, '') })} /></div>
            <div><label className="label" htmlFor="ps">Áp dụng cho</label><select id="ps" className="input" value={f.scope} onChange={(e) => setF({ ...f, scope: e.target.value as Form['scope'], target: '' })}><option value="order">Toàn đơn</option><option value="category">Một nhóm món</option><option value="recipe">Một món</option><option value="combo">Combo (đủ các món)</option></select></div>
            {f.scope === 'category' && <div><label className="label" htmlFor="pg">Nhóm</label><select id="pg" className="input" value={f.target} onChange={(e) => setF({ ...f, target: e.target.value })}><option value="">— Chọn —</option>{rc.data?.categories.map((c) => <option key={c.name}>{c.name}</option>)}</select></div>}
            {f.scope === 'recipe' && <div><label className="label" htmlFor="pr">Món</label><select id="pr" className="input" value={f.target} onChange={(e) => setF({ ...f, target: e.target.value })}><option value="">— Chọn —</option>{recipes.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}</select></div>}
          </div>
          {f.scope === 'combo' && <div><p className="label">Chọn các món trong combo (≥ 2)</p><div className="flex max-h-40 flex-wrap gap-1 overflow-auto">{recipes.map((r) => <button type="button" key={r.id} onClick={() => toggleCombo(r.id)} className={`rounded-full border px-3 py-1 text-sm ${f.target.split(',').includes(String(r.id)) ? 'border-coffee bg-coffee text-white' : 'border-[#eadfcd]'}`}>{r.name}</button>)}</div></div>}
          <details className="rounded-xl border border-[#eadfcd] p-3" open={!!(f.min_total || f.min_qty || f.time_from || f.days || f.date_from || f.date_to)}>
            <summary className="cursor-pointer font-semibold">Điều kiện (tuỳ chọn)</summary>
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <div><label className="label" htmlFor="pm">Đơn tối thiểu (đ)</label><input id="pm" inputMode="numeric" className="input" value={f.min_total} onChange={(e) => setF({ ...f, min_total: e.target.value.replace(/[^\d]/g, '') })} /></div>
              <div><label className="label" htmlFor="pq">Số ly tối thiểu</label><input id="pq" inputMode="numeric" className="input" value={f.min_qty} onChange={(e) => setF({ ...f, min_qty: e.target.value.replace(/[^\d]/g, '') })} /></div>
              <div><label className="label" htmlFor="pf">Từ giờ (happy hour)</label><input id="pf" type="time" className="input" value={f.time_from} onChange={(e) => setF({ ...f, time_from: e.target.value })} /></div>
              <div><label className="label" htmlFor="pto">Đến giờ</label><input id="pto" type="time" className="input" value={f.time_to} onChange={(e) => setF({ ...f, time_to: e.target.value })} /></div>
              <div><label className="label" htmlFor="pdf">Từ ngày</label><input id="pdf" type="date" className="input" value={f.date_from} onChange={(e) => setF({ ...f, date_from: e.target.value })} /></div>
              <div><label className="label" htmlFor="pdt">Đến ngày</label><input id="pdt" type="date" className="input" value={f.date_to} onChange={(e) => setF({ ...f, date_to: e.target.value })} /></div>
            </div>
            <p className="label mt-3">Thứ trong tuần (không chọn = mọi ngày)</p>
            <div className="flex flex-wrap gap-1">{DOW.map((d, i) => <button type="button" key={d} onClick={() => toggleDay(i + 1)} className={`h-10 w-12 rounded-xl border text-sm font-semibold ${f.days.split(',').includes(String(i + 1)) ? 'border-coffee bg-coffee text-white' : 'border-[#eadfcd]'}`}>{d}</button>)}</div>
          </details>
          <label className="flex items-center gap-2"><input type="checkbox" className="h-5 w-5 accent-[#7fa886]" checked={f.active} onChange={(e) => setF({ ...f, active: e.target.checked })} /> Đang bật</label>
          <button className="btn btn-green btn-lg w-full" onClick={save} disabled={busy}>{busy ? <Spinner /> : 'Lưu'}</button>
        </div>}
      </Modal>
    </div>
  );
}

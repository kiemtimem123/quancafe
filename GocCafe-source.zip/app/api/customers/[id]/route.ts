import { z } from 'zod';
import { ApiError, handle, parseId } from '@/lib/api';
import { audit } from '@/lib/audit';
import { getDb } from '@/lib/db';
import type { Customer } from '@/lib/customers';

type Ctx = { params: Promise<{ id: string }> };
export const dynamic = 'force-dynamic';
export const GET = (_r: Request, ctx: Ctx) => handle(async () => {
  const id = parseId((await ctx.params).id);
  const db = getDb();
  const customer = db.prepare('SELECT * FROM customers WHERE id=?').get(id) as Customer | undefined;
  if (!customer) throw new ApiError(404, 'Không tìm thấy khách');
  const top = db.prepare(`SELECT i.name, SUM(i.quantity) q FROM order_items i JOIN orders o ON o.id=i.order_id WHERE o.customer_id=? AND o.status='paid' GROUP BY i.name ORDER BY q DESC LIMIT 5`).all(id);
  const orders = db.prepare("SELECT id, order_date, seq, total, points_earned, points_used, created_at FROM orders WHERE customer_id=? AND status='paid' ORDER BY id DESC LIMIT 15").all(id);
  return { customer, top, orders };
}, 'view_dashboard');
export const PUT = (req: Request, ctx: Ctx) => handle(async (u) => {
  const id = parseId((await ctx.params).id);
  const d = z.object({ name: z.string().trim().max(60), points: z.number().int().min(0).max(1e7).optional() }).parse(await req.json());
  const r = getDb().prepare('UPDATE customers SET name=?, points=COALESCE(?, points) WHERE id=?').run(d.name, d.points ?? null, id);
  if (!r.changes) throw new ApiError(404, 'Không tìm thấy khách');
  audit(u, 'update', 'customer', id, `Sửa khách ${d.name}${d.points !== undefined ? ` (điểm → ${d.points})` : ''}`);
  return { ok: true };
}, 'edit_ingredients');

import { handle } from '@/lib/api';
import { findCustomer, loyaltyCfg } from '@/lib/customers';
import { normPhone } from '@/lib/loyalty-pure';

export const dynamic = 'force-dynamic';
/** Tra khách theo số điện thoại (mọi vai trò — dùng ở màn hình bán hàng). */
export const GET = (req: Request) => handle(() => {
  const phone = normPhone(new URL(req.url).searchParams.get('phone') ?? '');
  return { customer: phone ? findCustomer(phone) ?? null : null, loyalty: loyaltyCfg() };
});

import { handle } from '@/lib/api';
import { getDb } from '@/lib/db';
import type { Customer } from '@/lib/customers';

export const dynamic = 'force-dynamic';
export const GET = (req: Request) => handle(() => {
  const q = (new URL(req.url).searchParams.get('q') ?? '').trim();
  const like = `%${q.replace(/[%_]/g, '')}%`;
  const rows = getDb().prepare(`SELECT * FROM customers ${q ? 'WHERE phone LIKE ? OR name LIKE ?' : ''} ORDER BY COALESCE(last_visit, created_at) DESC LIMIT 300`).all(...(q ? [like, like] : [])) as Customer[];
  const t = getDb().prepare('SELECT COUNT(*) n, COALESCE(SUM(points),0) p, COALESCE(SUM(total_spent),0) s FROM customers').get() as { n: number; p: number; s: number };
  return { customers: rows, totals: t };
}, 'view_dashboard');

import { z } from 'zod';
import { handle } from '@/lib/api';
import { createOrder, listOrders, lastShiftEnd } from '@/lib/orders';
import { can } from '@/lib/roles';
import { vnDate } from '@/lib/time';

export const dynamic = 'force-dynamic';
export const GET = (req: Request) => handle((u) => {
  const d = new URL(req.url).searchParams.get('date') ?? '';
  const date = /^\d{4}-\d{2}-\d{2}$/.test(d) ? d : vnDate();
  const orders = listOrders(date).map((o) => (can(u.role, 'view_cost') ? o : { ...o, items: o.items.map((i) => ({ ...i, unit_cost: 0 })) }));
  return { date, orders, closed_until: lastShiftEnd() };
});

const schema = z.object({
  key: z.string().max(64).optional(),
  table_name: z.string().trim().min(1).max(30).default('Mang đi'),
  note: z.string().max(200).optional(),
  payment: z.enum(['cash', 'transfer']),
  cash_received: z.coerce.number().min(0).max(1e9).optional(),
  discount: z.object({ type: z.enum(['amount', 'percent']), value: z.coerce.number().min(0).max(1e9) }).optional(),
  items: z.array(z.object({ recipe_id: z.number().int().positive(), size: z.enum(['S', 'M', 'L']), quantity: z.number().int().min(1).max(100), note: z.string().max(120).optional(), options: z.array(z.object({ id: z.number().int().positive(), qty: z.number().int().min(1).max(10) })).max(20).optional() })).min(1, 'Đơn chưa có món nào').max(60),
  force: z.boolean().optional(),
  offline: z.boolean().optional(),
  promo_code: z.string().trim().max(40).optional(),
  promo: z.object({ label: z.string().max(60), discount: z.number().min(0).max(1e9) }).optional(),
  customer: z.object({ phone: z.string().max(20), name: z.string().max(60).optional() }).optional(),
  redeem_points: z.number().int().min(0).max(1e6).optional(),
  at: z.string().max(40).optional(),
});
export const POST = (req: Request) => handle(async (u) => {
  const d = schema.parse(await req.json());
  // chỉ quản lý/quản trị viên được bán dù kho báo thiếu
  return { order: createOrder(d, u, can(u.role, 'edit_ingredients')) };
});

import { z } from 'zod';
import { handle } from '@/lib/api';
import { closeShift, shiftSummary } from '@/lib/orders';
import { getDb } from '@/lib/db';

export const dynamic = 'force-dynamic';
export const GET = () => handle(() => ({
  summary: shiftSummary(),
  history: getDb().prepare('SELECT id, closed_at, closed_by, order_count, void_count, cash_total, transfer_total, opening_cash, expected_cash, counted_cash, diff, note FROM shift_closes ORDER BY id DESC LIMIT 10').all(),
}));
const schema = z.object({ opening_cash: z.coerce.number().min(0).max(1e10).default(0), counted_cash: z.coerce.number().min(0).max(1e10).optional(), note: z.string().trim().max(200).default('') });
export const POST = (req: Request) => handle(async (u) => ({ shift: closeShift(schema.parse(await req.json()), u) }));

import { z } from 'zod';
import { ApiError, handle, parseId } from '@/lib/api';
import { getOrder, voidOrder } from '@/lib/orders';

type Ctx = { params: Promise<{ id: string }> };
export const dynamic = 'force-dynamic';
export const GET = (_r: Request, ctx: Ctx) => handle(async () => {
  const o = getOrder(parseId((await ctx.params).id));
  if (!o) throw new ApiError(404, 'Không tìm thấy đơn');
  return { order: { ...o, items: o.items.map((i) => ({ ...i, unit_cost: 0 })) } };
});
/** Hủy đơn (hoàn kho + xóa doanh thu). */
export const DELETE = (req: Request, ctx: Ctx) => handle(async (u) => {
  const id = parseId((await ctx.params).id);
  const { reason } = z.object({ reason: z.string().trim().max(200).default('') }).parse(await req.json().catch(() => ({})));
  return { order: voidOrder(id, reason, u) };
}, 'void_order');

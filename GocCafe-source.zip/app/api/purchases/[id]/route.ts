import ExcelJS from 'exceljs';
import { z } from 'zod';
import { ApiError, handle, parseId } from '@/lib/api';
import { audit } from '@/lib/audit';
import { getSessionUser } from '@/lib/auth';
import { can } from '@/lib/roles';
import { getDb } from '@/lib/db';
import { xlsxResponse } from '@/lib/download';
import { loadPOs, poText } from '@/lib/purchases';
import { getSetting } from '@/lib/settings';

type Ctx = { params: Promise<{ id: string }> };
export const dynamic = 'force-dynamic';

async function excel(id: number) {
  const po = loadPOs([id])[0];
  if (!po) throw new ApiError(404, 'Không tìm thấy đơn đặt hàng');
  const shop = getSetting('shop_name', 'Góc Cafe');
  {
    const wb = new ExcelJS.Workbook();
    const ws = wb.addWorksheet('Đơn đặt hàng');
    ws.addRow([`${shop} — Đơn đặt hàng #${po.id} — ${po.supplier}`]); ws.getRow(1).font = { bold: true, size: 14 };
    ws.addRow(['Nguyên liệu', 'Đơn vị', 'Số lượng', 'Đơn giá', 'Thành tiền']); ws.getRow(2).font = { bold: true };
    po.lines.forEach((l, k) => { const r = k + 3; ws.addRow([l.name, l.unit, l.qty, l.price]).getCell(5).value = { formula: `C${r}*D${r}`, result: Math.round(l.qty * l.price) }; });
    const last = po.lines.length + 2;
    ws.addRow(['', '', '', 'Tổng', { formula: `SUM(E3:E${last})`, result: po.total }]).font = { bold: true };
    [30, 10, 12, 14, 16].forEach((w, i) => (ws.getColumn(i + 1).width = w));
    for (let r = 3; r <= last + 1; r++) { ws.getCell(`D${r}`).numFmt = '#,##0"đ"'; ws.getCell(`E${r}`).numFmt = '#,##0"đ"'; }
    return xlsxResponse(Buffer.from(await wb.xlsx.writeBuffer()), `dat-hang-${po.id}.xlsx`);
  }
}

export async function GET(req: Request, ctx: Ctx) {
  if (new URL(req.url).searchParams.get('format') === 'xlsx') {
    const u = await getSessionUser();
    if (!u) return Response.json({ error: 'Bạn cần đăng nhập' }, { status: 401 });
    if (!can(u.role, 'edit_ingredients')) return Response.json({ error: 'Bạn không có quyền' }, { status: 403 });
    try { return await excel(parseId((await ctx.params).id)); }
    catch (e) { return Response.json({ error: e instanceof Error ? e.message : 'Lỗi' }, { status: e instanceof ApiError ? e.status : 500 }); }
  }
  return handle(async () => {
    const po = loadPOs([parseId((await ctx.params).id)])[0];
    if (!po) throw new ApiError(404, 'Không tìm thấy đơn đặt hàng');
    return { order: po, text: poText(po, getSetting('shop_name', 'Góc Cafe')) };
  }, 'edit_ingredients');
}

const putSchema = z.object({
  status: z.enum(['draft', 'sent', 'cancelled']).optional(), note: z.string().max(200).optional(),
  lines: z.array(z.object({ ingredient_id: z.number().int().positive(), qty: z.coerce.number().gt(0).max(1e7), price: z.coerce.number().min(0).max(1e9) })).min(1).optional(),
});
export const PUT = (req: Request, ctx: Ctx) => handle(async (u) => {
  const id = parseId((await ctx.params).id);
  const d = putSchema.parse(await req.json());
  const db = getDb();
  const po = db.prepare('SELECT status FROM purchase_orders WHERE id=?').get(id) as { status: string } | undefined;
  if (!po) throw new ApiError(404, 'Không tìm thấy đơn đặt hàng');
  if (['received', 'partial'].includes(po.status) && (d.lines || d.status)) throw new ApiError(400, 'Đơn đã nhận hàng, không sửa được nữa');
  db.transaction(() => {
    if (d.status) db.prepare('UPDATE purchase_orders SET status=? WHERE id=?').run(d.status, id);
    if (d.note !== undefined) db.prepare('UPDATE purchase_orders SET note=? WHERE id=?').run(d.note, id);
    if (d.lines) {
      db.prepare('DELETE FROM purchase_order_lines WHERE po_id=?').run(id);
      const ins = db.prepare('INSERT INTO purchase_order_lines (po_id, ingredient_id, qty, price) VALUES (?,?,?,?)');
      for (const l of d.lines) ins.run(id, l.ingredient_id, l.qty, l.price);
    }
  })();
  audit(u, 'update', 'purchase', id, `Cập nhật đơn đặt hàng #${id}${d.status ? ` → ${d.status}` : ''}`);
  return { order: loadPOs([id])[0] };
}, 'edit_ingredients');

export const DELETE = (_r: Request, ctx: Ctx) => handle(async (u) => {
  const id = parseId((await ctx.params).id);
  const db = getDb();
  const po = db.prepare('SELECT status FROM purchase_orders WHERE id=?').get(id) as { status: string } | undefined;
  if (!po) throw new ApiError(404, 'Không tìm thấy đơn đặt hàng');
  if (po.status === 'received' || po.status === 'partial') throw new ApiError(400, 'Đơn đã nhận hàng — không xóa để giữ lịch sử');
  db.prepare('DELETE FROM purchase_orders WHERE id=?').run(id);
  audit(u, 'delete', 'purchase', id, `Xóa đơn đặt hàng #${id}`);
  return { ok: true };
}, 'edit_ingredients');

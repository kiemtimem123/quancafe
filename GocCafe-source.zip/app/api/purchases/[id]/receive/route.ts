import { z } from 'zod';
import { handle, parseId } from '@/lib/api';
import { audit } from '@/lib/audit';
import { loadPOs, receivePO } from '@/lib/purchases';

export const dynamic = 'force-dynamic';
const schema = z.object({ lines: z.array(z.object({ line_id: z.number().int().positive(), qty: z.coerce.number().min(0).max(1e7), price: z.coerce.number().min(0).max(1e9).optional(), expires_on: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional() })).min(1) });
/** Nhận hàng → nhập kho (có lô + hạn sử dụng, cập nhật giá nhập thực tế). */
export const POST = (req: Request, ctx: { params: Promise<{ id: string }> }) => handle(async (u) => {
  const id = parseId((await ctx.params).id);
  const d = schema.parse(await req.json());
  receivePO(id, d.lines, u.name);
  audit(u, 'purchase', 'purchase', id, `Nhận hàng đơn đặt #${id} (${d.lines.filter((l) => l.qty > 0).length} dòng)`);
  return { order: loadPOs([id])[0] };
}, 'edit_ingredients');

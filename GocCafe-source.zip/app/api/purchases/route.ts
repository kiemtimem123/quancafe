import { z } from 'zod';
import { ApiError, handle } from '@/lib/api';
import { audit } from '@/lib/audit';
import { createPO, loadPOs, suggestLines } from '@/lib/purchases';

export const dynamic = 'force-dynamic';
export const GET = () => handle(() => ({ orders: loadPOs() }), 'edit_ingredients');

const schema = z.union([
  z.object({ from_shopping: z.literal(true) }),
  z.object({ supplier: z.string().trim().min(1, 'Nhập nhà cung cấp').max(80), note: z.string().max(200).default(''), lines: z.array(z.object({ ingredient_id: z.number().int().positive(), qty: z.coerce.number().gt(0).max(1e7), price: z.coerce.number().min(0).max(1e9).optional() })).min(1, 'Thêm ít nhất một mặt hàng') }),
]);
/** Tạo đơn đặt hàng — hoặc ("from_shopping") tự tạo mỗi nhà cung cấp một đơn từ danh sách cần mua. */
export const POST = (req: Request) => handle(async (u) => {
  const d = schema.parse(await req.json());
  const ids: number[] = [];
  if ('from_shopping' in d) {
    const by = new Map<string, ReturnType<typeof suggestLines>>();
    for (const l of suggestLines()) (by.get(l.supplier) ?? by.set(l.supplier, []).get(l.supplier)!).push(l);
    if (!by.size) throw new ApiError(400, 'Hiện không có nguyên liệu nào dưới mức tồn tối thiểu');
    for (const [s, ls] of by) ids.push(createPO(s, ls, u.name));
  } else ids.push(createPO(d.supplier, d.lines, u.name, d.note));
  audit(u, 'create', 'purchase', ids[0], `Tạo ${ids.length} đơn đặt hàng NCC`);
  return { ids, orders: loadPOs() };
}, 'edit_ingredients');

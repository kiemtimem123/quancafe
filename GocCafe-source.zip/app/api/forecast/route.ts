import { handle } from '@/lib/api';
import { forecast } from '@/lib/reports';
export const dynamic = 'force-dynamic';
export const GET = (req: Request) => handle(() => {
  const sp = new URL(req.url).searchParams;
  return forecast(Math.min(60, Math.max(7, Number(sp.get('window')) || 28)), Math.min(30, Math.max(3, Number(sp.get('horizon')) || 14)));
}, 'edit_ingredients');

import { handle } from '@/lib/api';
import { listCustomerOrders } from '@/lib/customer-orders';
export const dynamic = 'force-dynamic';
export const GET = (req: Request) => handle(() => ({ pending: listCustomerOrders('pending'), recent: new URL(req.url).searchParams.get('recent') ? listCustomerOrders('recent') : [] }));

import { z } from 'zod';
import { handle, parseId } from '@/lib/api';
import { decideCustomerOrder } from '@/lib/customer-orders';
import { can } from '@/lib/roles';

type Ctx = { params: Promise<{ id: string }> };
export const dynamic = 'force-dynamic';
const schema = z.object({ action: z.enum(['accept', 'reject']), payment: z.enum(['cash', 'transfer']).optional(), reason: z.string().max(120).optional(), force: z.boolean().optional() });
export const POST = (req: Request, ctx: Ctx) => handle(async (u) => {
  const id = parseId((await ctx.params).id);
  return decideCustomerOrder(id, schema.parse(await req.json()), u, can(u.role, 'edit_ingredients'));
});

import { handle } from '@/lib/api';
import { pendingCount } from '@/lib/customer-orders';
export const dynamic = 'force-dynamic';
export const GET = () => handle(() => ({ pending: pendingCount() }));

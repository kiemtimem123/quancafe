import { z } from 'zod';
import { handle } from '@/lib/api';
import { canSeeCost } from '@/lib/redact';
import { aiAssistant, localAssistant } from '@/lib/assistant';

export const dynamic = 'force-dynamic';
export const POST = (req: Request) => handle(async (u) => {
  const { message } = z.object({ message: z.string().trim().min(2, 'Hãy nhập câu hỏi').max(1000) }).parse(await req.json());
  const local = localAssistant(message);
  const seeCost = canSeeCost(u);
  if (!seeCost) local.suggestions = local.suggestions.map((s) => ({ ...s, cost: 0, profit: 0, margin: 0 }));
  let ai: string | null = null;
  let ai_error: string | null = null;
  try { ai = seeCost ? await aiAssistant(message) : null; } catch (e) { ai_error = e instanceof Error ? e.message : 'Lỗi AI'; }
  return { ...local, ai, ai_error, ai_enabled: !!process.env.ANTHROPIC_API_KEY };
});

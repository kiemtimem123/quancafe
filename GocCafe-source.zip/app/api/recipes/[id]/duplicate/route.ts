import { audit } from '@/lib/audit';
import { ApiError, handle, parseId } from '@/lib/api';
import { loadRecipes, saveRecipe } from '@/lib/recipes';
import { getDb } from '@/lib/db';
import { copyImage } from '@/lib/images';

export const POST = (_r: Request, ctx: { params: Promise<{ id: string }> }) => handle(async (u) => {
  const id = parseId((await ctx.params).id);
  const db = getDb();
  const r = loadRecipes(db, [id])[0];
  if (!r) throw new ApiError(404, 'Không tìm thấy món');
  let name = `${r.name} (bản sao)`;
  for (let n = 2; db.prepare('SELECT 1 FROM recipes WHERE name=?').get(name); n++) name = `${r.name} (bản sao ${n})`;
  const nid = saveRecipe({
    name, category: r.category, description: r.description, image: copyImage(r.image), difficulty: r.difficulty,
    preparation_time: r.preparation_time, instructions: r.instructions,
    sizes: r.sizes.map((s) => ({ name: s.name, selling_price: s.selling_price, lines: s.lines.map((l) => ({ ingredient_id: l.ingredient_id, quantity: l.quantity, unit: l.unit, optional: l.optional })) })),
  });
  audit(u, 'create', 'recipe', nid, `Nhân bản món ${r.name}`);
  return { recipe: loadRecipes(db, [nid])[0] };
}, 'edit_recipes');

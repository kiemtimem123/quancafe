import { ApiError, handle, parseId } from '@/lib/api';
import { getDb } from '@/lib/db';

export const POST = (_r: Request, ctx: { params: Promise<{ id: string }> }) => handle(async () => {
  const id = parseId((await ctx.params).id);
  const db = getDb();
  const cur = db.prepare('SELECT favorite FROM recipes WHERE id=?').get(id) as { favorite: number } | undefined;
  if (!cur) throw new ApiError(404, 'Không tìm thấy món');
  const next = cur.favorite ? 0 : 1;
  db.prepare('UPDATE recipes SET favorite=? WHERE id=?').run(next, id);
  return { favorite: !!next };
});

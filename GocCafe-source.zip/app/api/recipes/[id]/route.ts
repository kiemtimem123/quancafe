import { audit } from '@/lib/audit';
import { ApiError, handle, parseId, recipeSchema } from '@/lib/api';
import { loadRecipes, saveRecipe, validateLines } from '@/lib/recipes';
import { getDb } from '@/lib/db';
import { removeImage } from '@/lib/images';
import { canSeeCost, redactRecipe } from '@/lib/redact';

type Ctx = { params: Promise<{ id: string }> };
export const dynamic = 'force-dynamic';

export const GET = (_r: Request, ctx: Ctx) => handle(async (u) => {
  const id = parseId((await ctx.params).id);
  const recipe = loadRecipes(getDb(), [id])[0];
  if (!recipe) throw new ApiError(404, 'Không tìm thấy món');
  return { recipe: canSeeCost(u) ? recipe : redactRecipe(recipe) };
});
export const PUT = (req: Request, ctx: Ctx) => handle(async (u) => {
  const id = parseId((await ctx.params).id);
  if (!getDb().prepare('SELECT 1 FROM recipes WHERE id=?').get(id)) throw new ApiError(404, 'Không tìm thấy món');
  const d = recipeSchema.parse(await req.json());
  const err = validateLines(d);
  if (err) throw new ApiError(400, err);
  saveRecipe(d, id);
  audit(u, 'update', 'recipe', id, `Sửa món ${d.name}`);
  return { recipe: loadRecipes(getDb(), [id])[0] };
}, 'edit_recipes');
export const DELETE = (_r: Request, ctx: Ctx) => handle(async (u) => {
  const id = parseId((await ctx.params).id);
  const db = getDb();
  const img = (db.prepare('SELECT image FROM recipes WHERE id=?').get(id) as { image: string } | undefined)?.image;
  const nm = (db.prepare('SELECT name FROM recipes WHERE id=?').get(id) as { name: string } | undefined)?.name ?? `#${id}`;
  const r = db.prepare('DELETE FROM recipes WHERE id=?').run(id);
  if (!r.changes) throw new ApiError(404, 'Không tìm thấy món');
  removeImage(img);
  audit(u, 'delete', 'recipe', id, `Xóa món ${nm}`);
  return { ok: true };
}, 'edit_recipes');

import { z } from 'zod';
import { ApiError, handle, parseId } from '@/lib/api';
import { getDb } from '@/lib/db';
import { loadIngredients, loadRecipes } from '@/lib/recipes';
import { moveStock } from '@/lib/stock';
import { audit } from '@/lib/audit';
import { makeConsumer } from '@/lib/consume';

const schema = z.object({ size: z.enum(['S', 'M', 'L']), quantity: z.coerce.number().int().min(1).max(100).default(1), force: z.boolean().optional() });

/** "Pha món này": trừ tồn kho (tự dùng nguyên liệu thay thế nếu thiếu) và ghi nhận số ly đã pha. */
export const POST = (req: Request, ctx: { params: Promise<{ id: string }> }) => handle(async (u) => {
  const id = parseId((await ctx.params).id);
  const { size, quantity, force } = schema.parse(await req.json());
  const db = getDb();
  const recipe = loadRecipes(db, [id])[0];
  if (!recipe) throw new ApiError(404, 'Không tìm thấy món');
  const sz = recipe.sizes.find((s) => s.name === size);
  if (!sz) throw new ApiError(400, `Món này chưa có size ${size}`);
  const ings = loadIngredients(db);
  const byId = new Map(ings.map((i) => [i.id, i]));
  const c = makeConsumer(ings);
  c.use(sz, quantity, !!force);
  const { deduct, short } = c.res;
  const subs = c.res.substitutes;
  if (short.length && !force) throw new ApiError(409, `Không đủ tồn kho: ${short.join(', ')}`, { short });
  db.transaction(() => {
    deduct.forEach((base, iid) => {
      const ing = byId.get(iid)!;
      moveStock(iid, -base / ing.pack_size, 'brew', { note: `${recipe.name} (${size}) × ${quantity}`, user: u.name, db });
    });
    db.prepare('INSERT INTO brew_log (recipe_id, size, quantity) VALUES (?,?,?)').run(id, size, quantity);
  })();
  audit(u, 'brew', 'recipe', id, `Pha ${quantity} ly ${recipe.name} (${size})`);
  return { ok: true, short, substitutes: Array.from(new Set(subs)) };
});

import { audit } from '@/lib/audit';
import { handle, recipeSchema, ApiError } from '@/lib/api';
import { loadRecipes, saveRecipe, validateLines } from '@/lib/recipes';
import { getDb } from '@/lib/db';
import { canSeeCost, redactRecipe } from '@/lib/redact';

export const dynamic = 'force-dynamic';
export const GET = () => handle((u) => {
  const db = getDb();
  return { recipes: loadRecipes(db).map((r) => (canSeeCost(u) ? r : redactRecipe(r))), categories: db.prepare('SELECT name, icon FROM categories ORDER BY id').all() };
});
export const POST = (req: Request) => handle(async (u) => {
  const d = recipeSchema.parse(await req.json());
  const err = validateLines(d);
  if (err) throw new ApiError(400, err);
  const id = saveRecipe(d);
  audit(u, 'create', 'recipe', id, `Thêm món ${d.name}`);
  return { recipe: loadRecipes(getDb(), [id])[0] };
}, 'edit_recipes');

import { ApiError, handle } from '@/lib/api';
import { commitRecipePlan, parseRecipeFile, planRecipeImport } from '@/lib/recipe-import';

export const POST = (req: Request) => handle(async (u) => {
  let form: FormData;
  try { form = await req.formData(); } catch { throw new ApiError(400, 'Dữ liệu tải lên không hợp lệ'); }
  const file = form.get('file');
  if (!(file instanceof File)) throw new ApiError(400, 'Chưa chọn file Excel');
  if (file.size > 5 * 1024 * 1024) throw new ApiError(413, 'File quá lớn (tối đa 5MB)');
  let parsed;
  try { parsed = await parseRecipeFile(Buffer.from(await file.arrayBuffer())); } catch (e) { throw new ApiError(400, e instanceof Error ? e.message : 'Không đọc được file'); }
  const plan = planRecipeImport(parsed.recipes, form.get('on_duplicate') === 'skip' ? 'skip' : 'update');
  const count = (a: string) => plan.filter((p) => p.action === a).length;
  const summary = { create: count('create'), update: count('update'), skip: count('skip'), error: count('error'), total: plan.length };
  if (form.get('mode') === 'commit') {
    if (summary.create + summary.update === 0) throw new ApiError(400, 'Không có món hợp lệ để nhập');
    return { ...commitRecipePlan(plan, u), summary };
  }
  return { format: parsed.format, summary, rows: plan.map((p) => ({ row: p.row, name: p.name, action: p.action, reason: p.reason, warnings: p.warnings, category: p.input?.category, sizes: p.sizes.map((s) => s.name), lines: p.sizes[0]?.lines.length ?? 0, price: p.sizes.find((s) => s.name === 'M')?.price ?? p.sizes[0]?.price })) };
}, 'edit_recipes');

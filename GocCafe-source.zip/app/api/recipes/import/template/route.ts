import ExcelJS from 'exceljs';
import { getSessionUser } from '@/lib/auth';
import { can } from '@/lib/roles';
import { xlsxResponse } from '@/lib/download';

export const dynamic = 'force-dynamic';
export async function GET() {
  const u = await getSessionUser();
  if (!u) return Response.json({ error: 'Bạn cần đăng nhập' }, { status: 401 });
  if (!can(u.role, 'edit_recipes')) return Response.json({ error: 'Bạn không có quyền' }, { status: 403 });
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Công thức');
  ws.addRow(['Món', 'Danh mục', 'Size', 'Giá bán', 'Nguyên liệu', 'Định lượng', 'Đơn vị', 'Tùy chọn (x)', 'Cách làm (mỗi bước 1 dòng)', 'Thời gian (phút)', 'Độ khó']);
  const rows: (string | number)[][] = [
    ['Cà phê sữa đá', 'Cà phê', 'M', 25000, 'Espresso', 45, 'ml', '', 'Cho sữa đặc vào ly\nChiết xuất espresso\nThêm đá', 3, 'Dễ'],
    ['', '', '', '', 'Sữa đặc', 30, 'ml', '', '', '', ''],
    ['', '', '', '', 'Kem tươi (whipping)', 20, 'ml', 'x', '', '', ''],
    ['', '', '', '', 'Ly + ống hút + nắp', 1, 'cái', '', '', '', ''],
    ['Cà phê sữa đá', '', 'L', 31000, 'Espresso', 60, 'ml', '', '', '', ''],
    ['', '', '', '', 'Sữa đặc', 40, 'ml', '', '', '', ''],
    ['', '', '', '', 'Ly + ống hút + nắp', 1, 'cái', '', '', '', ''],
  ];
  rows.forEach((r) => ws.addRow(r));
  ws.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
  ws.getRow(1).eachCell((c) => (c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF6F4E37' } }));
  [26, 14, 8, 12, 26, 12, 8, 14, 40, 14, 10].forEach((w, i) => (ws.getColumn(i + 1).width = w));
  ws.getCell('I2').alignment = { wrapText: true, vertical: 'top' };
  const help = wb.addWorksheet('Hướng dẫn');
  ['Mỗi nguyên liệu một dòng. Dòng đầu của món điền Món/Danh mục/Giá bán/Cách làm; các dòng sau để trống cột Món.',
   'Size: S, M hoặc L. Mỗi size một nhóm dòng và một Giá bán.', 'Tên nguyên liệu phải khớp với kho (khớp gần đúng sẽ được báo trong bước xem trước).',
   'Đơn vị bỏ trống = dùng đơn vị pha chế của nguyên liệu. Tùy chọn: ghi x nếu nguyên liệu không bắt buộc (topping, kem tươi…).',
   'Cũng nhập được thẳng bảng tính cost của quán (Tên | NL 1 | NL 2 … mỗi món 3 dòng).'].forEach((t) => help.addRow([t]));
  help.getColumn(1).width = 110;
  const buf = Buffer.from(await wb.xlsx.writeBuffer());
  return xlsxResponse(buf, 'mau-nhap-cong-thuc.xlsx');
}

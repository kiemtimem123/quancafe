import { z } from 'zod';
import { ApiError, handle } from '@/lib/api';
import { audit } from '@/lib/audit';
import { getDb } from '@/lib/db';
import { loadPromos } from '@/lib/promos';
import { promoSchema } from '@/lib/schemas';

export const dynamic = 'force-dynamic';
export const GET = () => handle(() => ({ promotions: loadPromos() }));
export const POST = (req: Request) => handle(async (u) => {
  const d = promoSchema.parse(await req.json());
  if (d.code && getDb().prepare('SELECT 1 FROM promotions WHERE lower(code)=lower(?)').get(d.code)) throw new ApiError(409, 'Mã này đã tồn tại');
  const id = Number(getDb().prepare('INSERT INTO promotions (name, code, type, value, scope, target, min_total, min_qty, time_from, time_to, days, date_from, date_to, active) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
    .run(d.name, d.code, d.type, d.value, d.scope, d.target, d.min_total, d.min_qty, d.time_from, d.time_to, d.days, d.date_from, d.date_to, d.active ? 1 : 0).lastInsertRowid);
  audit(u, 'create', 'promotion', id, `Thêm khuyến mãi ${d.name}`);
  return { promotions: loadPromos() };
}, 'edit_ingredients');

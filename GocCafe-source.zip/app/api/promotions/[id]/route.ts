import { ApiError, handle, parseId } from '@/lib/api';
import { audit } from '@/lib/audit';
import { getDb } from '@/lib/db';
import { loadPromos } from '@/lib/promos';
import { promoSchema } from '@/lib/schemas';

type Ctx = { params: Promise<{ id: string }> };
export const dynamic = 'force-dynamic';
export const PUT = (req: Request, ctx: Ctx) => handle(async (u) => {
  const id = parseId((await ctx.params).id);
  const d = promoSchema.parse(await req.json());
  if (d.code && getDb().prepare('SELECT 1 FROM promotions WHERE lower(code)=lower(?) AND id<>?').get(d.code, id)) throw new ApiError(409, 'Mã này đã tồn tại');
  const r = getDb().prepare('UPDATE promotions SET name=?, code=?, type=?, value=?, scope=?, target=?, min_total=?, min_qty=?, time_from=?, time_to=?, days=?, date_from=?, date_to=?, active=? WHERE id=?')
    .run(d.name, d.code, d.type, d.value, d.scope, d.target, d.min_total, d.min_qty, d.time_from, d.time_to, d.days, d.date_from, d.date_to, d.active ? 1 : 0, id);
  if (!r.changes) throw new ApiError(404, 'Không tìm thấy khuyến mãi');
  audit(u, 'update', 'promotion', id, `Sửa khuyến mãi ${d.name}`);
  return { promotions: loadPromos() };
}, 'edit_ingredients');
export const DELETE = (_r: Request, ctx: Ctx) => handle(async (u) => {
  const id = parseId((await ctx.params).id);
  getDb().prepare('DELETE FROM promotions WHERE id=?').run(id);
  audit(u, 'delete', 'promotion', id, 'Xóa khuyến mãi');
  return { promotions: loadPromos() };
}, 'edit_ingredients');

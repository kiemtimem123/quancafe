import { getSessionUser } from '@/lib/auth';
import { can } from '@/lib/roles';
import { xlsxResponse, today } from '@/lib/download';
import { buildIngredientExport } from '@/lib/xlsx-export';

export const dynamic = 'force-dynamic';
export async function GET() {
  const u = await getSessionUser();
  if (!u) return Response.json({ error: 'Bạn cần đăng nhập' }, { status: 401 });
  if (!can(u.role, 'edit_ingredients')) return Response.json({ error: 'Bạn không có quyền xuất danh sách nguyên liệu' }, { status: 403 });
  return xlsxResponse(await buildIngredientExport(), `nguyen-lieu-${today()}.xlsx`);
}

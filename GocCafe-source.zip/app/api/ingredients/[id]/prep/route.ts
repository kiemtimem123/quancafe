import { z } from 'zod';
import { getDb } from '@/lib/db';
import { ApiError, handle, parseId } from '@/lib/api';
import { loadIngredients, loadPreps } from '@/lib/recipes';
import { toBase } from '@/lib/units';
import { audit } from '@/lib/audit';
import { RECIPE_UNITS } from '@/lib/types';
import { diffMargins, marginSnapshot } from '@/lib/alerts';

type Ctx = { params: Promise<{ id: string }> };
export const dynamic = 'force-dynamic';

const schema = z.object({
  yield_qty: z.coerce.number().gt(0, 'Sản lượng mẻ phải lớn hơn 0').max(1e7),
  instructions: z.string().trim().max(1000).default(''),
  lines: z.array(z.object({ component_id: z.coerce.number().int().positive(), quantity: z.coerce.number().gt(0, 'Định lượng phải lớn hơn 0').max(1e7), unit: z.enum(RECIPE_UNITS) })).min(1, 'Cần ít nhất 1 thành phần'),
});

export const GET = (_r: Request, ctx: Ctx) => handle(async () => {
  const id = parseId((await ctx.params).id);
  return { prep: loadPreps().get(id) ?? null };
});

/** Tạo/sửa công thức bán thành phẩm của một nguyên liệu. */
export const PUT = (req: Request, ctx: Ctx) => handle(async (u) => {
  const id = parseId((await ctx.params).id);
  const d = schema.parse(await req.json());
  const db = getDb();
  const ings = new Map(loadIngredients(db).map((i) => [i.id, i]));
  const me = ings.get(id);
  if (!me) throw new ApiError(404, 'Không tìm thấy nguyên liệu');
  const seen = new Set<number>();
  for (const l of d.lines) {
    const c = ings.get(l.component_id);
    if (!c) throw new ApiError(400, `Thành phần #${l.component_id} không tồn tại`);
    if (c.id === id) throw new ApiError(400, 'Một nguyên liệu không thể là thành phần của chính nó');
    const b = toBase(l.quantity, l.unit);
    if (!b || b.base !== c.base_unit) throw new ApiError(400, `"${c.name}" tính theo ${c.base_unit}, không dùng được đơn vị ${l.unit}`);
    if (seen.has(c.id)) throw new ApiError(400, `"${c.name}" bị lặp`);
    seen.add(c.id);
  }
  // chống vòng lặp: từ các thành phần không được quay lại chính nó
  const preps = loadPreps(db);
  const reach = (from: number, visited = new Set<number>()): boolean => {
    if (from === id) return true;
    if (visited.has(from)) return false;
    visited.add(from);
    return (preps.get(from)?.lines ?? []).some((l) => reach(l.component_id, visited));
  };
  for (const l of d.lines) if (reach(l.component_id)) throw new ApiError(400, `Vòng lặp: "${ings.get(l.component_id)!.name}" đã dùng "${me.name}" làm thành phần`);

  const before = marginSnapshot();
  db.transaction(() => {
    db.prepare('INSERT INTO preps (ingredient_id, yield_qty, instructions) VALUES (?,?,?) ON CONFLICT(ingredient_id) DO UPDATE SET yield_qty=excluded.yield_qty, instructions=excluded.instructions').run(id, d.yield_qty, d.instructions);
    db.prepare('DELETE FROM prep_lines WHERE prep_id=?').run(id);
    const ins = db.prepare('INSERT INTO prep_lines (prep_id, component_id, quantity, unit) VALUES (?,?,?,?)');
    for (const l of d.lines) ins.run(id, l.component_id, l.quantity, l.unit);
  })();
  audit(u, 'prep.update', 'ingredient', id, `Đặt "${me.name}" là bán thành phẩm (${d.lines.length} thành phần, mẻ ${d.yield_qty}${me.base_unit})`);
  const updated = loadIngredients(db).find((i) => i.id === id);
  const { alerts, threshold } = diffMargins(before, marginSnapshot());
  return { prep: loadPreps(db).get(id), unit_cost: updated?.unit_cost ?? 0, alerts, threshold };
}, 'edit_ingredients');

export const DELETE = (_r: Request, ctx: Ctx) => handle(async (u) => {
  const id = parseId((await ctx.params).id);
  const db = getDb();
  const r = db.prepare('DELETE FROM preps WHERE ingredient_id=?').run(id);
  if (!r.changes) throw new ApiError(404, 'Nguyên liệu này không phải bán thành phẩm');
  audit(u, 'prep.delete', 'ingredient', id, 'Bỏ công thức bán thành phẩm (quay về giá nhập)');
  return { ok: true };
}, 'edit_ingredients');

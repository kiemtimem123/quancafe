import { getDb } from '@/lib/db';
import { ApiError, handle, ingredientSchema, parseId } from '@/lib/api';
import { loadIngredient } from '@/lib/recipes';
import { audit } from '@/lib/audit';
import { moveStock, recordPrice } from '@/lib/stock';
import { diffMargins, marginSnapshot } from '@/lib/alerts';

type Ctx = { params: Promise<{ id: string }> };
export const dynamic = 'force-dynamic';

export const PUT = (req: Request, ctx: Ctx) => handle(async (u) => {
  const id = parseId((await ctx.params).id);
  const d = ingredientSchema.parse(await req.json());
  const db = getDb();
  const cur = db.prepare('SELECT name, base_unit, purchase_price, stock_quantity FROM ingredients WHERE id=?').get(id) as { name: string; base_unit: string; purchase_price: number; stock_quantity: number } | undefined;
  if (!cur) throw new ApiError(404, 'Không tìm thấy nguyên liệu');
  if (cur.base_unit !== d.base_unit) {
    const used = db.prepare('SELECT COUNT(*) c FROM recipe_ingredients WHERE ingredient_id=?').get(id) as { c: number };
    const inPrep = db.prepare('SELECT COUNT(*) c FROM prep_lines WHERE component_id=?').get(id) as { c: number };
    if (used.c > 0 || inPrep.c > 0) throw new ApiError(409, 'Không đổi được đơn vị cơ bản (g/ml/cái) khi nguyên liệu đang dùng trong công thức');
  }
  const before = marginSnapshot();
  db.transaction(() => {
    db.prepare(`UPDATE ingredients SET name=?, category=?, unit=?, base_unit=?, pack_size=?, purchase_price=?, minimum_stock=?, supplier=?, note=?, group_name=?, track_stock=?, updated_at=datetime('now') WHERE id=?`)
      .run(d.name, d.category, d.unit, d.base_unit, d.pack_size, d.purchase_price, d.minimum_stock, d.supplier, d.note, d.group_name, d.track_stock ? 1 : 0, id);
    if (d.track_expiry !== undefined) db.prepare('UPDATE ingredients SET track_expiry=? WHERE id=?').run(d.track_expiry ? 1 : 0, id);
    if (d.shelf_life_days !== undefined) db.prepare('UPDATE ingredients SET shelf_life_days=? WHERE id=?').run(d.shelf_life_days, id);
    recordPrice(id, d.purchase_price, db);
    if (Math.abs(d.stock_quantity - cur.stock_quantity) > 1e-9) moveStock(id, d.stock_quantity - cur.stock_quantity, 'edit', { note: 'Sửa tay trong form nguyên liệu', user: u.name, db });
  })();
  const { alerts, threshold } = diffMargins(before, marginSnapshot());
  const ch: string[] = [];
  if (cur.name !== d.name) ch.push(`tên "${cur.name}" → "${d.name}"`);
  if (cur.purchase_price !== d.purchase_price) ch.push(`giá ${cur.purchase_price.toLocaleString('vi-VN')}đ → ${d.purchase_price.toLocaleString('vi-VN')}đ`);
  if (cur.stock_quantity !== d.stock_quantity) ch.push(`tồn ${cur.stock_quantity} → ${d.stock_quantity}`);
  audit(u, 'ingredient.update', 'ingredient', id, `Sửa nguyên liệu "${d.name}"${ch.length ? ': ' + ch.join(', ') : ''}`);
  return { ingredient: loadIngredient(id), alerts, threshold };
}, 'edit_ingredients');

export const DELETE = (_req: Request, ctx: Ctx) => handle(async (u) => {
  const id = parseId((await ctx.params).id);
  const db = getDb();
  const used = db.prepare('SELECT DISTINCT r.name FROM recipe_ingredients ri JOIN recipes r ON r.id=ri.recipe_id WHERE ri.ingredient_id=? ORDER BY r.name').all(id) as { name: string }[];
  if (used.length) throw new ApiError(409, `Không thể xóa: đang dùng trong ${used.length} công thức (${used.slice(0, 4).map((x) => x.name).join(', ')}${used.length > 4 ? '…' : ''})`);
  const inPrep = db.prepare('SELECT DISTINCT i.name FROM prep_lines pl JOIN ingredients i ON i.id=pl.prep_id WHERE pl.component_id=?').all(id) as { name: string }[];
  if (inPrep.length) throw new ApiError(409, `Không thể xóa: là thành phần của bán thành phẩm ${inPrep.map((x) => x.name).join(', ')}`);
  const name = (db.prepare('SELECT name FROM ingredients WHERE id=?').get(id) as { name: string } | undefined)?.name;
  const r = db.prepare('DELETE FROM ingredients WHERE id=?').run(id);
  if (!r.changes) throw new ApiError(404, 'Không tìm thấy nguyên liệu');
  audit(u, 'ingredient.delete', 'ingredient', id, `Xóa nguyên liệu "${name}"`);
  return { ok: true };
}, 'edit_ingredients');

import { z } from 'zod';
import { ApiError, handle, parseId } from '@/lib/api';
import { getDb } from '@/lib/db';
import { loadIngredient } from '@/lib/recipes';
import { moveStock, recordPrice, MOVE_LABEL, type MoveKind } from '@/lib/stock';
import { marginSnapshot, diffMargins } from '@/lib/alerts';
import { audit } from '@/lib/audit';
import { addDays } from '@/lib/batches-pure';
import { vnDate } from '@/lib/time';

export const dynamic = 'force-dynamic';

/** Sổ kho + lịch sử giá của một nguyên liệu. */
export const GET = (_r: Request, ctx: { params: Promise<{ id: string }> }) => handle(async () => {
  const id = parseId((await ctx.params).id);
  const db = getDb();
  if (!loadIngredient(id, db)) throw new ApiError(404, 'Không tìm thấy nguyên liệu');
  const moves = (db.prepare('SELECT id, kind, delta, balance, unit_price, note, user_name, created_at FROM stock_moves WHERE ingredient_id=? ORDER BY id DESC LIMIT 100').all(id) as { kind: MoveKind }[])
    .map((m) => ({ ...m, label: MOVE_LABEL[m.kind] ?? m.kind }));
  const prices = db.prepare('SELECT price, created_at FROM price_history WHERE ingredient_id=? ORDER BY id DESC LIMIT 30').all(id);
  const batches = db.prepare('SELECT id, qty, received_on, expires_on, unit_price, note FROM batches WHERE ingredient_id=? AND qty>0 ORDER BY COALESCE(expires_on, \'9999\'), id').all(id);
  return { moves, prices, batches };
}, 'edit_ingredients');

const schema = z.object({
  kind: z.enum(['purchase', 'adjust', 'waste']),
  quantity: z.coerce.number().min(0).max(1e7), // purchase/waste: lượng; adjust: tồn đếm được
  unit_price: z.coerce.number().min(0).max(1e9).optional(),
  note: z.string().trim().max(200).default(''),
  expires_on: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(), // hạn sử dụng của lô vừa nhập
  received_on: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
});

/** Nhập kho / kiểm kê / hao hụt. */
export const POST = (req: Request, ctx: { params: Promise<{ id: string }> }) => handle(async (u) => {
  const id = parseId((await ctx.params).id);
  const d = schema.parse(await req.json());
  const db = getDb();
  const ing = loadIngredient(id, db);
  if (!ing) throw new ApiError(404, 'Không tìm thấy nguyên liệu');
  if (ing.has_prep && d.unit_price !== undefined) throw new ApiError(400, 'Bán thành phẩm tự tính giá, không nhập giá');
  if (d.kind !== 'adjust' && d.quantity <= 0) throw new ApiError(400, 'Số lượng phải lớn hơn 0');
  const before = marginSnapshot();
  let balance = 0;
  db.transaction(() => {
    if (d.kind === 'purchase') {
      balance = moveStock(id, d.quantity, 'purchase', { note: d.note, unitPrice: d.unit_price ?? null, user: u.name, db, batch: ing.track_expiry ? { expires_on: d.expires_on ?? (ing.shelf_life_days > 0 ? addDays(d.received_on ?? vnDate(), ing.shelf_life_days) : null), received_on: d.received_on } : undefined });
      if (d.unit_price !== undefined && d.unit_price !== ing.purchase_price) {
        db.prepare("UPDATE ingredients SET purchase_price=?, updated_at=datetime('now') WHERE id=?").run(d.unit_price, id);
        recordPrice(id, d.unit_price, db);
      }
    } else if (d.kind === 'waste') {
      balance = moveStock(id, -d.quantity, 'waste', { note: d.note, user: u.name, db });
    } else {
      balance = moveStock(id, d.quantity - ing.stock_quantity, 'adjust', { note: d.note || 'Kiểm kê', user: u.name, db });
    }
  })();
  const { alerts, threshold } = diffMargins(before, marginSnapshot());
  audit(u, d.kind, 'ingredient', id, `${MOVE_LABEL[d.kind]} ${ing.name}: ${d.kind === 'adjust' ? `tồn → ${d.quantity}` : d.quantity} ${ing.unit}${d.unit_price !== undefined ? ` @ ${d.unit_price}đ` : ''}`);
  return { balance, alerts, threshold };
}, 'edit_ingredients');

import { z } from 'zod';
import { getDb } from '@/lib/db';
import { ApiError, handle, parseId } from '@/lib/api';
import { loadIngredients, loadPreps } from '@/lib/recipes';
import { toBase } from '@/lib/units';
import { moveStock } from '@/lib/stock';
import { audit } from '@/lib/audit';

const schema = z.object({ batches: z.coerce.number().int().min(1).max(100).default(1), force: z.boolean().optional() });

/** Làm N mẻ bán thành phẩm: trừ kho thành phần, cộng kho thành phẩm. */
export const POST = (req: Request, ctx: { params: Promise<{ id: string }> }) => handle(async (u) => {
  const id = parseId((await ctx.params).id);
  const { batches, force } = schema.parse(await req.json());
  const db = getDb();
  const prep = loadPreps(db).get(id);
  const ings = new Map(loadIngredients(db).map((i) => [i.id, i]));
  const me = ings.get(id);
  if (!prep || !me) throw new ApiError(404, 'Nguyên liệu này chưa có công thức bán thành phẩm');
  const use = prep.lines.map((l) => {
    const c = ings.get(l.component_id)!;
    const need = ((toBase(l.quantity, l.unit)?.qty ?? 0) * batches) / c.pack_size;
    return { c, need };
  });
  const short = use.filter((x) => x.c.track_stock && x.c.stock_quantity < x.need - 1e-9).map((x) => x.c.name);
  if (short.length && !force) throw new ApiError(409, `Không đủ tồn kho: ${short.join(', ')}`, { short });
  db.transaction(() => {
    for (const x of use) if (x.c.track_stock) moveStock(x.c.id, -x.need, 'prep_use', { note: `Làm ${batches} mẻ ${me.name}`, user: u.name, db });
    moveStock(id, (prep.yield_qty * batches) / me.pack_size, 'prep_make', { note: `${batches} mẻ`, user: u.name, db });
  })();
  audit(u, 'prep.make', 'ingredient', id, `Làm ${batches} mẻ "${me.name}" (+${prep.yield_qty * batches}${me.base_unit})`);
  return { ok: true, short, added: prep.yield_qty * batches };
}, 'edit_ingredients');

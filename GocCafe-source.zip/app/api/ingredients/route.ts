import { getDb } from '@/lib/db';
import { handle, ingredientSchema } from '@/lib/api';
import { loadIngredients, loadIngredient } from '@/lib/recipes';
import { canSeeCost, redactIngredient } from '@/lib/redact';
import { audit } from '@/lib/audit';
import { moveStock, recordPrice } from '@/lib/stock';

export const dynamic = 'force-dynamic';
export const GET = () => handle((u) => ({ ingredients: loadIngredients().map((i) => (canSeeCost(u) ? i : redactIngredient(i))) }));
export const POST = (req: Request) => handle(async (u) => {
  const d = ingredientSchema.parse(await req.json());
  const db = getDb();
  const id = db.transaction(() => {
    const id = Number(db.prepare(`INSERT INTO ingredients (name, category, unit, base_unit, pack_size, purchase_price, stock_quantity, minimum_stock, supplier, note, group_name, track_stock) VALUES (?,?,?,?,?,?,0,?,?,?,?,?)`)
      .run(d.name, d.category, d.unit, d.base_unit, d.pack_size, d.purchase_price, d.minimum_stock, d.supplier, d.note, d.group_name, d.track_stock || d.stock_quantity > 0 ? 1 : 0).lastInsertRowid);
    if (d.track_expiry !== undefined) db.prepare('UPDATE ingredients SET track_expiry=? WHERE id=?').run(d.track_expiry ? 1 : 0, id);
    if (d.shelf_life_days !== undefined) db.prepare('UPDATE ingredients SET shelf_life_days=? WHERE id=?').run(d.shelf_life_days, id);
    recordPrice(id, d.purchase_price, db);
    if (d.stock_quantity > 0) moveStock(id, d.stock_quantity, 'adjust', { note: 'Tồn ban đầu', user: u.name, db });
    return id;
  })();
  audit(u, 'ingredient.create', 'ingredient', id, `Thêm nguyên liệu "${d.name}" (${d.purchase_price.toLocaleString('vi-VN')}đ/${d.unit}, tồn ${d.stock_quantity})`);
  return { ingredient: loadIngredient(id) };
}, 'edit_ingredients');

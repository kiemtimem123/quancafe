import { getSessionUser } from '@/lib/auth';
import { can } from '@/lib/roles';
import { xlsxResponse } from '@/lib/download';
import { buildIngredientTemplate } from '@/lib/xlsx-export';

export const dynamic = 'force-dynamic';
export async function GET() {
  const u = await getSessionUser();
  if (!u) return Response.json({ error: 'Bạn cần đăng nhập' }, { status: 401 });
  if (!can(u.role, 'edit_ingredients')) return Response.json({ error: 'Bạn không có quyền' }, { status: 403 });
  return xlsxResponse(await buildIngredientTemplate(), 'mau-nhap-nguyen-lieu.xlsx');
}

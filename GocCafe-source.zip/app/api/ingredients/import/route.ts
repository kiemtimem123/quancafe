import { ApiError, handle } from '@/lib/api';
import { commitPlan, parseIngredientFile, planImport } from '@/lib/ingredient-import';

const MAX = 5 * 1024 * 1024;
/** multipart: file, mode=preview|commit, on_duplicate=update|skip */
export const POST = (req: Request) => handle(async () => {
  let form: FormData;
  try { form = await req.formData(); } catch { throw new ApiError(400, 'Dữ liệu tải lên không hợp lệ'); }
  const file = form.get('file');
  if (!(file instanceof File)) throw new ApiError(400, 'Chưa chọn file Excel');
  if (file.size > MAX) throw new ApiError(413, 'File quá lớn (tối đa 5MB)');
  const mode = form.get('mode') === 'commit' ? 'commit' : 'preview';
  const onDup = form.get('on_duplicate') === 'skip' ? 'skip' : 'update';
  let parsed;
  try { parsed = await parseIngredientFile(Buffer.from(await file.arrayBuffer())); }
  catch (e) { throw new ApiError(400, e instanceof Error ? e.message : 'Không đọc được file'); }
  const plan = planImport(parsed.rows, onDup);
  const count = (a: string) => plan.filter((p) => p.action === a).length;
  const summary = { create: count('create'), update: count('update'), skip: count('skip'), error: count('error'), total: plan.length };
  if (mode === 'commit') {
    if (summary.create + summary.update === 0) throw new ApiError(400, 'Không có dòng hợp lệ để nhập');
    return { ...commitPlan(plan), summary };
  }
  return { format: parsed.format, sheet: parsed.sheet, summary, rows: plan.map(({ final, ...r }) => ({ ...r, final })) };
}, 'edit_ingredients');

import { handle } from '@/lib/api';
import { profitReport } from '@/lib/reports';
import { vnDate } from '@/lib/time';
export const dynamic = 'force-dynamic';
export const GET = (req: Request) => handle(() => {
  const m = new URL(req.url).searchParams.get('month') ?? '';
  return profitReport(/^\d{4}-(0[1-9]|1[0-2])$/.test(m) ? m : vnDate().slice(0, 7));
}, 'view_cost');

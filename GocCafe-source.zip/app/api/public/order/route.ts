import { z } from 'zod';
import { headers } from 'next/headers';
import { ApiError, handlePublic } from '@/lib/api';
import { customerOrderStatus, submitCustomerOrder } from '@/lib/customer-orders';

export const dynamic = 'force-dynamic';
const schema = z.object({
  table_name: z.string().trim().min(1).max(30),
  note: z.string().max(200).optional(),
  pay_pref: z.enum(['cash', 'transfer']).default('cash'),
  customer_name: z.string().max(60).optional(),
  customer_phone: z.string().max(20).optional(),
  items: z.array(z.object({
    recipe_id: z.number().int().positive(), size: z.enum(['S', 'M', 'L']), quantity: z.number().int().min(1).max(20), note: z.string().max(120).optional(),
    options: z.array(z.object({ id: z.number().int().positive(), qty: z.number().int().min(1).max(5) })).max(6).optional(),
  })).min(1).max(30),
});
export const POST = (req: Request) => handlePublic(async () => {
  const d = schema.parse(await req.json());
  const h = await headers();
  const ip = (h.get('x-forwarded-for') ?? '').split(',')[0].trim() || h.get('x-real-ip') || 'local';
  return submitCustomerOrder(d, ip);
});
export const GET = (req: Request) => handlePublic(() => {
  const sp = new URL(req.url).searchParams;
  const id = Number(sp.get('id')); const token = sp.get('token') ?? '';
  if (!Number.isInteger(id) || !/^[a-f0-9]{32}$/.test(token)) throw new ApiError(400, 'Liên kết không hợp lệ');
  return customerOrderStatus(id, token);
});

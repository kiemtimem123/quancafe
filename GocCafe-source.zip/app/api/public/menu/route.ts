import { handlePublic } from '@/lib/api';
import { publicMenu } from '@/lib/customer-orders';
export const dynamic = 'force-dynamic';
export const GET = () => handlePublic(() => publicMenu());

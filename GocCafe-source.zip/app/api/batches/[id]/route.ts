import { ApiError, handle, parseId } from '@/lib/api';
import { getDb } from '@/lib/db';
import { moveStock } from '@/lib/stock';
import { audit } from '@/lib/audit';

export const dynamic = 'force-dynamic';
/** Hủy bỏ lô (hết hạn/hỏng): trừ khỏi tồn kho, ghi vào sổ hao hụt. */
export const DELETE = (_r: Request, ctx: { params: Promise<{ id: string }> }) => handle(async (u) => {
  const id = parseId((await ctx.params).id);
  const db = getDb();
  const b = db.prepare('SELECT b.*, i.name, i.unit FROM batches b JOIN ingredients i ON i.id=b.ingredient_id WHERE b.id=?').get(id) as { ingredient_id: number; qty: number; expires_on: string | null; name: string; unit: string } | undefined;
  if (!b) throw new ApiError(404, 'Không tìm thấy lô hàng');
  db.transaction(() => {
    db.prepare('UPDATE batches SET qty=0 WHERE id=?').run(id);
    if (b.qty > 0) moveStock(b.ingredient_id, -b.qty, 'waste', { note: `Hủy lô hết hạn${b.expires_on ? ` (HSD ${b.expires_on})` : ''}`, user: u.name, db, skipBatches: true });
  })();
  audit(u, 'waste', 'ingredient', b.ingredient_id, `Hủy lô ${b.name}: ${b.qty} ${b.unit}${b.expires_on ? `, HSD ${b.expires_on}` : ''}`);
  return { ok: true };
}, 'edit_ingredients');

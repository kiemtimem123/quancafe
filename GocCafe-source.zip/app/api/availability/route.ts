import { handle } from '@/lib/api';
import { getDb } from '@/lib/db';
import { loadRecipes } from '@/lib/recipes';
import { suggestAlternatives } from '@/lib/availability';

export const dynamic = 'force-dynamic';
/** Tình trạng từng món (còn / sắp hết / hết) + gợi ý món thay thế cho món hết hàng. */
export const GET = () => handle(() => {
  const recipes = loadRecipes(getDb());
  const slim = (r: (typeof recipes)[number]) => ({ id: r.id, name: r.name, category: r.category, image: r.image, availability: r.availability! });
  const items = recipes.map((r) => ({
    ...slim(r),
    alternatives: r.availability!.status === 'ok' ? [] : suggestAlternatives(r, recipes).map((a) => ({ ...slim(a), margin: undefined })),
  }));
  const rank = { out: 0, low: 1, ok: 2 } as const;
  items.sort((a, b) => rank[a.availability.status] - rank[b.availability.status] || (a.availability.cups ?? 1e9) - (b.availability.cups ?? 1e9) || a.name.localeCompare(b.name, 'vi'));
  return { items, counts: { out: items.filter((i) => i.availability.status === 'out').length, low: items.filter((i) => i.availability.status === 'low').length, ok: items.filter((i) => i.availability.status === 'ok').length } };
});

import { handle } from '@/lib/api';
import { getDb } from '@/lib/db';
import { loadIngredients, loadPreps, loadRecipes } from '@/lib/recipes';
import { canSeeCost, redactIngredient, redactRecipe } from '@/lib/redact';
import { listOrders, lastShiftEnd, shiftSummary } from '@/lib/orders';
import { readSettings } from '@/lib/settings';
import { recentlyRemoved } from '@/lib/expiry';
import { loadOptions } from '@/lib/options';
import { loadPromos } from '@/lib/promos';
import { can } from '@/lib/roles';
import { vnDate } from '@/lib/time';

export const dynamic = 'force-dynamic';

/** Bản sao dữ liệu để máy dùng khi mất mạng (đã ẩn giá vốn nếu tài khoản không được xem). */
export const GET = () => handle((u) => {
  const db = getDb();
  const cost = canSeeCost(u);
  const today = vnDate();
  const yesterday = vnDate(new Date(Date.now() - 864e5));
  const closed = lastShiftEnd();
  const orders = [...listOrders(today), ...listOrders(yesterday)];
  // đơn chưa chốt ca ở các ngày khác cũng cần để chốt ca/hủy đơn cục bộ
  const extra = (db.prepare('SELECT DISTINCT order_date d FROM orders WHERE id>? AND order_date NOT IN (?,?)').all(closed, today, yesterday) as { d: string }[]).flatMap((r) => listOrders(r.d));
  const all = [...orders, ...extra];
  const ded = db.prepare('SELECT order_id, ingredient_id, qty FROM order_deductions WHERE order_id IN (' + (all.length ? all.map(() => '?').join(',') : 'NULL') + ')').all(...all.map((o) => o.id)) as { order_id: number; ingredient_id: number; qty: number }[];
  const dedBy = new Map<number, { ingredient_id: number; qty: number }[]>();
  for (const d of ded) (dedBy.get(d.order_id) ?? dedBy.set(d.order_id, []).get(d.order_id)!).push({ ingredient_id: d.ingredient_id, qty: d.qty });
  const preps = [...loadPreps(db).entries()];
  const ingsAll = loadIngredients(db);
  return {
    at: new Date().toISOString(),
    user: u,
    can_cost: cost,
    recipes: loadRecipes(db).map((r) => (cost ? r : redactRecipe(r))),
    categories: db.prepare('SELECT name, icon FROM categories ORDER BY id').all(),
    ingredients: loadIngredients(db).map((i) => (cost ? i : redactIngredient(i))),
    preps,
    settings: readSettings(),
    qr_image: (db.prepare("SELECT value FROM settings WHERE key='qr_image'").get() as { value: string } | undefined)?.value ?? '',
    removed: recentlyRemoved(),
    options: loadOptions(db, ingsAll).map((o) => (cost ? o : { ...o, cost: 0 })),
    promos: loadPromos(db, true),
    customers: db.prepare('SELECT id, phone, name, points, visits, total_spent, last_visit FROM customers ORDER BY COALESCE(last_visit, created_at) DESC LIMIT 3000').all(),
    batches: db.prepare('SELECT id, ingredient_id, qty, received_on, expires_on, unit_price, note FROM batches WHERE qty>0').all(),
    orders: all.map((o) => ({ ...o, items: cost ? o.items : o.items.map((i) => ({ ...i, unit_cost: 0 })), ded: dedBy.get(o.id) ?? [] })),
    closed_until: closed,
    shift: { summary: shiftSummary(), history: db.prepare('SELECT id, closed_at, closed_by, order_count, void_count, cash_total, transfer_total, opening_cash, expected_cash, counted_cash, diff, note FROM shift_closes ORDER BY id DESC LIMIT 10').all() },
    perms: { void_order: can(u.role, 'void_order') },
  };
});

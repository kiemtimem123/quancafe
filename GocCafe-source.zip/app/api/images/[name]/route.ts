import fs from 'fs';
import { NextResponse } from 'next/server';
import { imagePath } from '@/lib/images';

export const dynamic = 'force-dynamic';
export async function GET(_req: Request, ctx: { params: Promise<{ name: string }> }) {
  // ảnh món được công khai (tên file ngẫu nhiên) để trang khách quét QR hiển thị được
  const { name } = await ctx.params;
  if (!/^[a-f0-9]{32}\.webp$/.test(name)) return NextResponse.json({ error: 'Không tìm thấy ảnh' }, { status: 404 });
  try {
    const buf = fs.readFileSync(imagePath(name));
    return new NextResponse(new Uint8Array(buf), { headers: { 'content-type': 'image/webp', 'cache-control': 'public, max-age=31536000, immutable', 'x-content-type-options': 'nosniff' } });
  } catch {
    return NextResponse.json({ error: 'Không tìm thấy ảnh' }, { status: 404 });
  }
}

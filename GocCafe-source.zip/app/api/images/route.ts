import { ApiError, handle } from '@/lib/api';
import { MAX_UPLOAD, saveImage } from '@/lib/images';

export const POST = (req: Request) => handle(async () => {
  const len = Number(req.headers.get('content-length') ?? 0);
  if (len > MAX_UPLOAD + 512 * 1024) throw new ApiError(413, 'Ảnh quá lớn (tối đa 8MB)');
  let form: FormData;
  try { form = await req.formData(); } catch { throw new ApiError(400, 'Dữ liệu tải lên không hợp lệ'); }
  const file = form.get('file');
  if (!(file instanceof File)) throw new ApiError(400, 'Chưa chọn file ảnh');
  if (file.size > MAX_UPLOAD) throw new ApiError(413, 'Ảnh quá lớn (tối đa 8MB)');
  return { url: await saveImage(Buffer.from(await file.arrayBuffer())) };
}, 'edit_recipes');

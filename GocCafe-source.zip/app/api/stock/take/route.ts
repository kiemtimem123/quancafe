import { z } from 'zod';
import { handle } from '@/lib/api';
import { getDb } from '@/lib/db';
import { moveStock } from '@/lib/stock';
import { audit } from '@/lib/audit';

const schema = z.object({ items: z.array(z.object({ id: z.number().int().positive(), counted: z.coerce.number().min(0).max(1e7) })).min(1).max(1000), note: z.string().trim().max(200).default('Kiểm kê định kỳ') });

/** Kiểm kê hàng loạt: đặt tồn = số đếm được, ghi chênh lệch vào sổ kho. */
export const POST = (req: Request) => handle(async (u) => {
  const { items, note } = schema.parse(await req.json());
  const db = getDb();
  let changed = 0;
  const diffs: { id: number; name: string; delta: number }[] = [];
  db.transaction(() => {
    for (const it of items) {
      const cur = db.prepare('SELECT name, stock_quantity s FROM ingredients WHERE id=?').get(it.id) as { name: string; s: number } | undefined;
      if (!cur || Math.abs(cur.s - it.counted) < 1e-9) continue;
      moveStock(it.id, it.counted - cur.s, 'adjust', { note, user: u.name, db });
      diffs.push({ id: it.id, name: cur.name, delta: it.counted - cur.s });
      changed++;
    }
  })();
  audit(u, 'stocktake', 'ingredient', null, `Kiểm kê ${items.length} nguyên liệu, lệch ${changed}`);
  return { changed, diffs };
}, 'edit_ingredients');

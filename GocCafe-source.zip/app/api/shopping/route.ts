import ExcelJS from 'exceljs';
import { getSessionUser } from '@/lib/auth';
import { can } from '@/lib/roles';
import { xlsxResponse } from '@/lib/download';
import { getDb } from '@/lib/db';
import { loadIngredients } from '@/lib/recipes';
import { getSetting } from '@/lib/settings';

export const dynamic = 'force-dynamic';
function shoppingList() {
  const ings = loadIngredients(getDb());
  const items = ings.filter((i) => !i.has_prep && i.track_stock && i.minimum_stock > 0 && i.stock_quantity < i.minimum_stock * 1.0001)
    .map((i) => {
      const target = i.minimum_stock * 2;
      const qty = Math.max(1, Math.ceil((target - i.stock_quantity) * 100) / 100);
      return { id: i.id, name: i.name, supplier: i.supplier || 'Chưa rõ NCC', unit: i.unit, stock: i.stock_quantity, minimum: i.minimum_stock, qty, price: i.purchase_price, total: Math.round(qty * i.purchase_price) };
    })
    .sort((a, b) => a.supplier.localeCompare(b.supplier, 'vi') || a.name.localeCompare(b.name, 'vi'));
  const preps = ings.filter((i) => i.has_prep && i.track_stock && i.minimum_stock > 0 && i.stock_quantity < i.minimum_stock).map((i) => ({ id: i.id, name: i.name, stock: i.stock_quantity, minimum: i.minimum_stock, unit: i.unit }));
  return { items, preps, total: items.reduce((a, x) => a + x.total, 0) };
}
/** Danh sách cần mua (mua đủ lên gấp đôi mức tối thiểu). ?format=xlsx để tải Excel. */
export async function GET(req: Request) {
  const u = await getSessionUser();
  if (!u) return Response.json({ error: 'Bạn cần đăng nhập' }, { status: 401 });
  if (!can(u.role, 'edit_ingredients')) return Response.json({ error: 'Bạn không có quyền' }, { status: 403 });
  const data = shoppingList();
  if (new URL(req.url).searchParams.get('format') !== 'xlsx') return Response.json(data);
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Cần mua');
  ws.addRow([`${getSetting('shop_name', 'Góc Cafe')} — Danh sách cần mua ${new Date().toLocaleDateString('vi-VN')}`]);
  ws.mergeCells('A1:G1'); ws.getRow(1).font = { bold: true, size: 14 };
  ws.addRow(['Nhà cung cấp', 'Nguyên liệu', 'Đơn vị', 'Tồn hiện tại', 'Cần mua', 'Đơn giá', 'Thành tiền']);
  ws.getRow(2).font = { bold: true };
  data.items.forEach((x, k) => {
    const r = k + 3;
    ws.addRow([x.supplier, x.name, x.unit, x.stock, x.qty, x.price]).getCell(7).value = { formula: `E${r}*F${r}`, result: x.total };
  });
  const last = data.items.length + 2;
  ws.addRow(['', '', '', '', '', 'Tổng', { formula: `SUM(G3:G${Math.max(last, 3)})`, result: data.total }]).font = { bold: true };
  [28, 28, 10, 14, 12, 14, 16].forEach((w, i) => (ws.getColumn(i + 1).width = w));
  for (let r = 3; r <= last + 1; r++) { ws.getCell(`F${r}`).numFmt = '#,##0"đ"'; ws.getCell(`G${r}`).numFmt = '#,##0"đ"'; }
  const buf = Buffer.from(await wb.xlsx.writeBuffer());
  return xlsxResponse(buf, 'danh-sach-can-mua.xlsx');
}

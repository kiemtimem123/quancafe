import { ApiError, handle } from '@/lib/api';
import { insertSales, parseSalesFile } from '@/lib/sales';
import { audit } from '@/lib/audit';

export const POST = (req: Request) => handle(async (u) => {
  let form: FormData;
  try { form = await req.formData(); } catch { throw new ApiError(400, 'Dữ liệu tải lên không hợp lệ'); }
  const file = form.get('file');
  if (!(file instanceof File)) throw new ApiError(400, 'Chưa chọn file Excel');
  if (file.size > 5 * 1024 * 1024) throw new ApiError(413, 'File quá lớn (tối đa 5MB)');
  let rows;
  try { rows = await parseSalesFile(Buffer.from(await file.arrayBuffer())); } catch (e) { throw new ApiError(400, e instanceof Error ? e.message : 'Không đọc được file'); }
  const ok = rows.filter((r) => !r.error).length;
  const summary = { total: rows.length, ok, error: rows.length - ok };
  if (form.get('mode') === 'commit') {
    if (!ok) throw new ApiError(400, 'Không có dòng hợp lệ để nhập');
    const n = insertSales(rows, 'excel');
    audit(u, 'import', 'sales', null, `Nhập Excel bán hàng: ${n} dòng`);
    return { inserted: n, summary };
  }
  return { summary, rows: rows.slice(0, 300) };
}, 'view_dashboard');

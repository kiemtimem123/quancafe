import { z } from 'zod';
import { ApiError, handle } from '@/lib/api';
import { getDb } from '@/lib/db';
import { insertSales, salesReport } from '@/lib/sales';
import { audit } from '@/lib/audit';

export const dynamic = 'force-dynamic';
const ymd = (d: Date) => d.toISOString().slice(0, 10);
export const GET = (req: Request) => handle(() => {
  const sp = new URL(req.url).searchParams;
  const to = /^\d{4}-\d{2}-\d{2}$/.test(sp.get('to') ?? '') ? sp.get('to')! : ymd(new Date());
  const from = /^\d{4}-\d{2}-\d{2}$/.test(sp.get('from') ?? '') ? sp.get('from')! : ymd(new Date(Date.now() - 29 * 864e5));
  const recent = getDb().prepare('SELECT id, recipe_name, size, quantity, revenue, sold_on, source FROM sales ORDER BY id DESC LIMIT 15').all();
  return { ...salesReport(from, to), recent, has_data: (getDb().prepare('SELECT COUNT(*) c FROM sales').get() as { c: number }).c > 0 };
}, 'view_dashboard');

const schema = z.object({ recipe_id: z.number().int().positive(), size: z.enum(['S', 'M', 'L']).default('M'), quantity: z.coerce.number().int().min(1).max(10000), sold_on: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), revenue: z.coerce.number().min(0).max(1e9).optional() });
/** Ghi nhận bán hàng thủ công. */
export const POST = (req: Request) => handle(async (u) => {
  const d = schema.parse(await req.json());
  const r = getDb().prepare('SELECT name FROM recipes WHERE id=?').get(d.recipe_id) as { name: string } | undefined;
  if (!r) throw new ApiError(404, 'Không tìm thấy món');
  const n = insertSales([{ row: 0, date: d.sold_on, recipe: r.name, size: d.size, quantity: d.quantity, revenue: d.revenue, recipe_id: d.recipe_id }], 'manual');
  if (!n) throw new ApiError(400, 'Món chưa có size này');
  audit(u, 'sale', 'sales', d.recipe_id, `Ghi bán ${d.quantity} ly ${r.name} (${d.size}) ngày ${d.sold_on}`);
  return { ok: true };
}, 'view_dashboard');

export const DELETE = (req: Request) => handle((u) => {
  const id = Number(new URL(req.url).searchParams.get('id'));
  if (!Number.isInteger(id) || id <= 0) throw new ApiError(400, 'ID không hợp lệ');
  const ch = getDb().prepare('DELETE FROM sales WHERE id=?').run(id).changes;
  if (!ch) throw new ApiError(404, 'Không tìm thấy dòng bán hàng');
  audit(u, 'delete', 'sales', id, 'Xóa một dòng bán hàng');
  return { ok: true };
}, 'view_dashboard');

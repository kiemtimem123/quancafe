import ExcelJS from 'exceljs';
import { getSessionUser } from '@/lib/auth';
import { can } from '@/lib/roles';
import { xlsxResponse } from '@/lib/download';

export const dynamic = 'force-dynamic';
export async function GET() {
  const u = await getSessionUser();
  if (!u) return Response.json({ error: 'Bạn cần đăng nhập' }, { status: 401 });
  if (!can(u.role, 'view_dashboard')) return Response.json({ error: 'Bạn không có quyền' }, { status: 403 });
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Bán hàng');
  ws.addRow(['Ngày', 'Món', 'Size', 'Số lượng', 'Doanh thu (tuỳ chọn)']);
  ws.addRow(['01/10/2026', 'Cà phê sữa đá', 'M', 42, '']);
  ws.addRow(['01/10/2026', 'Bạc xỉu', 'L', 15, 495000]);
  ws.getRow(1).font = { bold: true };
  [14, 30, 8, 12, 20].forEach((w, i) => (ws.getColumn(i + 1).width = w));
  return xlsxResponse(Buffer.from(await wb.xlsx.writeBuffer()), 'mau-nhap-ban-hang.xlsx');
}

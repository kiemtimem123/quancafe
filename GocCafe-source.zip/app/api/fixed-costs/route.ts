import { handle } from '@/lib/api';
import { audit } from '@/lib/audit';
import { getDb } from '@/lib/db';
import { fixedCostSchema } from '@/lib/schemas';

export const dynamic = 'force-dynamic';
const list = () => getDb().prepare('SELECT id, name, amount, active FROM fixed_costs ORDER BY id').all();
export const GET = () => handle(() => ({ costs: list() }), 'view_cost');
export const POST = (req: Request) => handle(async (u) => {
  const d = fixedCostSchema.parse(await req.json());
  const id = Number(getDb().prepare('INSERT INTO fixed_costs (name, amount, active) VALUES (?,?,?)').run(d.name, d.amount, d.active ? 1 : 0).lastInsertRowid);
  audit(u, 'create', 'fixed_cost', id, `Thêm chi phí cố định ${d.name}: ${d.amount}đ/tháng`);
  return { costs: list() };
}, 'view_cost');

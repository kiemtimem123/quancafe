import { ApiError, handle, parseId } from '@/lib/api';
import { audit } from '@/lib/audit';
import { getDb } from '@/lib/db';
import { fixedCostSchema } from '@/lib/schemas';

type Ctx = { params: Promise<{ id: string }> };
export const dynamic = 'force-dynamic';
const list = () => getDb().prepare('SELECT id, name, amount, active FROM fixed_costs ORDER BY id').all();
export const PUT = (req: Request, ctx: Ctx) => handle(async (u) => {
  const id = parseId((await ctx.params).id);
  const d = fixedCostSchema.parse(await req.json());
  if (!getDb().prepare('UPDATE fixed_costs SET name=?, amount=?, active=? WHERE id=?').run(d.name, d.amount, d.active ? 1 : 0, id).changes) throw new ApiError(404, 'Không tìm thấy khoản chi');
  audit(u, 'update', 'fixed_cost', id, `Sửa chi phí cố định ${d.name}: ${d.amount}đ/tháng`);
  return { costs: list() };
}, 'view_cost');
export const DELETE = (_r: Request, ctx: Ctx) => handle(async (u) => {
  const id = parseId((await ctx.params).id);
  getDb().prepare('DELETE FROM fixed_costs WHERE id=?').run(id);
  audit(u, 'delete', 'fixed_cost', id, 'Xóa chi phí cố định');
  return { costs: list() };
}, 'view_cost');

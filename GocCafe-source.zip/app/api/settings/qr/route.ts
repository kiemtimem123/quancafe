import sharp from 'sharp';
import { ApiError, handle } from '@/lib/api';
import { getDb } from '@/lib/db';
import { audit } from '@/lib/audit';

export const dynamic = 'force-dynamic';
export const GET = () => handle(() => ({ qr_image: (getDb().prepare("SELECT value FROM settings WHERE key='qr_image'").get() as { value: string } | undefined)?.value ?? '' }));

/** Tải ảnh QR chuyển khoản: giữ sắc nét (PNG, nền trắng), lưu thẳng vào cài đặt để in hóa đơn. */
export const POST = (req: Request) => handle(async (u) => {
  let form: FormData;
  try { form = await req.formData(); } catch { throw new ApiError(400, 'Dữ liệu tải lên không hợp lệ'); }
  const file = form.get('file');
  if (!(file instanceof File)) throw new ApiError(400, 'Chưa chọn ảnh QR');
  if (file.size > 8 * 1024 * 1024) throw new ApiError(413, 'Ảnh quá lớn (tối đa 8MB)');
  let png: Buffer;
  try {
    png = await sharp(Buffer.from(await file.arrayBuffer()), { limitInputPixels: 60e6 }).rotate().flatten({ background: '#ffffff' })
      .resize({ width: 700, height: 700, fit: 'inside', withoutEnlargement: true }).png({ palette: true, quality: 90 }).toBuffer();
  } catch { throw new ApiError(400, 'Không đọc được ảnh (dùng JPG/PNG/WebP)'); }
  if (png.length > 600 * 1024) throw new ApiError(400, 'Ảnh QR quá phức tạp, hãy chụp/cắt gọn riêng phần mã QR');
  getDb().prepare("INSERT OR REPLACE INTO settings (key, value) VALUES ('qr_image', ?)").run(`data:image/png;base64,${png.toString('base64')}`);
  audit(u, 'update', 'settings', null, 'Cập nhật ảnh QR chuyển khoản');
  return { ok: true };
}, 'edit_ingredients');

export const DELETE = () => handle((u) => {
  getDb().prepare("DELETE FROM settings WHERE key='qr_image'").run();
  audit(u, 'delete', 'settings', null, 'Xóa ảnh QR chuyển khoản');
  return { ok: true };
}, 'edit_ingredients');

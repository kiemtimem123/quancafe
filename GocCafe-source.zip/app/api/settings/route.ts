import { z } from 'zod';
import { handle } from '@/lib/api';
import { getDb } from '@/lib/db';
import { audit } from '@/lib/audit';

export const dynamic = 'force-dynamic';
import { readSettings as read } from '@/lib/settings';
export const GET = () => handle(read);
const schema = z.object({
  waste_percent: z.coerce.number().min(0).max(50).optional(),
  shop_name: z.string().trim().min(1).max(60).optional(), shop_address: z.string().trim().max(120).optional(), shop_phone: z.string().trim().max(30).optional(),
  receipt_footer: z.string().trim().max(120).optional(), paper_width: z.enum(['58', '80']).optional(), table_count: z.coerce.number().int().min(0).max(60).optional(),
  bank_info: z.string().trim().max(120).optional(), expiry_warn_days: z.coerce.number().int().min(0).max(30).optional(),
  bank_bin: z.string().trim().regex(/^(\d{6})?$/, 'Mã ngân hàng gồm 6 số').optional(), bank_account: z.string().trim().regex(/^(\d{4,20})?$/, 'Số tài khoản chỉ gồm số').optional(), bank_holder: z.string().trim().max(60).optional(),
  qr_order: z.union([z.boolean(), z.enum(['0', '1'])]).transform((v) => (v === true || v === '1' ? '1' : '0')).optional(),
  loyalty_earn_per: z.coerce.number().int().min(0).max(1e7).optional(), loyalty_point_value: z.coerce.number().int().min(0).max(1e6).optional(),
});
export const PUT = (req: Request) => handle(async (u) => {
  const d = schema.parse(await req.json());
  const db = getDb();
  const up = db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)');
  db.transaction(() => { for (const [k, v] of Object.entries(d)) if (v !== undefined) up.run(k, String(v)); })();
  audit(u, 'update', 'settings', null, `Đổi cài đặt: ${Object.keys(d).join(', ')}`);
  return read();
}, 'edit_ingredients');

import { handle } from '@/lib/api';
import { insights } from '@/lib/reports';
export const dynamic = 'force-dynamic';
export const GET = (req: Request) => handle(() => insights(Math.min(180, Math.max(1, Number(new URL(req.url).searchParams.get('days')) || 30))), 'view_dashboard');

import { handle } from '@/lib/api';
import { listExpiry } from '@/lib/expiry';

export const dynamic = 'force-dynamic';
export const GET = () => handle(() => listExpiry());

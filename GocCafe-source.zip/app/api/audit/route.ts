import { handle } from '@/lib/api';
import { getDb } from '@/lib/db';

export const dynamic = 'force-dynamic';
export const GET = (req: Request) => handle(() => {
  const sp = new URL(req.url).searchParams;
  const q = (sp.get('q') ?? '').trim();
  const entity = sp.get('entity') ?? '';
  const limit = Math.min(500, Math.max(1, Number(sp.get('limit')) || 100));
  const where: string[] = [], args: (string | number)[] = [];
  if (q) { where.push('(summary LIKE ? OR user_name LIKE ?)'); args.push(`%${q}%`, `%${q}%`); }
  if (entity) { where.push('entity=?'); args.push(entity); }
  const rows = getDb().prepare(`SELECT id, user_name, action, entity, entity_id, summary, created_at FROM audit_log ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY id DESC LIMIT ?`).all(...args, limit);
  return { rows };
}, 'view_audit');

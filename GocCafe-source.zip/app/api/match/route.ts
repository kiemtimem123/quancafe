import { z } from 'zod';
import { handle } from '@/lib/api';
import { loadRecipes } from '@/lib/recipes';
import { matchRecipes } from '@/lib/match';
import { buildCtx } from '@/lib/match-ctx';
import { getDb } from '@/lib/db';
import { canSeeCost, redactMatch } from '@/lib/redact';

const schema = z.object({ have: z.array(z.number().int()).max(500), priority: z.array(z.number().int()).max(500).default([]) });
export const POST = (req: Request) => handle(async (u) => {
  const { have, priority } = schema.parse(await req.json());
  // nguyên liệu ưu tiên cũng được tính là đang có
  const haveSet = new Set([...have, ...priority]);
  const results = matchRecipes(loadRecipes(getDb()), haveSet, new Set(priority), buildCtx());
  return { results: canSeeCost(u) ? results : results.map(redactMatch) };
});

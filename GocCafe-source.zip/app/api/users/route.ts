import { audit } from '@/lib/audit';
import { z } from 'zod';
import { handle, passwordSchema } from '@/lib/api';
import { hashPassword } from '@/lib/auth';
import { getDb } from '@/lib/db';
import { ROLES } from '@/lib/roles';

export const dynamic = 'force-dynamic';
const list = () => getDb().prepare('SELECT id, name, email, role, active, created_at FROM users ORDER BY id').all();
export const GET = () => handle(() => ({ users: list() }), 'manage_users');
export const POST = (req: Request) => handle(async (me) => {
  const d = z.object({ name: z.string().trim().min(1, 'Nhập tên').max(60), email: z.string().trim().toLowerCase().email('Email không hợp lệ'), password: passwordSchema, role: z.enum(ROLES as [string, ...string[]]) }).parse(await req.json());
  getDb().prepare("INSERT INTO users (name, email, password, role, active, created_at) VALUES (?,?,?,?,1,datetime('now'))").run(d.name, d.email, hashPassword(d.password), d.role);
  audit(me, 'create', 'user', null, `Thêm tài khoản ${d.email} (${d.role})`);
  return { users: list() };
}, 'manage_users');

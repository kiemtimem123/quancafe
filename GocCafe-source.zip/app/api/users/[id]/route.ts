import { audit } from '@/lib/audit';
import { z } from 'zod';
import { ApiError, handle, parseId, passwordSchema } from '@/lib/api';
import { destroyUserSessions, hashPassword } from '@/lib/auth';
import { getDb } from '@/lib/db';
import { ROLES } from '@/lib/roles';

type Ctx = { params: Promise<{ id: string }> };
const schema = z.object({
  name: z.string().trim().min(1, 'Nhập tên').max(60),
  role: z.enum(ROLES as [string, ...string[]]),
  active: z.boolean(),
  password: passwordSchema.optional().or(z.literal('').transform(() => undefined)),
});
const adminCount = () => (getDb().prepare("SELECT COUNT(*) c FROM users WHERE role='admin' AND active=1").get() as { c: number }).c;
const list = () => getDb().prepare('SELECT id, name, email, role, active, created_at FROM users ORDER BY id').all();

export const PUT = (req: Request, ctx: Ctx) => handle(async (me) => {
  const id = parseId((await ctx.params).id);
  const d = schema.parse(await req.json());
  const db = getDb();
  const cur = db.prepare('SELECT role, active FROM users WHERE id=?').get(id) as { role: string; active: number } | undefined;
  if (!cur) throw new ApiError(404, 'Không tìm thấy người dùng');
  if (id === me.id && (d.role !== 'admin' || !d.active)) throw new ApiError(400, 'Không thể tự hạ quyền hoặc vô hiệu hóa chính mình');
  if (cur.role === 'admin' && cur.active && (d.role !== 'admin' || !d.active) && adminCount() <= 1) throw new ApiError(400, 'Phải còn ít nhất 1 quản trị viên đang hoạt động');
  db.prepare('UPDATE users SET name=?, role=?, active=? WHERE id=?').run(d.name, d.role, d.active ? 1 : 0, id);
  if (d.password) db.prepare('UPDATE users SET password=? WHERE id=?').run(hashPassword(d.password), id);
  if (d.password || cur.role !== d.role || !d.active) destroyUserSessions(id); // buộc đăng nhập lại
  audit(me, 'update', 'user', id, `Sửa tài khoản #${id}: vai trò ${d.role}${d.active ? '' : ', vô hiệu hóa'}${d.password ? ', đổi mật khẩu' : ''}`);
  return { users: list() };
}, 'manage_users');

export const DELETE = (_req: Request, ctx: Ctx) => handle(async (me) => {
  const id = parseId((await ctx.params).id);
  const db = getDb();
  const cur = db.prepare('SELECT role, active FROM users WHERE id=?').get(id) as { role: string; active: number } | undefined;
  if (!cur) throw new ApiError(404, 'Không tìm thấy người dùng');
  if (id === me.id) throw new ApiError(400, 'Không thể xóa chính mình');
  if (cur.role === 'admin' && cur.active && adminCount() <= 1) throw new ApiError(400, 'Phải còn ít nhất 1 quản trị viên');
  db.prepare('DELETE FROM users WHERE id=?').run(id);
  audit(me, 'delete', 'user', id, `Xóa tài khoản #${id}`);
  return { users: list() };
}, 'manage_users');

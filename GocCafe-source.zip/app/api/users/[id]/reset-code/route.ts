import crypto from 'crypto';
import { sha } from '@/lib/auth';
import { ApiError, handle, parseId } from '@/lib/api';
import { audit } from '@/lib/audit';
import { getDb } from '@/lib/db';
import { emailReady, sendEmail } from '@/lib/notify';

export const dynamic = 'force-dynamic';

/** Quản trị viên tạo mã đặt lại mật khẩu dùng một lần (hiệu lực 30 phút) cho người dùng quên mật khẩu. */
export const POST = (_r: Request, ctx: { params: Promise<{ id: string }> }) => handle(async (u) => {
  const id = parseId((await ctx.params).id);
  const t = getDb().prepare('SELECT name, email FROM users WHERE id=?').get(id) as { name: string; email: string } | undefined;
  if (!t) throw new ApiError(404, 'Không tìm thấy người dùng');
  const code = String(crypto.randomInt(0, 100_000_000)).padStart(8, '0');
  getDb().prepare('INSERT OR REPLACE INTO reset_codes (user_id, code_hash, expires_at) VALUES (?,?,?)').run(id, sha(code), Date.now() + 30 * 60_000);
  audit(u, 'update', 'user', id, `Tạo mã đặt lại mật khẩu cho ${t.email}`);
  let emailed = false;
  if (emailReady() && /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(t.email)) emailed = (await sendEmail('Mã đặt lại mật khẩu Góc Cafe', `Mã đặt lại mật khẩu của bạn: ${code}\nCó hiệu lực 30 phút. Nhập mã ở màn hình đăng nhập → "Quên mật khẩu".`, t.email)).ok;
  return { code, expires_minutes: 30, emailed };
}, 'manage_users');

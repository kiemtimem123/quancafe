import { z } from 'zod';
import { handle } from '@/lib/api';
import { audit } from '@/lib/audit';
import { getDb } from '@/lib/db';
import { loadOptions } from '@/lib/options';
import { canSeeCost } from '@/lib/redact';
import { optionSchema } from '@/lib/schemas';

export const dynamic = 'force-dynamic';
export const GET = () => handle((u) => ({ options: loadOptions().map((o) => (canSeeCost(u) ? o : { ...o, cost: 0 })) }));
export const POST = (req: Request) => handle(async (u) => {
  const d = optionSchema.parse(await req.json());
  const db = getDb();
  const sort = ((db.prepare('SELECT MAX(sort) m FROM options').get() as { m: number | null }).m ?? 0) + 1;
  const id = Number(db.prepare('INSERT INTO options (name, price, ingredient_id, qty, active, sort) VALUES (?,?,?,?,?,?)').run(d.name, d.price, d.ingredient_id, d.qty, d.active ? 1 : 0, sort).lastInsertRowid);
  audit(u, 'create', 'option', id, `Thêm topping ${d.name} (+${d.price}đ)`);
  return { options: loadOptions() };
}, 'edit_ingredients');

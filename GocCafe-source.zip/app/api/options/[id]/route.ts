import { ApiError, handle, parseId } from '@/lib/api';
import { audit } from '@/lib/audit';
import { getDb } from '@/lib/db';
import { loadOptions } from '@/lib/options';
import { optionSchema } from '@/lib/schemas';

type Ctx = { params: Promise<{ id: string }> };
export const dynamic = 'force-dynamic';
export const PUT = (req: Request, ctx: Ctx) => handle(async (u) => {
  const id = parseId((await ctx.params).id);
  const d = optionSchema.parse(await req.json());
  const r = getDb().prepare('UPDATE options SET name=?, price=?, ingredient_id=?, qty=?, active=? WHERE id=?').run(d.name, d.price, d.ingredient_id, d.qty, d.active ? 1 : 0, id);
  if (!r.changes) throw new ApiError(404, 'Không tìm thấy topping');
  audit(u, 'update', 'option', id, `Sửa topping ${d.name}`);
  return { options: loadOptions() };
}, 'edit_ingredients');
export const DELETE = (_r: Request, ctx: Ctx) => handle(async (u) => {
  const id = parseId((await ctx.params).id);
  getDb().prepare('DELETE FROM options WHERE id=?').run(id); // đơn cũ giữ nguyên tên/giá trong order_items.options
  audit(u, 'delete', 'option', id, 'Xóa topping');
  return { options: loadOptions() };
}, 'edit_ingredients');

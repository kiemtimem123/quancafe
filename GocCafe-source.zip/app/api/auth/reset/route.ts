import { z } from 'zod';
import { ApiError, handlePublic, passwordSchema } from '@/lib/api';
import { audit } from '@/lib/audit';
import { sha, clearFails, destroyUserSessions, hashPassword, isLocked, loginKey, recordFail } from '@/lib/auth';
import { getDb } from '@/lib/db';

/** Người dùng tự đặt lại mật khẩu bằng mã do quản trị viên cấp. */
export const POST = (req: Request) => handlePublic(async () => {
  const { email, code, password } = z.object({ email: z.string().trim().toLowerCase().min(1), code: z.string().trim().min(6).max(12), password: passwordSchema }).parse(await req.json());
  const key = await loginKey(email);
  const wait = isLocked(key);
  if (wait) throw new ApiError(429, `Thử sai quá nhiều lần. Thử lại sau ${wait} phút.`);
  const db = getDb();
  const u = db.prepare('SELECT id, name, active FROM users WHERE email=?').get(email) as { id: number; name: string; active: number } | undefined;
  const rc = u ? (db.prepare('SELECT code_hash, expires_at FROM reset_codes WHERE user_id=?').get(u.id) as { code_hash: string; expires_at: number } | undefined) : undefined;
  if (!u || !u.active || !rc || rc.expires_at < Date.now() || rc.code_hash !== sha(code)) { recordFail(key); throw new ApiError(400, 'Mã không đúng hoặc đã hết hạn. Nhờ quản trị viên tạo mã mới.'); }
  db.transaction(() => {
    db.prepare('UPDATE users SET password=? WHERE id=?').run(hashPassword(password), u.id);
    db.prepare('DELETE FROM reset_codes WHERE user_id=?').run(u.id);
  })();
  destroyUserSessions(u.id);
  clearFails(key);
  audit({ id: u.id, name: u.name }, 'update', 'user', u.id, 'Đặt lại mật khẩu bằng mã');
  return { ok: true };
});

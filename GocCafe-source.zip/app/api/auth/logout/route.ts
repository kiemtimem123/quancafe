import { handlePublic } from '@/lib/api';
import { clearSessionCookie, currentToken, destroySession } from '@/lib/auth';

export const POST = () => handlePublic(async () => {
  const t = await currentToken();
  if (t) destroySession(t);
  await clearSessionCookie();
  return { ok: true };
});

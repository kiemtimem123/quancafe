import { z } from 'zod';
import { ApiError, handlePublic, passwordSchema } from '@/lib/api';
import { createSession, hashPassword, setSessionCookie } from '@/lib/auth';
import { getDb } from '@/lib/db';

const schema = z.object({ name: z.string().trim().min(1, 'Nhập tên').max(60), email: z.string().trim().toLowerCase().email('Email không hợp lệ'), password: passwordSchema });

/** Chỉ dùng được khi chưa có tài khoản nào: tạo quản trị viên đầu tiên. */
export const POST = (req: Request) => handlePublic(async () => {
  const d = schema.parse(await req.json());
  const db = getDb();
  const id = db.transaction(() => {
    if ((db.prepare('SELECT COUNT(*) c FROM users').get() as { c: number }).c > 0) throw new ApiError(403, 'Hệ thống đã được thiết lập');
    return Number(db.prepare("INSERT INTO users (name, email, password, role, active, created_at) VALUES (?,?,?,'admin',1,datetime('now'))").run(d.name, d.email, hashPassword(d.password)).lastInsertRowid);
  })();
  const { token, expires } = createSession(id);
  await setSessionCookie(token, expires);
  return { user: { id, name: d.name, email: d.email, role: 'admin' } };
});

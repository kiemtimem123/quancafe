import { z } from 'zod';
import { ApiError, handle } from '@/lib/api';
import { currentToken, destroyUserSessions, hashPassword, verifyPassword } from '@/lib/auth';
import { getDb } from '@/lib/db';

const schema = z.object({ current: z.string().min(1, 'Nhập mật khẩu hiện tại'), next: z.string().min(8, 'Mật khẩu mới tối thiểu 8 ký tự').max(200) });

export const POST = (req: Request) => handle(async (user) => {
  const { current, next } = schema.parse(await req.json());
  const db = getDb();
  const row = db.prepare('SELECT password FROM users WHERE id=?').get(user.id) as { password: string };
  if (!verifyPassword(current, row.password)) throw new ApiError(400, 'Mật khẩu hiện tại không đúng');
  db.prepare('UPDATE users SET password=? WHERE id=?').run(hashPassword(next), user.id);
  destroyUserSessions(user.id, await currentToken()); // đăng xuất các thiết bị khác
  return { ok: true };
});

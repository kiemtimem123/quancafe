import { audit } from '@/lib/audit';
import { z } from 'zod';
import { ApiError, handlePublic } from '@/lib/api';
import { clearFails, createSession, isLocked, loginKey, recordFail, setSessionCookie, verifyPassword } from '@/lib/auth';
import { getDb } from '@/lib/db';
import { useRecovery, verifyTotp } from '@/lib/totp';

const schema = z.object({ email: z.string().trim().toLowerCase().min(1, 'Nhập email'), password: z.string().min(1, 'Nhập mật khẩu').max(200), code: z.string().trim().max(20).optional() });

export const POST = (req: Request) => handlePublic(async () => {
  const { email, password, code } = schema.parse(await req.json());
  const key = await loginKey(email);
  const wait = isLocked(key);
  if (wait) throw new ApiError(429, `Đăng nhập sai quá nhiều lần. Thử lại sau ${wait} phút.`);
  const u = getDb().prepare('SELECT id, name, email, role, password, active, totp_secret, totp_enabled, recovery FROM users WHERE email=?').get(email) as
    { id: number; name: string; email: string; role: string; password: string; active: number; totp_secret: string; totp_enabled: number; recovery: string } | undefined;
  const ok = verifyPassword(password, u?.password ?? '');
  if (!u || !ok || !u.active) {
    recordFail(key);
    throw new ApiError(401, u && ok && !u.active ? 'Tài khoản đã bị vô hiệu hóa' : 'Email hoặc mật khẩu không đúng');
  }
  if (u.totp_enabled) {
    if (!code) throw new ApiError(401, 'Nhập mã xác thực 2 bước từ ứng dụng trên điện thoại', { needs_code: true });
    let pass = verifyTotp(u.totp_secret, code.replace(/\s/g, ''));
    if (!pass) {
      const left = useRecovery(JSON.parse(u.recovery || '[]'), code);
      if (left) { getDb().prepare('UPDATE users SET recovery=? WHERE id=?').run(JSON.stringify(left), u.id); pass = true; }
    }
    if (!pass) { recordFail(key); throw new ApiError(401, 'Mã xác thực không đúng', { needs_code: true }); }
  }
  clearFails(key);
  audit({ id: u.id, name: u.name }, 'login', 'user', u.id, `Đăng nhập: ${u.email}`);
  const { token, expires } = createSession(u.id);
  await setSessionCookie(token, expires);
  return { user: { id: u.id, name: u.name, email: u.email, role: u.role } };
});

import QRCode from 'qrcode';
import { z } from 'zod';
import { ApiError, handle } from '@/lib/api';
import { audit } from '@/lib/audit';
import { verifyPassword } from '@/lib/auth';
import { getDb } from '@/lib/db';
import { newRecoveryCodes, newSecret, otpauthUri, verifyTotp } from '@/lib/totp';

export const dynamic = 'force-dynamic';
type Row = { totp_secret: string; totp_enabled: number; password: string };
const row = (id: number) => getDb().prepare('SELECT totp_secret, totp_enabled, password FROM users WHERE id=?').get(id) as Row;

export const GET = () => handle((u) => ({ enabled: !!row(u.id).totp_enabled }));

/** action=setup: tạo khóa mới (chưa bật) · enable: xác nhận bằng mã 6 số, trả về mã khôi phục · disable: cần mật khẩu + mã. */
export const POST = (req: Request) => handle(async (u) => {
  const d = z.discriminatedUnion('action', [
    z.object({ action: z.literal('setup') }),
    z.object({ action: z.literal('enable'), code: z.string().trim() }),
    z.object({ action: z.literal('disable'), password: z.string(), code: z.string().trim() }),
  ]).parse(await req.json());
  const db = getDb();
  const r = row(u.id);
  if (d.action === 'setup') {
    if (r.totp_enabled) throw new ApiError(400, 'Đã bật xác thực 2 bước');
    const secret = newSecret();
    db.prepare('UPDATE users SET totp_secret=? WHERE id=?').run(secret, u.id);
    const uri = otpauthUri(secret, u.email);
    return { secret, uri, qr: await QRCode.toDataURL(uri, { width: 240, margin: 1 }) };
  }
  if (d.action === 'enable') {
    if (r.totp_enabled || !r.totp_secret) throw new ApiError(400, 'Hãy bấm "Bật" để tạo khóa trước');
    if (!verifyTotp(r.totp_secret, d.code)) throw new ApiError(400, 'Mã không đúng. Kiểm tra giờ trên điện thoại rồi thử lại.');
    const rc = newRecoveryCodes();
    db.prepare('UPDATE users SET totp_enabled=1, recovery=? WHERE id=?').run(JSON.stringify(rc.hashed), u.id);
    audit(u, 'update', 'user', u.id, 'Bật xác thực 2 bước');
    return { recovery: rc.plain };
  }
  if (!r.totp_enabled) throw new ApiError(400, 'Xác thực 2 bước chưa bật');
  if (!verifyPassword(d.password, r.password)) throw new ApiError(400, 'Mật khẩu không đúng');
  if (!verifyTotp(r.totp_secret, d.code)) throw new ApiError(400, 'Mã xác thực không đúng');
  db.prepare("UPDATE users SET totp_enabled=0, totp_secret='', recovery='[]' WHERE id=?").run(u.id);
  audit(u, 'update', 'user', u.id, 'Tắt xác thực 2 bước');
  return { ok: true };
});

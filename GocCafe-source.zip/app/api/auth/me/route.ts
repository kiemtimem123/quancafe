import { handlePublic } from '@/lib/api';
import { getSessionUser } from '@/lib/auth';
import { getDb } from '@/lib/db';

export const dynamic = 'force-dynamic';
export const GET = () => handlePublic(async () => {
  const user = await getSessionUser();
  const needsSetup = !user && (getDb().prepare('SELECT COUNT(*) c FROM users').get() as { c: number }).c === 0;
  return { user, needsSetup };
});

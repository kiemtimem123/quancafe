import { handle } from '@/lib/api';
import { getDb } from '@/lib/db';
import { loadIngredients, loadRecipes, mainSize } from '@/lib/recipes';

export const dynamic = 'force-dynamic';
export const GET = () => handle(() => {
  const db = getDb();
  const recipes = loadRecipes(db);
  const ings = loadIngredients(db);
  let sold = db.prepare('SELECT recipe_id, SUM(quantity) q FROM sales WHERE recipe_id IS NOT NULL GROUP BY recipe_id ORDER BY q DESC').all() as { recipe_id: number; q: number }[];
  if (!sold.length) sold = db.prepare('SELECT recipe_id, SUM(quantity) q FROM brew_log GROUP BY recipe_id ORDER BY q DESC').all() as { recipe_id: number; q: number }[];
  const byId = new Map(recipes.map((r) => [r.id, r]));
  const top = sold[0] ? byId.get(sold[0].recipe_id) : undefined;
  const rows = recipes.map((r) => ({ id: r.id, name: r.name, m: mainSize(r) })).filter((r) => r.m);
  const bestProfit = [...rows].sort((a, b) => b.m!.margin - a.m!.margin)[0];
  const low = ings.filter((i) => i.low_stock);
  const recent = recipes.filter((r) => Date.now() - new Date(r.created_at.replace(' ', 'T') + 'Z').getTime() < 30 * 864e5).length;
  return {
    total_recipes: recipes.length,
    total_ingredients: ings.length,
    best_seller: top ? { id: top.id, name: top.name, count: sold[0].q } : null,
    best_margin: bestProfit ? { id: bestProfit.id, name: bestProfit.name, margin: bestProfit.m!.margin } : null,
    low_stock: low.map((i) => ({ id: i.id, name: i.name, stock: i.stock_quantity, minimum: i.minimum_stock, unit: i.unit })),
    new_recipes: recent,
    top_sellers: sold.slice(0, 6).map((s) => ({ name: byId.get(s.recipe_id)?.name ?? '?', count: s.q })),
    price_chart: [...rows].sort((a, b) => b.m!.profit - a.m!.profit).slice(0, 8).map((r) => ({ name: r.name, cost: r.m!.cost, price: r.m!.selling_price, profit: r.m!.profit })),
    stock_chart: [...ings].filter((i) => i.minimum_stock > 0).sort((a, b) => a.stock_quantity / a.minimum_stock - b.stock_quantity / b.minimum_stock).slice(0, 8)
      .map((i) => ({ name: i.name, stock: i.stock_quantity, minimum: i.minimum_stock, unit: i.unit })),
  };
}, 'view_dashboard');

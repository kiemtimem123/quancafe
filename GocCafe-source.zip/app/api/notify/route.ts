import { z } from 'zod';
import { ApiError, handle } from '@/lib/api';
import { audit } from '@/lib/audit';
import { buildDailyReport } from '@/lib/daily-report';
import { createBackup, backupDir } from '@/lib/backup';
import { NOTIFY_KEYS, getNotify, publicNotify, saveNotify, sendAll, zaloRecentChats, type NotifyKey } from '@/lib/notify';
import { sendBackup } from '@/lib/ticker';
import path from 'path';

export const dynamic = 'force-dynamic';
export const GET = () => handle(() => publicNotify(), 'manage_users');

const schema = z.object(Object.fromEntries(NOTIFY_KEYS.map((k) => [k, z.string().trim().max(300).optional()])) as Record<NotifyKey, z.ZodOptional<z.ZodString>>);
export const PUT = (req: Request) => handle(async (u) => {
  const d = schema.parse(await req.json());
  if (d.n_report_time && !/^([01]\d|2[0-3]):[0-5]\d$/.test(d.n_report_time)) throw new ApiError(400, 'Giờ gửi báo cáo phải dạng HH:MM');
  if (d.n_backup_send && !['none', 'telegram', 'email', 'both'].includes(d.n_backup_send)) throw new ApiError(400, 'Kênh gửi sao lưu không hợp lệ');
  saveNotify(d);
  audit(u, 'update', 'settings', null, 'Đổi cài đặt thông báo & báo cáo tự động');
  return publicNotify();
}, 'manage_users');

/** Gửi thử: báo cáo hôm nay hoặc một bản sao lưu. */
export const POST = (req: Request) => handle(async () => {
  const { what } = z.object({ what: z.enum(['report', 'backup', 'ping', 'zalo_chats']) }).parse(await req.json());
  if (what === 'zalo_chats') {
    const t = getNotify().n_zalo_token;
    if (!t) throw new ApiError(400, 'Hãy nhập và lưu token Zalo Bot trước');
    try { return { chats: await zaloRecentChats(t) }; } catch (e) { throw new ApiError(502, `Zalo: ${e instanceof Error ? e.message : 'không lấy được'}. Hãy nhắn một tin cho bot rồi thử lại.`); }
  }
  if (what === 'backup') {
    const b = await createBackup('manual');
    return sendBackup(path.join(backupDir(), b.name)).then((r) => (r.sent.length || r.errors.length ? r : { sent: [], errors: ['Chưa chọn kênh gửi sao lưu (Telegram/email) hoặc chưa cấu hình kênh đó'] }));
  }
  if (what === 'ping') return sendAll('Kiểm tra thông báo', '✅ Góc Cafe: kết nối thông báo hoạt động.');
  const { subject, text } = buildDailyReport();
  return sendAll(subject, text);
}, 'manage_users');

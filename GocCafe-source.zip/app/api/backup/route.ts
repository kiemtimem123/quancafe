import { handle } from '@/lib/api';
import { audit } from '@/lib/audit';
import { createBackup, listBackups } from '@/lib/backup';

export const dynamic = 'force-dynamic';
export const GET = () => handle(() => ({ backups: listBackups() }), 'manage_users');
export const POST = () => handle(async (u) => {
  const b = await createBackup('manual');
  audit(u, 'create', 'backup', null, `Tạo bản sao lưu ${b.name}`);
  return { backup: b, backups: listBackups() };
}, 'manage_users');

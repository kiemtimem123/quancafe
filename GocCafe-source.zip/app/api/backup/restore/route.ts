import { z } from 'zod';
import { handle } from '@/lib/api';
import { audit } from '@/lib/audit';
import { restoreBackup } from '@/lib/backup';

export const dynamic = 'force-dynamic';
export const POST = (req: Request) => handle(async (u) => {
  const { name } = z.object({ name: z.string() }).parse(await req.json());
  await restoreBackup(name);
  audit(u, 'update', 'backup', null, `Khôi phục dữ liệu từ ${name}`);
  return { ok: true };
}, 'manage_users');

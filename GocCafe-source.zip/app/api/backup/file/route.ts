import fs from 'fs';
import path from 'path';
import { getSessionUser } from '@/lib/auth';
import { can } from '@/lib/roles';
import { backupDir } from '@/lib/backup';

export const dynamic = 'force-dynamic';
export async function GET(req: Request) {
  const u = await getSessionUser();
  if (!u) return Response.json({ error: 'Bạn cần đăng nhập' }, { status: 401 });
  if (!can(u.role, 'manage_users')) return Response.json({ error: 'Bạn không có quyền' }, { status: 403 });
  const name = new URL(req.url).searchParams.get('name') ?? '';
  if (!/^cafe-[\w-]+\.db$/.test(name)) return Response.json({ error: 'Tên file không hợp lệ' }, { status: 400 });
  const p = path.join(backupDir(), name);
  if (!fs.existsSync(p)) return Response.json({ error: 'Không tìm thấy' }, { status: 404 });
  return new Response(fs.readFileSync(p), { headers: { 'content-type': 'application/octet-stream', 'content-disposition': `attachment; filename="${name}"` } });
}

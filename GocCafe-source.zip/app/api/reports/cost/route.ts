
import { getSessionUser } from '@/lib/auth';
import { getDb } from '@/lib/db';
import { can } from '@/lib/roles';
import { xlsxResponse, today } from '@/lib/download';
import { buildCostReport } from '@/lib/xlsx-export';

export const dynamic = 'force-dynamic';
export async function GET() {
  const u = await getSessionUser();
  if (!u) return Response.json({ error: 'Bạn cần đăng nhập' }, { status: 401 });
  if (!can(u.role, 'view_cost')) return Response.json({ error: 'Bạn không có quyền xem báo cáo giá vốn' }, { status: 403 });
  try {
    const shop = (getDb().prepare("SELECT value FROM settings WHERE key='shop_name'").get() as { value: string } | undefined)?.value ?? 'Góc Cafe';
    return xlsxResponse(await buildCostReport(shop), `bao-cao-gia-von-${today()}.xlsx`);
  } catch (e) { console.error(e); return Response.json({ error: 'Không tạo được báo cáo' }, { status: 500 }); }
}

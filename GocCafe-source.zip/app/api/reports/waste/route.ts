import { handle } from '@/lib/api';
import { wasteReport } from '@/lib/reports';
export const dynamic = 'force-dynamic';
export const GET = (req: Request) => handle(() => wasteReport(Math.min(24, Number(new URL(req.url).searchParams.get('months')) || 6)), 'view_cost');

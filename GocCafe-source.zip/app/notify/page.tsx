'use client';
import { useEffect, useState } from 'react';
import { api } from '@/lib/client';
import { Forbidden, useAuth } from '@/components/Auth';
import { Loading, Spinner } from '@/components/ui';
import { useToast } from '@/components/Toast';

interface Cfg { n_zalo_chat: string; n_order_alert: string; has_zalo_token: boolean; n_tg_chat: string; n_smtp_host: string; n_smtp_port: string; n_smtp_user: string; n_smtp_from: string; n_mail_to: string; n_report_enabled: string; n_report_time: string; n_backup_send: string; has_tg_token: boolean; has_smtp_pass: boolean }
interface Res { sent: string[]; errors: string[] }

export default function NotifyPage() {
  const { can } = useAuth();
  const toast = useToast();
  const [c, setC] = useState<Cfg | null>(null);
  const [secrets, setSecrets] = useState({ n_tg_token: '', n_smtp_pass: '', n_zalo_token: '' });
  const [busy, setBusy] = useState('');
  const [res, setRes] = useState<Res | null>(null);
  useEffect(() => { if (can('manage_users')) api<Cfg>('/api/notify').then(setC).catch((e) => toast.err(e.message)); }, [can]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!can('manage_users')) return <Forbidden what="trang này" />;
  if (!c) return <Loading rows={3} />;
  const set = (p: Partial<Cfg>) => setC({ ...c, ...p });
  const save = async () => {
    setBusy('save');
    try {
      const { has_tg_token: _a, has_smtp_pass: _b, has_zalo_token: _z, ...rest } = c; void _a; void _b; void _z;
      setC(await api<Cfg>('/api/notify', { method: 'PUT', body: { ...rest, ...secrets } }));
      setSecrets({ n_tg_token: '', n_smtp_pass: '', n_zalo_token: '' }); toast.ok('Đã lưu cài đặt');
    } catch (e) { toast.err(e instanceof Error ? e.message : 'Không lưu được'); } finally { setBusy(''); }
  };
  const [chats, setChats] = useState<{ id: string; name: string }[] | null>(null);
  const findChats = async () => {
    setBusy('zc');
    try { await save(); setChats((await api<{ chats: { id: string; name: string }[] }>('/api/notify', { method: 'POST', body: { what: 'zalo_chats' } })).chats); } catch (e) { toast.err(e instanceof Error ? e.message : 'Lỗi'); } finally { setBusy(''); }
  };
  const test = async (what: 'ping' | 'report' | 'backup') => {
    setBusy(what); setRes(null);
    try { await save(); setRes(await api<Res>('/api/notify', { method: 'POST', body: { what } })); } catch (e) { toast.err(e instanceof Error ? e.message : 'Lỗi'); } finally { setBusy(''); }
  };
  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <div><h1 className="text-2xl font-extrabold">THÔNG BÁO & BÁO CÁO TỰ ĐỘNG</h1><p className="text-sm text-mocha">Tự gửi báo cáo cuối ngày và file sao lưu qua Telegram và/hoặc email. (Cần máy chủ có Internet.)</p></div>

      <section className="card space-y-3 p-4">
        <h2 className="font-bold">💬 Zalo (báo đơn khách đặt qua QR)</h2>
        <ol className="list-decimal space-y-0.5 pl-5 text-xs text-mocha"><li>Trên điện thoại, mở Zalo, tìm <b>Zalo Bot Creator</b> và tạo bot cho quán → nhận <b>Bot token</b>.</li><li>Dán token vào ô dưới, bấm Lưu. Dùng Zalo của chủ quán nhắn một tin bất kỳ cho bot vừa tạo.</li><li>Bấm “Tìm Chat ID” rồi chọn tên của bạn, bấm Lưu và “Gửi tin thử”.</li></ol>
        <div className="grid gap-3 sm:grid-cols-2">
          <div><label className="label" htmlFor="zt">Bot token</label><input id="zt" type="password" className="input" autoComplete="off" placeholder={c.has_zalo_token ? '•••••• (đã lưu — để trống để giữ)' : ''} value={secrets.n_zalo_token} onChange={(e) => setSecrets({ ...secrets, n_zalo_token: e.target.value })} /></div>
          <div><label className="label" htmlFor="zc">Chat ID người nhận</label><input id="zc" className="input" value={c.n_zalo_chat} onChange={(e) => set({ n_zalo_chat: e.target.value })} /></div>
        </div>
        <button className="btn btn-ghost btn-sm" onClick={findChats} disabled={!!busy}>{busy === 'zc' ? <Spinner /> : '🔍'} Tìm Chat ID</button>
        {chats && (chats.length === 0 ? <p className="text-xs font-semibold text-warn">Chưa thấy ai nhắn bot. Hãy nhắn bot một tin rồi bấm lại.</p> : <div className="flex flex-wrap gap-2">{chats.map((x) => <button key={x.id} className="chip" onClick={() => set({ n_zalo_chat: x.id })}>{x.name || 'Người dùng'} · {x.id.slice(0, 10)}…</button>)}</div>)}
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="h-5 w-5" checked={c.n_order_alert !== '0'} onChange={(e) => set({ n_order_alert: e.target.checked ? '1' : '0' })} /> Nhắn ngay cho tôi (Zalo / Telegram / email đã cấu hình) khi có khách đặt món</label>
      </section>

      <section className="card space-y-3 p-4">
        <h2 className="font-bold">✈ Telegram</h2>
        <p className="text-xs text-mocha">Tạo bot với @BotFather để lấy token; nhắn bot một tin rồi lấy Chat ID (ví dụ qua @userinfobot).</p>
        <div className="grid gap-3 sm:grid-cols-2">
          <div><label className="label" htmlFor="tt">Bot token</label><input id="tt" type="password" className="input" autoComplete="off" placeholder={c.has_tg_token ? '•••••• (đã lưu — để trống để giữ)' : '123456:ABC…'} value={secrets.n_tg_token} onChange={(e) => setSecrets({ ...secrets, n_tg_token: e.target.value })} /></div>
          <div><label className="label" htmlFor="tc">Chat ID</label><input id="tc" className="input" value={c.n_tg_chat} onChange={(e) => set({ n_tg_chat: e.target.value })} /></div>
        </div>
      </section>

      <section className="card space-y-3 p-4">
        <h2 className="font-bold">✉ Email (SMTP)</h2>
        <p className="text-xs text-mocha">Gmail: máy chủ smtp.gmail.com, cổng 587, dùng &quot;Mật khẩu ứng dụng&quot; (không phải mật khẩu đăng nhập).</p>
        <div className="grid gap-3 sm:grid-cols-2">
          <div><label className="label" htmlFor="sh">Máy chủ SMTP</label><input id="sh" className="input" value={c.n_smtp_host} onChange={(e) => set({ n_smtp_host: e.target.value })} placeholder="smtp.gmail.com" /></div>
          <div><label className="label" htmlFor="sp">Cổng</label><input id="sp" className="input" inputMode="numeric" value={c.n_smtp_port} onChange={(e) => set({ n_smtp_port: e.target.value })} /></div>
          <div><label className="label" htmlFor="su">Tài khoản</label><input id="su" className="input" autoComplete="off" value={c.n_smtp_user} onChange={(e) => set({ n_smtp_user: e.target.value })} /></div>
          <div><label className="label" htmlFor="sw">Mật khẩu</label><input id="sw" type="password" className="input" autoComplete="new-password" placeholder={c.has_smtp_pass ? '•••••• (đã lưu)' : ''} value={secrets.n_smtp_pass} onChange={(e) => setSecrets({ ...secrets, n_smtp_pass: e.target.value })} /></div>
          <div><label className="label" htmlFor="sf">Gửi từ (tuỳ chọn)</label><input id="sf" className="input" value={c.n_smtp_from} onChange={(e) => set({ n_smtp_from: e.target.value })} /></div>
          <div><label className="label" htmlFor="sm">Email nhận báo cáo</label><input id="sm" type="email" className="input" value={c.n_mail_to} onChange={(e) => set({ n_mail_to: e.target.value })} /></div>
        </div>
      </section>

      <section className="card space-y-3 p-4">
        <h2 className="font-bold">⏰ Tự động</h2>
        <label className="flex items-center gap-2"><input type="checkbox" className="h-5 w-5" checked={c.n_report_enabled === '1'} onChange={(e) => set({ n_report_enabled: e.target.checked ? '1' : '0' })} /> Gửi báo cáo cuối ngày lúc <input type="time" className="input !w-auto" value={c.n_report_time} onChange={(e) => set({ n_report_time: e.target.value })} /></label>
        <div><label className="label" htmlFor="bs">Gửi file sao lưu hằng ngày qua</label>
          <select id="bs" className="input" value={c.n_backup_send} onChange={(e) => set({ n_backup_send: e.target.value })}><option value="none">Không gửi (chỉ lưu trên máy chủ)</option><option value="telegram">Telegram</option><option value="email">Email</option><option value="both">Cả hai</option></select>
          <p className="mt-1 text-xs text-mocha">Giữ file sao lưu ở nơi khác máy chủ là cách an toàn nhất nếu máy hỏng. File có dữ liệu bán hàng — chỉ gửi vào kênh riêng của bạn.</p></div>
      </section>

      {res && <div className={`rounded-xl p-3 text-sm font-semibold ${res.errors.length ? 'bg-danger-soft text-danger' : 'bg-leaf-soft text-leaf-dark'}`} role="status">{res.sent.length > 0 && <p>✅ Đã gửi qua: {res.sent.join(', ')}</p>}{res.errors.map((e) => <p key={e}>⚠ {e}</p>)}</div>}
      <div className="flex flex-wrap gap-2">
        <button className="btn btn-green btn-lg" onClick={save} disabled={!!busy}>{busy === 'save' ? <Spinner /> : '💾'} Lưu</button>
        <button className="btn btn-ghost" onClick={() => test('ping')} disabled={!!busy}>Gửi tin thử</button>
        <button className="btn btn-ghost" onClick={() => test('report')} disabled={!!busy}>Gửi thử báo cáo hôm nay</button>
        <button className="btn btn-ghost" onClick={() => test('backup')} disabled={!!busy}>Gửi thử file sao lưu</button>
      </div>
    </div>
  );
}

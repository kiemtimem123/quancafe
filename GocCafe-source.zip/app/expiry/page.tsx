'use client';
import Link from 'next/link';
import { useState } from 'react';
import { api, useApi } from '@/lib/client';
import { num } from '@/lib/format';
import { Empty, ErrorBox, Loading } from '@/components/ui';
import { useAuth } from '@/components/Auth';
import { useToast } from '@/components/Toast';
import { daysText, dmy, type ExpiryData, type ExpiryRowT } from '@/components/ExpiryBanner';

export default function ExpiryPage() {
  const { can } = useAuth();
  const toast = useToast();
  const { data, error, loading, reload } = useApi<ExpiryData>('/api/expiry');
  const [busy, setBusy] = useState<number | null>(null);
  const discard = async (r: ExpiryRowT) => {
    if (!confirm(`Hủy lô ${r.name} (${num(r.qty, 2)} ${r.unit})? Số lượng sẽ bị trừ khỏi kho và ghi vào sổ hao hụt.`)) return;
    setBusy(r.id);
    try { await api(`/api/batches/${r.id}`, { method: 'DELETE' }); toast.ok('Đã hủy lô và trừ kho'); reload(); }
    catch (e) { toast.err(e instanceof Error ? e.message : 'Không hủy được'); } finally { setBusy(null); }
  };
  if (loading && !data) return <Loading rows={4} />;
  if (error) return <ErrorBox message={error} onRetry={reload} />;
  const rows = data?.rows ?? [];
  const groups: [string, string, ExpiryRowT[]][] = [
    ['⛔ Đã hết hạn', 'text-danger', rows.filter((r) => r.status === 'expired')],
    [`⏰ Sắp hết hạn (≤ ${data?.warn_days ?? 3} ngày)`, 'text-[#8a5a00]', rows.filter((r) => r.status === 'soon')],
    ['✅ Còn hạn', 'text-leaf-dark', rows.filter((r) => r.status === 'ok')],
    ['Không ghi hạn', 'text-mocha', rows.filter((r) => r.status === 'none')],
  ];
  const urgent = [...new Set(rows.filter((r) => r.status === 'soon').map((r) => r.ingredient_id))];
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div><h1 className="text-2xl font-extrabold">HẠN SỬ DỤNG</h1><p className="text-sm text-mocha">Các lô nguyên liệu còn hàng. App tự dùng lô sắp hết hạn trước và tự loại lô đã quá hạn khỏi kho.</p></div>
        {urgent.length > 0 && <Link href={`/?prio=${urgent.join(',')}`} className="btn btn-green">🔎 Tìm món dùng nguyên liệu sắp hết hạn</Link>}
      </div>
      {rows.length === 0 && !(data?.removed?.length) ? <Empty title="Chưa có lô nào" hint="Khi nhập kho nguyên liệu có theo dõi hạn, nhập kèm ngày hết hạn để app cảnh báo." /> : groups.filter(([, , g]) => g.length).map(([title, cls, g]) => (
        <section key={title} className="card overflow-hidden">
          <h2 className={`border-b border-[#eadfcd] p-3 font-bold ${cls}`}>{title} <span className="text-mocha">({g.length})</span></h2>
          <ul className="divide-y divide-[#f3ebdd]">
            {g.map((r) => (
              <li key={r.id} className="flex items-center justify-between gap-3 p-3">
                <div className="min-w-0"><p className="font-bold">{r.name} <span className="font-normal text-mocha">· {num(r.qty, 2)} {r.unit}</span></p>
                  <p className="text-xs text-mocha">Nhập {dmy(r.received_on)} · HSD {dmy(r.expires_on)} · <b className={r.status === 'expired' ? 'text-danger' : ''}>{daysText(r.days)}</b></p></div>
                {can('edit_ingredients') && <button className="btn btn-ghost btn-sm shrink-0" disabled={busy === r.id} onClick={() => discard(r)}>{r.status === 'expired' ? '🗑 Hủy lô' : 'Hủy'}</button>}
              </li>
            ))}
          </ul>
        </section>
      ))}
      {(data?.removed?.length ?? 0) > 0 && (
        <section className="card overflow-hidden"><h2 className="border-b border-[#eadfcd] p-3 font-bold text-mocha">🗑 Đã tự loại khỏi kho (3 ngày gần đây)</h2>
          <ul className="divide-y divide-[#f3ebdd]">{data!.removed!.map((x) => <li key={x.id} className="p-3 text-sm"><b>{x.name}</b> · {num(x.qty, 2)} {x.unit}<span className="block text-xs text-mocha">{x.note}</span></li>)}</ul></section>
      )}
    </div>
  );
}

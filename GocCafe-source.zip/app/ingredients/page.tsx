'use client';
import { useMemo, useState } from 'react';
import { api, useApi } from '@/lib/client';
import { ING_CATEGORIES, PURCHASE_UNITS, type BaseUnit, type Ingredient } from '@/lib/types';
import { defaultPack } from '@/lib/units';
import { norm, num, vnd } from '@/lib/format';
import { Empty, ErrorBox, Loading, Modal, Spinner } from '@/components/ui';
import { useToast } from '@/components/Toast';
import { useAuth } from '@/components/Auth';
import { ImportIngredients } from '@/components/ImportIngredients';
import { DownloadButton } from '@/components/DownloadButton';
import { StockModal } from '@/components/StockModal';
import { PrepModal } from '@/components/PrepModal';
import { StockTake } from '@/components/StockTake';
import { MarginAlerts, type MarginAlertT } from '@/components/MarginAlerts';
import Link from 'next/link';
import { ExpiryBanner, dmy } from '@/components/ExpiryBanner';

interface Form { id?: number; name: string; category: string; unit: string; base_unit: BaseUnit; pack_size: string; purchase_price: string; stock_quantity: string; minimum_stock: string; supplier: string; note: string; group_name: string; track_stock: boolean; track_expiry: boolean; shelf_life_days: string }
const blank: Form = { name: '', category: 'Khác', unit: 'kg', base_unit: 'g', pack_size: '1000', purchase_price: '', stock_quantity: '0', minimum_stock: '0', supplier: '', note: '', group_name: '', track_stock: true, track_expiry: true, shelf_life_days: '' };

export default function IngredientsPage() {
  const toast = useToast();
  const { can } = useAuth();
  const edit_ = can('edit_ingredients');
  const seeCost = can('view_cost');
  const { data, error, loading, reload } = useApi<{ ingredients: Ingredient[] }>('/api/ingredients');
  const settings = useApi<{ waste_percent: number }>('/api/settings');
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('');
  const [onlyLow, setOnlyLow] = useState(false);
  const [form, setForm] = useState<Form | null>(null);
  const [del, setDel] = useState<Ingredient | null>(null);
  const [busy, setBusy] = useState(false);
  const [waste, setWaste] = useState<string | null>(null);
  const [formErr, setFormErr] = useState('');
  const [importing, setImporting] = useState(false);
  const [stockFor, setStockFor] = useState<Ingredient | null>(null);
  const [prepFor, setPrepFor] = useState<Ingredient | null>(null);
  const [taking, setTaking] = useState(false);
  const [alerts, setAlerts] = useState<{ list: MarginAlertT[]; threshold: number } | null>(null);
  const showAlerts = (a?: MarginAlertT[], t?: number) => { reload(); if (a?.length) setAlerts({ list: a, threshold: t ?? 50 }); };

  const all = data?.ingredients ?? [];
  const low = all.filter((i) => i.low_stock);
  const shown = useMemo(() => all.filter((i) => (!cat || i.category === cat) && (!onlyLow || i.low_stock) && (!q || norm(`${i.name} ${i.supplier} ${i.category}`).includes(norm(q)))), [all, q, cat, onlyLow]);
  const cats = useMemo(() => [...new Set(all.map((i) => i.category))], [all]);

  const edit = (i: Ingredient) => { setFormErr(''); setForm({ id: i.id, name: i.name, category: i.category, unit: i.unit, base_unit: i.base_unit, pack_size: String(i.pack_size), purchase_price: String(i.purchase_price), stock_quantity: String(i.stock_quantity), minimum_stock: String(i.minimum_stock), supplier: i.supplier, note: i.note, group_name: i.group_name, track_stock: i.track_stock, track_expiry: i.track_expiry, shelf_life_days: String(i.shelf_life_days) }); };
  const save = async () => {
    if (!form) return;
    if (!form.name.trim()) return setFormErr('Nhập tên nguyên liệu');
    if (!(Number(form.pack_size) > 0)) return setFormErr('Quy cách phải lớn hơn 0');
    if (form.purchase_price === '' || Number(form.purchase_price) < 0) return setFormErr('Nhập giá nhập hợp lệ');
    if (Number(form.stock_quantity) < 0 || Number(form.minimum_stock) < 0) return setFormErr('Tồn kho không được âm');
    setBusy(true); setFormErr('');
    try {
      const body = { ...form, pack_size: Number(form.pack_size), purchase_price: Number(form.purchase_price), stock_quantity: Number(form.stock_quantity) || 0, minimum_stock: Number(form.minimum_stock) || 0, shelf_life_days: Number(form.shelf_life_days) || 0 };
      const r = await api<{ alerts?: MarginAlertT[]; threshold?: number }>(form.id ? `/api/ingredients/${form.id}` : '/api/ingredients', { method: form.id ? 'PUT' : 'POST', body });
      toast.ok(form.id ? 'Đã cập nhật nguyên liệu' : 'Đã thêm nguyên liệu'); setForm(null); showAlerts(r.alerts, r.threshold);
    } catch (e) { setFormErr(e instanceof Error ? e.message : 'Không lưu được'); } finally { setBusy(false); }
  };
  const remove = async () => {
    if (!del) return; setBusy(true);
    try { await api(`/api/ingredients/${del.id}`, { method: 'DELETE' }); toast.ok('Đã xóa nguyên liệu'); setDel(null); reload(); }
    catch (e) { toast.err(e instanceof Error ? e.message : 'Không xóa được'); setDel(null); } finally { setBusy(false); }
  };
  const saveWaste = async () => {
    try { await api('/api/settings', { method: 'PUT', body: { waste_percent: Number(waste) } }); toast.ok('Đã lưu % hao phí — giá vốn đã được tính lại'); setWaste(null); settings.reload(); }
    catch (e) { toast.err(e instanceof Error ? e.message : 'Lỗi'); }
  };
  const set = (p: Partial<Form>) => setForm((f) => f && { ...f, ...p });
  const unitCost = form && Number(form.pack_size) > 0 ? Number(form.purchase_price) / Number(form.pack_size) : 0;

  return (
    <div className="space-y-4">
      <ExpiryBanner />
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div><h1 className="text-2xl font-extrabold">QUẢN LÝ NGUYÊN LIỆU</h1><p className="text-sm text-mocha">{all.length} nguyên liệu</p></div>
        {edit_ && <div className="flex flex-wrap gap-2">
          <Link href="/expiry" className="btn btn-ghost">⏰ Hạn dùng</Link>
          <button className="btn btn-ghost" onClick={() => setTaking(true)}>🧮 Kiểm kê</button>
          <Link href="/shopping" className="btn btn-ghost">🛒 Cần mua</Link>
          <button className="btn btn-ghost" onClick={() => setImporting(true)}>⬆ Nhập từ Excel</button>
          <DownloadButton url="/api/ingredients/xlsx" filename="nguyen-lieu.xlsx">Xuất Excel</DownloadButton>
          <button className="btn btn-green btn-lg" onClick={() => { setFormErr(''); setForm(blank); }}>+ Thêm nguyên liệu</button>
        </div>}
      </div>

      {low.length > 0 && (
        <div className="rounded-2xl bg-warn-soft p-4" role="alert">
          {low.slice(0, 5).map((i) => <p key={i.id} className="font-semibold text-[#8a5a00]">⚠ {i.name} {i.stock_quantity <= 0 ? 'đã hết' : 'sắp hết'} (còn {num(i.stock_quantity)} {i.unit})</p>)}
          {low.length > 5 && <p className="text-sm">… và {low.length - 5} nguyên liệu khác</p>}
        </div>
      )}

      {edit_ && <div className="card flex flex-wrap items-center gap-3 p-3 text-sm">
        <span className="font-semibold">Hao phí khi tính giá vốn:</span>
        <input className="input !w-24" type="number" min={0} max={50} value={waste ?? settings.data?.waste_percent ?? ''} onChange={(e) => setWaste(e.target.value)} aria-label="% hao phí" /> %
        {waste !== null && <button className="btn btn-primary btn-sm" onClick={saveWaste}>Lưu</button>}
      </div>}

      <div className="flex flex-wrap gap-2">
        <input className="input !w-full sm:!w-72" placeholder="🔍 Tìm nguyên liệu, nhà cung cấp…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Tìm" />
        <select className="input !w-auto" value={cat} onChange={(e) => setCat(e.target.value)} aria-label="Phân loại"><option value="">Tất cả phân loại</option>{cats.map((c) => <option key={c}>{c}</option>)}</select>
        <button className="chip" aria-pressed={onlyLow} onClick={() => setOnlyLow(!onlyLow)}>⚠ Tồn kho thấp ({low.length})</button>
      </div>

      {error && <ErrorBox message={error} onRetry={reload} />}
      {loading && <Loading rows={5} />}
      {data && shown.length === 0 && <Empty icon="🫘" title="Không có nguyên liệu" hint={all.length ? 'Thử đổi bộ lọc.' : 'Hãy thêm nguyên liệu đầu tiên.'} />}

      {shown.length > 0 && (
        <div className="card overflow-x-auto">
          <table className="w-full min-w-[720px] text-sm">
            <thead><tr className="border-b border-[#eadfcd] text-left text-mocha"><th className="p-3">Nguyên liệu</th><th className="p-3 text-right">Tồn kho</th><th className="p-3">Đơn vị</th>{seeCost && <><th className="p-3 text-right">Giá nhập</th><th className="p-3 text-right">Giá / đơn vị nhỏ</th><th className="p-3">Nhà cung cấp</th></>}{edit_ && <th className="p-3" />}</tr></thead>
            <tbody>
              {shown.map((i) => (
                <tr key={i.id} className="border-b border-[#f3ebdd] hover:bg-foam">
                  <td className="p-3"><b>{i.name}</b>{i.has_prep && <span className="tag tag-ok ml-1">🍳 tự làm</span>}{i.group_name && <span className="tag tag-neutral ml-1">♻ {i.group_name}</span>}{!i.track_stock && <span className="tag tag-neutral ml-1">không theo dõi kho</span>}{i.expiry?.status === 'expired' && <span className="tag tag-miss ml-1">⛔ hết hạn</span>}{i.expiry?.status === 'soon' && <span className="tag tag-warn ml-1">⏰ HSD {dmy(i.expiry.next_date)}</span>}<span className="block text-xs text-mocha">{i.category}</span></td>
                  <td className="p-3 text-right">{num(i.stock_quantity, 2)} {i.track_stock && i.low_stock && <span className="tag tag-warn">⚠ {i.stock_quantity <= 0 ? 'hết' : 'sắp hết'}</span>}</td>
                  <td className="p-3">{i.unit}{i.pack_size !== 1 && <span className="block text-xs text-mocha">= {num(i.pack_size, 0)}{i.base_unit}</span>}</td>
                  {seeCost && <><td className="p-3 text-right">{vnd(i.purchase_price)}/{i.unit}</td>
                  <td className="p-3 text-right text-mocha">{num(i.unit_cost, 2)}đ/{i.base_unit}</td>
                  <td className="p-3">{i.supplier || '—'}</td></>}
                  {edit_ && <td className="p-3 text-right whitespace-nowrap"><button className="btn btn-primary btn-sm" onClick={() => setStockFor(i)}>Kho</button> <button className="btn btn-ghost btn-sm" onClick={() => setPrepFor(i)}>{i.has_prep ? '🍳 Làm mẻ' : 'Tự làm?'}</button> <button className="btn btn-ghost btn-sm" onClick={() => edit(i)}>Sửa</button> <button className="btn btn-danger btn-sm" onClick={() => setDel(i)} aria-label={`Xóa ${i.name}`}>Xóa</button></td>}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {stockFor && <StockModal ing={all.find((x) => x.id === stockFor.id) ?? stockFor} seeCost={seeCost} onClose={() => setStockFor(null)} onDone={showAlerts} />}
      {prepFor && <PrepModal ing={prepFor} all={all} seeCost={seeCost} onClose={() => setPrepFor(null)} onDone={showAlerts} />}
      <StockTake open={taking} all={all} onClose={() => setTaking(false)} onDone={reload} />
      {alerts && <MarginAlerts alerts={alerts.list} threshold={alerts.threshold} onClose={() => setAlerts(null)} />}
      <ImportIngredients open={importing} onClose={() => setImporting(false)} onDone={reload} />
      <Modal open={!!form} onClose={() => setForm(null)} title={form?.id ? 'Sửa nguyên liệu' : 'Thêm nguyên liệu'}>
        {form && (
          <div className="grid gap-3 sm:grid-cols-2">
            {formErr && <p className="rounded-xl bg-danger-soft p-3 text-sm text-danger sm:col-span-2" role="alert">{formErr}</p>}
            <div className="sm:col-span-2"><label className="label" htmlFor="in">Tên nguyên liệu *</label><input id="in" className="input" value={form.name} onChange={(e) => set({ name: e.target.value })} /></div>
            <div><label className="label" htmlFor="ic">Phân loại</label><select id="ic" className="input" value={form.category} onChange={(e) => set({ category: e.target.value })}>{[...new Set([...ING_CATEGORIES, form.category])].map((c) => <option key={c}>{c}</option>)}</select></div>
            <div><label className="label" htmlFor="iu">Đơn vị mua (kg, lon, chai…)</label><select id="iu" className="input" value={form.unit} onChange={(e) => { const d = defaultPack(e.target.value); set({ unit: e.target.value, base_unit: d.base, pack_size: String(d.pack) }); }}>{PURCHASE_UNITS.map((u) => <option key={u}>{u}</option>)}</select></div>
            <div><label className="label" htmlFor="ib">Đơn vị dùng pha chế</label><select id="ib" className="input" value={form.base_unit} onChange={(e) => set({ base_unit: e.target.value as BaseUnit })}><option value="g">g (gram)</option><option value="ml">ml</option><option value="cái">cái</option></select></div>
            <div><label className="label" htmlFor="ip">1 {form.unit} = bao nhiêu {form.base_unit}?</label><input id="ip" type="number" min={0} className="input" value={form.pack_size} onChange={(e) => set({ pack_size: e.target.value })} /></div>
            <div><label className="label" htmlFor="ipr">Giá nhập (đ / {form.unit}) *</label><input id="ipr" type="number" min={0} className="input" value={form.purchase_price} onChange={(e) => set({ purchase_price: e.target.value })} /></div>
            <div className="flex items-end rounded-xl bg-cream p-3 text-sm">≈ <b className="mx-1">{num(unitCost, 2)}đ</b> / {form.base_unit}</div>
            <div><label className="label" htmlFor="is">Tồn kho ({form.unit})</label><input id="is" type="number" min={0} step="any" className="input" value={form.stock_quantity} onChange={(e) => set({ stock_quantity: e.target.value })} /></div>
            <div><label className="label" htmlFor="im">Cảnh báo khi tồn ≤</label><input id="im" type="number" min={0} step="any" className="input" value={form.minimum_stock} onChange={(e) => set({ minimum_stock: e.target.value })} /></div>
            <div><label className="label" htmlFor="ig">Nhóm thay thế (tuỳ chọn)</label><input id="ig" className="input" list="groups" value={form.group_name} onChange={(e) => set({ group_name: e.target.value })} placeholder="VD: Caramel" /><datalist id="groups">{[...new Set(all.map((x) => x.group_name).filter(Boolean))].map((g) => <option key={g} value={g} />)}</datalist><p className="mt-1 text-xs text-mocha">Các nguyên liệu cùng nhóm dùng thay nhau được khi tìm món.</p></div>
            <label className="flex items-center gap-2 self-end rounded-xl bg-cream p-3 text-sm"><input type="checkbox" className="h-5 w-5" checked={form.track_stock} onChange={(e) => set({ track_stock: e.target.checked })} /> Theo dõi tồn kho</label>
            <label className="flex items-center gap-2 rounded-xl bg-cream p-3 text-sm"><input type="checkbox" className="h-5 w-5" checked={form.track_expiry} onChange={(e) => set({ track_expiry: e.target.checked })} /> Theo dõi hạn sử dụng<span className="block text-xs text-mocha">Tắt với đường, bao bì, ống hút…</span></label>
            {form.track_expiry && <div><label className="label" htmlFor="ish">Hạn dùng mặc định (ngày)</label><input id="ish" type="number" min={0} className="input" value={form.shelf_life_days} onChange={(e) => set({ shelf_life_days: e.target.value })} /><p className="mt-1 text-xs text-mocha">Tự điền hạn khi nhập kho (0 = tự nhập mỗi lần).</p></div>}
            <div className="sm:col-span-2"><label className="label" htmlFor="isu">Nhà cung cấp</label><input id="isu" className="input" value={form.supplier} onChange={(e) => set({ supplier: e.target.value })} /></div>
            <div className="sm:col-span-2"><label className="label" htmlFor="inn">Ghi chú</label><input id="inn" className="input" value={form.note} onChange={(e) => set({ note: e.target.value })} /></div>
            <button className="btn btn-green btn-lg sm:col-span-2" onClick={save} disabled={busy}>{busy ? <Spinner /> : '💾'} Lưu</button>
          </div>
        )}
      </Modal>
      <Modal open={!!del} onClose={() => setDel(null)} title="Xóa nguyên liệu?">
        <p>Xóa <b>{del?.name}</b>? Nếu đang dùng trong công thức, hệ thống sẽ không cho xóa.</p>
        <div className="mt-4 flex gap-2"><button className="btn btn-danger flex-1" onClick={remove} disabled={busy}>{busy ? <Spinner /> : 'Xóa'}</button><button className="btn btn-ghost" onClick={() => setDel(null)}>Hủy</button></div>
      </Modal>
    </div>
  );
}

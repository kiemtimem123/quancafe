'use client';
import { useState } from 'react';
import { api, downloadFile, useApi } from '@/lib/client';
import { ErrorBox, Loading } from '@/components/ui';
import { useAuth, Forbidden } from '@/components/Auth';
import { useToast } from '@/components/Toast';
import Link from 'next/link';

interface B { name: string; size: number; created_at: string; kind: string }
const KIND: Record<string, string> = { auto: 'Tự động', manual: 'Thủ công', restore: 'Trước khi khôi phục' };
export default function BackupPage() {
  const { can } = useAuth(); const toast = useToast();
  const { data, error, loading, reload } = useApi<{ backups: B[] }>(can('manage_users') ? '/api/backup' : null);
  const [busy, setBusy] = useState('');
  if (!can('manage_users')) return <Forbidden what="sao lưu dữ liệu" />;
  const run = async (k: string, fn: () => Promise<unknown>, ok: string) => { setBusy(k); try { await fn(); toast.ok(ok); reload(); } catch (e) { toast.err(e instanceof Error ? e.message : 'Lỗi'); } finally { setBusy(''); } };
  return (
    <div className="space-y-4">
      <div><h1 className="text-2xl font-extrabold">SAO LƯU & KHÔI PHỤC</h1><p className="text-sm text-mocha">Tự sao lưu mỗi ngày, giữ 14 bản gần nhất. Gửi bản sao lưu qua Telegram/email ở <Link href="/notify" className="font-semibold underline">Thông báo</Link>.</p></div>
      <button className="btn btn-green" disabled={!!busy} onClick={() => run('new', () => api('/api/backup', { method: 'POST' }), 'Đã tạo bản sao lưu')}>💾 Sao lưu ngay</button>
      {error && <ErrorBox message={error} onRetry={reload} />}
      {loading && !data && <Loading rows={3} />}
      {data && <div className="card divide-y divide-[#f3ebdd]">{data.backups.length === 0 && <p className="p-4 text-sm text-mocha">Chưa có bản sao lưu.</p>}{data.backups.map((b) => (
        <div key={b.name} className="flex flex-wrap items-center gap-2 p-3 text-sm">
          <div className="min-w-0 flex-1"><p className="truncate font-semibold">{b.name}</p><p className="text-xs text-mocha">{KIND[b.kind] ?? b.kind} · {(b.size / 1024).toFixed(0)} KB · {new Date(b.created_at).toLocaleString('vi-VN')}</p></div>
          <button className="btn btn-ghost" onClick={() => downloadFile(`/api/backup/file?name=${encodeURIComponent(b.name)}`, b.name).catch((e) => toast.err(String(e.message ?? e)))}>⬇ Tải</button>
          <button className="btn btn-ghost !text-danger" disabled={!!busy} onClick={() => { if (confirm(`Khôi phục dữ liệu về bản ${b.name}? Dữ liệu hiện tại sẽ được sao lưu trước.`)) run(b.name, () => api('/api/backup/restore', { method: 'POST', body: { name: b.name } }), 'Đã khôi phục — hãy tải lại trang'); }}>↩ Khôi phục</button>
        </div>))}</div>}
      <p className="text-xs text-mocha">Lưu ý: bản sao lưu chứa dữ liệu (cơ sở dữ liệu); ảnh món nằm ở thư mục data/uploads — hãy sao chép thư mục data/ định kỳ nếu cần giữ cả ảnh.</p>
    </div>
  );
}

'use client';
import { useState } from 'react';
import { api, useApi } from '@/lib/client';
import { vnd } from '@/lib/format';
import { ErrorBox, Loading } from '@/components/ui';
import { Forbidden, useAuth } from '@/components/Auth';
import { useToast } from '@/components/Toast';

interface P { month: string; revenue: number; cogs: number; cups: number; gross: number; margin: number; waste: number; fixed: { id: number; name: string; amount: number; active: number }[]; fixed_total: number; net: number; break_even_revenue: number | null; break_even_per_day: number | null; reached: boolean; progress: number; days_in_month: number; days_elapsed: number; avg_daily_revenue: number; projected_revenue: number }
const thisMonth = () => new Date(Date.now() + 7 * 3600_000).toISOString().slice(0, 7);
export default function ProfitPage() {
  const { can } = useAuth(); const toast = useToast();
  const [month, setMonth] = useState(thisMonth());
  const { data, error, loading, reload } = useApi<P>(can('view_cost') ? `/api/profit?month=${month}` : null);
  const [name, setName] = useState(''); const [amount, setAmount] = useState('');
  if (!can('view_cost')) return <Forbidden what="báo cáo lợi nhuận" />;
  const call = async (fn: () => Promise<unknown>) => { try { await fn(); reload(); } catch (e) { toast.err(e instanceof Error ? e.message : 'Lỗi'); } };
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-2"><div><h1 className="text-2xl font-extrabold">LỢI NHUẬN & ĐIỂM HÒA VỐN</h1><p className="text-sm text-mocha">Lãi gộp − hao hụt − chi phí cố định (mặt bằng, lương, điện nước…).</p></div>
        <input type="month" className="input !w-44" value={month} onChange={(e) => e.target.value && setMonth(e.target.value)} aria-label="Tháng" /></div>
      {error && <ErrorBox message={error} onRetry={reload} />}
      {loading && !data && <Loading rows={3} />}
      {data && (<>
        <div className={`card p-4 ${data.net >= 0 ? 'bg-leaf-soft' : 'bg-danger-soft'}`}><p className="text-sm">Lợi nhuận ròng tháng {month.split('-').reverse().join('/')}</p><p className={`text-3xl font-extrabold ${data.net >= 0 ? 'text-leaf-dark' : 'text-danger'}`}>{vnd(data.net)}</p></div>
        <div className="card space-y-1 p-4 text-sm">
          <div className="flex justify-between"><span>Doanh thu ({data.cups} ly)</span><b>{vnd(data.revenue)}</b></div>
          <div className="flex justify-between"><span>Giá vốn</span><span>−{vnd(data.cogs)}</span></div>
          <div className="flex justify-between border-t pt-1"><span>Lãi gộp ({Math.round(data.margin * 100)}%)</span><b>{vnd(data.gross)}</b></div>
          <div className="flex justify-between"><span>Hao hụt/thất thoát</span><span>−{vnd(data.waste)}</span></div>
          <div className="flex justify-between"><span>Chi phí cố định</span><span>−{vnd(data.fixed_total)}</span></div>
        </div>
        <div className="card space-y-2 p-4 text-sm"><p className="font-bold">Điểm hòa vốn</p>
          {data.break_even_revenue === null ? <p className="text-mocha">Chưa đủ doanh thu để tính (cần có lãi gộp).</p> : (<>
            <div className="h-3 overflow-hidden rounded-full bg-cream"><div className={`h-full ${data.reached ? 'bg-leaf' : 'bg-warn'}`} style={{ width: `${data.progress * 100}%` }} /></div>
            <p>Cần doanh thu <b>{vnd(data.break_even_revenue)}</b>/tháng (≈ <b>{vnd(data.break_even_per_day ?? 0)}</b>/ngày) để hòa vốn. {data.reached ? '✅ Đã hòa vốn!' : `Đã đạt ${Math.round(data.progress * 100)}%.`}</p>
            <p className="text-mocha">Trung bình {vnd(data.avg_daily_revenue)}/ngày · dự kiến cả tháng {vnd(data.projected_revenue)}</p></>)}</div>
        <div className="card p-4"><p className="mb-2 font-bold">Chi phí cố định hàng tháng</p>
          <ul className="divide-y divide-[#f3ebdd] text-sm">{data.fixed.map((f) => (
            <li key={f.id} className="flex items-center gap-2 py-2"><label className="flex min-w-0 flex-1 items-center gap-2"><input type="checkbox" checked={!!f.active} onChange={(e) => call(() => api(`/api/fixed-costs/${f.id}`, { method: 'PUT', body: { name: f.name, amount: f.amount, active: e.target.checked } }))} /><span className="truncate">{f.name}</span></label><b>{vnd(f.amount)}</b>
              <button className="text-xs text-danger underline" onClick={() => confirm(`Xóa “${f.name}”?`) && call(() => api(`/api/fixed-costs/${f.id}`, { method: 'DELETE' }))}>Xóa</button></li>))}</ul>
          <div className="mt-3 flex gap-2"><input className="input" placeholder="Tên khoản (VD: Tiền thuê)" value={name} onChange={(e) => setName(e.target.value)} /><input className="input !w-36" type="number" min={0} placeholder="Số tiền/tháng" value={amount} onChange={(e) => setAmount(e.target.value)} />
            <button className="btn btn-green" onClick={() => call(async () => { await api('/api/fixed-costs', { method: 'POST', body: { name, amount: Number(amount) || 0, active: true } }); setName(''); setAmount(''); })}>Thêm</button></div></div>
      </>)}
    </div>
  );
}

'use client';
import { useMemo } from 'react';
import Link from 'next/link';
import { useApi, useLocalState } from '@/lib/client';
import { num, vnd } from '@/lib/format';
import { Empty, ErrorBox, Loading } from '@/components/ui';
import { DownloadButton } from '@/components/DownloadButton';
import { useAuth } from '@/components/Auth';
import { Forbidden } from '@/components/Auth';
import { useToast } from '@/components/Toast';

interface Item { id: number; name: string; supplier: string; unit: string; stock: number; minimum: number; qty: number; price: number; total: number }
interface Data { items: Item[]; preps: { id: number; name: string; stock: number; minimum: number; unit: string }[]; total: number }

export default function Shopping() {
  const { can } = useAuth();
  const toast = useToast();
  const { data, error, loading, reload } = useApi<Data>(can('edit_ingredients') ? '/api/shopping' : null);
  const [done, setDone] = useLocalState<number[]>('shopDone', []);
  const seeCost = can('view_cost');
  const groups = useMemo(() => {
    const m = new Map<string, Item[]>();
    for (const i of data?.items ?? []) (m.get(i.supplier) ?? m.set(i.supplier, []).get(i.supplier)!).push(i);
    return [...m];
  }, [data]);
  if (!can('edit_ingredients')) return <Forbidden />;
  const text = () => groups.map(([s, l]) => `${s}:\n` + l.map((i) => `- ${i.name}: ${num(i.qty, 2)} ${i.unit}`).join('\n')).join('\n\n');
  const copy = async () => { try { await navigator.clipboard.writeText(text()); toast.ok('Đã chép danh sách — dán vào Zalo/tin nhắn gửi nhà cung cấp'); } catch { toast.err('Không chép được, hãy dùng nút Excel hoặc In'); } };
  const left = (data?.items ?? []).filter((i) => !done.includes(i.id));
  return (
    <div className="space-y-4">
      <div className="no-print flex flex-wrap items-center justify-between gap-2">
        <div><h1 className="text-2xl font-extrabold">DANH SÁCH CẦN MUA</h1><p className="text-sm text-mocha">Nguyên liệu dưới mức tồn tối thiểu — gợi ý mua lên gấp đôi mức tối thiểu.</p></div>
        <div className="flex flex-wrap gap-2"><button className="btn btn-ghost" onClick={copy}>📋 Chép</button><button className="btn btn-ghost" onClick={() => window.print()}>🖨 In</button><DownloadButton url="/api/shopping?format=xlsx" filename="danh-sach-can-mua.xlsx">Excel</DownloadButton></div>
      </div>
      {error && <ErrorBox message={error} onRetry={reload} />}
      {loading && !data && <Loading rows={3} />}
      {data && data.items.length === 0 && data.preps.length === 0 && <Empty icon="✅" title="Không có gì cần mua" hint="Mọi nguyên liệu đều trên mức tồn tối thiểu." />}
      {data?.preps.length ? <div className="rounded-2xl bg-warn-soft p-3 text-sm"><b>🍳 Bán thành phẩm cần làm mẻ:</b> {data.preps.map((p) => `${p.name} (còn ${num(p.stock, 2)} ${p.unit})`).join(', ')} — <Link href="/ingredients" className="underline">vào Nguyên liệu để làm mẻ</Link></div> : null}
      {groups.map(([sup, list]) => (
        <section key={sup} className="card overflow-hidden">
          <h2 className="border-b border-[#eadfcd] bg-cream px-4 py-2 font-bold">{sup} <span className="text-sm font-normal text-mocha">· {list.length} món hàng</span></h2>
          <ul>{list.map((i) => (
            <li key={i.id} className="flex items-center gap-3 border-b border-[#f3ebdd] px-4 py-3 last:border-0">
              <input type="checkbox" className="no-print h-5 w-5 accent-[#7fa886]" aria-label={`Đã mua ${i.name}`} checked={done.includes(i.id)} onChange={(e) => setDone(e.target.checked ? [...done, i.id] : done.filter((x) => x !== i.id))} />
              <div className={`min-w-0 flex-1 ${done.includes(i.id) ? 'line-through opacity-50' : ''}`}><b>{i.name}</b><span className="block text-xs text-mocha">Tồn {num(i.stock, 2)} / tối thiểu {num(i.minimum, 2)} {i.unit}</span></div>
              <div className="text-right"><b>{num(i.qty, 2)} {i.unit}</b>{seeCost && <span className="block text-xs text-mocha">≈ {vnd(i.total)}</span>}</div>
            </li>))}</ul>
        </section>
      ))}
      {data && data.items.length > 0 && seeCost && <p className="text-right text-lg font-extrabold">Ước tính tổng: {vnd(data.total)} {left.length !== data.items.length && <span className="text-sm font-normal text-mocha">(còn {left.length} mục chưa mua)</span>}</p>}
      {done.length > 0 && <button className="no-print text-sm underline" onClick={() => setDone([])}>Bỏ chọn tất cả</button>}
    </div>
  );
}

'use client';
import { useEffect, useMemo, useRef, useState } from 'react';
import Link from 'next/link';
import { api, useApi, useLocalState } from '@/lib/client';
import { RECIPE_CATEGORIES, type Recipe, type Size } from '@/lib/types';
import type { Order } from '@/lib/orders';
import { norm, vnd } from '@/lib/format';
import { ErrorBox, Loading, Modal, RecipeThumb, Spinner, catIcon } from '@/components/ui';
import { AlternativesBox, AvailBadge, type AvailItem } from '@/components/Availability';
import { ShopSettings } from '@/components/ShopSettings';
import { useAuth } from '@/components/Auth';
import { useToast } from '@/components/Toast';
import { printReceipt } from '@/lib/print-client';
import type { Option } from '@/lib/options';
import { bestPromo, vnNow, type Promo, type PLine } from '@/lib/promo-pure';
import { LOYALTY_DEFAULT, normPhone, pointsEarned, redeem, validPhone, type LoyaltyCfg } from '@/lib/loyalty-pure';
import { TransferQr, type BankCfg } from '@/components/TransferQr';
import { bankConfigured } from '@/lib/vietqr';

interface CartLine { id: string; recipe_id: number; size: Size; quantity: number; note: string; options?: { id: number; qty: number }[] }
interface Settings extends BankCfg { table_count: number; has_qr: boolean; paper_width: string }
interface Cust { id: number; phone: string; name: string; points: number; visits: number }
type PrintMode = 'both' | 'bill' | 'kitchen' | 'none';
const NOTES = ['Ít đường', 'Không đường', 'Ít đá', 'Không đá', 'Nhiều đá', 'Ít ngọt', 'Thêm shot', 'Mang đi'];
const CASH = [50000, 100000, 200000, 500000];
const uid = () => (typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : String(Date.now() + Math.random()));

export default function Pos() {
  const toast = useToast();
  const { can } = useAuth();
  const rec = useApi<{ recipes: Recipe[] }>('/api/recipes');
  const av = useApi<{ items: AvailItem[] }>('/api/availability');
  const st = useApi<Settings>('/api/settings');
  const opt = useApi<{ options: Option[] }>('/api/options');
  const pr = useApi<{ promotions: Promo[] }>('/api/promotions');
  const [cart, setCart] = useLocalState<CartLine[]>('pos.cart', []);
  const [table, setTable] = useLocalState<string>('pos.table', 'Mang đi');
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('');
  const [adding, setAdding] = useState<Recipe | null>(null);
  const [outOf, setOutOf] = useState<AvailItem | null>(null);
  const [cartOpen, setCartOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [done, setDone] = useState<Order | null>(null);
  const [printMode, setPrintMode] = useLocalState<PrintMode>('pos.print', 'both');

  const recipes = useMemo(() => rec.data?.recipes ?? [], [rec.data]);
  const byId = useMemo(() => new Map(recipes.map((r) => [r.id, r])), [recipes]);
  const availBy = useMemo(() => new Map((av.data?.items ?? []).map((i) => [i.id, i])), [av.data]);
  const list = useMemo(() => recipes.filter((r) => (!cat || r.category === cat) && (!q || norm(`${r.name} ${r.category}`).includes(norm(q)))), [recipes, q, cat]);
  const lines = cart.filter((l) => byId.has(l.recipe_id));
  const options = useMemo(() => (opt.data?.options ?? []).filter((o) => o.active), [opt.data]);
  const optBy = useMemo(() => new Map((opt.data?.options ?? []).map((o) => [o.id, o])), [opt.data]);
  const promos = useMemo(() => (pr.data?.promotions ?? []).filter((p) => p.active), [pr.data]);
  const priceOf = (l: CartLine) => (byId.get(l.recipe_id)?.sizes.find((s) => s.name === l.size)?.selling_price ?? 0) + (l.options ?? []).reduce((a, o) => a + (optBy.get(o.id)?.price ?? 0) * o.qty, 0);
  const subtotal = lines.reduce((a, l) => a + priceOf(l) * l.quantity, 0);
  const count = lines.reduce((a, l) => a + l.quantity, 0);

  const addLine = (l: Omit<CartLine, 'id'>) => {
    setCart((c) => {
      const same = c.find((x) => x.recipe_id === l.recipe_id && x.size === l.size && x.note === l.note && JSON.stringify(x.options ?? []) === JSON.stringify(l.options ?? []));
      return same ? c.map((x) => (x === same ? { ...x, quantity: Math.min(100, x.quantity + l.quantity) } : x)) : [...c, { ...l, id: uid() }];
    });
  };
  const tap = (r: Recipe) => {
    if (r.availability?.status === 'out') setOutOf(availBy.get(r.id) ?? { id: r.id, name: r.name, category: r.category, image: r.image, availability: r.availability, alternatives: [] });
    else setAdding(r);
  };

  return (
    <div className="space-y-4 lg:grid lg:grid-cols-[1fr_400px] lg:gap-5 lg:space-y-0">
      <div className="min-w-0 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h1 className="text-2xl font-extrabold">BÁN HÀNG</h1>
          <div className="flex gap-2"><Link href="/orders" className="btn btn-ghost">🧾 Đơn hôm nay</Link>{can('edit_ingredients') && <button className="btn btn-ghost" onClick={() => setSettingsOpen(true)} aria-label="Cài đặt hóa đơn">⚙ In ấn</button>}</div>
        </div>
        <input className="input !min-h-12" placeholder="🔍 Tìm món…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Tìm món" />
        <div className="flex gap-2 overflow-x-auto pb-1" role="group" aria-label="Danh mục"><button className="chip shrink-0" aria-pressed={!cat} onClick={() => setCat('')}>Tất cả</button>
          {RECIPE_CATEGORIES.map((c) => <button key={c.name} className="chip shrink-0" aria-pressed={cat === c.name} onClick={() => setCat(cat === c.name ? '' : c.name)}>{catIcon(c.name)} {c.name}</button>)}</div>
        {rec.error && <ErrorBox message={rec.error} onRetry={rec.reload} />}
        {rec.loading && !rec.data && <Loading rows={4} />}
        <div className="grid grid-cols-2 gap-2.5 pb-28 sm:grid-cols-3 lg:grid-cols-3 lg:pb-4 xl:grid-cols-4">
          {list.map((r) => {
            const m = r.sizes.find((s) => s.name === 'M') ?? r.sizes[0];
            const out = r.availability?.status === 'out';
            const inCart = lines.filter((l) => l.recipe_id === r.id).reduce((a, l) => a + l.quantity, 0);
            return (
              <button key={r.id} onClick={() => tap(r)} className={`card pop relative overflow-hidden text-left transition active:scale-[.97] ${out ? 'opacity-60' : 'hover:-translate-y-0.5 hover:shadow-md'}`}>
                <RecipeThumb category={r.category} image={r.image} className="h-20 w-full" />
                {inCart > 0 && <span className="absolute right-2 top-2 flex h-7 min-w-7 items-center justify-center rounded-full bg-leaf px-1.5 text-sm font-extrabold text-white shadow">{inCart}</span>}
                <div className="p-2.5"><p className="line-clamp-2 min-h-[2.5em] text-sm font-bold leading-tight">{r.name}</p>
                  <p className="mt-1 flex flex-wrap items-center gap-1 text-sm"><b>{m ? vnd(m.selling_price) : '—'}</b>{out ? <span className="tag tag-miss">Hết hàng</span> : <AvailBadge a={r.availability} />}</p></div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Giỏ hàng — cột bên phải trên máy tính */}
      <aside className="no-print hidden lg:block"><div className="card sticky top-20 max-h-[calc(100vh-6rem)] overflow-y-auto p-4">
        <Cart lines={lines} byId={byId} setCart={setCart} table={table} setTable={setTable} st={st.data} availBy={availBy} subtotal={subtotal} unit={priceOf} optBy={optBy} promos={promos} printMode={printMode} setPrintMode={setPrintMode}
          onDone={(o) => { setDone(o); setCartOpen(false); av.reload(); rec.reload(); }} />
      </div></aside>

      {/* Thanh giỏ hàng trên điện thoại */}
      {count > 0 && (
        <button className="no-print fixed inset-x-3 bottom-[70px] z-30 flex items-center justify-between rounded-2xl bg-coffee px-5 py-3.5 text-white shadow-xl lg:hidden" onClick={() => setCartOpen(true)}>
          <span className="font-bold">🛒 {count} ly</span><span className="text-lg font-extrabold">{vnd(subtotal)} →</span></button>
      )}
      <Modal open={cartOpen} onClose={() => setCartOpen(false)} title="Đơn hiện tại">
        <Cart lines={lines} byId={byId} setCart={setCart} table={table} setTable={setTable} st={st.data} availBy={availBy} subtotal={subtotal} unit={priceOf} optBy={optBy} promos={promos} printMode={printMode} setPrintMode={setPrintMode}
          onDone={(o) => { setDone(o); setCartOpen(false); av.reload(); rec.reload(); }} />
      </Modal>

      <AddSheet recipe={adding} options={options} onClose={() => setAdding(null)} onAdd={(l) => { addLine(l); setAdding(null); toast.ok('Đã thêm vào đơn'); }} />
      <Modal open={!!outOf} onClose={() => setOutOf(null)} title={outOf ? `${outOf.name} đã hết hàng` : ''}>{outOf && <AlternativesBox item={outOf} />}
        {outOf && outOf.alternatives.length > 0 && <p className="mt-3 text-sm text-mocha">Chạm vào món gợi ý để xem; quay lại màn hình bán hàng để thêm vào đơn.</p>}</Modal>
      <Done order={done} printMode={printMode} onClose={() => setDone(null)} />
      <ShopSettings open={settingsOpen} onClose={() => setSettingsOpen(false)} onSaved={() => st.reload()} />
    </div>
  );
}

function AddSheet({ recipe, options, onClose, onAdd }: { recipe: Recipe | null; options: Option[]; onClose: () => void; onAdd: (l: Omit<CartLine, 'id'>) => void }) {
  const [size, setSize] = useState<Size>('M');
  const [qty, setQty] = useState(1);
  const [notes, setNotes] = useState<string[]>([]);
  const [free, setFree] = useState('');
  const [picked, setPicked] = useState<Record<number, number>>({});
  useEffect(() => { if (recipe) { setPicked({}); setSize(recipe.sizes.find((s) => s.name === 'M')?.name ?? recipe.sizes[0]?.name ?? 'M'); setQty(1); setNotes([]); setFree(''); } }, [recipe]);
  if (!recipe) return null;
  const sz = recipe.sizes.find((s) => s.name === size);
  const cups = recipe.availability?.cups;
  const optSum = Object.entries(picked).reduce((a, [id, q]) => a + (options.find((o) => o.id === Number(id))?.price ?? 0) * q, 0);
  return (
    <Modal open onClose={onClose} title={recipe.name}>
      <div className="space-y-4">
        {recipe.availability?.status === 'low' && <p className="rounded-xl bg-warn-soft p-2.5 text-sm font-semibold text-[#8a5a00]">⚠ Chỉ còn khoảng {cups} ly</p>}
        <div><p className="label">Size</p><div className="flex gap-2">{recipe.sizes.map((s) => <button key={s.name} className="chip flex-1 flex-col !items-center !rounded-2xl !py-2" aria-pressed={size === s.name} onClick={() => setSize(s.name)}><b className="text-lg">{s.name}</b><span className="text-xs">{vnd(s.selling_price)}</span></button>)}</div></div>
        <div><p className="label">Số lượng</p><div className="flex items-center gap-3"><button className="btn btn-ghost btn-lg" onClick={() => setQty(Math.max(1, qty - 1))} aria-label="Giảm">−</button><b className="w-10 text-center text-2xl">{qty}</b><button className="btn btn-ghost btn-lg" onClick={() => setQty(Math.min(100, qty + 1))} aria-label="Tăng">+</button></div></div>
        {options.length > 0 && <div><p className="label">Topping / thêm</p><div className="flex flex-wrap gap-1.5">{options.map((o) => { const q = picked[o.id] ?? 0; return (
          <button key={o.id} disabled={!o.available} className="chip disabled:opacity-40" aria-pressed={q > 0} onClick={() => setPicked((p) => { const n = { ...p }; if (q >= 3) delete n[o.id]; else n[o.id] = q + 1; return n; })} title={o.available ? 'Chạm thêm để tăng số lượng' : 'Hết nguyên liệu'}>
            {o.name}{q > 0 && ` ×${q}`} <small>+{vnd(o.price)}</small>{!o.available && ' (hết)'}</button>); })}</div></div>}
        <div><p className="label">Ghi chú</p><div className="flex flex-wrap gap-1.5">{NOTES.map((n) => <button key={n} className="chip" aria-pressed={notes.includes(n)} onClick={() => setNotes(notes.includes(n) ? notes.filter((x) => x !== n) : [...notes, n])}>{n}</button>)}</div>
          <input className="input mt-2" placeholder="Ghi chú khác…" maxLength={60} value={free} onChange={(e) => setFree(e.target.value)} /></div>
        <button className="btn btn-green btn-lg w-full" onClick={() => onAdd({ recipe_id: recipe.id, size, quantity: qty, note: [...notes, free.trim()].filter(Boolean).join(', '), options: Object.entries(picked).map(([id, q]) => ({ id: Number(id), qty: q })) })}>Thêm vào đơn · {vnd(((sz?.selling_price ?? 0) + optSum) * qty)}</button>
      </div>
    </Modal>
  );
}

function Cart({ lines, byId, setCart, table, setTable, st, availBy, subtotal, unit, optBy, promos, printMode, setPrintMode, onDone }: {
  unit: (l: CartLine) => number; optBy: Map<number, Option>; promos: Promo[];
  lines: CartLine[]; byId: Map<number, Recipe>; setCart: (f: (c: CartLine[]) => CartLine[]) => void; table: string; setTable: (t: string) => void; st: Settings | null;
  availBy: Map<number, AvailItem>; subtotal: number; printMode: PrintMode; setPrintMode: (m: PrintMode) => void; onDone: (o: Order) => void;
}) {
  const { can } = useAuth();
  const toast = useToast();
  const [dtype, setDtype] = useState<'amount' | 'percent'>('percent');
  const [dval, setDval] = useState('');
  const [pay, setPay] = useState<'cash' | 'transfer'>('cash');
  const [received, setReceived] = useState('');
  const [orderNote, setOrderNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<{ msg: string; recipes: number[]; canForce: boolean } | null>(null);
  const [qr, setQr] = useState('');
  const [voucher, setVoucher] = useState('');
  const [phone, setPhone] = useState('');
  const [cname, setCname] = useState('');
  const [cust, setCust] = useState<Cust | null>(null);
  const [loy, setLoy] = useState<LoyaltyCfg>(LOYALTY_DEFAULT);
  const [useP, setUseP] = useState(0);
  const key = useRef(uid());
  useEffect(() => {
    const ph = normPhone(phone);
    setCust(null); setUseP(0);
    if (!validPhone(ph)) return;
    let alive = true;
    const t = setTimeout(() => { api<{ customer: Cust | null; loyalty: LoyaltyCfg }>(`/api/customers/lookup?phone=${ph}`).then((r) => { if (alive) { setCust(r.customer); setLoy(r.loyalty); } }).catch(() => {}); }, 250);
    return () => { alive = false; clearTimeout(t); };
  }, [phone]);
  useEffect(() => { if (st?.has_qr && pay === 'transfer' && !qr) api<{ qr_image: string }>('/api/settings/qr').then((r) => setQr(r.qr_image)).catch(() => {}); }, [st?.has_qr, pay, qr]);

  const dnum = Number(dval) || 0;
  const plines: PLine[] = lines.map((l) => ({ recipe_id: l.recipe_id, category: byId.get(l.recipe_id)?.category ?? '', quantity: l.quantity, unit_price: unit(l) }));
  const bp = useMemo(() => bestPromo(promos, plines, subtotal, vnNow(), voucher), [promos, lines, subtotal, voucher]); // eslint-disable-line react-hooks/exhaustive-deps
  const promoDisc = bp.result?.discount ?? 0;
  const afterPromo = subtotal - promoDisc;
  const manual = Math.min(afterPromo, dtype === 'percent' ? Math.round((afterPromo * Math.min(100, dnum)) / 100) : Math.round(dnum));
  const rd = cust ? redeem(useP, cust.points, afterPromo - manual, loy) : { points: 0, discount: 0 };
  const discount = promoDisc + manual + rd.discount;
  const total = subtotal - discount;
  const willEarn = validPhone(phone) ? pointsEarned(total, loy) : 0;
  const rec = Number(received) || 0;
  const change = rec - total;
  const tables = ['Mang đi', ...Array.from({ length: st?.table_count ?? 10 }, (_, i) => `Bàn ${i + 1}`)];

  const upd = (id: string, p: Partial<CartLine>) => setCart((c) => c.map((l) => (l.id === id ? { ...l, ...p } : l)));
  const submit = async (force = false) => {
    if (!lines.length) return;
    if (pay === 'cash' && received !== '' && rec < total) return toast.err('Tiền khách đưa chưa đủ');
    setBusy(true); setErr(null);
    try {
      const body = { key: key.current, table_name: table, note: orderNote, payment: pay, cash_received: pay === 'cash' && received !== '' ? rec : undefined, discount: dnum > 0 ? { type: dtype, value: dnum } : undefined, force: force || undefined,
        promo_code: voucher.trim() || undefined, customer: validPhone(phone) ? { phone: normPhone(phone), name: cname.trim() || undefined } : undefined, redeem_points: rd.points || undefined,
        items: lines.map((l) => ({ recipe_id: l.recipe_id, size: l.size, quantity: l.quantity, note: l.note || undefined, options: (l.options ?? []).length ? l.options : undefined })) };
      const r = await api<{ order: Order }>('/api/orders', { method: 'POST', body });
      key.current = uid();
      setCart(() => []); setDval(''); setReceived(''); setOrderNote(''); setVoucher(''); setPhone(''); setCname(''); setCust(null); setUseP(0);
      onDone(r.order);
      if (printMode !== 'none') printReceipt(r.order.id, printMode);
    } catch (e) {
      const er = e as Error & { status?: number; details?: { recipes?: number[] } };
      if (er.status === 409) setErr({ msg: er.message, recipes: er.details?.recipes ?? [], canForce: can('edit_ingredients') });
      else toast.err(er.message);
    } finally { setBusy(false); }
  };

  if (!lines.length) return <p className="py-8 text-center text-mocha">Chưa có món nào. Chạm vào món để thêm vào đơn.</p>;
  return (
    <div className="space-y-4">
      <ul className="divide-y divide-[#f3ebdd]">
        {lines.map((l) => { const r = byId.get(l.recipe_id)!; const price = unit(l); return (
          <li key={l.id} className="py-2.5">
            <div className="flex items-start justify-between gap-2"><div className="min-w-0"><p className="font-bold leading-tight">{r.name} <span className="tag tag-neutral">{l.size}</span></p>
              {(l.options ?? []).length > 0 && <p className="text-xs font-semibold text-leaf-dark">{(l.options ?? []).map((o) => `+ ${optBy.get(o.id)?.name ?? 'topping'}${o.qty > 1 ? ` ×${o.qty}` : ''}`).join(', ')}</p>}
              <input className="mt-1 w-full rounded-lg border border-transparent bg-transparent text-xs text-mocha placeholder:text-mocha/50 hover:border-[#e3d5c1] focus:border-latte focus:bg-white" placeholder="+ ghi chú" value={l.note} maxLength={120} onChange={(e) => upd(l.id, { note: e.target.value })} aria-label={`Ghi chú ${r.name}`} /></div>
              <b className="shrink-0">{vnd(price * l.quantity)}</b></div>
            <div className="mt-1 flex items-center gap-2"><button className="btn btn-ghost btn-sm" onClick={() => (l.quantity > 1 ? upd(l.id, { quantity: l.quantity - 1 }) : setCart((c) => c.filter((x) => x.id !== l.id)))} aria-label="Giảm">−</button><b className="w-6 text-center">{l.quantity}</b>
              <button className="btn btn-ghost btn-sm" onClick={() => upd(l.id, { quantity: Math.min(100, l.quantity + 1) })} aria-label="Tăng">+</button>
              <button className="ml-auto text-xs text-danger underline" onClick={() => setCart((c) => c.filter((x) => x.id !== l.id))}>Xóa</button></div>
          </li>); })}
      </ul>

      <div><p className="label">Bàn / hình thức</p><div className="flex max-h-28 flex-wrap gap-1.5 overflow-y-auto">{tables.map((t) => <button key={t} className="chip" aria-pressed={table === t} onClick={() => setTable(t)}>{t === 'Mang đi' ? '🥡 Mang đi' : t}</button>)}</div></div>
      <input className="input" placeholder="Ghi chú cho cả đơn (tuỳ chọn)" maxLength={200} value={orderNote} onChange={(e) => setOrderNote(e.target.value)} />

      <div><p className="label">Khách thân thiết (tuỳ chọn)</p>
        <input className="input" type="tel" inputMode="tel" placeholder="Số điện thoại khách" value={phone} onChange={(e) => setPhone(e.target.value)} maxLength={14} />
        {validPhone(phone) && (cust
          ? <div className="mt-2 space-y-1.5 rounded-xl bg-leaf-soft p-2.5 text-sm"><p className="font-bold">{cust.name || 'Khách quen'} · {cust.points} điểm · {cust.visits} lần ghé</p>
              {cust.points > 0 && <label className="flex items-center gap-2"><span>Dùng điểm:</span><input className="input !w-24 !min-h-9" type="number" min={0} max={cust.points} value={useP || ''} placeholder="0" onChange={(e) => setUseP(Math.max(0, Math.min(cust.points, Math.floor(Number(e.target.value) || 0))))} aria-label="Số điểm dùng" />{rd.points > 0 && <b className="text-leaf-dark">−{vnd(rd.discount)}</b>}</label>}</div>
          : <div className="mt-2 space-y-1.5 text-sm"><p className="text-mocha">Khách mới — sẽ tạo hồ sơ khi thanh toán.</p><input className="input !min-h-9" placeholder="Tên khách (tuỳ chọn)" value={cname} onChange={(e) => setCname(e.target.value)} maxLength={60} /></div>)}
        {willEarn > 0 && <p className="mt-1 text-xs text-mocha">Đơn này tích <b>+{willEarn} điểm</b></p>}</div>

      <div><p className="label">Mã giảm giá / khuyến mãi</p>
        <input className="input" placeholder="Nhập mã voucher (nếu có)" value={voucher} onChange={(e) => setVoucher(e.target.value)} maxLength={30} />
        {bp.codeError && <p className="mt-1 text-xs font-semibold text-danger">{bp.codeError}</p>}
        {bp.result && <p className="mt-1 rounded-lg bg-leaf-soft p-2 text-sm font-semibold text-leaf-dark">🎁 {bp.result.label}: −{vnd(bp.result.discount)}</p>}</div>

      <div><p className="label">Giảm giá</p><div className="flex gap-2"><select className="input !w-28" value={dtype} onChange={(e) => setDtype(e.target.value as 'amount' | 'percent')} aria-label="Loại giảm giá"><option value="percent">%</option><option value="amount">đ</option></select>
        <input className="input" type="number" min={0} inputMode="decimal" placeholder="0" value={dval} onChange={(e) => setDval(e.target.value)} aria-label="Giá trị giảm" /></div></div>

      <div className="space-y-1 rounded-2xl bg-cream p-3 text-sm">
        <div className="flex justify-between"><span>Tạm tính</span><span>{vnd(subtotal)}</span></div>
        {promoDisc > 0 && <div className="flex justify-between text-leaf-dark"><span>KM {bp.result?.label}</span><span>-{vnd(promoDisc)}</span></div>}
        {manual > 0 && <div className="flex justify-between text-leaf-dark"><span>Giảm giá</span><span>-{vnd(manual)}</span></div>}
        {rd.discount > 0 && <div className="flex justify-between text-leaf-dark"><span>Điểm ×{rd.points}</span><span>-{vnd(rd.discount)}</span></div>}
        <div className="flex justify-between text-xl font-extrabold"><span>Khách trả</span><span>{vnd(total)}</span></div>
      </div>

      <div><p className="label">Thanh toán</p><div className="flex gap-2">{([['cash', '💵 Tiền mặt'], ['transfer', '🏦 Chuyển khoản']] as const).map(([k, l]) => <button key={k} className="chip flex-1 justify-center !py-2.5" aria-pressed={pay === k} onClick={() => setPay(k)}>{l}</button>)}</div></div>
      {pay === 'cash' && (<div><p className="label">Tiền khách đưa (tuỳ chọn)</p><input className="input" type="number" min={0} inputMode="numeric" value={received} onChange={(e) => setReceived(e.target.value)} placeholder={String(total)} />
        <div className="mt-2 flex flex-wrap gap-1.5"><button className="chip" onClick={() => setReceived(String(total))}>Đủ</button>{CASH.filter((c) => c >= total).slice(0, 3).map((c) => <button key={c} className="chip" onClick={() => setReceived(String(c))}>{c / 1000}k</button>)}</div>
        {received !== '' && <p className={`mt-2 font-bold ${change < 0 ? 'text-danger' : 'text-leaf-dark'}`}>{change < 0 ? `Còn thiếu ${vnd(-change)}` : `Tiền thừa: ${vnd(change)}`}</p>}</div>)}
      {pay === 'transfer' && (<div className="rounded-2xl bg-white p-3 text-center">{st && bankConfigured(st) ? <TransferQr cfg={st} amount={total} memo="Thanh toan" /> : qr ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={qr} alt="QR chuyển khoản" className="mx-auto h-44 w-44 object-contain" /> : <p className="text-sm text-mocha">{st?.has_qr ? <Spinner /> : 'Chưa có ảnh QR — quản lý có thể tải ở “⚙ In ấn”.'}</p>}<p className="mt-1 text-sm font-bold">Số tiền: {vnd(total)}</p></div>)}

      {err && (
        <div className="space-y-2 rounded-2xl bg-danger-soft p-3 text-sm" role="alert">
          <p className="font-bold text-danger">🚫 {err.msg}</p>
          <p>Xóa món hết hàng khỏi đơn hoặc chọn món thay thế:</p>
          {err.recipes.map((id) => { const a = availBy.get(id); return a ? <div key={id}><p className="mb-1 font-semibold">{a.name}</p><AlternativesBox item={{ ...a, availability: { ...a.availability, status: a.availability.status === 'ok' ? 'low' : a.availability.status } }} compact /></div> : null; })}
          {err.canForce && <button className="btn btn-danger btn-sm" onClick={() => confirm('Kho báo thiếu nguyên liệu. Vẫn bán và trừ kho về 0?') && submit(true)}>Vẫn bán (bỏ qua kiểm tra kho)</button>}
        </div>
      )}

      <div className="flex items-center gap-2 text-xs text-mocha"><span>In:</span>{([['both', 'Hóa đơn + phiếu pha'], ['bill', 'Hóa đơn'], ['kitchen', 'Phiếu pha'], ['none', 'Không in']] as const).map(([k, l]) => <button key={k} className="chip !min-h-8 !px-2 !text-xs" aria-pressed={printMode === k} onClick={() => setPrintMode(k)}>{l}</button>)}</div>
      <button className="btn btn-green btn-lg w-full !text-lg" onClick={() => submit()} disabled={busy}>{busy ? <Spinner /> : '✔'} Thanh toán {vnd(total)}</button>
      <button className="w-full text-sm text-mocha underline" onClick={() => confirm('Xóa toàn bộ đơn đang soạn?') && setCart(() => [])}>Xóa đơn đang soạn</button>
    </div>
  );
}

function Done({ order, printMode, onClose }: { order: Order | null; printMode: PrintMode; onClose: () => void }) {
  if (!order) return null;
  return (
    <Modal open onClose={onClose} title="Đã thanh toán">
      <div className="space-y-3 text-center">
        <div className="text-5xl">✅</div>
        <p className="text-2xl font-extrabold">Đơn #{order.code}</p>
        <p className="text-lg">{vnd(order.total)} · {order.payment === 'cash' ? 'Tiền mặt' : 'Chuyển khoản'} · {order.table_name}</p>
        {order.points_earned > 0 && <p className="rounded-xl bg-leaf-soft p-2 text-sm font-semibold text-leaf-dark">⭐ Khách được cộng {order.points_earned} điểm{order.points_used > 0 ? ` · đã dùng ${order.points_used} điểm` : ''}</p>}
        {order.payment === 'cash' && order.cash_received != null && order.cash_received > order.total && <p className="text-xl font-extrabold text-leaf-dark">Trả lại khách: {vnd(order.cash_received - order.total)}</p>}
        {printMode !== 'none' && <p className="text-sm text-mocha">Đang mở hộp thoại in… Nếu không thấy, bấm “In lại” bên dưới.</p>}
        <div className="grid grid-cols-2 gap-2"><button className="btn btn-ghost" onClick={() => printReceipt(order.id, 'bill')}>🧾 In hóa đơn</button><button className="btn btn-ghost" onClick={() => printReceipt(order.id, 'kitchen')}>🍹 In phiếu pha</button></div>
        <button className="btn btn-green btn-lg w-full" onClick={onClose}>Đơn mới</button>
      </div>
    </Modal>
  );
}

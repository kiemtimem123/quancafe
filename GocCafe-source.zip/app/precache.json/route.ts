import fs from 'fs';
import path from 'path';

export const dynamic = 'force-dynamic';
const PAGES = ['/', '/pos', '/recipes', '/recipes/new', '/recipes/0', '/recipes/0/edit', '/ingredients', '/orders', '/availability', '/kitchen', '/expiry', '/options', '/promotions', '/customers', '/purchases', '/shopping', '/sales', '/dashboard', '/audit', '/customer-orders', '/assistant', '/receipt/0', '/login'];

function walk(dir: string, base: string, out: string[]) {
  let ents: fs.Dirent[] = [];
  try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
  for (const e of ents) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, `${base}/${e.name}`, out);
    else if (!e.name.endsWith('.map')) out.push(`${base}/${e.name}`);
  }
}
/** Danh sách tệp cần lưu sẵn để mở được mọi trang khi mất mạng (đọc từ bản build hiện tại). */
export const GET = () => {
  const files: string[] = [];
  walk(path.join(process.cwd(), '.next', 'static'), '/_next/static', files);
  let build = '';
  try { build = fs.readFileSync(path.join(process.cwd(), '.next', 'BUILD_ID'), 'utf8').trim(); } catch { /* dev */ }
  return Response.json({ build, pages: PAGES, files: files.map((f) => encodeURI(f)) }, { headers: { 'cache-control': 'no-store' } });
};

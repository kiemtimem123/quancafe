'use client';
import { useState } from 'react';
import { api, useApi } from '@/lib/client';
import { num, vnd } from '@/lib/format';
import { Empty, ErrorBox, Loading, Modal, Spinner } from '@/components/ui';
import { Forbidden, useAuth } from '@/components/Auth';
import { useToast } from '@/components/Toast';

interface Opt { id: number; name: string; price: number; ingredient_id: number | null; qty: number; active: boolean; cost: number; available: boolean; ingredient_name: string }
interface Ing { id: number; name: string; base_unit: string }
type Form = { id?: number; name: string; price: string; ingredient_id: number | null; qty: string; active: boolean };
const blank: Form = { name: '', price: '', ingredient_id: null, qty: '', active: true };

export default function OptionsPage() {
  const { can } = useAuth();
  const toast = useToast();
  const ok = can('edit_ingredients');
  const opts = useApi<{ options: Opt[] }>(ok ? '/api/options' : null);
  const ings = useApi<{ ingredients: Ing[] }>(ok ? '/api/ingredients' : null);
  const [f, setF] = useState<Form | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  if (!ok) return <Forbidden />;
  const ing = ings.data?.ingredients.find((i) => i.id === f?.ingredient_id);
  const save = async () => {
    if (!f) return;
    setErr(''); setBusy(true);
    try {
      const body = { name: f.name, price: Number(f.price || 0), ingredient_id: f.ingredient_id, qty: Number(f.qty || 0), active: f.active };
      await api(f.id ? `/api/options/${f.id}` : '/api/options', { method: f.id ? 'PUT' : 'POST', body });
      toast.ok('Đã lưu topping'); setF(null); opts.reload();
    } catch (e) { setErr(e instanceof Error ? e.message : 'Lỗi'); } finally { setBusy(false); }
  };
  const del = async (o: Opt) => {
    if (!confirm(`Xóa topping "${o.name}"? Đơn cũ vẫn giữ nguyên.`)) return;
    try { await api(`/api/options/${o.id}`, { method: 'DELETE' }); opts.reload(); } catch (e) { toast.err(e instanceof Error ? e.message : 'Lỗi'); }
  };
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div><h1 className="text-2xl font-extrabold">TOPPING & TÙY CHỌN</h1><p className="text-sm text-mocha">Khách chọn thêm khi order; tự trừ kho và tính vào giá vốn nếu gắn nguyên liệu.</p></div>
        <button className="btn btn-green btn-lg" onClick={() => { setErr(''); setF(blank); }}>+ Thêm topping</button>
      </div>
      {opts.error && <ErrorBox message={opts.error} onRetry={opts.reload} />}
      {opts.loading && !opts.data && <Loading rows={3} />}
      {opts.data && opts.data.options.length === 0 && <Empty icon="🧋" title="Chưa có topping" hint="Ví dụ: Trân châu đen +5.000đ, Kem cheese +10.000đ, Thêm shot espresso +8.000đ." />}
      <ul className="grid gap-2 sm:grid-cols-2">
        {opts.data?.options.map((o) => (
          <li key={o.id} className={`card flex items-center gap-3 p-3 ${o.active ? '' : 'opacity-50'}`}>
            <div className="min-w-0 flex-1">
              <b>{o.name}</b> <span className="text-leaf-dark">+{vnd(o.price)}</span>
              <span className="block text-xs text-mocha">{o.ingredient_name ? `Trừ ${num(o.qty, 2)} • ${o.ingredient_name}${can('view_cost') ? ` • vốn ${vnd(o.cost)}` : ''}` : 'Không trừ kho'}{!o.available && <span className="tag tag-danger ml-1">Hết</span>}{!o.active && <span className="tag tag-neutral ml-1">Tắt</span>}</span>
            </div>
            <button className="btn btn-ghost btn-sm" onClick={() => { setErr(''); setF({ id: o.id, name: o.name, price: String(o.price), ingredient_id: o.ingredient_id, qty: String(o.qty), active: o.active }); }}>Sửa</button>
            <button className="btn btn-danger btn-sm" onClick={() => del(o)}>Xóa</button>
          </li>
        ))}
      </ul>
      <Modal open={!!f} onClose={() => setF(null)} title={f?.id ? 'Sửa topping' : 'Thêm topping'}>
        {f && <div className="space-y-3">
          {err && <p className="rounded-xl bg-danger-soft p-3 text-sm text-danger" role="alert">{err}</p>}
          <div><label className="label" htmlFor="on">Tên</label><input id="on" className="input" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
          <div><label className="label" htmlFor="op">Giá bán thêm (đ)</label><input id="op" inputMode="numeric" className="input" value={f.price} onChange={(e) => setF({ ...f, price: e.target.value.replace(/[^\d]/g, '') })} /></div>
          <div><label className="label" htmlFor="oi">Nguyên liệu bị trừ kho (tuỳ chọn)</label>
            <select id="oi" className="input" value={f.ingredient_id ?? ''} onChange={(e) => setF({ ...f, ingredient_id: e.target.value ? Number(e.target.value) : null })}>
              <option value="">— Không trừ kho —</option>{ings.data?.ingredients.map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}
            </select></div>
          {f.ingredient_id && <div><label className="label" htmlFor="oq">Lượng dùng mỗi lần ({ing?.base_unit})</label><input id="oq" inputMode="decimal" className="input" value={f.qty} onChange={(e) => setF({ ...f, qty: e.target.value.replace(',', '.') })} /></div>}
          <label className="flex items-center gap-2"><input type="checkbox" className="h-5 w-5 accent-[#7fa886]" checked={f.active} onChange={(e) => setF({ ...f, active: e.target.checked })} /> Đang bán</label>
          <button className="btn btn-green btn-lg w-full" onClick={save} disabled={busy}>{busy ? <Spinner /> : 'Lưu'}</button>
        </div>}
      </Modal>
    </div>
  );
}

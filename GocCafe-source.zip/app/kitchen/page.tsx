'use client';
import { ExpiryBanner } from '@/components/ExpiryBanner';
import { useEffect, useMemo, useState } from 'react';
import { useApi } from '@/lib/client';
import { RECIPE_CATEGORIES, type Recipe, type Size } from '@/lib/types';
import { norm, num } from '@/lib/format';
import { ErrorBox, Loading, RecipeThumb, catIcon } from '@/components/ui';
import { AvailBadge } from '@/components/Availability';

/** Màn hình bếp: chữ to, ít thao tác, không hiện giá vốn — dùng trên máy tính bảng đặt ở quầy. Hoạt động offline sau lần mở đầu. */
export default function Kitchen() {
  const { data, error, loading, reload } = useApi<{ recipes: Recipe[] }>('/api/recipes');
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('');
  const [sel, setSel] = useState<Recipe | null>(null);
  const [size, setSize] = useState<Size>('M');
  const [done, setDone] = useState<number[]>([]);
  const [mult, setMult] = useState(1);

  // giữ màn hình sáng khi đang làm món
  useEffect(() => {
    if (!sel) return;
    let lock: { release: () => Promise<void> } | null = null;
    const nav = navigator as Navigator & { wakeLock?: { request: (t: 'screen') => Promise<{ release: () => Promise<void> }> } };
    nav.wakeLock?.request('screen').then((l) => (lock = l)).catch(() => {});
    return () => { lock?.release().catch(() => {}); };
  }, [sel]);

  const list = useMemo(() => (data?.recipes ?? []).filter((r) => (!cat || r.category === cat) && (!q || norm(`${r.name} ${r.category}`).includes(norm(q)))), [data, q, cat]);
  const open = (r: Recipe) => { setSel(r); setSize(r.sizes.find((s) => s.name === 'M')?.name ?? r.sizes[0]?.name ?? 'M'); setDone([]); setMult(1); window.scrollTo(0, 0); };

  if (sel) {
    const sz = sel.sizes.find((s) => s.name === size) ?? sel.sizes[0];
    const steps = sel.instructions;
    return (
      <div className="space-y-5 text-lg">
        <div className="flex items-center justify-between gap-2">
          <button className="btn btn-ghost btn-lg" onClick={() => setSel(null)}>← Danh sách</button>
          <div className="flex gap-2" role="tablist" aria-label="Size">{sel.sizes.map((s) => <button key={s.name} role="tab" aria-selected={s.name === size} className="chip !min-h-12 !min-w-14 justify-center !text-xl" aria-pressed={s.name === size} onClick={() => setSize(s.name)}>{s.name}</button>)}</div>
        </div>
        <div className="flex items-center gap-4"><RecipeThumb category={sel.category} image={sel.image} className="h-24 w-24 shrink-0 rounded-2xl" />
          <div><h1 className="text-3xl font-extrabold uppercase leading-tight sm:text-4xl">{sel.name}</h1><p className="text-mocha">⏱ {sel.preparation_time} phút · {sel.difficulty} <AvailBadge a={sel.availability} /></p></div></div>
        <section className="card p-4"><div className="mb-2 flex items-center justify-between"><h2 className="text-xl font-extrabold">NGUYÊN LIỆU {mult > 1 && <span className="text-mocha">× {mult} ly</span>}</h2>
          <div className="flex items-center gap-2"><button className="btn btn-ghost" onClick={() => setMult(Math.max(1, mult - 1))} aria-label="Giảm số ly">−</button><b className="w-8 text-center text-xl">{mult}</b><button className="btn btn-ghost" onClick={() => setMult(Math.min(50, mult + 1))} aria-label="Tăng số ly">+</button></div></div>
          <ul className="divide-y divide-[#f3ebdd]">{sz?.lines.map((l) => (
            <li key={l.ingredient_id} className="flex items-center justify-between gap-3 py-2.5"><span className={`font-semibold ${l.optional ? 'text-mocha' : ''}`}>{l.name}{l.optional && ' (tuỳ chọn)'}{!l.stock_ok && <span className="tag tag-miss ml-2">hết</span>}</span><b className="text-2xl tabular-nums">{num(l.quantity * mult, 1)} <small className="text-base font-semibold text-mocha">{l.unit}</small></b></li>))}</ul></section>
        <section className="space-y-2"><h2 className="text-xl font-extrabold">CÁCH LÀM</h2>
          {steps.length === 0 && <p className="text-mocha">Chưa có hướng dẫn.</p>}
          {steps.map((t, i) => (
            <button key={i} onClick={() => setDone(done.includes(i) ? done.filter((x) => x !== i) : [...done, i])} aria-pressed={done.includes(i)}
              className={`flex w-full items-start gap-4 rounded-2xl border-2 p-4 text-left transition ${done.includes(i) ? 'border-leaf bg-leaf-soft opacity-60' : 'border-[#eadfcd] bg-white'}`}>
              <span className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-full text-xl font-extrabold ${done.includes(i) ? 'bg-leaf text-white' : 'bg-coffee text-white'}`}>{done.includes(i) ? '✓' : i + 1}</span>
              <span className={`pt-1.5 text-xl leading-snug ${done.includes(i) ? 'line-through' : ''}`}>{t}</span></button>))}
          {steps.length > 0 && done.length === steps.length && <p className="rounded-2xl bg-leaf-soft p-4 text-center text-xl font-extrabold text-leaf-dark">✅ Xong! Phục vụ khách.</p>}
        </section>
      </div>
    );
  }
  return (
    <div className="space-y-4">
      <ExpiryBanner />
      <div><h1 className="text-2xl font-extrabold">MÀN HÌNH BẾP</h1><p className="text-sm text-mocha">Chọn món để xem công thức cỡ lớn. Mở trang này một lần khi có mạng — sau đó dùng được cả khi mất mạng.</p></div>
      <input className="input !min-h-14 !text-xl" placeholder="🔍 Gõ tên món…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Tìm món" />
      <div className="flex gap-2 overflow-x-auto pb-1" role="group" aria-label="Danh mục"><button className="chip !min-h-12 !text-base" aria-pressed={!cat} onClick={() => setCat('')}>Tất cả</button>{RECIPE_CATEGORIES.map((c) => <button key={c.name} className="chip !min-h-12 shrink-0 !text-base" aria-pressed={cat === c.name} onClick={() => setCat(cat === c.name ? '' : c.name)}>{catIcon(c.name)} {c.name}</button>)}</div>
      {error && <ErrorBox message={error} onRetry={reload} />}
      {loading && !data && <Loading rows={4} />}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-4">
        {list.map((r) => (
          <button key={r.id} onClick={() => open(r)} className={`card pop overflow-hidden text-left transition active:scale-[.98] ${r.availability?.status === 'out' ? 'opacity-60' : ''}`}>
            <RecipeThumb category={r.category} image={r.image} className="h-24 w-full" />
            <div className="p-3"><p className="text-lg font-extrabold leading-tight">{r.name}</p><p className="mt-1"><AvailBadge a={r.availability} /></p></div></button>))}
      </div>
    </div>
  );
}

'use client';
import { Suspense, use, useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { useApi, api, useRouteId } from '@/lib/client';
import type { Order } from '@/lib/orders';
import QRCode from 'qrcode';
import { bankConfigured, vietQrPayload } from '@/lib/vietqr';

interface Settings { shop_name: string; shop_address: string; shop_phone: string; receipt_footer: string; paper_width: '58' | '80'; has_qr: boolean; bank_info: string; bank_bin?: string; bank_account?: string; bank_holder?: string }
const money = (n: number) => Math.round(n).toLocaleString('vi-VN');
const dt = (s: string) => new Date(s.replace(' ', 'T') + 'Z').toLocaleString('vi-VN', { timeZone: 'Asia/Ho_Chi_Minh', day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });

function Bill({ o, s, qr }: { o: Order; s: Settings; qr: string }) {
  const cups = o.items.reduce((a, i) => a + i.quantity, 0);
  return (
    <section className="rc-page">
      <div className="rc-c rc-big">{s.shop_name}</div>
      {s.shop_address && <div className="rc-c rc-sm">{s.shop_address}</div>}
      {s.shop_phone && <div className="rc-c rc-sm">ĐT: {s.shop_phone}</div>}
      <div className="rc-hr" />
      <div className="rc-c rc-b">HÓA ĐƠN BÁN HÀNG</div>
      {o.status === 'void' && <div className="rc-c rc-b rc-stamp">*** ĐÃ HỦY ***</div>}
      <div className="rc-row"><span>Đơn #{o.code}</span><span>{o.table_name}</span></div>
      <div className="rc-sm">{dt(o.created_at)} · Thu ngân: {o.user_name}</div>
      <div className="rc-hr" />
      {o.items.map((i) => (
        <div key={i.id} className="rc-item">
          <div className="rc-row"><span>{i.name} ({i.size})</span><span>{money(i.unit_price * i.quantity)}</span></div>
          <div className="rc-sm">{i.quantity} × {money(i.unit_price)}</div>
          {(i.options ?? []).map((x) => <div key={x.id} className="rc-sm">+ {x.name}{x.qty > 1 ? ` ×${x.qty}` : ''}</div>)}
          {i.note && <div className="rc-sm rc-i">• {i.note}</div>}
        </div>
      ))}
      <div className="rc-hr" />
      <div className="rc-row rc-sm"><span>Số ly: {cups}</span><span /></div>
      <div className="rc-row"><span>Tạm tính</span><span>{money(o.subtotal)}</span></div>
      {o.discount > 0 && <div className="rc-row"><span>{o.discount_label || 'Giảm giá'}</span><span>-{money(o.discount)}</span></div>}
      <div className="rc-row rc-total"><span>TỔNG CỘNG</span><span>{money(o.total)}đ</span></div>
      <div className="rc-row"><span>Thanh toán</span><span>{o.payment === 'cash' ? 'Tiền mặt' : 'Chuyển khoản'}</span></div>
      {o.payment === 'cash' && o.cash_received != null && o.cash_received > 0 && (<>
        <div className="rc-row"><span>Khách đưa</span><span>{money(o.cash_received)}</span></div>
        <div className="rc-row"><span>Tiền thừa</span><span>{money(Math.max(0, o.cash_received - o.total))}</span></div></>)}
      {o.payment === 'transfer' && qr && (<>
        <div className="rc-hr" />
        <div className="rc-c rc-sm">Quét mã để chuyển khoản</div>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={qr} alt="QR chuyển khoản" className="rc-qr" />
        {s.bank_info && !bankConfigured(s) && <div className="rc-c rc-sm">{s.bank_info}</div>}
        {bankConfigured(s) && <div className="rc-c rc-sm">{s.bank_account}{s.bank_holder ? ` · ${s.bank_holder}` : ''}</div>}
        <div className="rc-c rc-sm">Số tiền: {money(o.total)}đ · Nội dung: Don {o.code}</div></>)}
      {o.payment === 'transfer' && !qr && s.bank_info && <div className="rc-c rc-sm" style={{ marginTop: 6 }}>{s.bank_info}</div>}
      {o.customer_phone && <div className="rc-sm">Khách: {o.customer_name || 'Thân thiết'} ({o.customer_phone.slice(0, 3)}***{o.customer_phone.slice(-3)}){o.points_earned > 0 ? ` · +${o.points_earned} điểm` : ''}{o.points_used > 0 ? ` · dùng ${o.points_used} điểm` : ''}</div>}
      <div className="rc-hr" />
      <div className="rc-c rc-sm">{s.receipt_footer}</div>
    </section>
  );
}

function Kitchen({ o }: { o: Order }) {
  return (
    <section className="rc-page">
      <div className="rc-c rc-b">PHIẾU PHA CHẾ</div>
      <div className="rc-c rc-huge">#{o.code.split('-')[1]}</div>
      <div className="rc-c rc-big">{o.table_name.toUpperCase()}</div>
      <div className="rc-c rc-sm">{dt(o.created_at)}</div>
      <div className="rc-hr" />
      {o.items.map((i) => (
        <div key={i.id} className="rc-item">
          <div className="rc-kline"><b>{i.quantity} ×</b> {i.name} <b>({i.size})</b></div>
          {(i.options ?? []).map((x) => <div key={x.id} className="rc-knote">+ {x.name.toUpperCase()}{x.qty > 1 ? ` ×${x.qty}` : ''}</div>)}
          {i.note && <div className="rc-knote">→ {i.note.toUpperCase()}</div>}
        </div>
      ))}
      {o.note && (<><div className="rc-hr" /><div className="rc-knote">GHI CHÚ: {o.note}</div></>)}
      <div className="rc-hr" />
      <div className="rc-c rc-sm">Tổng {o.items.reduce((a, i) => a + i.quantity, 0)} ly</div>
    </section>
  );
}

function View({ id }: { id: string }) {
  const sp = useSearchParams();
  const kind = sp.get('kind') ?? 'bill';
  const auto = sp.get('auto') === '1';
  const order = useApi<{ order: Order }>(`/api/orders/${id}`);
  const settings = useApi<Settings>('/api/settings');
  const [qr, setQr] = useState('');
  const [qrReady, setQrReady] = useState(false);
  const printed = useRef(false);
  const paper = sp.get('paper') === '58' || sp.get('paper') === '80' ? sp.get('paper')! : settings.data?.paper_width ?? '80';

  useEffect(() => {
    if (!settings.data || !order.data) return;
    const s = settings.data;
    if (order.data.order.payment === 'transfer' && bankConfigured(s)) {
      const payload = vietQrPayload({ bin: s.bank_bin!, account: s.bank_account!, amount: order.data.order.total, memo: 'Don ' + order.data.order.code });
      QRCode.toDataURL(payload, { margin: 1, width: 360 }).then(setQr).catch(() => {}).finally(() => setQrReady(true));
      return;
    }
    if (!s.has_qr) { setQrReady(true); return; }
    api<{ qr_image: string }>('/api/settings/qr').then((r) => setQr(r.qr_image)).catch(() => {}).finally(() => setQrReady(true));
  }, [settings.data, order.data]);

  const ready = !!order.data && !!settings.data && qrReady;
  useEffect(() => {
    if (!auto || !ready || printed.current) return;
    printed.current = true;
    const done = () => { try { window.parent?.postMessage('receipt-printed', location.origin); } catch { /* bỏ qua */ } };
    window.addEventListener('afterprint', done);
    // đợi ảnh QR nạp xong rồi mới in
    const t = setTimeout(() => window.print(), 350);
    return () => clearTimeout(t);
  }, [auto, ready]);

  if (order.error) return <p style={{ padding: 16 }}>Lỗi: {order.error}</p>;
  if (!ready) return <p style={{ padding: 16 }}>Đang tải…</p>;
  const o = order.data!.order, s = settings.data!;
  const w = paper === '58' ? 48 : 72;
  return (
    <div className="rc-root">
      <style>{`
        @page { size: ${paper}mm auto; margin: 0; }
        html, body { background: #fff !important; margin: 0; padding: 0; }
        .rc-root { font-family: 'Courier New', ui-monospace, monospace; color: #000; font-size: ${paper === '58' ? 11 : 12.5}px; line-height: 1.35; }
        .rc-page { width: ${w}mm; margin: 0 auto; padding: 3mm 0 6mm; box-sizing: content-box; }
        .rc-c { text-align: center; } .rc-b { font-weight: 800; } .rc-i { font-style: italic; }
        .rc-big { font-size: ${paper === '58' ? 15 : 18}px; font-weight: 800; text-align: center; }
        .rc-huge { font-size: ${paper === '58' ? 34 : 44}px; font-weight: 900; text-align: center; line-height: 1.1; }
        .rc-sm { font-size: ${paper === '58' ? 10 : 11}px; }
        .rc-row { display: flex; justify-content: space-between; gap: 6px; } .rc-row span:first-child { min-width: 0; word-break: break-word; }
        .rc-row span:last-child { white-space: nowrap; text-align: right; }
        .rc-hr { border-top: 1px dashed #000; margin: 5px 0; }
        .rc-item { margin-bottom: 4px; }
        .rc-total { font-size: ${paper === '58' ? 14 : 16}px; font-weight: 900; margin: 3px 0; }
        .rc-qr { display: block; width: ${paper === '58' ? 38 : 52}mm; max-width: 100%; margin: 4px auto; image-rendering: pixelated; }
        .rc-stamp { font-size: 16px; border: 2px solid #000; margin: 4px 0; padding: 2px 0; text-align: center; }
        .rc-kline { font-size: ${paper === '58' ? 14 : 17}px; line-height: 1.25; }
        .rc-knote { font-weight: 900; font-size: ${paper === '58' ? 12 : 14}px; }
        .rc-page + .rc-page { break-before: page; page-break-before: always; }
        @media screen { body { background: #e8e8e8 !important; } .rc-page { background: #fff; margin: 12px auto; padding: 4mm 3mm 6mm; box-shadow: 0 1px 6px rgba(0,0,0,.25); } .rc-bar { display: flex; } }
        @media print { .rc-bar { display: none !important; } body { background: #fff !important; } }
        .rc-bar { display: none; position: sticky; top: 0; gap: 8px; justify-content: center; padding: 8px; background: #6f4e37; }
        .rc-bar button, .rc-bar a { background: #fff; border: 0; border-radius: 8px; padding: 8px 14px; font-weight: 700; cursor: pointer; color: #3b2a20; text-decoration: none; font-family: system-ui; font-size: 14px; }
      `}</style>
      {!auto && <div className="rc-bar"><button onClick={() => window.print()}>🖨 In</button><a href={`?kind=bill&paper=${paper}`}>Hóa đơn</a><a href={`?kind=kitchen&paper=${paper}`}>Phiếu pha chế</a><a href={`?kind=both&paper=${paper}`}>Cả hai</a><a href={`?kind=${kind}&paper=${paper === '80' ? '58' : '80'}`}>Khổ {paper === '80' ? '58' : '80'}mm</a></div>}
      {(kind === 'bill' || kind === 'both') && <Bill o={o} s={s} qr={qr} />}
      {(kind === 'kitchen' || kind === 'both') && <Kitchen o={o} />}
    </div>
  );
}
export default function Page({ params }: { params: Promise<{ id: string }> }) {
  const id = useRouteId(use(params).id);
  return <Suspense fallback={null}><View id={id} /></Suspense>;
}

'use client';
import { useState } from 'react';
import { api, useApi } from '@/lib/client';
import { vnd } from '@/lib/format';
import { Empty, ErrorBox, Loading, Modal, Spinner } from '@/components/ui';
import { Forbidden, useAuth } from '@/components/Auth';
import { useToast } from '@/components/Toast';

interface Cust { id: number; phone: string; name: string; points: number; visits: number; total_spent: number; last_visit: string | null }
interface Detail { customer: Cust; top: { name: string; q: number }[]; orders: { id: number; order_date: string; seq: number; total: number; points_earned: number; points_used: number; created_at: string }[] }

export default function CustomersPage() {
  const { can } = useAuth();
  const toast = useToast();
  const ok = can('view_dashboard');
  const [q, setQ] = useState('');
  const list = useApi<{ customers: Cust[]; totals: { n: number; p: number; s: number } }>(ok ? `/api/customers?q=${encodeURIComponent(q)}` : null);
  const [sel, setSel] = useState<number | null>(null);
  const det = useApi<Detail>(sel ? `/api/customers/${sel}` : null);
  const [name, setName] = useState('');
  const [pts, setPts] = useState('');
  const [busy, setBusy] = useState(false);
  if (!ok) return <Forbidden />;
  const open = (c: Cust) => { setSel(c.id); setName(c.name); setPts(String(c.points)); };
  const save = async () => {
    if (!sel) return;
    setBusy(true);
    try { await api(`/api/customers/${sel}`, { method: 'PUT', body: { name, points: can('edit_ingredients') ? Number(pts || 0) : undefined } }); toast.ok('Đã lưu'); setSel(null); list.reload(); }
    catch (e) { toast.err(e instanceof Error ? e.message : 'Lỗi'); } finally { setBusy(false); }
  };
  return (
    <div className="space-y-4">
      <div><h1 className="text-2xl font-extrabold">KHÁCH THÂN THIẾT</h1><p className="text-sm text-mocha">Khách được tạo tự động khi thu ngân nhập số điện thoại lúc thanh toán.</p></div>
      {list.data && <div className="grid grid-cols-3 gap-2 text-center"><div className="card p-3"><b className="text-xl">{list.data.totals.n}</b><span className="block text-xs text-mocha">Khách</span></div><div className="card p-3"><b className="text-xl">{list.data.totals.p.toLocaleString('vi-VN')}</b><span className="block text-xs text-mocha">Điểm đang giữ</span></div><div className="card p-3"><b className="text-xl">{vnd(list.data.totals.s)}</b><span className="block text-xs text-mocha">Tổng đã chi</span></div></div>}
      <input className="input" placeholder="🔍 Tìm theo số điện thoại hoặc tên" value={q} onChange={(e) => setQ(e.target.value)} />
      {list.error && <ErrorBox message={list.error} onRetry={list.reload} />}
      {list.loading && !list.data && <Loading rows={3} />}
      {list.data && list.data.customers.length === 0 && <Empty icon="🤝" title="Chưa có khách" hint="Nhập số điện thoại ở màn hình bán hàng để bắt đầu tích điểm." />}
      <ul className="grid gap-2 sm:grid-cols-2">
        {list.data?.customers.map((c) => (
          <li key={c.id}><button className="card flex w-full items-center gap-3 p-3 text-left" onClick={() => open(c)}>
            <div className="min-w-0 flex-1"><b>{c.name || 'Khách'}</b> <span className="text-mocha">{c.phone}</span><span className="block text-xs text-mocha">{c.visits} lần • {vnd(c.total_spent)}{c.last_visit ? ` • gần nhất ${c.last_visit.slice(0, 10)}` : ''}</span></div>
            <span className="tag tag-neutral">{c.points} điểm</span></button></li>
        ))}
      </ul>
      <Modal open={!!sel} onClose={() => setSel(null)} title="Chi tiết khách">
        {det.loading && !det.data && <Loading rows={2} />}
        {det.data && <div className="space-y-3">
          <p><b>{det.data.customer.phone}</b> • {det.data.customer.visits} lần • {vnd(det.data.customer.total_spent)}</p>
          <div><label className="label" htmlFor="cn">Tên</label><input id="cn" className="input" value={name} onChange={(e) => setName(e.target.value)} /></div>
          {can('edit_ingredients') && <div><label className="label" htmlFor="cp">Điểm</label><input id="cp" inputMode="numeric" className="input" value={pts} onChange={(e) => setPts(e.target.value.replace(/[^\d]/g, ''))} /></div>}
          {det.data.top.length > 0 && <div><p className="label">Món hay gọi</p><p className="text-sm">{det.data.top.map((t) => `${t.name} (${t.q})`).join(' • ')}</p></div>}
          {det.data.orders.length > 0 && <div><p className="label">Đơn gần đây</p><ul className="max-h-40 overflow-auto text-sm">{det.data.orders.map((o) => <li key={o.id} className="flex justify-between border-b border-[#f3ebdd] py-1"><span>{o.order_date} #{o.seq}</span><span>{vnd(o.total)}{o.points_earned ? ` · +${o.points_earned}đ` : ''}{o.points_used ? ` · −${o.points_used}đ` : ''}</span></li>)}</ul></div>}
          <button className="btn btn-green btn-lg w-full" onClick={save} disabled={busy}>{busy ? <Spinner /> : 'Lưu'}</button>
        </div>}
      </Modal>
    </div>
  );
}

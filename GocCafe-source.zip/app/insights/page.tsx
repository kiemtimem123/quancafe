'use client';
import { useState } from 'react';
import { useApi } from '@/lib/client';
import { vnd } from '@/lib/format';
import { ErrorBox, Loading } from '@/components/ui';
import { Forbidden, useAuth } from '@/components/Auth';

interface R { hours: { h: number; n: number; rev: number }[]; peak: { h: number; n: number; rev: number }[]; weekdays: { d: number; label: string; n: number; rev: number; avg_rev: number }[]; staff: { name: string; n: number; rev: number; disc: number; voids: number; cups: number; avg: number }[] }
export default function Insights() {
  const { can } = useAuth();
  const [days, setDays] = useState(30);
  const { data, error, loading, reload } = useApi<R>(can('view_dashboard') ? `/api/insights?days=${days}` : null);
  if (!can('view_dashboard')) return <Forbidden what="phân tích giờ cao điểm" />;
  const maxH = Math.max(1, ...(data?.hours ?? []).map((h) => h.n));
  const maxW = Math.max(1, ...(data?.weekdays ?? []).map((h) => h.avg_rev));
  return (
    <div className="space-y-4">
      <div><h1 className="text-2xl font-extrabold">GIỜ CAO ĐIỂM & NHÂN VIÊN</h1><p className="text-sm text-mocha">Biết giờ nào đông để xếp ca, và hiệu suất từng nhân viên thu ngân.</p></div>
      <div className="flex gap-2">{[7, 30, 90].map((d) => <button key={d} className="chip" aria-pressed={days === d} onClick={() => setDays(d)}>{d} ngày</button>)}</div>
      {error && <ErrorBox message={error} onRetry={reload} />}
      {loading && !data && <Loading rows={3} />}
      {data && (<>
        <div className="card p-4"><p className="mb-1 font-bold">Số đơn theo giờ</p>
          {data.peak.length > 0 && <p className="mb-2 text-sm text-mocha">Cao điểm: {data.peak.map((p) => `${p.h}h (${p.n} đơn)`).join(' · ')}</p>}
          <div className="flex h-36 items-end gap-0.5" role="img" aria-label="Biểu đồ số đơn theo giờ">{data.hours.map((h) => <div key={h.h} className="flex h-full flex-1 flex-col justify-end" title={`${h.h}h: ${h.n} đơn, ${vnd(h.rev)}`}><div className={`rounded-t ${data.peak.some((p) => p.h === h.h) ? 'bg-leaf' : 'bg-latte'}`} style={{ height: `${(h.n / maxH) * 100}%`, minHeight: h.n ? 2 : 0 }} /></div>)}</div>
          <div className="mt-1 flex justify-between text-[10px] text-mocha"><span>0h</span><span>6h</span><span>12h</span><span>18h</span><span>23h</span></div></div>
        <div className="card divide-y divide-[#f3ebdd]"><p className="p-3 font-bold">Doanh thu trung bình theo thứ</p>{data.weekdays.map((w) => (
          <div key={w.d} className="flex items-center gap-2 p-3 text-sm"><span className="w-20">{w.label}</span><div className="h-2 flex-1 overflow-hidden rounded-full bg-cream"><div className="h-full bg-coffee" style={{ width: `${(w.avg_rev / maxW) * 100}%` }} /></div><b className="w-28 text-right">{vnd(w.avg_rev)}</b></div>))}</div>
        <div className="card divide-y divide-[#f3ebdd]"><p className="p-3 font-bold">Nhân viên</p>{data.staff.length === 0 && <p className="p-3 text-sm text-mocha">Chưa có đơn.</p>}{data.staff.map((s) => (
          <div key={s.name} className="p-3 text-sm"><div className="flex justify-between"><b>{s.name || '—'}</b><b>{vnd(s.rev)}</b></div><p className="text-xs text-mocha">{s.n} đơn · {s.cups} ly · TB {vnd(s.avg)}/đơn · giảm giá {vnd(s.disc)} · hủy {s.voids}</p></div>))}</div>
      </>)}
    </div>
  );
}

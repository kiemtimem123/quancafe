'use client';
import { useApi } from '@/lib/client';
import { num, vnd } from '@/lib/format';
import { Empty, ErrorBox, Loading } from '@/components/ui';
import { Forbidden, useAuth } from '@/components/Auth';

interface Rep { monthly: { month: string; expired: number; waste: number; stocktake: number; total: number }[]; top: { name: string; unit: string; qty: number; cost: number }[]; recent: { at: string; name: string; unit: string; qty: number; cost: number; kind: string; note: string }[]; total: number }
const K: Record<string, string> = { expired: '⏰ Hết hạn', waste: '🗑 Hủy/hao hụt', stocktake: '🧮 Kiểm kê thiếu' };
export default function WastePage() {
  const { can } = useAuth();
  const { data, error, loading, reload } = useApi<Rep>(can('view_cost') ? '/api/reports/waste?months=6' : null);
  if (!can('view_cost')) return <Forbidden what="báo cáo hao hụt" />;
  const max = Math.max(1, ...(data?.monthly ?? []).map((m) => m.total));
  return (
    <div className="space-y-4">
      <div><h1 className="text-2xl font-extrabold">HAO HỤT & THẤT THOÁT</h1><p className="text-sm text-mocha">Hết hạn (tự loại), hủy bỏ và chênh lệch kiểm kê — quy ra tiền theo giá nhập, 6 tháng gần nhất.</p></div>
      {error && <ErrorBox message={error} onRetry={reload} />}
      {loading && !data && <Loading rows={3} />}
      {data && data.monthly.length === 0 && <Empty icon="✅" title="Chưa có thất thoát nào" hint="Khi có nguyên liệu hết hạn, hủy hoặc kiểm kê thiếu, số liệu sẽ hiện ở đây." />}
      {data && data.monthly.length > 0 && (<>
        <div className="card p-4"><p className="text-sm text-mocha">Tổng thất thoát 6 tháng</p><p className="text-3xl font-extrabold text-danger">{vnd(data.total)}</p></div>
        <div className="card divide-y divide-[#f3ebdd]">{data.monthly.map((m) => (
          <div key={m.month} className="space-y-1 p-3 text-sm"><div className="flex justify-between"><b>Tháng {m.month.split('-').reverse().join('/')}</b><b className="text-danger">{vnd(m.total)}</b></div>
            <div className="h-2 overflow-hidden rounded-full bg-cream"><div className="h-full bg-danger" style={{ width: `${(m.total / max) * 100}%` }} /></div>
            <p className="text-xs text-mocha">Hết hạn {vnd(m.expired)} · Hủy/hao hụt {vnd(m.waste)} · Kiểm kê thiếu {vnd(m.stocktake)}</p></div>))}</div>
        <div className="card p-4"><p className="mb-2 font-bold">Nguyên liệu thất thoát nhiều nhất</p><ul className="space-y-1 text-sm">{data.top.map((t) => <li key={t.name} className="flex justify-between"><span>{t.name} <span className="text-mocha">({num(t.qty)} {t.unit})</span></span><b>{vnd(t.cost)}</b></li>)}</ul></div>
        <div className="card divide-y divide-[#f3ebdd]"><p className="p-3 font-bold">Gần đây</p>{data.recent.map((r, i) => (
          <div key={i} className="flex items-start justify-between gap-2 p-3 text-sm"><div><p className="font-semibold">{r.name} · {num(r.qty)} {r.unit}</p><p className="text-xs text-mocha">{K[r.kind]} · {r.note || '—'} · {r.at.slice(0, 16).replace('T', ' ')}</p></div><b className="text-danger">{vnd(r.cost)}</b></div>))}</div>
      </>)}
    </div>
  );
}

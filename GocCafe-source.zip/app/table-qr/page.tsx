'use client';
import { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { api, useApi } from '@/lib/client';
import { ErrorBox, Loading } from '@/components/ui';
import { Forbidden, useAuth } from '@/components/Auth';
import { useToast } from '@/components/Toast';

interface S { shop_name: string; table_count: number; qr_order: boolean }
export default function TableQrPage() {
  const { can } = useAuth(); const toast = useToast();
  const { data, error, loading, reload } = useApi<S>(can('edit_ingredients') ? '/api/settings' : null);
  const [base, setBase] = useState('');
  const [imgs, setImgs] = useState<Record<string, string>>({});
  useEffect(() => { setBase(location.origin); }, []);
  const names = data ? ['Mang đi', ...Array.from({ length: data.table_count }, (_, i) => `Bàn ${i + 1}`)] : [];
  useEffect(() => {
    if (!data || !base) return;
    let alive = true;
    (async () => {
      const out: Record<string, string> = {};
      for (const n of ['Mang đi', ...Array.from({ length: data.table_count }, (_, i) => `Bàn ${i + 1}`)]) out[n] = await QRCode.toDataURL(`${base.replace(/\/$/, '')}/order?table=${encodeURIComponent(n)}`, { width: 360, margin: 1, errorCorrectionLevel: 'M' });
      if (alive) setImgs(out);
    })().catch(() => {});
    return () => { alive = false; };
  }, [data, base]);
  if (!can('edit_ingredients')) return <Forbidden what="mã QR đặt món" />;
  const toggle = async (on: boolean) => { try { await api('/api/settings', { method: 'PUT', body: { qr_order: on } }); toast.ok(on ? 'Đã bật đặt món qua QR' : 'Đã tắt đặt món qua QR'); reload(); } catch (e) { toast.err(e instanceof Error ? e.message : 'Lỗi'); } };
  return (
    <div className="space-y-4">
      <div className="no-print"><h1 className="text-2xl font-extrabold">MÃ QR ĐẶT MÓN</h1><p className="text-sm text-mocha">In và dán mỗi mã lên bàn tương ứng. Khách quét bằng camera điện thoại để gọi món, không cần cài app hay đăng nhập.</p></div>
      {error && <ErrorBox message={error} onRetry={reload} />}
      {loading && !data && <Loading rows={2} />}
      {data && (<>
        <div className="card no-print space-y-3 p-4">
          <label className="flex items-center gap-3"><input type="checkbox" className="h-5 w-5" checked={data.qr_order} onChange={(e) => toggle(e.target.checked)} /><span className="font-bold">Cho phép khách đặt món qua QR</span></label>
          <div><label className="label" htmlFor="base">Địa chỉ web của quán (mã QR sẽ trỏ về đây)</label><input id="base" className="input" value={base} onChange={(e) => setBase(e.target.value)} placeholder="https://cafe.tenmiencuaban.vn" />
            <p className="mt-1 text-xs text-mocha">Phải là địa chỉ khách mở được bằng điện thoại của họ (tên miền công khai hoặc địa chỉ Wi-Fi quán). Không dùng “localhost”.</p></div>
          {/localhost|127\.0\.0\.1/.test(base) && <p className="rounded-xl bg-warn-soft p-3 text-sm font-semibold text-[#8a5a00]">⚠ Đang dùng địa chỉ localhost — điện thoại khách sẽ không mở được. Hãy nhập địa chỉ thật của quán ở ô trên.</p>}
          <button className="btn btn-green" onClick={() => window.print()}>🖨 In tất cả mã QR</button>
        </div>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 print:grid-cols-3">{names.map((n) => (
          <div key={n} className="card break-inside-avoid p-4 text-center">
            <p className="text-sm font-semibold text-mocha">{data.shop_name}</p>
            {imgs[n] ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={imgs[n]} alt={`QR ${n}`} className="mx-auto my-2 h-44 w-44" /> : <div className="mx-auto my-2 h-44 w-44" />}
            <p className="text-xl font-extrabold">{n === 'Mang đi' ? '🥡 Mang đi' : n}</p><p className="text-xs text-mocha">Quét để gọi món</p>
          </div>))}</div>
      </>)}
    </div>
  );
}

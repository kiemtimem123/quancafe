'use client';
import { useState } from 'react';
import { useApi } from '@/lib/client';
import { num, vnd } from '@/lib/format';
import { Empty, ErrorBox, Loading } from '@/components/ui';
import { Forbidden, useAuth } from '@/components/Auth';
import Link from 'next/link';

interface Row { id: number; name: string; unit: string; supplier: string; stock: number; per_day: number; days_left: number | null; buy: number; cost: number; overstock: boolean; shelf_life_days: number }
export default function ForecastPage() {
  const { can } = useAuth();
  const [window, setWindow] = useState(28); const [horizon, setHorizon] = useState(14);
  const { data, error, loading, reload } = useApi<{ window: number; horizon: number; rows: Row[]; total: number }>(can('edit_ingredients') ? `/api/forecast?window=${window}&horizon=${horizon}` : null);
  if (!can('edit_ingredients')) return <Forbidden what="dự báo nhập hàng" />;
  return (
    <div className="space-y-4">
      <div><h1 className="text-2xl font-extrabold">DỰ BÁO NHẬP HÀNG</h1><p className="text-sm text-mocha">Dựa trên lượng nguyên liệu đã dùng trong {window} ngày gần nhất để đoán lượng cần nhập cho {horizon} ngày tới.</p></div>
      <div className="flex flex-wrap items-center gap-2 text-sm"><span>Lấy số liệu:</span>{[14, 28, 42, 56].map((w) => <button key={w} className="chip" aria-pressed={window === w} onClick={() => setWindow(w)}>{w / 7} tuần</button>)}<span className="ml-2">Nhập đủ cho:</span>{[7, 14, 21].map((h) => <button key={h} className="chip" aria-pressed={horizon === h} onClick={() => setHorizon(h)}>{h} ngày</button>)}</div>
      {error && <ErrorBox message={error} onRetry={reload} />}
      {loading && !data && <Loading rows={4} />}
      {data && data.rows.length === 0 && <Empty icon="📈" title="Chưa đủ dữ liệu" hint="Cần có đơn hàng/pha chế trừ kho để dự báo." />}
      {data && data.rows.length > 0 && (<>
        <div className="card flex items-center justify-between p-4"><div><p className="text-sm text-mocha">Ước tính tiền cần nhập</p><p className="text-2xl font-extrabold">{vnd(data.total)}</p></div><Link href="/purchases" className="btn btn-green">📑 Tạo đơn đặt hàng</Link></div>
        <div className="card divide-y divide-[#f3ebdd]">{data.rows.map((r) => (
          <div key={r.id} className="flex flex-wrap items-center gap-2 p-3 text-sm"><div className="min-w-0 flex-1"><p className="font-bold">{r.name}{r.overstock && <span className="tag tag-warn ml-2">Dễ hết hạn nếu nhập nhiều</span>}</p>
            <p className="text-xs text-mocha">Dùng ~{num(r.per_day, 2)} {r.unit}/ngày · Tồn {num(r.stock)} {r.unit}{r.days_left !== null ? ` · đủ ${num(r.days_left, 1)} ngày` : ''}{r.supplier ? ` · ${r.supplier}` : ''}</p></div>
            <div className="text-right">{r.buy > 0 ? <><b>Nhập {num(r.buy)} {r.unit}</b><p className="text-xs text-mocha">{vnd(r.cost)}</p></> : <span className="tag tag-ok">Đủ dùng</span>}</div></div>))}</div>
      </>)}
    </div>
  );
}

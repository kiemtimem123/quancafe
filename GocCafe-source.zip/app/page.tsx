'use client';
import { ExpiryBanner } from '@/components/ExpiryBanner';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Link from 'next/link';
import { api, useApi, useLocalState } from '@/lib/client';
import type { Ingredient, MatchResult } from '@/lib/types';
import { norm } from '@/lib/format';
import { ErrorBox, Empty, Loading, Spinner } from '@/components/ui';
import { IngredientPicker } from '@/components/IngredientPicker';
import { MatchCard } from '@/components/MatchCard';
import { useToast } from '@/components/Toast';
import type { AvailItem } from '@/components/Availability';

type Tier = 'ready' | 'm1' | 'm2' | 'all';

export default function Home() {
  const toast = useToast();
  const { data, error, loading, reload } = useApi<{ ingredients: Ingredient[] }>('/api/ingredients');
  const ings = useMemo(() => data?.ingredients ?? [], [data]);
  const av = useApi<{ items: AvailItem[]; counts: { out: number; low: number } }>('/api/availability');
  const availBy = useMemo(() => new Map((av.data?.items ?? []).map((i) => [i.id, i])), [av.data]);
  const [onlyStock, setOnlyStock] = useLocalState<boolean>('onlyStock', false);
  const [have, setHave] = useLocalState<number[]>('have', []);
  const [priority, setPriority] = useLocalState<number[]>('priority', []);
  const [saveMode, setSaveMode] = useLocalState<boolean>('saveMode', false);
  const [picker, setPicker] = useState<'have' | 'priority' | null>(null);
  const [q, setQ] = useState('');
  const [results, setResults] = useState<MatchResult[] | null>(null);
  const [searching, setSearching] = useState(false);
  const [searchErr, setSearchErr] = useState<string | null>(null);
  const [tier, setTier] = useState<Tier>('ready');
  const resRef = useRef<HTMLDivElement>(null);
  const byId = useMemo(() => new Map(ings.map((i) => [i.id, i])), [ings]);
  const validHave = useMemo(() => have.filter((id) => byId.has(id)), [have, byId]);
  const validPrio = useMemo(() => (saveMode ? priority.filter((id) => byId.has(id)) : []), [priority, saveMode, byId]);

  const suggestions = useMemo(() => {
    const n = norm(q);
    if (!n) return [];
    return ings.filter((i) => i.category !== 'Cơ bản' && i.category !== 'Bao bì' && !have.includes(i.id) && norm(i.name).includes(n)).slice(0, 6);
  }, [q, ings, have]);

  const run = useCallback(async (scroll = false) => {
    if (!validHave.length && !validPrio.length) { toast.err('Hãy chọn ít nhất 1 nguyên liệu'); return; }
    setSearching(true); setSearchErr(null);
    try {
      const r = await api<{ results: MatchResult[] }>('/api/match', { method: 'POST', body: { have: validHave, priority: validPrio } });
      setResults(r.results);
      const c = (k: number) => r.results.filter((x) => x.missing.length === k).length;
      setTier((t) => (t === 'all' ? t : c(0) ? 'ready' : c(1) ? 'm1' : c(2) ? 'm2' : 'all'));
      if (scroll) setTimeout(() => resRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 50);
    } catch (e) { setSearchErr(e instanceof Error ? e.message : 'Lỗi'); }
    finally { setSearching(false); }
  }, [validHave, validPrio, toast]);

  // tự cập nhật kết quả khi đã bấm tìm và người dùng đổi lựa chọn
  const searched = useRef(false);
  // /?prio=1,2,3 : ưu tiên dùng các nguyên liệu sắp hết hạn
  useEffect(() => {
    const ids = new URLSearchParams(window.location.search).get('prio')?.split(',').map(Number).filter((n) => Number.isInteger(n) && n > 0) ?? [];
    if (!ids.length) return;
    setPriority(ids); setSaveMode(true); searched.current = true;
    window.history.replaceState(null, '', '/');
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (!searched.current) return;
    const t = setTimeout(() => { if (validHave.length || validPrio.length) run(); else setResults(null); }, 250);
    return () => clearTimeout(t);
  }, [validHave, validPrio, run]);

  const counts = useMemo(() => {
    const r = (results ?? []).filter((x) => !onlyStock || x.recipe.availability?.status !== 'out');
    return { ready: r.filter((x) => x.missing.length === 0).length, m1: r.filter((x) => x.missing.length === 1).length, m2: r.filter((x) => x.missing.length === 2).length, all: r.length };
  }, [results, onlyStock]);
  const shown = useMemo(() => {
    const r = (results ?? []).filter((x) => !onlyStock || x.recipe.availability?.status !== 'out');
    if (tier === 'all') return r;
    const k = tier === 'ready' ? 0 : tier === 'm1' ? 1 : 2;
    return r.filter((x) => x.missing.length === k);
  }, [results, tier, onlyStock]);

  const add = (id: number) => { setHave((h) => (h.includes(id) ? h : [...h, id])); setQ(''); };
  const Chip = ({ id, onRemove, tone }: { id: number; onRemove: () => void; tone: 'g' | 'o' }) => (
    <span className={`tag ${tone === 'g' ? 'tag-ok' : 'tag-warn'} !py-1.5 !text-sm`}>{byId.get(id)?.name}
      <button onClick={onRemove} aria-label={`Bỏ ${byId.get(id)?.name}`} className="ml-1 font-bold opacity-70 hover:opacity-100">✕</button></span>
  );

  return (
    <div className="space-y-6">
      <section className="card overflow-hidden bg-gradient-to-br from-coffee to-espresso p-5 text-white sm:p-8">
        <ol className="mb-4 flex flex-wrap gap-x-4 gap-y-1 text-xs font-semibold text-latte sm:text-sm" aria-label="3 bước">
          <li>① Chọn nguyên liệu</li><li>→ ② Bấm “Tìm món”</li><li>→ ③ Chọn món, xem công thức, pha</li>
        </ol>
        <ExpiryBanner />
        <h1 className="text-2xl font-extrabold sm:text-4xl">Hôm nay bạn có nguyên liệu gì?</h1>
        <p className="mt-1 text-sm text-latte">Chọn những gì đang có trong quầy — app sẽ cho biết pha được món nào.</p>

        <div className="relative mt-5">
          <input className="input !min-h-[52px] !rounded-2xl text-base" value={q} onChange={(e) => setQ(e.target.value)}
            placeholder="Nhập nguyên liệu, ví dụ: cà phê, sữa đặc, matcha…" aria-label="Nhập nguyên liệu"
            onKeyDown={(e) => { if (e.key === 'Enter' && suggestions[0]) { e.preventDefault(); add(suggestions[0].id); } }} />
          {suggestions.length > 0 && (
            <ul className="card absolute inset-x-0 top-full z-20 mt-1 overflow-hidden text-espresso shadow-xl">
              {suggestions.map((s) => (
                <li key={s.id}><button className="flex w-full items-center justify-between px-4 py-3 text-left hover:bg-cream" onClick={() => add(s.id)}><span>{s.name}</span><span className="text-xs text-mocha">{s.category} · + thêm</span></button></li>
              ))}
            </ul>
          )}
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-2">
          <button className="btn btn-ghost" onClick={() => setPicker('have')} disabled={loading}>+ Chọn nguyên liệu</button>
          {validHave.length > 0 && <button className="text-sm underline text-latte" onClick={() => setHave([])}>Xóa hết</button>}
        </div>

        {validHave.length > 0 && <div className="mt-3 flex flex-wrap gap-2">{validHave.map((id) => <Chip key={id} id={id} tone="g" onRemove={() => setHave(have.filter((x) => x !== id))} />)}</div>}

        <label className="mt-4 flex cursor-pointer items-start gap-3 rounded-2xl bg-white/10 p-3 text-sm">
          <input type="checkbox" className="mt-0.5 h-5 w-5 accent-[#7fa886]" checked={saveMode} onChange={(e) => setSaveMode(e.target.checked)} />
          <span><b>♻ Tôi muốn tận dụng nguyên liệu sắp hết hạn</b><br /><span className="text-latte">Ưu tiên món dùng nhiều nguyên liệu cần dùng gấp, rồi đến món pha được ngay và lợi nhuận cao.</span></span>
        </label>
        {saveMode && (
          <div className="mt-3 rounded-2xl bg-white/10 p-3">
            <div className="flex flex-wrap items-center gap-2">
              <button className="btn btn-ghost btn-sm" onClick={() => setPicker('priority')}>+ Chọn nguyên liệu cần tận dụng</button>
              {validPrio.map((id) => <Chip key={id} id={id} tone="o" onRemove={() => setPriority(priority.filter((x) => x !== id))} />)}
              {validPrio.length === 0 && <span className="text-sm text-latte">Ví dụ: sữa tươi, dâu, cam, syrup đào</span>}
            </div>
          </div>
        )}

        <button className="btn btn-green btn-lg mt-5 w-full sm:w-auto sm:min-w-[320px]" disabled={searching || loading}
          onClick={() => { searched.current = true; run(true); }}>
          {searching ? <Spinner /> : '🔎'} TÌM MÓN CÓ THỂ PHA
        </button>
      </section>

      {av.data && av.data.counts.out + av.data.counts.low > 0 && (
        <Link href="/availability" className="card flex items-center justify-between gap-3 border-warn/40 bg-warn-soft p-3 text-sm font-semibold text-[#8a5a00]">
          <span>📦 {av.data.counts.out > 0 && `${av.data.counts.out} món đang hết hàng`}{av.data.counts.out > 0 && av.data.counts.low > 0 && ' · '}{av.data.counts.low > 0 && `${av.data.counts.low} món sắp hết`}</span><span>Xem gợi ý món thay thế →</span>
        </Link>
      )}
      {error && <ErrorBox message={error} onRetry={reload} />}
      {loading && <Loading rows={2} />}

      <div ref={resRef} className="scroll-mt-20">
        {searchErr && <ErrorBox message={searchErr} onRetry={() => run()} />}
        {results && (
          <section aria-live="polite">
            <h2 className="mb-3 text-xl font-extrabold">{saveMode && validPrio.length ? '♻ Món gợi ý để tận dụng nguyên liệu' : 'Món bạn có thể pha'}</h2>
            <div className="mb-4 flex flex-wrap gap-2" role="group" aria-label="Lọc kết quả">
              {([['ready', 'Pha được ngay'], ['m1', 'Thiếu 1 nguyên liệu'], ['m2', 'Thiếu 2 nguyên liệu'], ['all', 'Tất cả món']] as [Tier, string][]).map(([k, label]) => (
                <button key={k} className="chip" aria-pressed={tier === k} onClick={() => setTier(k)}>{label} <b>({counts[k]})</b></button>
              ))}
            </div>
            <label className="mb-3 flex cursor-pointer items-center gap-2 text-sm"><input type="checkbox" className="h-5 w-5 accent-[#7fa886]" checked={onlyStock} onChange={(e) => setOnlyStock(e.target.checked)} /> 📦 Ẩn món đã hết hàng trong kho</label>
            {searching && <p className="mb-3 flex items-center gap-2 text-sm text-mocha"><Spinner /> Đang cập nhật…</p>}
            {shown.length === 0 ? (
              <Empty icon="🤔" title={tier === 'ready' ? 'Chưa có món nào pha được ngay' : 'Không có món nào ở nhóm này'}
                hint={counts.m1 ? 'Thử xem nhóm “Thiếu 1 nguyên liệu” — chỉ cần mua thêm 1 thứ.' : 'Thêm vài nguyên liệu nữa như sữa, đường, đá để có nhiều lựa chọn hơn.'}
                action={counts.m1 && tier !== 'm1' ? <button className="btn btn-primary" onClick={() => setTier('m1')}>Xem món thiếu 1 nguyên liệu</button> : undefined} />
            ) : (
              <div className="space-y-3">
                {tier === 'all' ? (
                  <>
                    {[['Có thể pha ngay', (m: MatchResult) => m.missing.length === 0], ['Có thể pha – thiếu 1–2 nguyên liệu', (m: MatchResult) => m.missing.length >= 1 && m.missing.length <= 2], ['Có thể pha – thiếu nhiều nguyên liệu', (m: MatchResult) => m.missing.length > 2]]
                      .map(([title, f]) => {
                        const list = shown.filter(f as (m: MatchResult) => boolean);
                        return list.length ? <div key={title as string} className="space-y-3"><h3 className="pt-2 text-sm font-bold uppercase tracking-wide text-mocha">{title as string} ({list.length})</h3>{list.map((m) => <MatchCard key={m.recipe.id} m={m} showPriority={saveMode} avail={availBy.get(m.recipe.id)} />)}</div> : null;
                      })}
                  </>
                ) : shown.map((m) => <MatchCard key={m.recipe.id} m={m} showPriority={saveMode} avail={availBy.get(m.recipe.id)} />)}
              </div>
            )}
          </section>
        )}
      </div>

      {!results && !loading && !error && (
        <section className="grid gap-3 sm:grid-cols-3">
          {[['📖', 'Kho công thức', 'Xem toàn bộ món, size S/M/L, giá vốn', '/recipes'], ['🫘', 'Nguyên liệu & tồn kho', 'Cập nhật giá nhập, tồn kho', '/ingredients'], ['✨', 'Trợ lý pha chế AI', 'Hỏi: “Tôi có … hãy gợi ý 5 món dễ bán”', '/assistant']].map(([i, t, d, h]) => (
            <Link key={h} href={h} className="card p-4 transition hover:-translate-y-0.5 hover:shadow-md"><div className="text-3xl">{i}</div><p className="mt-2 font-bold">{t}</p><p className="text-sm text-mocha">{d}</p></Link>
          ))}
        </section>
      )}

      <IngredientPicker open={picker === 'have'} onClose={() => setPicker(null)} title="Chọn nguyên liệu đang có" ingredients={ings} selected={validHave} onChange={setHave} />
      <IngredientPicker open={picker === 'priority'} onClose={() => setPicker(null)} title="Nguyên liệu cần tận dụng" ingredients={ings} selected={validPrio} onChange={(ids) => { setPriority(ids); }} />
    </div>
  );
}

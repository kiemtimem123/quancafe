'use client';
import { useState } from 'react';
import { useApi } from '@/lib/client';
import { Empty, ErrorBox, Loading } from '@/components/ui';
import { useAuth, Forbidden } from '@/components/Auth';

interface Row { id: number; user_name: string; action: string; entity: string; summary: string; created_at: string }
const ENT: [string, string][] = [['', 'Tất cả'], ['recipe', 'Công thức'], ['ingredient', 'Nguyên liệu'], ['sales', 'Bán hàng'], ['order', 'Đơn hàng'], ['shift', 'Chốt ca'], ['user', 'Người dùng'], ['settings', 'Cài đặt']];
const ICON: Record<string, string> = { create: '➕', update: '✏️', delete: '🗑', import: '⬆', brew: '☕', login: '🔑', purchase: '📥', adjust: '🧮', waste: '🗑', stocktake: '🧮', sale: '🧾', order: '🧾', void: '↩️', shift: '🔒', 'prep.update': '🍳', 'prep.make': '🍳', 'prep.delete': '🍳' };
export default function Audit() {
  const { can } = useAuth();
  const [q, setQ] = useState('');
  const [entity, setEntity] = useState('');
  const { data, error, loading, reload } = useApi<{ rows: Row[] }>(can('view_audit') ? `/api/audit?limit=300&entity=${entity}&q=${encodeURIComponent(q)}` : null);
  if (!can('view_audit')) return <Forbidden what="nhật ký thao tác" />;
  return (
    <div className="space-y-4">
      <div><h1 className="text-2xl font-extrabold">NHẬT KÝ THAO TÁC</h1><p className="text-sm text-mocha">Ai đã sửa gì, lúc nào (300 thao tác gần nhất).</p></div>
      <div className="flex flex-wrap gap-2"><input className="input !w-full sm:!w-72" placeholder="🔍 Tìm theo nội dung hoặc người dùng…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Tìm" />
        {ENT.map(([k, l]) => <button key={k} className="chip" aria-pressed={entity === k} onClick={() => setEntity(k)}>{l}</button>)}<button className="btn btn-ghost" onClick={reload}>↻</button></div>
      {error && <ErrorBox message={error} onRetry={reload} />}
      {loading && !data && <Loading rows={4} />}
      {data && data.rows.length === 0 && <Empty icon="📜" title="Chưa có thao tác nào" />}
      {data && data.rows.length > 0 && <div className="card divide-y divide-[#f3ebdd]">{data.rows.map((r) => (
        <div key={r.id} className="flex items-start gap-3 p-3 text-sm"><span className="text-lg">{ICON[r.action] ?? '•'}</span>
          <div className="min-w-0 flex-1"><p>{r.summary}</p><p className="text-xs text-mocha">{r.user_name || 'Hệ thống'} · {new Date(r.created_at.replace(' ', 'T') + 'Z').toLocaleString('vi-VN')}</p></div></div>))}</div>}
    </div>
  );
}

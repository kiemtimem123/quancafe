'use client';
import { useState } from 'react';
import { api, useApi } from '@/lib/client';
import { num, vnd } from '@/lib/format';
import { Empty, ErrorBox, Loading, Modal, Spinner } from '@/components/ui';
import { DownloadButton } from '@/components/DownloadButton';
import { Forbidden, useAuth } from '@/components/Auth';
import { useToast } from '@/components/Toast';
import type { PO } from '@/lib/purchases';

interface Ing { id: number; name: string; unit: string; supplier: string; purchase_price: number; has_prep?: boolean }
const STATUS: Record<PO['status'], [string, string]> = { draft: ['Nháp', 'tag-neutral'], sent: ['Đã gửi NCC', 'tag-warn'], partial: ['Nhận một phần', 'tag-warn'], received: ['Đã nhận', 'tag-ok'], cancelled: ['Đã hủy', 'tag-neutral'] };

export default function Purchases() {
  const { can } = useAuth();
  const toast = useToast();
  const ok = can('edit_ingredients');
  const list = useApi<{ orders: PO[] }>(ok ? '/api/purchases' : null);
  const ings = useApi<{ ingredients: Ing[] }>(ok ? '/api/ingredients' : null);
  const [sel, setSel] = useState<PO | null>(null);
  const [text, setText] = useState('');
  const [recv, setRecv] = useState<Record<number, { qty: string; price: string; exp: string }> | null>(null);
  const [busy, setBusy] = useState(false);
  const [draft, setDraft] = useState<{ supplier: string; lines: { ingredient_id: number; qty: string }[] } | null>(null);
  if (!ok) return <Forbidden />;
  const seeCost = can('view_cost');

  const run = async (fn: () => Promise<unknown>, msg?: string) => { setBusy(true); try { await fn(); if (msg) toast.ok(msg); list.reload(); } catch (e) { toast.err(e instanceof Error ? e.message : 'Lỗi'); } finally { setBusy(false); } };
  const open = async (po: PO) => { setSel(po); setRecv(null); setText(''); try { const r = await api<{ text: string }>(`/api/purchases/${po.id}`); setText(r.text); } catch { /* bỏ qua */ } };
  const fromShopping = () => run(async () => { await api('/api/purchases', { method: 'POST', body: { from_shopping: true } }); }, 'Đã tạo đơn cho từng nhà cung cấp');
  const setStatus = (po: PO, status: 'sent' | 'cancelled' | 'draft') => run(async () => { const r = await api<{ order: PO }>(`/api/purchases/${po.id}`, { method: 'PUT', body: { status } }); setSel(r.order); });
  const copy = async () => { try { await navigator.clipboard.writeText(text); toast.ok('Đã chép — dán vào Zalo gửi nhà cung cấp'); } catch { toast.err('Không chép được'); } };
  const startRecv = (po: PO) => setRecv(Object.fromEntries(po.lines.map((l) => [l.id, { qty: String(Math.max(0, Math.round((l.qty - l.received_qty) * 100) / 100)), price: String(l.price), exp: '' }])));
  const doRecv = (po: PO) => run(async () => {
    const lines = po.lines.map((l) => { const r = recv![l.id]; return { line_id: l.id, qty: Number(r.qty || 0), price: Number(r.price || 0), expires_on: r.exp || undefined }; }).filter((l) => l.qty > 0);
    if (!lines.length) throw new Error('Nhập số lượng thực nhận');
    const res = await api<{ order: PO }>(`/api/purchases/${po.id}/receive`, { method: 'POST', body: { lines } });
    setSel(res.order); setRecv(null);
  }, 'Đã nhập kho');
  const del = (po: PO) => { if (confirm(`Xóa đơn #${po.id}?`)) run(async () => { await api(`/api/purchases/${po.id}`, { method: 'DELETE' }); setSel(null); }); };
  const createDraft = () => run(async () => {
    if (!draft) return;
    const lines = draft.lines.filter((l) => l.ingredient_id && Number(l.qty) > 0).map((l) => ({ ingredient_id: l.ingredient_id, qty: Number(l.qty) }));
    await api('/api/purchases', { method: 'POST', body: { supplier: draft.supplier, lines } }); setDraft(null);
  }, 'Đã tạo đơn');

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div><h1 className="text-2xl font-extrabold">ĐẶT HÀNG NHÀ CUNG CẤP</h1><p className="text-sm text-mocha">Tạo đơn, gửi Zalo/Excel, khi hàng về bấm “Nhận hàng” để tự nhập kho (kèm hạn sử dụng).</p></div>
        <div className="flex flex-wrap gap-2"><button className="btn btn-green" onClick={fromShopping} disabled={busy}>🛒 Tạo từ danh sách cần mua</button><button className="btn btn-ghost" onClick={() => setDraft({ supplier: '', lines: [{ ingredient_id: 0, qty: '' }] })}>+ Đơn mới</button></div>
      </div>
      {list.error && <ErrorBox message={list.error} onRetry={list.reload} />}
      {list.loading && !list.data && <Loading rows={3} />}
      {list.data && list.data.orders.length === 0 && <Empty icon="📑" title="Chưa có đơn đặt hàng" hint="Bấm “Tạo từ danh sách cần mua” — mỗi nhà cung cấp một đơn." />}
      <ul className="grid gap-2 sm:grid-cols-2">
        {list.data?.orders.map((po) => (
          <li key={po.id}><button className="card w-full p-3 text-left" onClick={() => open(po)}>
            <div className="flex items-center gap-2"><b className="flex-1">#{po.id} · {po.supplier}</b><span className={`tag ${STATUS[po.status][1]}`}>{STATUS[po.status][0]}</span></div>
            <p className="text-sm text-mocha">{po.lines.length} mặt hàng{seeCost ? ` • ≈ ${vnd(po.total)}` : ''} • {po.created_at.slice(0, 10)}</p></button></li>
        ))}
      </ul>

      <Modal open={!!sel} onClose={() => setSel(null)} title={sel ? `Đơn #${sel.id} · ${sel.supplier}` : ''} wide>
        {sel && <div className="space-y-3">
          <span className={`tag ${STATUS[sel.status][1]}`}>{STATUS[sel.status][0]}</span>
          <div className="overflow-x-auto"><table className="w-full text-sm"><thead><tr className="text-left text-mocha"><th className="p-1">Nguyên liệu</th><th className="p-1 text-right">Đặt</th><th className="p-1 text-right">Đã nhận</th>{recv && <><th className="p-1">Nhận nay</th><th className="p-1">Giá</th><th className="p-1">HSD</th></>}</tr></thead><tbody>
            {sel.lines.map((l) => (
              <tr key={l.id} className="border-t border-[#f3ebdd]"><td className="p-1">{l.name}</td><td className="p-1 text-right">{num(l.qty, 2)} {l.unit}</td><td className="p-1 text-right">{num(l.received_qty, 2)}</td>
                {recv && <><td className="p-1"><input aria-label={`Nhận ${l.name}`} className="input !min-h-0 !w-20 !py-1" inputMode="decimal" value={recv[l.id].qty} onChange={(e) => setRecv({ ...recv, [l.id]: { ...recv[l.id], qty: e.target.value.replace(',', '.') } })} /></td>
                  <td className="p-1"><input aria-label={`Giá ${l.name}`} className="input !min-h-0 !w-24 !py-1" inputMode="numeric" value={recv[l.id].price} onChange={(e) => setRecv({ ...recv, [l.id]: { ...recv[l.id], price: e.target.value.replace(/[^\d.]/g, '') } })} /></td>
                  <td className="p-1">{l.track_expiry ? <input aria-label={`Hạn dùng ${l.name}`} type="date" className="input !min-h-0 !py-1" value={recv[l.id].exp} onChange={(e) => setRecv({ ...recv, [l.id]: { ...recv[l.id], exp: e.target.value } })} /> : <span className="text-xs text-mocha">—</span>}</td></>}
              </tr>))}
          </tbody></table></div>
          {seeCost && <p className="text-right font-bold">Tổng ước tính: {vnd(sel.total)}</p>}
          {recv ? <div className="flex gap-2"><button className="btn btn-green btn-lg flex-1" onClick={() => doRecv(sel)} disabled={busy}>{busy ? <Spinner /> : '✔ Xác nhận nhập kho'}</button><button className="btn btn-ghost" onClick={() => setRecv(null)}>Hủy</button></div>
            : <div className="flex flex-wrap gap-2">
              <button className="btn btn-ghost" onClick={copy}>📋 Chép nội dung (Zalo)</button>
              <DownloadButton url={`/api/purchases/${sel.id}?format=xlsx`} filename={`dat-hang-${sel.id}.xlsx`}>Excel</DownloadButton>
              {sel.status === 'draft' && <button className="btn btn-ghost" onClick={() => setStatus(sel, 'sent')} disabled={busy}>Đánh dấu đã gửi</button>}
              {['draft', 'sent', 'partial'].includes(sel.status) && <button className="btn btn-green" onClick={() => startRecv(sel)}>📦 Nhận hàng</button>}
              {['draft', 'sent'].includes(sel.status) && <button className="btn btn-ghost" onClick={() => setStatus(sel, 'cancelled')} disabled={busy}>Hủy đơn</button>}
              {!['received', 'partial'].includes(sel.status) && <button className="btn btn-danger" onClick={() => del(sel)} disabled={busy}>Xóa</button>}
            </div>}
          {text && !recv && <pre className="whitespace-pre-wrap rounded-xl bg-cream p-3 text-sm">{text}</pre>}
        </div>}
      </Modal>

      <Modal open={!!draft} onClose={() => setDraft(null)} title="Đơn đặt hàng mới">
        {draft && <div className="space-y-3">
          <div><label className="label" htmlFor="ds">Nhà cung cấp</label><input id="ds" className="input" value={draft.supplier} onChange={(e) => setDraft({ ...draft, supplier: e.target.value })} /></div>
          {draft.lines.map((l, k) => (
            <div key={k} className="flex gap-2">
              <select aria-label="Nguyên liệu" className="input min-w-0 flex-1" value={l.ingredient_id} onChange={(e) => { const id = Number(e.target.value); const lines = [...draft.lines]; lines[k] = { ...l, ingredient_id: id }; const ing = ings.data?.ingredients.find((i) => i.id === id); setDraft({ ...draft, supplier: draft.supplier || ing?.supplier || '', lines }); }}>
                <option value={0}>— Chọn nguyên liệu —</option>{ings.data?.ingredients.filter((i) => !i.has_prep).map((i) => <option key={i.id} value={i.id}>{i.name} ({i.unit})</option>)}</select>
              <input aria-label="Số lượng" className="input !w-24" inputMode="decimal" placeholder="SL" value={l.qty} onChange={(e) => { const lines = [...draft.lines]; lines[k] = { ...l, qty: e.target.value.replace(',', '.') }; setDraft({ ...draft, lines }); }} />
            </div>))}
          <button className="btn btn-ghost btn-sm" onClick={() => setDraft({ ...draft, lines: [...draft.lines, { ingredient_id: 0, qty: '' }] })}>+ Thêm dòng</button>
          <button className="btn btn-green btn-lg w-full" onClick={createDraft} disabled={busy}>{busy ? <Spinner /> : 'Tạo đơn'}</button>
        </div>}
      </Modal>
    </div>
  );
}

'use client';
import { useMemo, useState } from 'react';
import Link from 'next/link';
import { api, useApi } from '@/lib/client';
import type { Order } from '@/lib/orders';
import { vnd } from '@/lib/format';
import { Empty, ErrorBox, Loading, Modal, Spinner } from '@/components/ui';
import { useAuth } from '@/components/Auth';
import { useToast } from '@/components/Toast';
import { printReceipt } from '@/lib/print-client';

interface Shift { summary: { from_order_id: number; to_order_id: number; orders: number; voids: number; cash: number; transfer: number; discount: number; cups: number; total: number; since: string | null };
  history: { id: number; closed_at: string; closed_by: string; order_count: number; cash_total: number; transfer_total: number; opening_cash: number; expected_cash: number; counted_cash: number | null; diff: number | null; note: string }[] }
const ymd = (d: Date) => new Date(d.getTime() + 7 * 3600_000).toISOString().slice(0, 10);
const hm = (s: string) => new Date(s.replace(' ', 'T') + 'Z').toLocaleTimeString('vi-VN', { timeZone: 'Asia/Ho_Chi_Minh', hour: '2-digit', minute: '2-digit' });
const dtm = (s: string) => new Date(s.replace(' ', 'T') + 'Z').toLocaleString('vi-VN', { timeZone: 'Asia/Ho_Chi_Minh', day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });

export default function Orders() {
  const { can } = useAuth();
  const toast = useToast();
  const [date, setDate] = useState(ymd(new Date()));
  const { data, error, loading, reload } = useApi<{ date: string; orders: Order[]; closed_until: number }>(`/api/orders?date=${date}`);
  const shift = useApi<Shift>('/api/orders/shift');
  const [voiding, setVoiding] = useState<Order | null>(null);
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const [closing, setClosing] = useState(false);
  const [f, setF] = useState({ opening: '', counted: '', note: '' });
  const [open, setOpen] = useState<number | null>(null);
  const [report, setReport] = useState<null | { cash: number; transfer: number; orders: number; expected: number; counted: number | null; diff: number | null }>(null);

  const paid = useMemo(() => (data?.orders ?? []).filter((o) => o.status === 'paid'), [data]);
  const sum = useMemo(() => ({ total: paid.reduce((a, o) => a + o.total, 0), cash: paid.filter((o) => o.payment === 'cash').reduce((a, o) => a + o.total, 0), transfer: paid.filter((o) => o.payment === 'transfer').reduce((a, o) => a + o.total, 0), cups: paid.reduce((a, o) => a + o.items.reduce((x, i) => x + i.quantity, 0), 0) }), [paid]);
  const s = shift.data?.summary;
  const expected = (Number(f.opening) || 0) + (s?.cash ?? 0);

  const doVoid = async () => {
    if (!voiding) return; setBusy(true);
    try { await api(`/api/orders/${voiding.id}`, { method: 'DELETE', body: { reason } }); toast.ok(`Đã hủy đơn #${voiding.code} và hoàn kho`); setVoiding(null); setReason(''); reload(); shift.reload(); }
    catch (e) { toast.err(e instanceof Error ? e.message : 'Không hủy được'); } finally { setBusy(false); }
  };
  const doClose = async () => {
    setBusy(true);
    try {
      const r = await api<{ shift: { cash: number; transfer: number; orders: number; expected_cash: number; counted_cash: number | null; diff: number | null } }>('/api/orders/shift', { method: 'POST', body: { opening_cash: Number(f.opening) || 0, counted_cash: f.counted === '' ? undefined : Number(f.counted), note: f.note } });
      setReport({ cash: r.shift.cash, transfer: r.shift.transfer, orders: r.shift.orders, expected: r.shift.expected_cash, counted: r.shift.counted_cash, diff: r.shift.diff });
      setClosing(false); setF({ opening: '', counted: '', note: '' }); reload(); shift.reload();
    } catch (e) { toast.err(e instanceof Error ? e.message : 'Không chốt được ca'); } finally { setBusy(false); }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div><h1 className="text-2xl font-extrabold">ĐƠN HÀNG</h1><p className="text-sm text-mocha">Xem lại, in lại, hủy đơn và chốt ca.</p></div>
        <div className="flex flex-wrap gap-2"><Link href="/pos" className="btn btn-green btn-lg">+ Bán hàng</Link><button className="btn btn-primary btn-lg" onClick={() => { setF({ opening: '', counted: '', note: '' }); setClosing(true); }}>🔒 Chốt ca</button></div>
      </div>

      <div className="flex flex-wrap items-center gap-2"><input type="date" className="input !w-auto" value={date} max={ymd(new Date())} onChange={(e) => e.target.value && setDate(e.target.value)} aria-label="Ngày" />
        <button className="chip" onClick={() => setDate(ymd(new Date()))}>Hôm nay</button><button className="chip" onClick={() => setDate(ymd(new Date(Date.now() - 864e5)))}>Hôm qua</button><button className="btn btn-ghost btn-sm" onClick={() => { reload(); shift.reload(); }}>↻</button></div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {[['Doanh thu', vnd(sum.total)], ['Tiền mặt', vnd(sum.cash)], ['Chuyển khoản', vnd(sum.transfer)], ['Số đơn · ly', `${paid.length} · ${sum.cups}`]].map(([l, v]) => <div key={l} className="card p-3"><p className="text-xs font-semibold uppercase tracking-wide text-mocha">{l}</p><p className="mt-0.5 text-lg font-extrabold">{v}</p></div>)}
      </div>
      {s && s.orders + s.voids > 0 && <p className="rounded-2xl bg-warn-soft p-3 text-sm font-semibold text-[#8a5a00]">Ca hiện tại (chưa chốt): {s.orders} đơn · tiền mặt {vnd(s.cash)} · chuyển khoản {vnd(s.transfer)}</p>}

      {error && <ErrorBox message={error} onRetry={reload} />}
      {loading && !data && <Loading rows={3} />}
      {data && data.orders.length === 0 && <Empty icon="🧾" title="Chưa có đơn nào" hint="Các đơn bán trong ngày sẽ hiện ở đây." action={<Link href="/pos" className="btn btn-green">Bán đơn đầu tiên</Link>} />}
      <div className="space-y-2.5">
        {data?.orders.map((o) => (
          <article key={o.id} className={`card p-3.5 ${o.status === 'void' ? 'opacity-60' : ''}`}>
            <button className="flex w-full items-start justify-between gap-2 text-left" onClick={() => setOpen(open === o.id ? null : o.id)} aria-expanded={open === o.id}>
              <div className="min-w-0"><p className="font-extrabold">#{o.code} <span className="font-normal text-mocha">· {hm(o.created_at)} · {o.table_name}</span></p>
                <p className="truncate text-sm text-mocha">{o.items.map((i) => `${i.quantity}× ${i.name} (${i.size})`).join(', ')}</p></div>
              <div className="shrink-0 text-right"><b className={o.status === 'void' ? 'line-through' : ''}>{vnd(o.total)}</b><p className="mt-0.5">{o.status === 'void' ? <span className="tag tag-miss">Đã hủy</span> : <span className={`tag ${o.payment === 'cash' ? 'tag-ok' : 'tag-neutral'}`}>{o.payment === 'cash' ? 'Tiền mặt' : 'Chuyển khoản'}</span>}</p></div>
            </button>
            {open === o.id && (
              <div className="mt-3 space-y-2 border-t border-[#f3ebdd] pt-3 text-sm">
                <ul className="space-y-1">{o.items.map((i) => <li key={i.id} className="flex justify-between"><span>{i.quantity} × {i.name} ({i.size}){(i.options ?? []).length > 0 && <span className="block text-xs font-semibold text-leaf-dark">{i.options.map((x) => `+ ${x.name}${x.qty > 1 ? ` ×${x.qty}` : ''}`).join(', ')}</span>}{i.note && <em className="block text-xs text-mocha">• {i.note}</em>}</span><span>{vnd(i.unit_price * i.quantity)}</span></li>)}</ul>
                {o.discount > 0 && <p className="flex justify-between text-leaf-dark"><span>{o.discount_label || 'Giảm giá'}</span><span>-{vnd(o.discount)}</span></p>}
                {o.customer_phone && <p className="text-mocha">Khách: {o.customer_name || o.customer_phone} ({o.customer_phone}){o.points_earned > 0 && ` · +${o.points_earned} điểm`}{o.points_used > 0 && ` · dùng ${o.points_used} điểm`}</p>}
                {o.note && <p className="text-mocha">Ghi chú đơn: {o.note}</p>}
                <p className="text-xs text-mocha">Thu ngân: {o.user_name}{o.status === 'void' && <> · Hủy bởi {o.voided_by}{o.void_reason && `: ${o.void_reason}`}</>}</p>
                <div className="flex flex-wrap gap-2">
                  <button className="btn btn-ghost btn-sm" onClick={() => printReceipt(o.id, 'bill')}>🧾 In hóa đơn</button><button className="btn btn-ghost btn-sm" onClick={() => printReceipt(o.id, 'kitchen')}>🍹 In phiếu pha</button>
                  <a className="btn btn-ghost btn-sm" href={`/receipt/${o.id}?kind=both`} target="_blank" rel="noreferrer">Xem trước</a>
                  {can('void_order') && o.status === 'paid' && (o.id > (data?.closed_until ?? 0) ? <button className="btn btn-danger btn-sm" onClick={() => { setReason(''); setVoiding(o); }}>Hủy đơn</button> : <span className="tag tag-neutral">Ca đã chốt</span>)}
                </div>
              </div>)}
          </article>
        ))}
      </div>

      {shift.data && shift.data.history.length > 0 && (
        <section className="card overflow-hidden"><h2 className="border-b border-[#eadfcd] p-3.5 font-bold">Các ca đã chốt gần đây</h2>
          <ul>{shift.data.history.map((h) => <li key={h.id} className="border-b border-[#f3ebdd] px-3.5 py-2.5 text-sm last:border-0"><div className="flex justify-between"><b>{dtm(h.closed_at)} · {h.closed_by}</b><span>{h.order_count} đơn</span></div>
            <p className="text-mocha">Tiền mặt {vnd(h.cash_total)} · CK {vnd(h.transfer_total)}{h.diff !== null && <> · <b className={h.diff === 0 ? 'text-leaf-dark' : 'text-danger'}>{h.diff === 0 ? 'khớp két' : `lệch ${vnd(h.diff)}`}</b></>}{h.note && ` · ${h.note}`}</p></li>)}</ul></section>
      )}

      <Modal open={!!voiding} onClose={() => setVoiding(null)} title={`Hủy đơn #${voiding?.code ?? ''}?`}>
        <p className="text-sm">Hủy đơn sẽ <b>hoàn lại nguyên liệu vào kho</b> và xóa doanh thu của đơn khỏi báo cáo.</p>
        <label className="label mt-3" htmlFor="vr">Lý do</label><input id="vr" className="input" placeholder="VD: khách đổi ý, nhập nhầm" value={reason} onChange={(e) => setReason(e.target.value)} />
        <div className="mt-4 flex gap-2"><button className="btn btn-danger flex-1" onClick={doVoid} disabled={busy}>{busy ? <Spinner /> : 'Hủy đơn'}</button><button className="btn btn-ghost" onClick={() => setVoiding(null)}>Không</button></div>
      </Modal>

      <Modal open={closing} onClose={() => setClosing(false)} title="Chốt ca">
        {s && s.orders + s.voids === 0 ? <p className="p-4 text-center text-mocha">Chưa có đơn mới kể từ lần chốt ca trước.</p> : s && (
          <div className="space-y-3">
            <div className="space-y-1 rounded-2xl bg-cream p-3 text-sm">
              <p className="flex justify-between"><span>Số đơn (đã hủy {s.voids})</span><b>{s.orders}</b></p><p className="flex justify-between"><span>Số ly</span><b>{s.cups}</b></p>
              <p className="flex justify-between"><span>Giảm giá</span><b>{vnd(s.discount)}</b></p><p className="flex justify-between"><span>Chuyển khoản</span><b>{vnd(s.transfer)}</b></p>
              <p className="flex justify-between"><span>Tiền mặt bán được</span><b>{vnd(s.cash)}</b></p><p className="flex justify-between border-t border-[#e3d5c1] pt-1 text-base"><span>Tổng doanh thu</span><b>{vnd(s.total)}</b></p></div>
            <div><label className="label" htmlFor="oc">Tiền đầu ca trong két (đ)</label><input id="oc" type="number" min={0} className="input" value={f.opening} onChange={(e) => setF({ ...f, opening: e.target.value })} placeholder="0" /></div>
            <p className="text-sm">Tiền mặt lẽ ra có trong két: <b>{vnd(expected)}</b></p>
            <div><label className="label" htmlFor="cc">Tiền mặt đếm được (đ)</label><input id="cc" type="number" min={0} className="input" value={f.counted} onChange={(e) => setF({ ...f, counted: e.target.value })} />
              {f.counted !== '' && <p className={`mt-1 text-sm font-bold ${Number(f.counted) === expected ? 'text-leaf-dark' : 'text-danger'}`}>{Number(f.counted) === expected ? '✓ Khớp' : `Lệch ${vnd(Number(f.counted) - expected)}`}</p>}</div>
            <div><label className="label" htmlFor="cn">Ghi chú</label><input id="cn" className="input" value={f.note} onChange={(e) => setF({ ...f, note: e.target.value })} /></div>
            <p className="text-xs text-mocha">Sau khi chốt, các đơn trong ca không thể hủy nữa.</p>
            <button className="btn btn-green btn-lg w-full" onClick={doClose} disabled={busy}>{busy ? <Spinner /> : '🔒'} Chốt ca</button></div>)}
      </Modal>
      <Modal open={!!report} onClose={() => setReport(null)} title="Đã chốt ca">
        {report && <div className="space-y-2 text-center"><div className="text-5xl">🔒</div><p className="text-lg">{report.orders} đơn · tiền mặt <b>{vnd(report.cash)}</b> · chuyển khoản <b>{vnd(report.transfer)}</b></p>
          <p>Két lẽ ra có <b>{vnd(report.expected)}</b>{report.counted !== null && <> · đếm được <b>{vnd(report.counted)}</b></>}</p>
          {report.diff !== null && <p className={`text-xl font-extrabold ${report.diff === 0 ? 'text-leaf-dark' : 'text-danger'}`}>{report.diff === 0 ? '✓ Khớp két' : `Lệch ${vnd(report.diff)}`}</p>}
          <button className="btn btn-primary w-full" onClick={() => window.print()}>🖨 In báo cáo</button></div>}
      </Modal>
    </div>
  );
}

'use client';
import { useState } from 'react';
import Link from 'next/link';
import { api } from '@/lib/client';
import type { Suggestion } from '@/lib/assistant';
import { num, pct, vnd } from '@/lib/format';
import { ErrorBox, Spinner } from '@/components/ui';
import { useAuth } from '@/components/Auth';

interface Reply { mode: 'local'; reply: string; suggestions: Suggestion[]; detected: string[]; ai: string | null; ai_error: string | null; ai_enabled: boolean }
const EXAMPLES = [
  'Tôi có cà phê, sữa đặc, sữa tươi, caramel và đá. Hãy gợi ý 5 món dễ bán.',
  'Tôi có 500ml sữa tươi và 100g matcha, hãy tạo công thức sử dụng hết nguyên liệu.',
  'Tôi có dâu tây, soda, chanh, syrup dâu và đá. Gợi ý 3 món.',
];

export default function Assistant() {
  const { can } = useAuth();
  const seeCost = can('view_cost');
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [res, setRes] = useState<Reply | null>(null);
  const ask = async (t = text) => {
    if (t.trim().length < 2) { setErr('Hãy nhập câu hỏi hoặc liệt kê nguyên liệu.'); return; }
    setBusy(true); setErr(null);
    try { setRes(await api<Reply>('/api/assistant', { method: 'POST', body: { message: t } })); }
    catch (e) { setErr(e instanceof Error ? e.message : 'Lỗi'); } finally { setBusy(false); }
  };
  return (
    <div className="space-y-5">
      <div><h1 className="text-2xl font-extrabold">✨ TRỢ LÝ PHA CHẾ AI</h1><p className="text-sm text-mocha">Mô tả nguyên liệu (có thể kèm số lượng), trợ lý sẽ gợi ý món từ kho công thức và giá vốn thật của quán.</p></div>
      <section className="card p-4">
        <textarea className="input min-h-28" value={text} onChange={(e) => setText(e.target.value)} placeholder="VD: Tôi có cà phê, sữa đặc, sữa tươi, caramel và đá. Hãy gợi ý 5 món dễ bán." aria-label="Câu hỏi" />
        <div className="mt-3 flex flex-wrap gap-2">{EXAMPLES.map((e) => <button key={e} className="chip !text-left" onClick={() => { setText(e); ask(e); }}>{e.length > 48 ? e.slice(0, 48) + '…' : e}</button>)}</div>
        <button className="btn btn-green btn-lg mt-4 w-full sm:w-auto" onClick={() => ask()} disabled={busy}>{busy ? <Spinner /> : '✨'} Gợi ý món</button>
      </section>
      {err && <ErrorBox message={err} />}
      {res && (
        <section className="space-y-4" aria-live="polite">
          <p className="card p-4 font-semibold">{res.reply}</p>
          {res.ai && <div className="card whitespace-pre-wrap p-4 text-sm leading-relaxed"><p className="mb-2 text-xs font-bold uppercase text-leaf-dark">Trả lời từ Claude</p>{res.ai}</div>}
          {res.ai_error && <p className="text-sm text-danger">Không gọi được AI ({res.ai_error}); đang hiển thị gợi ý từ kho công thức.</p>}
          {seeCost && !res.ai_enabled && <p className="text-xs text-mocha">Đang dùng bộ gợi ý nội bộ. Đặt biến môi trường <code>ANTHROPIC_API_KEY</code> để trợ lý Claude trả lời tự do (tạo món mới).</p>}
          <div className="grid gap-3 lg:grid-cols-2">
            {res.suggestions.map((s, i) => (
              <article key={s.id} className="card pop p-4">
                <div className="flex items-start justify-between gap-2"><h3 className="text-lg font-bold">{i + 1}. {s.name}</h3><span className={`tag ${s.missing.length ? 'tag-warn' : 'tag-ok'}`}>{s.missing.length ? `Thiếu ${s.missing.length}` : 'Pha ngay'} · {pct(s.percent)}</span></div>
                {s.missing.length > 0 && <p className="mt-1 text-sm text-danger">Thiếu: {s.missing.join(', ')}</p>}
                {s.note && <p className="mt-1 text-sm font-semibold text-leaf-dark">{s.note}</p>}
                <ul className="mt-2 text-sm">{s.lines.map((l) => <li key={l.name} className="flex justify-between border-b border-[#f3ebdd] py-0.5"><span>{l.name}</span><b>{num(l.quantity)}{l.unit}</b></li>)}</ul>
                <ol className="mt-2 list-decimal space-y-0.5 pl-5 text-sm text-mocha">{s.steps.map((x, j) => <li key={j}>{x}</li>)}</ol>
                <div className={`mt-3 grid gap-1 text-center text-xs ${seeCost ? 'grid-cols-4' : 'grid-cols-3'}`}>{seeCost && <div className="rounded-lg bg-cream p-1.5"><b className="block">{vnd(s.cost)}</b>Giá vốn</div>}<div className="rounded-lg bg-cream p-1.5"><b className="block">{vnd(s.price)}</b>Giá bán</div>{seeCost && <div className="rounded-lg bg-leaf-soft p-1.5 text-leaf-dark"><b className="block">{vnd(s.profit)}</b>Lợi nhuận</div>}<div className="rounded-lg bg-cream p-1.5"><b className="block">{s.difficulty}</b>{s.time}′</div></div>
                <Link href={`/recipes/${s.id}`} className="btn btn-primary mt-3 w-full">Xem công thức</Link>
              </article>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

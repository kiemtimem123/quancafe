# Góc Cafe — Công thức & pha chế

Next.js 15 (App Router) · TypeScript · Tailwind v4 · SQLite (better-sqlite3) · zod

## Chạy local
```bash
npm install --ignore-scripts
npm run dev        # http://localhost:3000  (lần đầu tự tạo data/cafe.db + nạp dữ liệu mẫu)
npm run seed       # xóa DB và nạp lại dữ liệu mẫu
npm run build && npm start   # chạy bản production
```
Tùy chọn: đặt `ANTHROPIC_API_KEY` (và `ANTHROPIC_MODEL`) để Trợ lý AI trả lời tự do bằng Claude; không đặt thì dùng bộ gợi ý nội bộ.

## Cấu trúc
- `lib/db.ts` schema SQLite · `lib/seed.ts` 40 nguyên liệu (giá từ file Excel) + 40 công thức
- `lib/recipes.ts` tải công thức + tính giá vốn/hao phí · `lib/match.ts` thuật toán tìm món · `lib/assistant.ts` trợ lý
- `app/api/*` REST API (zod validation) · `app/*` các trang · `components/*`

## Đăng nhập & phân quyền
- Lần chạy đầu, mở app sẽ hiện màn hình **tạo tài khoản quản trị viên** (không có mật khẩu mặc định).
- 3 vai trò: **Quản trị viên** (toàn quyền + quản lý người dùng), **Quản lý** (sửa công thức/nguyên liệu/giá, xem giá vốn & dashboard), **Nhân viên pha chế** (tìm món, xem công thức, pha, in — server không trả giá vốn/lợi nhuận cho vai trò này).
- Mật khẩu băm scrypt; phiên lưu trong DB (cookie httpOnly, 7 ngày); khóa tạm sau 5 lần sai; chặn request ghi khác origin.
- Chạy sau HTTPS: đặt `COOKIE_SECURE=1` (hoặc proxy gửi `x-forwarded-proto: https`).
- Quên mật khẩu admin duy nhất: xóa `data/cafe.db` hoặc xóa dòng trong bảng `users` để thiết lập lại.

## Ảnh món
- Quản lý/Quản trị viên tải ảnh ở trang thêm/sửa món (chọn từ máy hoặc chụp bằng điện thoại). Ảnh được kiểm tra bằng nội dung thật (JPG/PNG/WebP/GIF, ≤ 8MB; SVG bị từ chối), xoay theo EXIF, thu nhỏ ≤ 1200px, bỏ metadata và lưu WebP trong `data/uploads/`.
- Ảnh chỉ xem được khi đã đăng nhập. Thay/xóa ảnh hoặc xóa món sẽ xóa file cũ; ảnh tải lên rồi bỏ dở được dọn sau 1 giờ. Nhớ sao lưu cả thư mục `data/` (gồm `cafe.db` và `uploads/`).

## Excel: báo cáo giá vốn & nhập nguyên liệu hàng loạt
- **Báo cáo giá vốn** (Dashboard hoặc Kho công thức → "Báo cáo giá vốn", cần quyền xem giá vốn): file .xlsx gồm Tổng quan, Giá vốn món (mỗi món × size; Tổng giá vốn/Lợi nhuận/Tỷ suất là công thức Excel), Chi tiết nguyên liệu, Nguyên liệu.
- **Nhập hàng loạt** (Nguyên liệu → "Nhập từ Excel", cần quyền sửa nguyên liệu): tải file mẫu, điền, tải lên → xem trước từng dòng (thêm mới / cập nhật / bỏ qua / lỗi) → xác nhận. Dòng lỗi bị bỏ qua, phần còn lại nhập trong một giao dịch.
- Đọc được cả bảng tính có cột `Tên | Giá nhập | Số lượng | Đơn vị` (như file "Bảng tính Giá Quán Cafe"). Ô giá là công thức chưa có kết quả thì cần mở Excel, lưu lại rồi nhập.
- "Xuất Excel" ở trang Nguyên liệu cho cùng định dạng file mẫu → sửa giá/tồn kho hàng loạt rồi nhập lại (chọn "Cập nhật").
- Cảnh báo tồn thấp chỉ áp dụng cho nguyên liệu có đặt "Tồn tối thiểu" > 0.

## Ghi chú
- Số liệu "món bán chạy" ban đầu là dữ liệu mẫu; bấm "Pha món này" sẽ trừ tồn kho và cộng số ly.

## Tính năng nâng cao (bước 1–8)
1. **Bán thành phẩm** (cốt trà, syrup tự nấu, kem mặn…): Nguyên liệu → "Tự làm?" khai báo thành phần + sản lượng 1 mẻ. Giá vốn tự tính (đệ quy, chặn vòng lặp) và tự cập nhật vào các món; "Làm mẻ" trừ kho thành phần, cộng kho thành phẩm.
2. **Nguyên liệu thay thế & tùy chọn**: đặt cùng "Nhóm thay thế" (VD: Caramel) → tìm món coi như có, hiện "(thay bằng …)"; khi pha tự trừ kho nguyên liệu thay thế. Dòng công thức đánh dấu *tùy chọn* không bị tính là thiếu. Bán thành phẩm làm được từ nguyên liệu đang có cũng được tính là có.
3. **Tồn kho → số ly còn pha được**: món hiện "Hết hàng"/"Còn ~N ly" (trang **Tình trạng món**, kết quả tìm, kho công thức). Món hết/sắp hết kèm **gợi ý món khác còn hàng** (cùng danh mục, chung nguyên liệu, lãi cao). Chỉ nguyên liệu bật "Theo dõi tồn kho" mới ảnh hưởng — nguyên liệu nhập từ Excel không có cột tồn sẽ mặc định *không theo dõi* để tránh báo hết hàng sai.
4. **Sổ kho**: Nguyên liệu → "Kho": nhập kho (kèm giá mới), kiểm kê, hao hụt, lịch sử giao dịch & lịch sử giá. **Kiểm kê hàng loạt**, **cảnh báo lợi nhuận** khi giá nhập đổi làm món xuống dưới 50% (đặt `min_margin` trong bảng settings), **Danh sách cần mua** gom theo nhà cung cấp (chép/in/Excel).
5. **Bán hàng & lợi nhuận** (`/sales`): nhập số liệu từ Excel (Ngày · Món · Size · Số lượng) hoặc ghi tay; báo cáo doanh thu/giá vốn/lợi nhuận theo ngày, món, danh mục + phân tích menu (ngôi sao / bán chạy lãi thấp / lãi cao ít bán / nên bỏ).
6. **Nhập công thức hàng loạt**: Kho công thức → "Nhập từ Excel" — file mẫu (mỗi nguyên liệu 1 dòng, nhiều size) hoặc thẳng bảng tính cost của quán (Tên | NL 1…NL 7, mỗi món 3 dòng). Có xem trước, khớp tên gần đúng và báo lỗi từng món.
7. **PWA & Màn hình bếp**: cài lên màn hình chính (manifest), công thức/nguyên liệu xem được khi mất mạng (service worker, chỉ bản production; đăng xuất sẽ xóa dữ liệu lưu). `/kitchen`: chữ to, chọn size, nhân số ly, tick từng bước, giữ màn hình sáng.
8. **Nhật ký thao tác** (`/audit`, chỉ quản trị viên): ai sửa gì, lúc nào — công thức, nguyên liệu, kho, nhập Excel, bán hàng, người dùng, đăng nhập.

## Order, hóa đơn & POS
Trang **Bán hàng** (`/pos`): chọn món/size, topping (tự trừ kho + tính giá vốn), ghi chú, bàn/mang đi, khuyến mãi/voucher (giờ vàng, theo món/danh mục), khách thân thiết (SĐT, tích/đổi điểm), tiền mặt hoặc **chuyển khoản VietQR** (đúng số tiền + nội dung “Don <mã đơn>”). In hóa đơn 58/80mm và phiếu pha (không giá) qua hộp thoại in của trình duyệt. **Đơn hàng** (`/orders`): xem/in lại/hủy (hoàn kho, hoàn điểm), chốt ca.

## Chế độ offline
Bán hàng, tra công thức, kho đều dùng được khi mất mạng; thao tác lưu trên máy và tự đồng bộ khi có mạng (nút trạng thái ở thanh trên). Chỉ hoạt động khi chạy bản build (`npm run build && npm start`) qua **HTTPS** — xem `DEPLOY.md`.

## Hạn sử dụng
Nhập kho theo lô có hạn; cảnh báo trước 3 ngày (đổi được ở cài đặt); lô quá hạn tự loại khỏi kho (ghi nhận là hao hụt). Không theo dõi hạn: đường trắng/phèn, bao bì, ống hút, đồ nhựa.

## Quản lý & báo cáo mở rộng
- **Topping**, **Khuyến mãi & voucher**, **Khách thân thiết** (menu tài khoản).
- **Đặt hàng nhà cung cấp** từ danh sách cần mua (xuất Excel/sao chép gửi Zalo; nhận hàng → tạo lô + cập nhật giá nhập).
- **Hao hụt & thất thoát** theo tháng; **Dự báo nhập hàng** từ 2–8 tuần bán gần nhất; **Lợi nhuận & hòa vốn** (chi phí cố định); **Giờ cao điểm & nhân viên**.
- **Thông báo & báo cáo tự động**: báo cáo cuối ngày qua Telegram/email, gửi bản sao lưu (token/mật khẩu không bao giờ trả về trình duyệt).
- **Sao lưu & khôi phục** (`/backup`), nút **Cài ứng dụng**.

## Bảo mật đăng nhập
Khóa 10 phút sau 5 lần sai, quản trị viên cấp mã đặt lại mật khẩu (8 số, hiệu lực 30 phút), 2FA (TOTP) tuỳ chọn kèm mã khôi phục, cookie HttpOnly, chống CSRF cùng origin.

## Khách quét QR tự đặt món
1. Đăng nhập quản lý → menu **Danh mục → 🔳 In mã QR cho bàn**. Bật “Cho phép khách đặt món qua QR”.
2. Nhập **địa chỉ web thật của quán** (tên miền HTTPS hoặc IP Wi-Fi quán, không dùng localhost) rồi in mã QR dán lên từng bàn.
3. Khách quét → chọn món/size/topping → gửi. Nhân viên thấy chuông 🔔 + âm báo trên thanh trên, vào **📲 Đơn khách đặt qua QR** bấm *Nhận đơn* (trừ kho, in phiếu pha, cộng điểm thành viên) hoặc *Từ chối*.
4. Trang khách (`/order`) công khai, giới hạn 6 đơn/10 phút/IP; giá và tồn được máy chủ tính lại, khách không sửa được giá.

### Báo đơn mới qua Zalo
Menu **Danh mục → Thông báo** → mục “Zalo”: dán token Zalo Bot (tạo bằng *Zalo Bot Creator*), nhắn bot một tin, bấm “Tìm Chat ID”, Lưu, “Gửi tin thử”. Mỗi khi khách đặt món qua QR, Zalo của chủ quán nhận tin tóm tắt đơn (đồng thời Telegram/email nếu đã cấu hình).
